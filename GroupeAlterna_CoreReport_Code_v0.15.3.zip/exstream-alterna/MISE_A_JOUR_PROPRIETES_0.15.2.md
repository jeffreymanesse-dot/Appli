# Groupe Alterna — CoreReport 0.15.2

Cette version corrige les contenus de signature, les règles portées par les objets image, les propriétés de lignes et leur présentation dans le rapport. Les décodeurs reconnaissent des structures du package : aucun nom WEBLURE, identifiant de composant client, empreinte ou emplacement propre à un fichier ne déclenche un correctif.

## Changements

- Les contenus dont le premier style utilise une couleur de palette sont récupérés avec leurs propriétés et variables. Les deux blocs de signature WEBLURE comportent désormais leurs six cellules, dont les cellules vides conservées.
- Les règles des objets image sont rattachées à leur cible et leurs repères encadrent l'objet dans la vue détaillée. Cela rétablit notamment R18 et R20 ; les autres règles des images du courrier sont également contrôlées.
- Les types Header (H), Repeating footer — Except last Page (F-) et Automated row (R) sont reconnus. Les propriétés First row of table section, rupture sur changement de variable et Group with previous row sont décrites lorsqu'elles sont explicitement décodées.
- Le profil de tableau étendu retrouve son ancrage dans le texte. Dans la simulation WEBLURE, le tableau se place après la date de naissance et avant le taux technique.
- Le rapport signale les DOCUMENT, PAGE et SECTION et affiche leurs règles lorsqu'il en trouve. Les définitions PAGE initiales et de débordement sont présentées à l'entrée du DOCUMENT ; la pagination native n'est pas simulée.
- Les tableaux de lignes sont fusionnés. Les statuts des Data Section et les mentions d'absence de driver ou d'ordre local non établi sont retirés de la présentation demandée.

Les sources des règles, fonctions et formules, leurs commentaires et leurs algorithmes sont conservés. L'annexe facultative Template et Page reste disponible. La section Pages, composants et débordements reste exclue du PDF Visuel.

## Installation

1. Conserver le fichier `.env` et les volumes Docker de l'installation existante.
2. Remplacer les fichiers du programme par le dossier `exstream-alterna` de cette archive.
3. Depuis ce dossier, exécuter `docker compose up -d --build`, ou utiliser le lanceur Windows habituel.
4. Lancer une **nouvelle analyse** du PUB. Les anciens PDF ne sont pas recalculés automatiquement.

Aucune dépendance ni migration ajoutée. Aucun déploiement sur votre installation n'est effectué par cette livraison.

## Validation

**101 tests ciblés réussis**, complétés par l'analyse et le contrôle de couverture de six autres packages, dont le dernier Bulletin de versement. Rapport WEBLURE : **223 pages**, avec l'annexe Template et Page ; Visuel : **15 pages**. Toutes les pages ont été contrôlées visuellement, avec agrandissement des zones modifiées.

Les images alimentées par une variable restent représentées par leur emplacement et leur variable lorsque leurs octets ne sont pas disponibles. La restitution statique ne certifie pas la pagination native Exstream ni les variantes binaires encore inconnues.

Voir `docs/VALIDATION_PROPRIETES_0.15.2.md`, `validation/properties_0.15.2/` et `ETAT_VALIDATION_MOTEUR.md`.
