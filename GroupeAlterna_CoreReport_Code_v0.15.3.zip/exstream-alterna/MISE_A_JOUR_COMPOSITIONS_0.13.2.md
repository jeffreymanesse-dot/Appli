# Mise à jour Core Report 0.13.2

Remplacer les fichiers du programme par le contenu du ZIP en conservant le `.env` et les volumes de l’installation existante. Reconstruire les services selon le README, puis relancer les analyses : les anciens PDF ne sont pas modifiés automatiquement.

Cette version ajoute les compositions graphiques compilées (tableaux et images alignés), les ancrages avec commutation de style, la typographie indépendante du ciblage et la distinction des fragments conditionnels. L’image centrale NOA est localisée mais sa ressource reste non résolue ; son emplacement est signalé explicitement. Voir `docs/VALIDATION_COMPOSITIONS_0.13.2.md` pour les preuves et limites.

Aucune migration de données ni modification des écrans métier. Sources complètes et tests inclus ; fichiers PUB client exclus.
