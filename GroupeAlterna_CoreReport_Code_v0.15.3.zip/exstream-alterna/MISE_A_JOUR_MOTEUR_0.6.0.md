# Mise à jour du moteur 0.6.0

Cette version améliore l'analyse des PUB et leurs rapports. Elle conserve l'interface et son contrat API.

## Installation existante

1. Attendre la fin des analyses en cours et conserver une copie de l'installation.
2. Copier le dossier complet `backend/retro` de cette archive dans le dossier `backend/retro` de votre installation. Le nouveau module `valuation.py` est nécessaire.
3. Conserver votre `.env` actuel : ses identifiants doivent correspondre à ceux de la base déjà initialisée. Ne pas remplacer les secrets ni supprimer les volumes Docker.
4. Depuis votre dossier d'application, reconstruire les services du moteur :

```powershell
docker compose up -d --build api worker purge
```

Le frontend n'a pas besoin d'être remplacé. Relancer une analyse du PUB pour obtenir un nouveau rapport : les PDF des anciens traitements ne sont pas réécrits.

Pour une installation neuve, utiliser `DEMARRER_WINDOWS.cmd`, qui crée le `.env` local à partir de `.env.example`. Le ZIP ne contient aucun secret utilisateur. Les instructions générales sont dans `LIRE_EN_PREMIER.md`.

Docker Desktop/Windows/PostgreSQL n'ont pas été exécutés ici. La validation effectuée porte sur le moteur Python, l'API testée et les PDF générés.

## Reproduction des cinq analyses

Installer `backend/requirements-dev.txt`, disposer des polices DejaVu, puis, depuis l'application :

```powershell
$env:PYTHONPATH="backend"
python scripts/validate_corpus.py --source-dir "C:\Documents\PUB" --output-dir "validation\nouvelle_iteration" --include-obseques
```

Le dossier doit contenir Adhésion, Versement, FIP Essenciel, Devis Auto et Projet Obsèques Essenciel. Les noms exacts et les noms préfixés sont acceptés ; une source ambiguë est refusée. Le dossier de sortie doit être vide. Chaque analyse fournit PDF et JSON ; aucun PDF de référence ni Tools Report n'entre dans le moteur.

Pour les tests de corpus, placer les cinq fichiers dans `../project_sources` avec les préfixes historiques `03-`, `04-`, `05-`, `06-` et `07-`. Les sources clients ne sont pas incluses dans le code ; les tests concernés sont sautés si elles manquent.

```powershell
python -m pytest backend/tests -q
python scripts/validate_revision.py
```

## Résultat et limites

Consulter `docs/VALIDATION_MOTEUR_0.6.0.md` et `ETAT_VALIDATION_MOTEUR.md`. Les noms de pages, règles et fonctions sont privilégiés ; les affectations dans les règles sont prises en compte ; un profil de ciblage de colonnes a été ajouté. Les preuves et branches locales sont conservées. Les résultats restent une analyse statique partielle : ils ne prouvent ni l'ordre événementiel complet, ni le rendu Exstream exact, ni la fiabilité de tout PUB possible.
