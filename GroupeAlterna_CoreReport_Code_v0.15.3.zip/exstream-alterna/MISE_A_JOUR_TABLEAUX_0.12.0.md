# Core Report — mise à jour tableaux 0.12.0

Cette livraison intègre le décodage des tableaux au moteur, au modèle d'audit, aux rapports FR/EN et au PDF visuel. Il ne s'agit plus de la sonde de calibration à offsets liés aux fichiers.

## Installation existante

1. Arrêter les services Core Report.
2. Sauvegarder l'installation et conserver son `.env` ainsi que ses volumes de données.
3. Décompresser `GroupeAlterna_CoreReport_Code_v0.12.0.zip` dans un dossier distinct, puis remplacer les fichiers du programme à partir de `exstream-alterna`, sans écraser le `.env` de l'installation.
4. Reconstruire et relancer les services depuis le dossier de l'installation :

```bash
docker compose up -d --build
```

5. Lancer une nouvelle analyse d'un PUB. Les résultats d'anciennes tâches ne sont pas réécrits automatiquement.

Pour une installation neuve, suivre `LIRE_EN_PREMIER.md` et `DEMARRER_WINDOWS.cmd`. L'archive complète contient le `.env` initial à marqueurs de la version de base, identique à `.env.example` ; ne pas le fusionner sur une installation configurée. Aucune migration de base n'est requise. Les dépendances de production ne changent pas ; PyMuPDF est ajouté uniquement à celles de validation.

## Ce qui est disponible

- Largeurs fixes reconnues : valeur brute, unité 1/300 inch, cm et points, avec preuves. Les largeurs automatiques restent explicitement non interprétées.
- Fonds RGB : résolution dans la palette propre au fichier.
- Formes : rectangle, Rounded, Rounded left, Rounded right. Rayon de rendu indicatif de 3 points ; rayon source non décodé.
- Bordures : trait supérieur local calibré avec BorderPink et profil inférieur historique NOA, couleur et épaisseur. Les autres côtés et l'héritage restent à valider.
- Rapport : nouveau détail des dimensions et styles dans « Tables et répétitions », en français ou en anglais.
- Visuel : utilisation des styles reconnus et des largeurs sources, réduites si nécessaire pour tenir dans la page. Les facteurs de restitution sont conservés dans le modèle exporté.

## Vérification livrée

171 tests passent sans échec ni saut. Les 12 chemins PUB, soit 11 contenus distincts, ont été validés. Le ZIP de validation contient les rapports, visuels, preuves de styles, empreintes, résultats comparés à 0.11.0 et captures de revue. Lire `docs/VALIDATION_TABLEAUX_0.12.0.md` pour les limites et le détail du corpus.

Le fichier Color fourni ne présente pas les trois changements de couleurs annoncés dans les champs contrôlés. Le moteur restitue ses valeurs décodées ; les cas Black et BorderPink sont les références de validation correspondantes.
