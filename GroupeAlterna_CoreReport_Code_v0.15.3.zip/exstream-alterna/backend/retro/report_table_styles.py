"""Factual table dimensions and grouped cell properties for the FR/EN report."""
import json
from .i18n import tr


def append_table_styles(grid, story, add, table):
    style = grid.get('presentation')
    if not style:
        return
    add(tr('Dimensions et styles décodés'), 'label')
    rows = [[tr('Colonne'), tr('Largeur source')]]
    for col in style['columns']:
        m = col.get('width')
        rows.append([str(col['index']+1), f"{m['cm']:.4f} cm / {m['pt']:.2f} pt" if m else tr('Non interprété')])
    story.append(table(rows, [100,391], padding=4))
    groups = {}
    names = {'rectangle':tr('Rectangle'), 'rounded':tr('Arrondi'),
             'rounded_left':tr('Arrondi à gauche'), 'rounded_right':tr('Arrondi à droite')}
    def color(c):
        rgb=c.get('rgb')
        return 'RGB('+','.join(str(int(rgb[i:i+2],16)) for i in (1,3,5))+') '+rgb if rgb else tr('Non interprété')
    scope_rows=[[tr('Portée de la bordure'),tr('Côté / étendue'),tr('Propriété source')]]
    sides={'top':tr('Supérieure'),'bottom':tr('Inférieure'),'left':tr('Gauche'),'right':tr('Droite')}
    def describe(pen):
        if pen.get('renderable'):
            m=pen['thickness']
            return color(pen['color'])+f" / {m['cm']:.4f} cm ({m['pt']:.2f} pt)"
        if pen.get('status')=='decoded' and not pen.get('active') or pen.get('effective_status') in ('none','explicit_none','inactive'):
            return tr('Aucun trait propre')
        return tr('Non interprété')
    frame=describe(style.get('frame',{}))
    if frame!=tr('Aucun trait propre'):scope_rows.append([tr('Tableau'),tr('Contour extérieur complet'),frame])
    for key,label,extent in (('rows','Ligne','Toute la largeur du tableau'),('columns','Colonne','Toute la hauteur du tableau')):
        for axis in style.get(key,[]):
            for pen in axis.get('borders',[]):
                value=describe(pen)
                if value!=tr('Aucun trait propre'):
                    scope_rows.append([tr(label)+' '+str(axis['index']+1),sides[pen['side']]+' / '+tr(extent),value])
    if len(scope_rows)>1:story.append(table(scope_rows,[100,180,211],padding=4,split_in_row=True))
    for cell in style['cells']:
        bg, shape = cell['background'], cell['shape']
        fill = tr('Sans fond explicite') if bg.get('status')=='none' else color(bg)
        form = names.get(shape.get('kind'), tr('Non interprété'))
        if shape.get('kind','').startswith('rounded'):
            form += ' / '+tr('rayon non décodé')
        if bg.get('status')=='none':form=''
        pens=[]
        for pen in cell['borders']:
            if not pen['renderable']:continue
            pens.append(tr({'top':'Supérieure','bottom':'Inférieure','left':'Gauche','right':'Droite'}[pen['side']])+' : '+color(pen['color'])+
                        f" / {pen['thickness']['cm']:.4f} cm ({pen['thickness']['pt']:.2f} pt)"+' / '+tr({'cell':'Cellule','row':'Ligne','column':'Colonne'}.get(pen.get('scope'),'Cellule')))
        border = '\n'.join(pens) if pens else tr('Aucune bordure locale validée')
        if not pens and bg.get('status')=='none':continue
        key=json.dumps([fill,form,border],ensure_ascii=False)
        groups.setdefault(key,[]).append(cell)
    rows=[[tr('Cellules (ligne, colonne)'),tr('Fond / forme'),tr('Bordures locales décodées')]]
    for key,cells in groups.items():
        fill,form,border=json.loads(key)
        coords=', '.join(f"({c['row']+1},{c['column']+1})" for c in cells)
        # The full proof ranges and all raw selectors remain in the model.
        rows.append([coords,fill+('\n'+form if form else ''),border])
    if len(rows)>1:story.append(table(rows,[115,185,191],padding=4,split_in_row=True))
