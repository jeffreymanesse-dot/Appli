"""Lecture lexicale bornée ; les expressions non prises en charge restent opaques."""
import re
TOKEN = re.compile(r'''//[^\r\n]*|/\*[\s\S]*?\*/|"(?:""|\\.|[^"\\])*"|'(?:''|\\.|[^'\\])*'|\b(?:ENDIF|IF|THEN|ELSEIF|ELSE|INCLUDE|EXCLUDE)\b''',re.I)

def remove_comments(text):
    """Remove Exstream comments while preserving quoted strings and line breaks."""
    out=[];i=0;quote=None
    while i<len(text):
        if quote:
            ch=text[i];out.append(ch)
            if ch==quote:
                if i+1<len(text) and text[i+1]==quote:
                    out.append(text[i+1]);i+=1
                else:quote=None
            elif ch=='\\' and i+1<len(text):out.append(text[i+1]);i+=1
            i+=1;continue
        if text[i] in ('"',"'"):
            quote=text[i];out.append(text[i]);i+=1;continue
        if text.startswith('//',i):
            end=text.find('\n',i)
            if end<0:break
            out.append('\n');i=end+1;continue
        if text.startswith('/*',i):
            end=text.find('*/',i+2)
            if end<0:return text
            out.append('\n'*(text[i:end+2].count('\n')));i=end+2;continue
        out.append(text[i]);i+=1
    return ''.join(out)

def complete_source(text):
    """Accept a balanced active expression with trailing or inline comments."""
    active=remove_comments(text).strip()
    if not active or not re.search(r'\bENDIF\s*\Z',active,re.I):return False
    roots,incomplete=if_blocks(active)
    return bool(roots) and not incomplete and all('end' in node for node in roots)

def if_blocks(text):
    stack=[]; roots=[]
    for m in TOKEN.finditer(text):
        word=m.group().upper()
        if word=='IF':
            node={'kind':'if','start':m.start(),'children':[]}
            if stack:stack[-1]['children'].append(node)
            stack.append(node)
        elif word=='ENDIF' and stack:
            node=stack.pop();node['end']=m.end();node['raw']=text[node['start']:node['end']]
            if not stack:roots.append(node)
    return roots, bool(stack)

def summarize(text):
    ast,incomplete=if_blocks(text)
    # Only a single un-nested IF with an explicit THEN and action is interpreted.
    normalized=None;true=None;false=None
    if len(ast)==1 and not ast[0]['children'] and not incomplete:
        raw=ast[0]['raw']; toks=[m for m in TOKEN.finditer(raw) if m.group().upper() in ('IF','THEN','ELSE','ENDIF','INCLUDE','EXCLUDE','ELSEIF')]
        kinds=[m.group().upper() for m in toks]
        if kinds in (['IF','THEN','INCLUDE','ENDIF'],['IF','THEN','EXCLUDE','ENDIF'],['IF','THEN','INCLUDE','ELSE','EXCLUDE','ENDIF'],['IF','THEN','EXCLUDE','ELSE','INCLUDE','ENDIF']):
            normalized=raw[toks[0].end():toks[1].start()].strip();true=kinds[2]
            # No implicit ELSE invented. Compiled numIncludes default must be checked separately.
            false=kinds[4] if 'ELSE' in kinds else None
    return {'source_ast':ast,'incomplete':incomplete,'condition_readable':normalized,
            'effect_true':true,'effect_false':false,'interpretation':'simple_if' if normalized else 'source_preserved_not_interpreted'}

def function_end(data,start,max_length=1000000):
    # Balanced braces ignoring quotes, line comments and block comments.
    text=data[start:min(len(data),start+max_length)].decode('latin1')
    depth=0;quote=None;escaped=False;line=False;block=False;seen=False;i=0
    while i<len(text):
        c=text[i]; nxt=text[i:i+2]
        if line:
            if c in '\r\n':line=False
        elif block:
            if nxt=='*/':block=False;i+=1
        elif quote:
            if escaped:escaped=False
            elif c=='\\':escaped=True
            elif c==quote:quote=None
        elif nxt=='//':line=True;i+=1
        elif nxt=='/*':block=True;i+=1
        elif c in '\"\'':quote=c
        elif c=='{':depth+=1;seen=True
        elif c=='}':
            depth-=1
            if seen and depth==0:return start+i+1
        i+=1
    return None


def summarize_compiled(code, rule_id):
    """Only an exact single comparison with both explicit include branches."""
    name=r"[A-Za-z_][A-Za-z0-9_]*"
    literal=r'''true|false|[-+]?\d+(?:\.\d+)?|'(?:[^'\\]|\\.)*'|"(?:[^"\\]|\\.)*"'''
    atom=rf"UserLogic\.getValue\('(?P<variable>{name})'\)\s*(?P<operator>==|!=|>=|<=|>|<)\s*(?P<literal>{literal})"
    pattern=rf"_rules\['rule{rule_id}'\]\s*=\s*function\s*\(\s*\)\s*\{{\s*if\s*\(\s*{atom}\s*\)\s*\{{\s*UserLogic\.setInclude\('rule{rule_id}',\s*(?P<yes>[01])\);\s*\}}\s*else\s*\{{\s*UserLogic\.setInclude\('rule{rule_id}',\s*(?P<no>[01])\);\s*\}}\s*\}}"
    m=re.fullmatch(pattern,code.strip())
    if not m:return {}
    op={'==':'=','!=':'<>'}.get(m['operator'],m['operator'])
    true='INCLUDE' if m['yes']=='1' else 'EXCLUDE';false='INCLUDE' if m['no']=='1' else 'EXCLUDE'
    condition=f"{m['variable']} {op} {m['literal']}"
    return {'condition_readable':condition,'effect_true':true,'effect_false':false,
            'false_effect_origin':'explicit_compiled_else','interpretation':'exact_compiled_comparison',
            'decoded_expression':f'IF {condition} THEN\n  {true}\nELSE\n  {false}\nENDIF'}
