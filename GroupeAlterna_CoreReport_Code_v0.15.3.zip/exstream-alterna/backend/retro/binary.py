"""Primitives bornées. Aucune donnée extraite n'est exécutée."""
import hashlib,re,struct
MARKER = b'\x57\x07\xf0\x42'
MAX_BYTES = 32 * 1024 * 1024
class InvalidPackage(ValueError): pass

def u32(data, offset):
    if offset < 0 or offset + 4 > len(data):
        raise InvalidPackage('Champ tronqué')
    return struct.unpack_from('<I', data, offset)[0]

def occurrences(data, needle, limit=200000):
    start=0
    for _ in range(limit):
        offset=data.find(needle,start)
        if offset < 0:return
        yield offset
        start=offset+len(needle)
    raise InvalidPackage('Trop de structures')

def validate(data):
    if len(data) > MAX_BYTES:raise InvalidPackage('Taille maximale dépassée')
    if len(data) < 256 or data[49:68] != b'ExstreamPackageFile':
        raise InvalidPackage('Signature de package Exstream non reconnue')
    standard=(data[:4] in (bytes.fromhex('21941e00'),bytes.fromhex('35202300'))
        and data[4:12]==bytes.fromhex('4f61bc00b17f3905') and 68<=u32(data,24)<len(data))
    # A second container profile keeps a 32-byte zero header, then an opaque
    # 8-byte token, a zero word and the shared Pascal package signature.
    zero_header=(data[:4]==bytes.fromhex('35202300') and data[4:36]==bytes(32)
        and data[36:44]!=bytes(8) and data[44:48]==bytes(4) and data[48]==19)
    if not (standard or zero_header):
        raise InvalidPackage('Structure ou longueur de package non reconnue')
    if data.find(MARKER)<0:raise InvalidPackage('Structures Exstream absentes')

def evidence(data, offset, end, decoder, note=''):
    if not 0<=offset<end<=len(data):raise InvalidPackage('Preuve hors fichier')
    return {'offset_start':offset,'offset_end':end,'sha256':hashlib.sha256(data[offset:end]).hexdigest(),
            'bytes_hex':data[offset:min(end,offset+128)].hex(),'decoder':decoder,'note':note}

def strings(data, max_count=250000):
    result=[]
    for encoding,pattern in [('latin1',rb'[\x09\x0a\x0d\x20-\x7e\xa0-\xff]{4,}'),('utf-16-le',rb'(?:[\x09\x0a\x0d\x20-\x7e\xa0-\xff]\x00){4,}')]:
        for m in re.finditer(pattern,data):
            if len(result)>=max_count:raise InvalidPackage('Trop de chaînes')
            result.append({'offset':m.start(),'end':m.end(),'encoding':encoding,'text':m.group().decode(encoding),
                           'sha256':hashlib.sha256(m.group()).hexdigest()})
    return sorted(result,key=lambda x:(x['offset'],x['encoding']))

def pascal(data, offset):
    if offset>=len(data):raise InvalidPackage('Chaîne tronquée')
    n=data[offset]; start=offset+1
    if n==255:
        if start+2>len(data):raise InvalidPackage('Longueur tronquée')
        n=int.from_bytes(data[start:start+2],'little');start+=2
        if n==65535:n=u32(data,start);start+=4
    if n>1048576 or start+n>len(data):raise InvalidPackage('Longueur invalide')
    return data[start:start+n].decode('latin1'),start,start+n
