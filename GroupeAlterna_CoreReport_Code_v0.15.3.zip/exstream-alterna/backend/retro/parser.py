import hashlib,re,struct
from bisect import bisect_right
from pathlib import Path
from . import __version__
from .binary import MARKER,validate,u32,pascal,evidence,strings,occurrences,InvalidPackage
from .rules import function_end,summarize,summarize_compiled,complete_source
TYPES={0:'String',1:'Integer',2:'Boolean',3:'Floating',4:'Date',5:'Currency'}
IDENT=re.compile(r'(?<![A-Za-z0-9_])(?:DF_)?(?:APP|DOC|PAG|CMP|SEC|PAR|STY|RUL|WRK|FCT|FIC|REF|VARSET|TBL|TAB|ROW|COL)_[A-Za-z0-9_.$:-]+')
VAR=re.compile(r'(?:DF_(?:FIC|REF|WRK|PAR|CMP)|WRK)_[A-Za-z0-9_.$:-]+\Z')
CLASS={35:'variable',21:'paragraph',24:'page',206:'section',159:'function'}

def definitions(data):
    result=[]
    for offset in occurrences(data,MARKER+struct.pack('<I',104)):
        try:
            cls=u32(data,offset+8);iid=u32(data,offset+12);name,start,end=pascal(data,offset+16)
        except InvalidPackage:continue
        if not (3<=len(name)<=241 and name[0].isalpha() and all(c.isprintable() for c in name)):continue
        result.append({'id':f'{cls}:{iid}','internal_id':iid,'class_code':cls,'kind':CLASS.get(cls,'unknown'),
            'name':name,'offset':offset,'name_end':end,'evidence':[evidence(data,offset,end,'OBS-definition-104-v1')],
            'parent_id':None,'document_order':None})
    for i,d in enumerate(result):d['end']=result[i+1]['offset'] if i+1<len(result) else len(data)
    return result

def variable_records(data,defs):
    out=[]
    for d in defs:
        if d['class_code']!=35:continue
        candidates=[]
        # Profile requires the type header AND an identical length-prefixed name at fixed header offset.
        for tag in (141,142):
            for p in occurrences(data[d['name_end']:min(d['end'],d['name_end']+220)],MARKER+struct.pack('<I',tag)):
                p+=d['name_end']
                try:
                    name,_,end=pascal(data,p+40)
                    if name!=d['name'] or data[end:end+4]!=b'\0'*4:continue
                    code=u32(data,p+8);flag=u32(data,end+4)
                    if flag not in (0,1):continue
                    candidates.append((p,code,flag,end+4))
                except InvalidPackage:continue
        v={**d,'source':'unknown','source_hint':d['name'].split('_')[1] if d['name'].startswith('DF_') else None,
           'type_code':None,'type':None,'cardinality_flag':None,'cardinality':None,'sample_value':None,
           'sample_origin':None,'mappings':[],'usage_evidence':[],'confidence':'HYPOTHÈSE','warnings':[]}
        if len(candidates)==1:
            p,code,flag,co=candidates[0]
            v.update(type_code=code,type=TYPES.get(code,f'UNKNOWN_{code}'),cardinality_flag=flag,cardinality=['Scalar','Array'][flag],
                     type_offset=p+8,cardinality_offset=co,confidence='TRÈS PROBABLE')
            v['evidence']=v['evidence']+[evidence(data,p,co+4,'OBS-type-cardinality-v1','Interprétation empirique, corroborée lorsque le mapping réutilise cet ID.')]
        else:v['warnings'].append('Définition de type/cardinalité inconnue ou ambiguë')
        out.append(v)
    return out

def mappings(data,variables,data_file_defs=None):
    byid={v['internal_id']:v for v in variables};result=[]
    for off in occurrences(data,MARKER+struct.pack('<I',115)):
        try:
            n=u32(data,off+12)
            if not 1<=n<=240:continue
            element=data[off+16:off+16+n].decode('ascii')
            if not re.fullmatch('[A-Za-z_][A-Za-z0-9_.-]*',element):continue
            pp=off+16+n+37
            parent,ps,end=pascal(data,pp)
            if not re.fullmatch(r'[A-Za-z_][A-Za-z0-9_.-]*(?: [A-Za-z_][A-Za-z0-9_.-]*)*',parent):continue
            # Multiple fixed guards, not a proximity association.
            if data[end:end+17]!=bytes.fromhex('0800000000010000007000000000000000'):continue
            vid=u32(data,end+21)
            if vid not in byid:continue
            # Require the duplicate element+parent tuple in the same mapping before the next record.
            limit=data.find(MARKER+struct.pack('<I',115),end+25)
            limit=min(limit if limit>=0 else len(data),end+1500)
            duplicate=bytes([len(element)])+element.encode()+bytes([len(parent)])+parent.encode()
            dup=data.find(duplicate,end+25,limit)
            if dup<0:continue
            path='/'+parent.replace(' ','/')+'/'+element
            v=byid[vid]
            item={'id':f'map:{off}','variable_id':v['id'],'internal_id':vid,'element':element,'parent_path':parent,
                'xml_path':path,'namespace':None,'source_classification':'unknown',
                'offset':off,'id_offset':end+21,'confidence':'CERTAIN','evidence':[evidence(data,off,dup+len(duplicate),'OBS-xml-115-v1')]}
            result.append(item);v['mappings'].append(item['id'])
            if v['type'] is not None:v['confidence']='CERTAIN'
        except (InvalidPackage,UnicodeDecodeError,ValueError):continue
    # CSV-key files use a distinct, fixed-width mapping record (tag 112).
    # A file must first pass the bounded source descriptor and CSV format
    # profile; arbitrary occurrences of a variable ID are never promoted.
    from .content import source_descriptor
    for source in (d for d in (data_file_defs or definitions(data)) if d['class_code']==15):
        descriptor=source_descriptor(data,source)
        if descriptor.get('format_code')!=1:continue
        for rel in occurrences(data[source['name_end']:source['end']],MARKER+struct.pack('<I',112)):
            p=source['name_end']+rel
            try:
                if p+52>source['end'] or u32(data,p+8)!=0 or u32(data,p+12)!=1:continue
                vid=u32(data,p+16)
                if vid not in byid or [u32(data,p+x) for x in (20,24,28,32,36,40,44,48)]!=[0,0,1,0xffffffff,0,0,2,0]:continue
                v=byid[vid]
                item={'id':f'map:{p}','variable_id':v['id'],'internal_id':vid,'element':None,'parent_path':None,
                    'xml_path':None,'namespace':None,'source_classification':descriptor['classification'],
                    'mapping_kind':'csv_key_mapping_candidate','data_source_id':source['id'],'data_source_name':source['name'],
                    'data_source_descriptor':descriptor,'offset':p,'id_offset':p+16,'confidence':'TRÈS PROBABLE',
                    'evidence':[evidence(data,p,p+52,'OBS-csv-key-mapping-112-v1'),*descriptor.get('evidence',[])]}
                result.append(item);v['mappings'].append(item['id'])
            except (InvalidPackage,IndexError):continue
    return result

def read_ids(code,variables):
    byname={v['name']:v['internal_id'] for v in variables}
    ids=set(int(x) for x in re.findall(r'UserLogic\.getValue(?:At|WithType)?\((\d+)',code))
    ids.update(byname[x] for x in re.findall(r"UserLogic\.getValue(?:At|WithType)?\(['\"]([^'\"]+)['\"]",code) if x in byname)
    return sorted(ids)

def compiled_rules(data,defs,variables):
    grouped={};starts=[d['offset'] for d in defs];byid={v['internal_id']:v for v in variables}
    for m in re.finditer(rb"_rules\['rule(\d+)'\]\s*=\s*function",data):
        cid=int(m.group(1));end=function_end(data,m.start())
        if end is None:continue
        code=data[m.start():end].decode('latin1');idx=bisect_right(starts,m.start())-1
        owner=defs[idx] if idx>=0 else None
        r=grouped.setdefault(cid,{'id':f'rule:{cid}','compiled_id':cid,'variants':[],'target':None,'scope':None,
            'confidence':'HYPOTHÈSE','target_candidates':[],'limitations':['Cible et portée non décodées ; aucun ciblage affirmé par proximité.']})
        source=None;source_ev=None;rule_name=None;rule_header=None
        # A separate rule record (tag 108/class 30) carries the same compiled ID.
        signature=MARKER+struct.pack('<III',108,30,cid)
        header=data.rfind(signature,0,m.start())
        if header>=0 and m.start()-header<1000000:
            next_header=data.find(MARKER+struct.pack('<II',108,30),header+16)
            if next_header<0 or next_header>m.start():
                try:
                    rule_header=evidence(data,header,header+16,'OBS-rule-header-108-v1')
                    name_at=header+36
                    mode=u32(data,header+24)
                    if mode==1 and u32(data,header+28) in byid:
                        _,_,literal_end=pascal(data,header+32)
                        if data[literal_end:literal_end+8]==b'\0'*8:name_at=literal_end+8
                        else:name_at=None
                    elif mode!=0 or data[header+28:header+36]!=b'\0'*8:name_at=None
                    if name_at is not None:
                        candidate,_,name_end=pascal(data,name_at)
                        if candidate and name_end<=m.start() and all(c.isprintable() for c in candidate):
                            rule_name=candidate
                            rule_header['name_evidence']=evidence(data,name_at,name_end,'OBS-rule-name-108-v2')
                    from .design_source import source_record
                    candidate=source_record(data,header,m.start())
                    if candidate:
                        ss,source=candidate;source_ev=evidence(data,ss,ss+len(source),'OBS-rule-source-u32-v1')
                except InvalidPackage:pass
        reads=read_ids(code,variables)
        variant={'offset':m.start(),'compiled_code':code,'source_expression':source,'name':rule_name,'reads':reads,
                 'evidence':[evidence(data,m.start(),end,'compiled-function-v1')]+([source_ev] if source_ev else [])+([rule_header] if rule_header else [])}
        if rule_header and not source:
            from .design_source import simple_rule
            design=simple_rule(data,header,m.start(),byid)
            if design:variant['design_condition']=design
        if source:
            variant.update(summarize(source))
            if variant['condition_readable'] and variant['effect_false'] is None:
                default=re.search(r'var numIncludes = ([01]);',code)
                assignments=re.findall(r'(?<!var )numIncludes = ([01]);',code)
                if default and len(assignments)==1 and code.count('if (')==1 and 'else' not in code:
                    variant['effect_false']='INCLUDE' if default.group(1)=='1' else 'EXCLUDE'
                    variant['false_effect_origin']='compiled_numIncludes_initialization' 
        if not source:variant.update(summarize_compiled(code,cid))
        r['variants'].append(variant)
        for vid in reads:
            if vid in byid:byid[vid]['usage_evidence'].append({'kind':'rule','id':r['id'],'offset':m.start()})
    for i,(cid,r) in enumerate(sorted(grouped.items()),1):
        r['document_id']=f'R{i}'
        for off in occurrences(data,struct.pack('<I',cid),limit=10000):
            idx=bisect_right(starts,off)-1;owner=defs[idx] if idx>=0 else None
            r['target_candidates'].append({'offset':off,'enclosing_definition_candidate':owner['id'] if owner else None,
                'confidence':'HYPOTHÈSE','reason':'Entier identique observé ; nature du champ non décodée.'})
    return [grouped[k] for k in sorted(grouped)]

def repeats(data,variables,defs):
    byid={v['internal_id']:v for v in variables};out=[]
    patterns=[('column',rb'\x02\0\0\0\x01\0\0\0(.{4})\0\0\0\0\x01\0\0\0',8),
              ('row',rb'\x01\0\0\0(.{4})\x03\0\0\0\x2d\0\0\0',4)]
    for axis,pat,delta in patterns:
        for m in re.finditer(pat,data,re.S):
            vid=int.from_bytes(m.group(1),'little');v=byid.get(vid)
            if not v or v['cardinality']!='Array':continue
            out.append({'id':f'repeat-candidate:{axis}:{m.start()}','axis':axis,'driver_internal_id':vid,'driver_name':v['name'],
                'offset':m.start()+delta,'confidence':'HYPOTHÈSE','confirmed_repeat':False,'table_id':None,
                'limitation':'Signature empirique trouvée ; parent ligne/colonne non prouvé. Ne constitue pas un REP-L/REP-C validé.',
                'evidence':[evidence(data,m.start(),m.end(),'OBS-repeat-candidate-v1')]})
    return out

def analyze(path, source_name=None, progress=lambda phase:None):
    path=Path(path);data=path.read_bytes();validate(data);progress('extraction')
    sha=hashlib.sha256(data).hexdigest();tokens=strings(data);defs=definitions(data)
    progress('analyse');vs=variable_records(data,defs);maps=mappings(data,vs,defs);rs=compiled_rules(data,defs,vs)
    inv={}
    for t in tokens:
        for m in IDENT.finditer(t['text']):
            name=m.group();item=inv.setdefault(name,{'name':name,'offsets':[],'status':'name_observed_not_object_relationship'})
            item['offsets'].append(t['offset']+m.start()*(2 if t['encoding']=='utf-16-le' else 1))
    calculations=[]
    for m in re.finditer(rb'(?:_formulas?\[\x27formula\d+\x27\]|_functions\[[^\]\r\n]{1,100}\])\s*=\s*function',data):
        end=function_end(data,m.start())
        if end:
            code=data[m.start():end].decode('latin1');calculations.append({'offset':m.start(),'source_code':code,
                'writes':sorted(set(int(x) for x in re.findall(r'UserLogic\.setValue(?:At)?\((\d+)',code))),
                'reads':read_ids(code,vs),
                'interpretation':'code_preserved_not_executed','evidence':[evidence(data,m.start(),end,'compiled-calculation-v1')]})
    model={'schema_version':'1.0','engine_version':__version__,'analysis_status':'partial_not_validated',
      'metadata':{'source_name':source_name or path.name,'sha256':sha,'size':len(data),'header_profile':data[:12].hex(),
                  'parser_profile':'OBS-AXA-2026-v1','ordering':'unknown','deterministic':True},
      'sources':[{'kind':'pub','name':source_name or path.name,'sha256':sha}],
      'definitions':defs,'inventory':sorted(inv.values(),key=lambda x:x['name']),'strings':tokens,
      'variables':vs,'mappings':maps,'rules':rs,'calculations':calculations,
      'pages':[],'blocks':[],'tables':[],'repeat_candidates':repeats(data,vs,defs),
      'input_dictionary':[{'variable_id':m['variable_id'],'xml_path':m['xml_path'],'mapping_id':m['id']} for m in maps if m['source_classification']=='input_candidate'],
      'unknowns':[
        {'code':'ORDER','detail':'Ordre et relations des pages/blocs non décodés. Aucun Pxx arbitraire.'},
        {'code':'VISUAL','detail':'Visuel complet non reconstruit. Moteur de composition, données et ressources absents.'},
        {'code':'TABLES','detail':'Inventaire complet table/ligne/colonne/cellule non décodé. Les signatures Repeat restent des candidats.'},
        {'code':'SCOPE','detail':'Cibles et portée des règles non prouvées. Les occurrences entières ne suffisent pas.'},
        {'code':'SAMPLES','detail':'Valeurs d’exemple non rattachées avec certitude ; null signifie non déterminé.'},
        {'code':'USAGE','detail':'Dépendances de règles compilées indexées ; usages de contenu et calculs incomplets.'},
        {'code':'LOOKUP','detail':'Clés et ressources des références non reliées.'},
        {'code':'XSD','detail':'Mappings de feuilles décodés, mais ordre XML, namespaces et occurrences structurelles non établis. XSD non généré.'}],
      'xsd':{'available':False,'reason':'Un mapping de variable Array ne prouve pas la cardinalité XML des parents. Ordre, namespace et contraintes incomplets.'}}
    from .content import enrich
    enrich(data, model)
    from .content_recovery import recover_content
    recover_content(data, model)
    from .content import classify_sources
    classify_sources(data, model)
    from .formula_timing import enrich_compute_times
    enrich_compute_times(data, model)
    from .layout import decode_layout
    decode_layout(data, model)
    from .structure import document_graph
    document_graph(data, model)
    from .hierarchy import application_graph
    application_graph(data, model)
    from .campaigns import campaign_graph
    campaign_graph(data, model)
    from .document_order import apply_application_document_order
    apply_application_document_order(model)
    from .data_sections import enrich_data_sections, audit_rule_catalog
    enrich_data_sections(data, model)
    audit_rule_catalog(data, model)
    from .layout import decode_page_regions, inspect_columns
    decode_page_regions(data, model)
    from .content_recovery import assign_page_contents
    assign_page_contents(data,model)
    inspect_columns(data, model)
    from .document_flow import build_document_flow
    model['document_flow']=build_document_flow(model)
    from .component_properties import paragraph_global_rules
    paragraph_global_rules(data, model)
    from .scopes import decode_scopes
    decode_scopes(data, model)
    from .layout import inspect_cell_spans
    inspect_cell_spans(data, model)
    from .provenance import enrich_provenance
    enrich_provenance(data, model)
    from .valuation import enrich_valuations
    enrich_valuations(data, model)
    from .page_analysis import analyze_pages
    analyze_pages(data,model)
    from .inline_objects import decode_inline_objects
    decode_inline_objects(data,model)
    from .coverage import finalize
    finalize(model)
    from .table_anchors import decode_table_anchors
    decode_table_anchors(data,model)
    # Style records must follow the validated cell set, including revoked
    # associations between free text and the next cell's trailer.
    from .table_styles import enrich_table_styles
    enrich_table_styles(data, model)
    from .visual_model import build_visual
    from .object_composition import decode_compositions
    decode_compositions(data,model)
    model['visual'] = build_visual(data, model)
    from .page_layout import decode_page_layouts
    decode_page_layouts(data, model)
    from .content_integrity import validate_content
    model['content_integrity']=validate_content(model)
    return model
