import hashlib,hmac,json,os,secrets,shutil,time
from pathlib import Path
from contextlib import asynccontextmanager
from fastapi import FastAPI,Request,HTTPException,UploadFile,File,Form,Depends
from fastapi.responses import JSONResponse,FileResponse
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import func
from .config import settings
from .db import initialize,Session,Job,transaction
from .security import owner,csrf,session_cookie,download_token
from .binary import validate,InvalidPackage
from .jobs import purge,TERMINAL,mark_failure
from . import __version__
from .report_options import DEFAULT_CHAPTERS, public_outputs
from typing import Literal
from starlette.exceptions import HTTPException as StarletteHTTPException
from .i18n import tr,use_language

def interface_language(request):
    return 'en' if request.headers.get('accept-language','fr').lower().startswith('en') else 'fr'

@asynccontextmanager
async def lifespan(app):
    initialize();yield
app=FastAPI(title='Rétro-documentation Exstream',version=__version__,lifespan=lifespan,docs_url=None if settings.production else '/api/docs',openapi_url=None if settings.production else '/api/openapi.json')
app.add_middleware(CORSMiddleware,allow_origins=list(settings.allowed_origins),allow_credentials=True,allow_methods=['GET','POST','DELETE'],allow_headers=['Content-Type','X-Alterna-Request'])

class BodyLimit:
    def __init__(self,app):self.app=app
    async def __call__(self,scope,receive,send):
        if scope['type']!='http':return await self.app(scope,receive,send)
        headers=dict(scope.get('headers',[]));limit=2*settings.max_file_bytes+1024*1024
        try:size=int(headers.get(b'content-length',b'0'))
        except ValueError:size=limit+1
        if size>limit:return await JSONResponse({'detail':'Requête trop volumineuse'},413)(scope,receive,send)
        consumed=0
        async def bounded():
            nonlocal consumed
            message=await receive();consumed+=len(message.get('body',b''))
            if consumed>limit:raise HTTPException(413,'Requête trop volumineuse')
            return message
        await self.app(scope,bounded,send)
app.add_middleware(BodyLimit)

@app.middleware('http')
async def security_headers(request,call_next):
    response=await call_next(request)
    response.headers.update({'Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer','X-Frame-Options':'DENY'})
    response.headers.setdefault('Content-Language',interface_language(request))
    return response

@app.exception_handler(StarletteHTTPException)
async def public_error(request,exc):
    with use_language(interface_language(request)):
        return JSONResponse({'detail':tr(exc.detail) if isinstance(exc.detail,str) else exc.detail},exc.status_code,headers=exc.headers)

@app.exception_handler(Exception)
async def internal_error(request,exc):
    with use_language(interface_language(request)):
        return JSONResponse({'detail':tr('Erreur interne. Réessayez ou contactez le support avec l’identifiant de tâche.')},500)

@app.get('/api/health')
def health():
    with Session() as db:db.query(Job.id).limit(1).all()
    if settings.queue_backend=='rq':
        from redis import Redis
        Redis.from_url(settings.redis_url,socket_connect_timeout=2).ping()
    return {'status':'ok','engine_version':__version__,'mode':settings.auth_mode,'analysis_status':'partial_not_validated'}

@app.post('/api/session',dependencies=[Depends(csrf)])
def session(request:Request):
    if settings.auth_mode!='dev':return {'mode':'proxy','authenticated':bool(owner(request))}
    response=JSONResponse({'mode':'dev','warning':'Session de développement uniquement'})
    try:owner(request)
    except HTTPException:response.set_cookie('alterna_dev',session_cookie(),httponly=True,secure=settings.production,samesite='strict',max_age=7*86400)
    return response

def get_job(jid,user):
    if len(jid)!=48 or any(c not in '0123456789abcdef' for c in jid):raise HTTPException(404,'Tâche introuvable')
    with Session() as db:j=db.get(Job,jid)
    if not j or not hmac.compare_digest(j.owner,user):raise HTTPException(404,'Tâche introuvable')
    return j

@app.post('/api/jobs',dependencies=[Depends(csrf)],status_code=202)
async def submit(request:Request,mode:str=Form(...),file_a:UploadFile=File(...),file_b:UploadFile|None=File(None),
                 include_valuation:bool=Form(True),include_input_dictionary:bool=Form(True),
                 include_reconstruction:bool=Form(True),include_template_pages:bool=Form(True),
                 report_language:Literal['fr','en']=Form('fr'),user:str=Depends(owner)):
    if mode not in ('analyze','compare') or (mode=='compare')!=(file_b is not None):raise HTTPException(422,'Sélectionnez un fichier en analyse ou deux en comparaison')
    files=[file_a]+([file_b] if file_b else [])
    for f in files:
        if not f.filename or len(f.filename)>200 or Path(f.filename).name!=f.filename or '\\' in f.filename or not f.filename.lower().endswith(('.pub','.txt')) or any(ord(c)<32 for c in f.filename):
            raise HTTPException(422,'Nom ou extension invalide. Un package Exstream .pub ou .txt est requis.')
    purge();now=time.time();jid=secrets.token_hex(24);reserved=len(files)*settings.max_file_bytes+settings.max_output_bytes
    with transaction() as db:
        if db.query(Job).filter(Job.owner==user,Job.created>now-60).count()>=5:raise HTTPException(429,'Trop de demandes. Réessayez dans une minute.')
        if db.query(Job).filter(Job.owner==user,Job.state.notin_(list(TERMINAL))).count()>=settings.max_user_jobs:raise HTTPException(429,'Trop de tâches en cours')
        if db.query(Job).filter(Job.state.notin_(list(TERMINAL))).count()>=settings.max_total_jobs:raise HTTPException(429,'Capacité de traitement atteinte')
        used=db.query(func.coalesce(func.sum(Job.reserved_bytes),0)).scalar()
        if used+reserved>settings.disk_quota_bytes:raise HTTPException(507,'Quota de stockage de l’application atteint. Attendez l’expiration des résultats ou augmentez le quota configuré.')
        db.add(Job(id=jid,owner=user,mode=mode,state='reception',created=now,updated=now,expires=now+settings.retention_seconds,
            inputs=[],outputs=[],history=[{'state':'reception','at':now}],
            summary={'report_language':report_language,'report_chapters':[key for key, enabled in zip(DEFAULT_CHAPTERS,
                (include_valuation,include_input_dictionary,include_reconstruction,include_template_pages)) if enabled]},
            engine_version=__version__,reserved_bytes=reserved))
    directory=settings.storage/jid;directory.mkdir(mode=0o700)
    try:
        inputs=[]
        for index,f in enumerate(files):
            stored=secrets.token_hex(16)+'.pub';path=directory/stored;total=0
            with path.open('xb') as stream:
                os.chmod(path,0o600)
                while chunk:=await f.read(1024*1024):
                    total+=len(chunk)
                    if total>settings.max_file_bytes:raise HTTPException(413,'Fichier trop volumineux (32 Mio maximum)')
                    stream.write(chunk)
            data=path.read_bytes()
            try:validate(data)
            except InvalidPackage:raise HTTPException(422,'Le contenu ne correspond pas au profil Exstream pris en charge')
            inputs.append({'name':f.filename,'stored':stored,'size':total,'sha256':hashlib.sha256(data).hexdigest()})
        with transaction() as db:
            j=db.get(Job,jid);j.inputs=inputs;j.state='attente';j.updated=time.time();j.history=[*j.history,{'state':'attente','at':j.updated}]
            j.reserved_bytes=sum(item['size'] for item in inputs)+settings.max_output_bytes
        if settings.queue_backend=='rq':
            from redis import Redis
            from rq import Queue
            from .jobs import rq_failure,rq_stopped
            try:Queue('exstream',connection=Redis.from_url(settings.redis_url)).enqueue('retro.jobs.run_job',jid,job_id=jid,job_timeout=settings.max_job_seconds,result_ttl=0,failure_ttl=0,on_failure=rq_failure,on_stopped=rq_stopped)
            except Exception:raise HTTPException(503,'Service de traitement indisponible')
        return {'id':jid,'state':'attente','expires':now+settings.retention_seconds}
    except BaseException:
        shutil.rmtree(directory,ignore_errors=True)
        with transaction() as db:
            j=db.get(Job,jid)
            if j:j.state='echec';j.error='RECEPTION_FAILED';j.reserved_bytes=0;j.inputs=[]
        raise
    finally:
        for f in files:await f.close()

@app.get('/api/jobs/{jid}')
def status(jid:str,user:str=Depends(owner)):
    j=get_job(jid,user)
    expired=j.expires<=time.time() or j.state=='expire'
    return {'id':j.id,'mode':j.mode,'state':'expire' if expired else j.state,'history':j.history,'created':j.created,'expires':j.expires,
      'cancel_requested':j.cancelled,'report_language':j.summary.get('report_language','fr'),'summary':{} if expired else j.summary,'outputs':[] if expired else public_outputs(j.outputs),
      'error':'Le traitement a échoué. Communiquez cet identifiant au support.' if j.error else None,
      'inputs':[] if expired else [{k:x[k] for k in ('name','size','sha256')} for x in j.inputs]}

@app.post('/api/jobs/{jid}/cancel',dependencies=[Depends(csrf)])
def cancel(jid:str,user:str=Depends(owner)):
    get_job(jid,user)
    with transaction() as db:
        j=db.get(Job,jid)
        if j.state in TERMINAL:raise HTTPException(409,'La tâche est déjà terminée')
        j.cancelled=True;j.updated=time.time()
        if j.state=='attente':j.state='annule';j.history=[*j.history,{'state':'annule','at':j.updated}]
    if settings.queue_backend=='rq':
        from redis import Redis
        from rq.command import send_stop_job_command
        try:send_stop_job_command(Redis.from_url(settings.redis_url),jid)
        except Exception:pass # Worker callbacks also check the durable cancellation flag.
    return {'id':jid,'cancel_requested':True}

@app.post('/api/jobs/{jid}/links',dependencies=[Depends(csrf)])
def links(jid:str,user:str=Depends(owner)):
    j=get_job(jid,user)
    if j.expires<=time.time():raise HTTPException(410,'Résultat expiré')
    if j.state!='termine':raise HTTPException(409,'Résultats indisponibles')
    expiry=min(int(time.time())+settings.download_seconds,int(j.expires))
    return {'expires':expiry,'links':[{ 'name':name,'url':f'/api/jobs/{jid}/download/{name}?expires={expiry}&signature={download_token(jid,name,user,expiry)}'} for name in public_outputs(j.outputs)]}

@app.get('/api/jobs/{jid}/download/{filename}')
def download(jid:str,filename:str,expires:int,signature:str,user:str=Depends(owner)):
    j=get_job(jid,user)
    if expires<time.time() or j.expires<=time.time():raise HTTPException(410,'Lien ou résultat expiré')
    if expires>time.time()+settings.download_seconds+1 or not hmac.compare_digest(signature,download_token(jid,filename,user,expires)):raise HTTPException(403,'Lien non autorisé')
    if j.state!='termine' or filename not in public_outputs(j.outputs):raise HTTPException(404,'Livrable introuvable')
    path=settings.storage/jid/filename
    if not path.is_file():raise HTTPException(410,'Résultat indisponible')
    return FileResponse(path,filename=filename,media_type='application/pdf',headers={'Content-Language':j.summary.get('report_language','fr')})
