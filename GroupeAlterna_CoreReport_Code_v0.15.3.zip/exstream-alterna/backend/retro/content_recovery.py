"""Bounded content discovery shared by documentation and visual projection.

No filename, paragraph name or sample value selects a decoding profile.
New rich-text candidates require a complete glyph stream and independent
variable directory. Literal records require redundant lengths and a paired
owner, and cannot overlap an already accepted payload.
"""
import copy
import re
import struct
from .binary import MARKER, InvalidPackage, evidence, occurrences, u32
from .layout import sig
from .scopes import read_richtext, colour_prelude


def bounded_owners(data, definitions):
    owners=[]
    for d in definitions:
        if d['class_code'] not in (21,24):continue
        opens=list(occurrences(data[:d['offset']],sig(111,d['class_code'],d['internal_id'])))
        if len(opens)!=1:continue
        a,z=opens[0],d['offset']
        if z-a>2_000_000 or any(a<x['offset']<z for x in definitions):continue
        owners.append(dict(id=d['id'],offset=a,end=z,
            evidence=[evidence(data,a,a+16,'OBS-content-owner-111-v1'),*d['evidence']]))
    return owners


def recover_content(data, model):
    units=model['content_units'];known={u['offset'] for u in units}
    variables={v['internal_id']:v for v in model['variables']}
    rules={r['compiled_id']:r for r in model['rules']}
    recovered=[];literals=[];failures=[]
    for owner in bounded_owners(data,model['definitions']):
        a,z=owner['offset'],owner['end']
        for rel in occurrences(data[a:z],MARKER):
            p=a+rel
            if p in known or p+12>z:continue
            n=u32(data,p+4)
            if not 4<=n<65536 or p+12+n>z or data[p+8+n:p+12+n]!=data[p+4:p+8]:continue
            raw=data[p+8:p+8+n]
            if raw[:3]!=b'\0\0\0':continue
            if not any(colour_prelude(data,p,nf) for nf in range(1,129)):continue
            parts=[dict(text=h.group().decode('cp1252',errors='replace'),offset=p+8+h.start(),kind='text')
                   for h in re.finditer(rb'[\x20-\x7e\x80-\xff]+',raw)]
            if not parts and raw!=b'\0'*4:continue
            item=dict(id=f'text:{p}',offset=p,parent_id=owner['id'],parent_offset=a,decode_end=z,
                parent_evidence=owner['evidence'],parts=parts,document_order=None,
                text=' | '.join(t['text'] for t in parts),variable_names=[],confidence='TRÈS PROBABLE',
                evidence=[evidence(data,p,p+12+n,'OBS-content-redundant-length-v1')],
                limitation='Contenu borné ; les propriétés non reconnues restent non interprétées.')
            try:
                payload=read_richtext(data,item,variables,rules,content_only=True)
            except (InvalidPackage,ValueError,KeyError,IndexError,struct.error) as exc:
                failures.append(dict(offset=p,parent=owner['id'],reason=str(exc)));continue
            item['serialized_parts']=copy.deepcopy(parts)
            item['parts']=payload.pop('decoded_parts');item['text_structure']=payload
            item['variable_names']=list(dict.fromkeys(t['variable_name'] for t in item['parts'] if t['kind']=='variable'))
            units.append(item);known.add(p);recovered.append(item['id'])
        for hit in re.finditer(rb'\xa0\x00\x00\x00\x01',data[a:z]):
            p=a+hit.start()
            if p in known or p+9>z:continue
            n=int.from_bytes(data[p+5:p+7],'little')
            if not 3<n<10000 or p+9+n>z or data[p+5:p+7]!=data[p+7:p+9]:continue
            raw=data[p+9:p+9+n]
            if not all(c>=32 or c in (9,10,13) for c in raw):continue
            # Deduplicate by byte ownership, never by equal text in other objects.
            if any(u['offset']<p+9+n and p<u['evidence'][0]['offset_end'] for u in units):continue
            text=raw.decode('cp1252',errors='replace')
            units.append(dict(id=f'literal:{p}',offset=p,parent_id=owner['id'],parent_offset=a,decode_end=z,
                parent_evidence=owner['evidence'],parts=[dict(text=text,kind='text',offset=p+9)],text=text,
                variable_names=[],document_order=None,confidence='TRÈS PROBABLE',
                evidence=[evidence(data,p,p+9+n,'OBS-literal-A0-u16-duplicate-v1')],
                limitation='Texte littéral borné ; style et position exacte non interprétés'))
            known.add(p);literals.append(f'literal:{p}')
    units.sort(key=lambda u:u['offset'])
    for i,u in enumerate(units,1):u['serialized_index']=i
    model['content_recovery']={'profile':'OBS-shared-bounded-content-v1','bounded_richtext':recovered,
        'literal_text':literals,'uninterpreted_candidates':failures}


def assign_page_contents(data,model):
    """Bind page-only decorations before variable decoding, for both outputs."""
    known={p['id'] for p in model['paragraphs']}
    defs={d['id']:d for d in model['definitions']}
    pages=[]
    for owner in bounded_owners(data,model['definitions']):
        if defs[owner['id']]['class_code']!=24:continue
        page={**owner,'name':defs[owner['id']]['name'],'content_ids':[]}
        for u in model['content_units']:
            if not owner['offset']<u['offset']<owner['end'] or u.get('parent_id') in known:continue
            u.update(parent_id=owner['id'],parent_offset=owner['offset'],decode_end=owner['end'],parent_evidence=owner['evidence'])
            page['content_ids'].append(u['id'])
        pages.append(page)
    model['visual_page_containers']=pages
