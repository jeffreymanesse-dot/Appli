"""Optional Template/Page appendix, with native scale and shared references."""
import base64
from collections import defaultdict
from io import BytesIO
import json
from pathlib import Path
from tempfile import TemporaryDirectory
from xml.sax.saxutils import escape
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4,A3,landscape
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.utils import ImageReader
from reportlab.platypus import (BaseDocTemplate,PageTemplate,Frame,Paragraph,Table,
    TableStyle,PageBreak,NextPageTemplate,Flowable,Spacer,CondPageBreak,KeepTogether)
from .i18n import tr
from .page_layout import selected_pages

PT=.24
MM=72/25.4
NAVY='#212F44';BLUE='#176B9A';GRAY='#536476'


def reference(page_index,obj):
    return f"P{page_index+1}.{obj['index']:02d}"


def appendix_rule_ids(pages):
    ids=[]
    for page in pages:
        if page.get('page_rule_id'):ids.append(page['page_rule_id'])
        for obj in page['objects']:
            if obj.get('rule_id'):ids.append(obj['rule_id'])
            for unit in obj['units']:ids.extend(unit['rule_ids'])
    return list(dict.fromkeys(ids))


def existing_rule_ids(model):
    # The fallback renderer prints the complete native rule catalogue.
    if not model.get('document_paragraph_ids'):return {r['compiled_id'] for r in model.get('rules',[])}
    return set(model.get('document_rule_ids',[]))


def style_key(unit):
    return json.dumps({k:unit[k] for k in ('fonts','colors','alignments')},sort_keys=True,ensure_ascii=False)


def page_sheet(size):
    w,h=[v*PT for v in size]
    # A3 carries a native A4 page at 100%, with annotations outside its bounds.
    for sheet in (A3,landscape(A3)):
        if w+140<=sheet[0]-104 and h+145<=sheet[1]-128:return sheet
    return (max(A3[0],w+244),max(A3[1],h+273))


class PagePlan(Flowable):
    def __init__(self,page,index,resources,width):
        super().__init__();self.page=page;self.index=index;self.resources=resources
        self.width=width;self.height=page['size_raw'][1]*PT+145

    def draw(self):
        c=self.canv;p=self.page;pw,ph=[v*PT for v in p['size_raw']]
        left=32;top=self.height-70
        c.saveState()
        c.setFillColor(colors.HexColor(NAVY));c.setFont('AlternaBold',15)
        c.drawString(0,self.height-16,tr('Plan à l’échelle 1:1')+f" - P{self.index+1}")
        title=Paragraph(escape(p['name']),ParagraphStyle('page-name',fontName='Alterna',fontSize=10,leading=13,textColor=colors.HexColor(NAVY)))
        _,th=title.wrap(self.width,40);title.drawOn(c,0,self.height-24-th)
        c.setStrokeColor(colors.HexColor(NAVY));c.setLineWidth(.7)
        c.rect(left,top-ph,pw,ph)
        def point(x,y):return left+x*PT,top-y*PT
        def rectangle(r,colour,dash=(),width=.65):
            x,y,right,bottom=r;xx,yy=point(x,bottom)
            c.setStrokeColor(colors.HexColor(colour));c.setLineWidth(width);c.setDash(*dash) if dash else c.setDash()
            c.rect(xx,yy,(right-x)*PT,(bottom-y)*PT,fill=0,stroke=1)
        region=p.get('page_rectangle_raw')
        if region:rectangle(region,'#AEBBC7',(2,3),.45)
        labels=defaultdict(list)
        for obj in p['objects']:
            for image in obj['images']:
                resource=self.resources.get(str(image.get('resource_id')))
                if not resource:continue
                x,y,r,b=image['rect_raw'];xx,yy=point(x,b)
                c.drawImage(ImageReader(BytesIO(base64.b64decode(resource['data_base64']))),xx,yy,(r-x)*PT,(b-y)*PT)
            r=obj.get('rect_raw')
            if not r:continue
            # A graphic pair stays two objects; only coincident leader labels group.
            name=obj.get('name') or ''
            colour,dash=(('#A15A16',(2,2)) if 'SegPh' in name else (BLUE,()) if 'JpgPh' in name else (NAVY,()))
            if obj['type_code']==0:colour,dash=GRAY,(1,2)
            rectangle(r,colour,dash)
            labels[tuple(r)].append(reference(self.index,obj))
            for image in obj['images']:
                if image['rect_raw']!=r:rectangle(image['rect_raw'],BLUE,(1,2),.45)
        # Leader labels move; object rectangles, image extents and rotations do not.
        rows=sorted(labels.items(),key=lambda pair:(pair[0][1]+pair[0][3],pair[0][0]))
        positions=[];previous=top+12
        for r,refs in rows:
            desired=top-(r[1]+r[3])*.5*PT
            placed=min(desired,previous-12);positions.append(placed);previous=placed
        if positions and positions[-1]<top-ph:
            positions[-1]=top-ph
            for i in range(len(positions)-2,-1,-1):positions[i]=max(positions[i],positions[i+1]+12)
        # Excessive label density is handled by a concise reference list, not by
        # displacing native objects or squeezing arbitrary text into their frames.
        if positions and positions[0]>top+10:
            rows=[];positions=[]
        for (r,refs),yy in zip(rows,positions):
            xx=left+pw+12;target=point(r[2],(r[1]+r[3])/2)
            label='/'.join(refs)
            c.setFont('Alterna',7);c.setFillColor(colors.HexColor(GRAY))
            c.drawString(xx,yy-2,label)
            c.setStrokeColor(colors.HexColor('#70849A'));c.setLineWidth(.35);c.setDash();c.line(xx-3,yy,target[0],target[1])
        c.setFont('Alterna',7);c.setFillColor(colors.HexColor(GRAY));c.setDash()
        for k in range(0,int(pw/MM)+1,50):
            c.drawString(left+k*MM-3,top+8,str(k));c.line(left+k*MM,top+2,left+k*MM,top+5)
        for k in range(0,int(ph/MM)+1,50):c.drawRightString(left-7,top-k*MM-2,str(k))
        c.drawString(left-20,top+8,'mm')
        c.setFont('Alterna',8)
        c.drawString(left,49,tr('Cadres d’étude ; les valeurs dynamiques ne sont pas calculées.'))
        c.drawString(left,36,tr('Pointillé gris : rectangle de page dont le rôle reste à confirmer.'))
        c.setLineWidth(.8);c.line(left,18,left+50*MM,18)
        c.line(left,15,left,21);c.line(left+50*MM,15,left+50*MM,21)
        c.drawString(left+50*MM+8,15,tr('50 mm - imprimer à 100 %'))
        c.restoreState()


def build_page_appendix(model,path,*,start_number=0):
    from .render import setup,ROOT
    from .design_source import source_lines,source_markup
    from .rule_labels import rule_labels,rule_algorithms
    c=setup();pages=selected_pages(model);resources=model.get('page_layouts',{}).get('resources',{})
    styles={
        'body':ParagraphStyle('tp-body',fontName='Alterna',fontSize=9.2,leading=12.8,spaceAfter=7,textColor=c['navy']),
        'small':ParagraphStyle('tp-small',fontName='Alterna',fontSize=8,leading=10.8,spaceAfter=4,textColor=c['navy']),
        'head':ParagraphStyle('tp-head',fontName='AlternaBold',fontSize=17,leading=22,spaceAfter=12,keepWithNext=True,textColor=c['navy']),
        'sub':ParagraphStyle('tp-sub',fontName='AlternaBold',fontSize=10,leading=14,spaceBefore=9,spaceAfter=7,keepWithNext=True,textColor=c['primary']),
        'code':ParagraphStyle('tp-code',fontName='AlternaMono',fontSize=7.2,leading=10,spaceAfter=0,textColor=c['navy']),
        'white':ParagraphStyle('tp-white',fontName='AlternaBold',fontSize=8,leading=10.8,textColor=colors.white),
    }
    story=[]
    def paragraph(text,kind='body',markup=False):return Paragraph(str(text) if markup else escape(str(text)).replace('\n','<br/>'),styles[kind])
    def add(text,kind='body'):story.append(paragraph(text,kind))
    def table(rows,widths):
        flow=Table([[v if isinstance(v,(Paragraph,list)) else paragraph(v,'white' if i==0 else 'small') for v in row] for i,row in enumerate(rows)],colWidths=widths,repeatRows=1,hAlign='LEFT',splitInRow=1)
        flow.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),c['navy']),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,c['surface']]),('VALIGN',(0,0),(-1,-1),'TOP'),('TOPPADDING',(0,0),(-1,-1),5),('BOTTOMPADDING',(0,0),(-1,-1),5)]));story.append(flow)
    def new(title):story.append(PageBreak());add(title,'head')
    existing=existing_rule_ids(model);rids=appendix_rule_ids(pages)
    rs={r['compiled_id']:r for r in model.get('rules',[])};names=rule_labels(model.get('rules',[]))
    additional=[rid for rid in rids if rid not in existing and rid in rs]
    rrefs={rid:(rs[rid]['document_id'] if rid in existing else 'TP-R'+str(additional.index(rid)+1)) for rid in rids if rid in rs}
    style_registry={};style_values={};content_registry={};targets=defaultdict(list)
    add(tr('Annexe - Template et Page'),'head')
    if not pages:
        add(tr('Aucune page exploitable n’est disponible dans ce modèle. Une nouvelle analyse est nécessaire pour les anciens résultats.'))
    else:
        add(tr('Cette annexe complète la structure et le catalogue des règles : plans à taille réelle, objets de page et propriétés d’implantation. Les paragraphes du courrier ne sont pas reproduits une seconde fois.'))
        add(tr('Les repères Pn.nn identifient les objets de cette annexe. Les repères Rn renvoient au catalogue ; les repères TP-R désignent les seules conditions supplémentaires détaillées ici.'),'small')
        table([[tr('Page'),tr('Composant'),tr('Format / objets')]]+[[f'P{i+1}',p['name'],
            (' × '.join(f'{v*25.4/300:.2f}' for v in p['size_raw'])+' mm\n' if p.get('size_raw') else '')+
            str(len(p['objects']))+tr(' objets décrits')] for i,p in enumerate(pages)],[35,320,136])
        add(tr('Aucun lien vers un composant Template n’est affirmé sans référence interprétée. Le nom de l’annexe ne crée pas de relation supplémentaire.'),'small')
        add(tr('Les contours sont des repères d’étude, pas des bordures imprimées. Les images retrouvées dans le PUB sont conservées ; les images dynamiques non résolues restent des cadres. La présence simultanée des cadres ne prouve pas leur impression simultanée.'),'small')
    sheets={}
    for i,page in enumerate(pages):
        pid=f'plan-{i}'
        # Avoid unbounded media boxes on hostile or unrecognised packages.
        if page.get('size_raw') and max(page['size_raw'])<=20000:
            sheet=page_sheet(page['size_raw']);sheets[pid]=sheet
            story.extend([NextPageTemplate(pid),PageBreak(),PagePlan(page,i,resources,sheet[0]-104),NextPageTemplate('A4'),PageBreak()])
        else:story.append(PageBreak())
        add(tr('Objets de page')+f' - P{i+1}','head');add(page['name'],'sub')
        if page['status']!='decoded':add(tr('Certaines propriétés de cette page ne sont pas interprétées. Les positions inconnues ne sont pas dessinées.'),'small')
        if page.get('page_rule_id') in rrefs:
            rid=page['page_rule_id'];targets[rid].append(f'P{i+1}')
            add(tr('Condition de page : ')+rrefs[rid]+' · '+names[rid],'small')
        rows=[[tr('Rep.'),tr('Objet et contenu'),tr('Implantation (mm)'),tr('Conditions')]]
        for obj in page['objects']:
            ref=reference(i,obj);body=[paragraph(obj.get('name') or tr('Objet non nommé'),'small')]
            # Compare the actual content/styles/rules, without unit identities.
            fingerprint=json.dumps([{k:v for k,v in u.items() if k!='content_id'} for u in obj['units']],sort_keys=True)
            if obj['units'] and fingerprint in content_registry:
                body.append(paragraph(tr('Contenu et style : voir ')+content_registry[fingerprint]+'.','small'))
            else:
                if obj['units']:content_registry[fingerprint]=ref
                for unit in obj['units']:
                    key=style_key(unit)
                    if key not in style_registry:style_registry[key]='S'+str(len(style_registry)+1);style_values[key]=unit
                    homonymous=len(unit['parts'])==1 and unit['parts'][0].get('variable_name')==obj.get('name')
                    text=tr('Variable homonyme') if homonymous else ''.join('['+part['variable_name']+']' if part.get('variable_name') else part.get('text','') for part in unit['parts'])
                    body.append(paragraph(text+' · '+style_registry[key],'small'))
            for image in obj['images']:
                desc=tr('Image : ')+(image.get('resource_name') or tr('ressource non résolue'))
                if image['rect_raw']!=obj.get('rect_raw'):
                    x,y,r,b=image['rect_raw'];desc+=' · X/Y '+f'{x*25.4/300:.2f}/{y*25.4/300:.2f}'+tr(' ; L/H ')+f'{(r-x)*25.4/300:.2f}/{(b-y)*25.4/300:.2f} mm'
                body.append(paragraph(desc,'small'))
            r=obj.get('rect_raw')
            if r:
                x,y,right,bottom=[v*25.4/300 for v in r]
                loc=f'X {x:.2f} ; Y {y:.2f}\nL {right-x:.2f} ; H {bottom-y:.2f}'
                if obj.get('rotation') is not None:loc+='\n'+tr('Rotation : ')+str(obj['rotation'])+'°'
                if obj.get('geometry_kind')=='image':loc+='\n'+tr('Emprise de l’image')
            else:loc=tr('Non interprétée')
            conditions=[]
            if obj.get('rule_id') in rrefs:
                rid=obj['rule_id'];conditions.append(rrefs[rid]);targets[rid].append(ref)
            for unit in obj['units']:
                for rid in unit['rule_ids']:
                    if rid in rrefs:conditions.append(rrefs[rid]+tr(' (texte)'));targets[rid].append(ref+tr(' (texte)'))
            rows.append([ref,body,loc,'\n'.join(dict.fromkeys(conditions)) or '-'])
        if len(rows)>1:table(rows,[41,243,111,96])
        else:add(tr('Aucun objet de page décodé.'),'small')
        if page.get('page_rectangle_raw'):
            x,y,r,b=[v*25.4/300 for v in page['page_rectangle_raw']]
            add(tr('Rectangle de page relevé, rôle à confirmer : ')+f'X {x:.2f}, Y {y:.2f}, L {r-x:.2f}, H {b-y:.2f} mm.','small')
        overlaps=[]
        for oi,a in enumerate(page['objects']):
            if not a.get('rect_raw'):continue
            for b in page['objects'][oi+1:]:
                if not b.get('rect_raw'):continue
                ar=a['rect_raw'];br=b['rect_raw']
                if min(ar[2],br[2])>max(ar[0],br[0]) and min(ar[3],br[3])>max(ar[1],br[1]):overlaps.append((a,b))
        if overlaps:
            add(tr('Superpositions conservées'),'sub')
            groups=defaultdict(list)
            for a,b in overlaps:groups[reference(i,a)].append(reference(i,b))
            add(' ; '.join(a+' / '+', '.join(bs) for a,bs in groups.items())+'.','small')
            add(tr('Ces intersections concernent les cadres. Les valeurs, conditions et priorités d’impression ne sont pas simulées.'),'small')
    if style_registry:
        new(tr('Styles partagés des objets de page'))
        add(tr('Chaque style est décrit une seule fois. Pour une variable portant une image, ces propriétés décrivent son texte de substitution, pas les couleurs de l’image finale.'),'small')
        rows=[[tr('Rep.'),tr('Police et taille'),tr('Couleur'),tr('Alignement')]]
        for key,label in style_registry.items():
            value=style_values[key]
            font=' ; '.join(dict.fromkeys(f['name']+' '+str(f['size'])+' pt' for f in value['fonts'])) or tr('Non interprétée')
            colour=' ; '.join(dict.fromkeys((c.get('name')+' · ' if c.get('name') else '')+c['rgb'].upper() if c.get('rgb') else tr('Non interprétée') for c in value['colors'])) or tr('Non interprétée')
            align=', '.join(tr({'left':'Gauche','right':'Droite','center':'Centré','justify':'Justifié'}.get(a,a)) for a in value['alignments']) or '-'
            rows.append([label,font,colour,align])
        table(rows,[35,191,200,65])
    referenced=[rid for rid in rids if rid in existing and rid in rs]
    if referenced:
        add(tr('Renvois au catalogue des règles'),'sub')
        table([[tr('Rep.'),tr('Règle'),tr('Objets de page')]]+[[rrefs[rid],names[rid],', '.join(dict.fromkeys(targets[rid]))] for rid in referenced],[40,300,151])
    if additional:
        new(tr('Conditions propres aux pages'))
        for rid in additional:
            story.append(CondPageBreak(110));add(rrefs[rid]+' · '+names[rid],'sub')
            add(tr('Cibles : ')+', '.join(dict.fromkeys(targets[rid])),'small')
            for kind,code in rule_algorithms(rs[rid]):
                for line in source_lines(code):
                    story.append(paragraph(source_markup(line),'code',True) if kind in ('script','parameters') else paragraph(line,'small'))
            story.append(Spacer(1,7))
    def header(canvas,doc):
        w,h=canvas._pagesize;canvas.saveState()
        canvas.drawImage(str(ROOT/'assets/Logo_GroupeAlterna_825px.png'),w-171,h-53,width=119,height=29,preserveAspectRatio=True,mask='auto')
        canvas.setStrokeColor(c['primary']);canvas.line(52,h-66,w-52,h-66)
        canvas.setFont('Alterna',7);canvas.setFillColor(c['navy'])
        canvas.drawString(52,29,tr('Groupe Alterna | Analyse PUB | ')+model['engine_version'])
        canvas.drawRightString(w-52,29,str(start_number+doc.page));canvas.restoreState()
    doc=BaseDocTemplate(str(path),pagesize=A4,leftMargin=52,rightMargin=52,topMargin=80,bottomMargin=48)
    all_sheets={'A4':A4,**sheets}
    doc.addPageTemplates([PageTemplate(id=key,pagesize=size,frames=[Frame(52,48,size[0]-104,size[1]-128,leftPadding=0,rightPadding=0,topPadding=0,bottomPadding=0)],onPage=header) for key,size in all_sheets.items()])
    doc.build(story)


def append_page_annex(model,path):
    """Append before the original source archive is attached by render.report."""
    from pypdf import PdfReader,PdfWriter
    path=Path(path)
    with TemporaryDirectory(prefix='template-pages-',dir=path.parent) as folder:
        folder=Path(folder);source=PdfReader(path);count=len(source.pages)
        appendix=folder/'appendix.pdf';build_page_appendix(model,appendix,start_number=count-1)
        writer=PdfWriter();writer.clone_document_from_reader(source)
        writer.append(PdfReader(appendix),import_outline=False)
        writer.add_outline_item(tr('Annexe - Template et Page'),count)
        target=folder/'merged.pdf'
        with target.open('wb') as stream:writer.write(stream)
        target.replace(path)
