"""Empirical PUB graphics, isolated per analysis. Unknown fields stay explicit."""
import re,struct,hashlib,bisect,collections
from .binary import MARKER as M, pascal, InvalidPackage

def source_rgb(kind,value,palette):
    """One colour resolver for native rich text and graphical display objects."""
    if kind==0 and 0<=value<=0xffffff:return '#'+value.to_bytes(4,'little')[:3].hex()
    if kind==50:return palette.get(str(value),palette.get(value,{})).get('rgb')
    return None

class GraphicsDecoder:
    def __init__(self,data,model):
        self.data=data;self.model=model;self.fonts={};self.palette={}
        # Two observed resource envelopes share the same bounded font schema:
        # tag 133 (NOA/Adhésion/Auto/Obsèques) and 134 (Versement/FIP).
        for hit in re.finditer(rb'[\x85\x86]\x00\x00\x00',data):
            p=hit.start()
            try:
                name,_,end=pascal(data,p+12)
                if not name or not all(32<=ord(c)<127 for c in name):continue
                values=struct.unpack_from('<9I',data,end)
                if self.u(p+8)!=0 or not 0<values[0]<4096 or values[1]!=300:continue
                fid=self.u(p+4)
                value=dict(id=fid,name=name,size=values[0]/10,offset=p,name_end=end,resource_tag=self.u(p),
                           bold=bool(values[4]) if values[4] in (0,1) else None,
                           italic=bool(values[5]) if values[5] in (0,1) else None,
                           decoration_raw=list(values[6:]),decoration_status='not_calibrated',
                           attributes_offset=end+16)
                if str(fid) in self.fonts and self.fonts[str(fid)]['name']!=name:
                    self.fonts[str(fid)]['ambiguous']=True
                else:self.fonts[str(fid)]=value
            except (InvalidPackage,ValueError,IndexError,struct.error):continue
        for hit in re.finditer(re.escape(struct.pack('<II',1,105)),data):
            p=hit.start()-4
            if p<0 or data[p+20:p+28]!=struct.pack('<II',101,0) or data[p+32:p+40]!=M+b'\0'*4:continue
            try:
                name,_,end=pascal(data,p+42)
                if not name or not all(32<=ord(c)<127 for c in name) or not 0<=self.u(end)<128:continue
                cid=self.u(p+12);value=dict(id=cid,offset=p,name=name,rgb='#'+data[p+28:p+31].hex())
                if cid in self.palette and self.palette[cid]['rgb']!=value['rgb']:
                    self.palette[cid]['rgb']=None
                else:self.palette[cid]=value
            except (InvalidPackage,ValueError,IndexError,struct.error):continue
    def u(self,p):return struct.unpack_from('<I',self.data,p)[0]
    def s(self,p):return struct.unpack_from('<i',self.data,p)[0]

    def colour(self, p):
        assert self.u(p) == 101, (p, 'colour signature')
        kind, value = (self.u(p + 4), self.u(p + 8))
        if kind == 0 and self.data[p + 11] == 0:
            return dict(offset=p, kind='RGB', rgb=source_rgb(kind,value,self.palette), raw_value=value)
        if kind == 50 and value in self.palette:
            return dict(offset=p, kind='palette', palette_id=value, rgb=source_rgb(kind,value,self.palette), name=self.palette[value]['name'], palette_offset=self.palette[value]['offset'])
        return dict(offset=p, kind='uninterpreted', raw_kind=kind, raw_value=value, rgb=None)

    def rich_graphics(self, item):
        rt = item.get('richtext') or item.get('text_structure')
        if not rt or not rt.get('style_prelude_count'):
            return {'status': 'uninterpreted', 'reason': 'No bounded rich-text grammar'}
        p = rt['stream_end']
        nf = self.u(p)
        assert 0 < nf <= 128
        fonts = []
        for i in range(nf):
            q = p + 4 + 40 * i
            fid = self.u(q)
            assert str(fid) in self.fonts and not self.fonts[str(fid)].get('ambiguous'), ('Unresolved font resource',fid,q)
            assert self.data[q + 24:q + 28] == M, ('Invalid font slot envelope',q)
            size, asc, desc, flags = struct.unpack_from('<4H', self.data, q + 28)
            assert 0 < size < 4096
            resource=self.fonts[str(fid)]
            fonts.append(dict(slot=i, id=fid, name=resource['name'], size=size / 10, ascent_raw=asc, descent_raw=desc, metric_flags=flags, offset=q,
                              bold=resource.get('bold'),italic=resource.get('italic'),
                              decoration_raw=resource.get('decoration_raw'),decoration_status='not_calibrated',
                              resource_offset=resource['offset'],attributes_offset=resource['attributes_offset']))
        nc = rt['style_prelude_count']
        q = item['offset'] - (20 + 16 * (nc - 1))
        assert self.data[q:q + 4] == M and self.u(q + 4) == nc
        colors = [self.colour(q + 8)] + [self.colour(q + 24 + 16 * i) for i in range(nc - 1)]
        chars = []
        for part in item['parts']:
            chars.extend((part['offset'] + i for i in range(len(part['text']))))
        pending = []
        events = []
        unknown = []
        coords = []
        cursor = 0
        p = rt['stream_start']
        font = 0
        color = 0
        raw_cursor = item['offset'] + 8
    
        def flush(boundary):
            nonlocal font, color
            if not pending:
                return
            widths = {-62: 1, -63: 1, -384: 4}
            expected = sum((widths.get(op, 2) for op, _ in pending))
            slack = boundary - raw_cursor - expected
            field = raw_cursor
            for opcode, at in pending:
                if opcode not in (-62, -63):
                    field += widths.get(opcode, 2)
                    if opcode == -111 and slack == 1:
                        field += 1
                    continue
                value = self.data[field]
                count = nf if opcode == -62 else nc
                valid = 0 <= value < count and (slack == 0 or (slack == 1 and any((op == -111 for op, _ in pending))))
                event = dict(design_position=cursor, opcode=opcode, opcode_offset=at, field_offset=field, slot=value, valid=valid)
                if valid:
                    if opcode == -62:
                        font = value
                    else:
                        color = value
                    events.append(event)
                else:
                    unknown.append({**event, 'payload_slack': slack})
                field += 1
            pending.clear()
        arity = {-244: 1, -254: 1, -384: 3, -111: 1, -110: 1, -62: 0, -63: 0, -246: 1, -251: 1, -106: 1, -156: 1, -157: 1, -158: 1, -247: 1, -159: 1, -252: 1, -109: 1}
        styles = []
        while p < rt['stream_end']:
            at = p
            op = self.s(p)
            p += 4
            if op == -64:
                break
            if op >= 0 or op == -159:
                if cursor >= len(chars):
                    raise ValueError('glyph overflow')
                flush(chars[cursor])
                raw_cursor = chars[cursor] + 1
                styles.append((font, color))
                coords.append(op if op >= 0 else self.u(p))
                cursor += 1
                if op == -159:
                    p += 4
                continue
            assert op in arity, (at, op)
            args = [self.u(p + 4 * j) for j in range(arity[op])]
            p += 4 * arity[op]
            pending.append((op, at))
        assert cursor == len(chars)
        from .text_styles import paragraph_styles
        inline_breaks=[];superscripts=[];raised=None
        for control in rt.get('opaque_controls',[]):
            pos=control['design_position'];opcode=control['opcode']
            if opcode==-156 and 0<pos<len(chars) and chars[pos]-chars[pos-1]==3 and self.data[chars[pos]-2:chars[pos]]==b'\0\0':
                inline_breaks.append({'design_position':pos,'offset':control['offset'],'profile':'OBS-inline-line-break-v1'})
            elif opcode==-246 and control['arguments']==[9] and raised is None:
                raised={'start':pos,'offset':control['offset'],'profile':'OBS-raised-callout-v1'}
            elif opcode==-247 and control['arguments']==[9] and raised is not None:
                superscripts.append({**raised,'end':pos,'end_offset':control['offset']+8});raised=None
        if raised is not None:
            para=next((p for p in rt['paragraphs'] if p['start']<=raised['start']<p['end']),None)
            if para:superscripts.append({**raised,'end':para['end'],'end_offset':None})
        return dict(status='decoded' if not unknown else 'partial', fonts=fonts, colors=colors, style_events=events, styles=styles, coordinates=coords, unknown=unknown,
                    paragraphs=paragraph_styles(self.data,item,fonts),inline_breaks=inline_breaks,superscript_spans=superscripts)

    def cell_graphics(self, cell):
        p = cell['offset']
        mode = self.u(p + 17)
        q = p + 21
        result = dict(offset=p, raw_mode=mode, column=cell['column'], row=cell['row'], content_id=cell.get('content_id'), nested_table_id=cell.get('nested_table_id'))
        if mode == 0:
            span = self.u(q)
            tlv = p + 53
        elif 0 < mode < 32 and self.u(q) == 0 and (self.u(p + 25) == 101) and (self.data[p + 37:p + 41] == M):
            result['leading_color'] = self.colour(p + 25)
            result['leading_raw_style'] = self.u(p + 41)
            span = self.u(p + 45)
            tlv = p + 77
        else:
            result['status'] = 'uninterpreted'
            return result
        if not 0 < span < 256 or self.s(tlv) != -102 or self.u(tlv + 4) not in (36, 484):
            result['status'] = 'uninterpreted'
            return result
        a = tlv + 8
        length = self.u(tlv + 4)
        if a + length > len(self.data):
            return {**result, 'status': 'uninterpreted'}
        result.update(status='partial', column_span=span, property_offset=a, property_size=length, raw_sha256=hashlib.sha256(self.data[a:a + length]).hexdigest(), raw_hex=self.data[a:a + length].hex())
        if length == 36:
            return result
        result['edge_groups'] = []
        for i in range(4):
            q = a + 32 + 112 * i
            if (any(self.u(q + k) != 101 for k in (0, 16, 40, 60, 76, 100))
                or any(self.data[q + k:q + k + 4] != M for k in (28, 36, 56, 88, 96, 108))
                or self.u(q + 44) not in (1, 2, 4, 8) or self.u(q + 44) != self.u(q + 104)):
                result.update(status='uninterpreted', edge_groups=[])
                return result
            result['edge_groups'].append(dict(code=self.u(q + 44), first_mode=self.u(q + 12), first_color=self.colour(q + 16), second_mode=self.u(q + 72), second_color=self.colour(q + 76), raw_width=self.u(q + 92),
                pen_profile=self.u(q+64),line_pattern=self.u(q+68),offset=q))
        return result

    def backgrounds(self,units):
        headers=[]
        for match in re.finditer(re.escape(struct.pack('<I',113)),self.data):
            p=match.start()
            if p+148>len(self.data):continue
            if self.u(p+24)!=101 or self.u(p+48)!=101 or self.data[p+36:p+40]!=M or self.data[p+60:p+64]!=M:continue
            if self.u(p+20)not in (0,1) or not 0<self.u(p+100)<50000 or not 0<self.u(p+104)<50000:continue
            if (self.u(p+100),self.u(p+104))!=(self.u(p+140),self.u(p+144)):continue
            headers.append(p)
        grouped=collections.defaultdict(list);result={}
        for item in units:grouped[item['parent_id']].append(item)
        for items in grouped.values():
            previous_end=0
            for item in sorted(items,key=lambda x:x['offset']):
                n=bisect.bisect_left(headers,item['offset'])-1
                lower=max(previous_end,item.get('parent_offset',0))
                previous_end=max(e['offset_end']for e in item['evidence'])
                if n<0 or headers[n]<lower or not item.get('richtext'):continue
                p=headers[n]
                if p!=item['richtext']['outer_offset']+4:continue
                result[item['id']]=dict(header_offset=p,fill_flag=self.u(p+20),fill=self.colour(p+24)if self.u(p+20)==0 else None,
                    dimensions_raw=[self.u(p+100),self.u(p+104)],corner_radius_pub=None,
                    four_inset_candidates=[self.u(p+k)for k in range(124,140,4)],
                    header_sha256=hashlib.sha256(self.data[p:p+148]).hexdigest())
        return result

    def decode(self):
        units={};tables={};borders={};issues=[];text_boxes={}
        from .text_boxes import text_box_frame
        for item in self.model['content_units']:
            try:
                units[item['id']]=self.rich_graphics(item)
                frame=text_box_frame(self.data,item,self)
                if frame:text_boxes[item['id']]=frame
            except (AssertionError,ValueError,InvalidPackage,KeyError,IndexError,struct.error) as e:
                units[item['id']]={'status':'uninterpreted','reason':str(e)}
        for table in self.model['tables']:
            cells=[];axes={}
            for cell in table['cells']:
                try:cg=self.cell_graphics(cell)
                except (AssertionError,ValueError,IndexError,struct.error) as e:
                    cg={'offset':cell['offset'],'status':'uninterpreted','reason':str(e)}
                cells.append(cg)
                edges=cg.get('edge_groups',[])
                selected=[e for e in edges if e['code']==4 and e['second_mode']==2 and e['raw_width']==1]
                if (cg.get('raw_mode')==8 and cg.get('leading_raw_style')==2 and len(selected)==1
                    and all(e['raw_width']==0 for e in edges if e['code']!=4)):
                    color=selected[0]['second_color'].get('rgb')
                    if color and cg.get('leading_color',{}).get('rgb')==color:
                        borders[str(cell['offset'])]=dict(side='bottom',color=color,width_pt=.48,
                            evidence_offset=selected[0]['offset'],profile='OBS-cell-mode8-bottom-300dpi')
            for key in ('rows','columns'):
                axes[key]=[]
                for axis in table[key]:
                    try:axes[key].append(dict(index=axis['index'],offset=axis['offset'],dimension_raw=axis['raw_dimension'],
                        first_color=self.colour(axis['offset']+20),second_color=self.colour(axis['offset']+36),
                        raw_flags=[self.u(axis['properties_offset']+4+4*i)for i in range(12)]))
                    except (AssertionError,ValueError,KeyError,IndexError,struct.error):
                        axes[key].append(dict(index=axis['index'],offset=axis['offset'],status='uninterpreted'))
            tables[table['id']]={**axes,'cells':cells}
        from .table_styles import decode_table_styles
        styles = decode_table_styles(self.data, self.model, self)
        return dict(profile='PUB-graphics-0.12',source_sha256=hashlib.sha256(self.data).hexdigest(),fonts=self.fonts,palette=self.palette,
                    units=units,tables=tables,text_boxes=text_boxes,backgrounds=self.backgrounds(self.model['content_units']),borders=borders,
                    table_styles=styles['tables'], table_style_coverage=styles['coverage'])
