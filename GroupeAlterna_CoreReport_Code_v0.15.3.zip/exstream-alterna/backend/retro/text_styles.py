"""Bounded paragraph presentation; character ownership remains in scopes.py."""
import struct
from .binary import MARKER, u32, evidence
from .scopes import paragraph_prefix_length

ALIGNMENTS={0:'left',1:'right',2:'center',3:'justify'}
PROFILE='OBS-paragraph-presentation-300-v1'

def paragraph_styles(data,item,fonts=None):
    rt=item.get('richtext') or {};out=[]
    for para in rt.get('paragraphs',[]):
        p=dict(para);q=p.get('properties_offset');p['presentation_status']='uninterpreted'
        if q is not None:
            starts=[]
            for x in range(max(item.get('parent_offset',0),q-1200),q-119):
                if data[x+4:x+8]!=struct.pack('<I',108):continue
                if p['index']==0 and u32(data,x)!=len(rt['paragraphs']):continue
                if p['index']>0 and data[x:x+4]!=MARKER:continue
                length=paragraph_prefix_length(data,x)
                if length and x+length==q:starts.append(x)
            if len(starts)==1:
                x=starts[0];raw=u32(data,x+52)
                p.update(prefix_offset=x,alignment_raw=raw,alignment=ALIGNMENTS.get(raw),
                         presentation_status='decoded' if raw in ALIGNMENTS else 'partial',
                         evidence=[evidence(data,x,q+4,PROFILE)],
                         spacing_before_raw=u32(data,x+24),spacing_after_raw=u32(data,x+28),
                         indent_raw=[struct.unpack_from('<i',data,x+k)[0] for k in (8,12,16)],
                         bullet_mode_raw=u32(data,x+88))
                mode=p['bullet_mode_raw'];p['bullet']={'status':'none' if mode in (0,0xffffffff) else 'uninterpreted','mode':mode}
                # Counted custom glyph string, font slot and colour slot in the
                # paragraph prefix. Wingdings mapping: Unicode WG2 N4115, w-1167.
                if mode==1 and u32(data,x+92)==1 and q-x==125:
                    slot=u32(data,x+80);raw_glyph=data[x+96]
                    font=next((f for f in (fonts or []) if f['slot']==slot),None)
                    if font and font['name']=='Wingdings' and raw_glyph==0xa7:
                        p['bullet']={'status':'decoded','glyph':'▪','raw_glyph':raw_glyph,'font_slot':slot,
                                     'source_font':font['name'],'size_pt':font['size'],'render_font':'GlyphFallback',
                                     'font_substitution':True,'mapping':'Unicode-N4115-w1167-U25AA'}
                p['keep_with_next']=bool(u32(data,q+12)) if u32(data,q+12) in (0,1) else None
        out.append(p)
    apply_line_metrics(data,item,out)
    return out


def apply_line_metrics(data,item,paragraphs):
    """Bounded native line geometry; automatic wraps remain distinct from breaks."""
    rt=item.get('richtext') or item.get('text_structure') or {};p=rt.get('line_table_offset')
    if p is None:return
    n=rt['line_count'];limit=rt['stream_end'];body=item['offset']+8
    if not 1<n<65536 or p+4+44*n>limit or u32(data,p)!=n:return
    lines=[]
    for i in range(n):
        q=p+4+44*i
        start=u32(data,q);baseline=u32(data,q+4);top=u32(data,q+10);height=u32(data,q+14);width=u32(data,q+18)
        if start>u32(data,item['offset']+4) or max(baseline,top,height,width)>100000:return
        if lines and (start<lines[-1]['raw_start'] or top<lines[-1]['top']):return
        pos=sum(max(0,min(len(t['text']),body+start-t['offset'])) for t in item['parts'])
        lines.append({'raw_start':start,'start':pos,'baseline':baseline,'top':top,'height':height,'width':width})
    if lines[-1]['baseline']!=0 or lines[-1]['height']!=0:return
    for index,para in enumerate(paragraphs):
        own=[line for line in lines[:-1] if para['start']<=line['start']<para['end']]
        if not own:continue
        prior_after=paragraphs[index-1].get('spacing_after_raw',0) if index else 0
        effective_before=max(0,para.get('spacing_before_raw',0)-prior_after)
        heights=[line['height']-(effective_before if i==0 else 0)
                 -(para.get('spacing_after_raw',0) if i==len(own)-1 else 0) for i,line in enumerate(own)]
        if len(own)>1:
            heights=[b['baseline']-a['baseline'] for a,b in zip(own,own[1:])]
        if heights and min(heights)>0 and max(heights)-min(heights)<=2 and max(heights)<=500:
            para['leading_pt']=sorted(heights)[len(heights)//2]*.24
            para['line_metric_profile']='OBS-bounded-native-lines-300-v1'
        para['native_line_count']=len(own)
