"""Render decoded display commands at their source coordinates."""
from reportlab.platypus import Flowable
from reportlab.lib.colors import HexColor

class ObjectComposition(Flowable):
    def __init__(self,composition,width,font_resolver):
        super().__init__();self.composition=composition;self.resolve=font_resolver
        x,y,r,b=composition['bounds_raw'];self.scale=min(.24,width/(r-x))
        self.width=(r-x)*self.scale;self.height=(b-y)*self.scale
    def draw(self):
        c=self.canv;s=self.scale;x0,y0,x1,y1=self.composition['bounds_raw']
        c.saveState();c.scale(s,s)
        for obj in self.composition['objects']:
            for cmd in obj['commands']:
                kind=cmd['kind']
                if kind=='polygon':
                    p=c.beginPath();x,y=cmd['points'][0];p.moveTo(x-x0,y1-y)
                    for x,y in cmd['points'][1:]:p.lineTo(x-x0,y1-y)
                    p.close();c.setFillColor(HexColor(cmd['fill']));c.drawPath(p,stroke=0,fill=1)
                elif kind=='line':
                    (x,y),(r,b)=cmd['points']
                    c.setStrokeColor(HexColor(cmd['color']));c.setLineWidth(cmd['width_raw'])
                    c.line(x-x0,y1-y,r-x0,y1-b)
                elif kind=='text':
                    f=cmd['font'];c.setFont(self.resolve(f['name'],f.get('bold'),f.get('italic')),f['size']/.24)
                    c.setFillColor(HexColor(cmd['color']))
                    for ch,(x,y) in zip(cmd['text'],cmd['glyphs']):c.drawString(x-x0,y1-y,ch)
                elif kind=='image':
                    # Source extent is preserved. No unrelated image substitution.
                    x,y,r,b=cmd['rect'];c.saveState();c.setLineWidth(.5/s)
                    c.setStrokeColor(HexColor('#8d99a7'));c.setDash(2/s,2/s)
                    c.rect(x-x0,y1-b,r-x,b-y,stroke=1,fill=0);c.setDash()
                    c.line(x-x0,y1-y,r-x0,y1-b);c.line(x-x0,y1-b,r-x0,y1-y);c.restoreState()
        c.restoreState()
