"""Schéma d'audit versionné ; propriétés inconnues conservées explicitement."""
import json
from pathlib import Path
SCHEMA={
 '$schema':'https://json-schema.org/draft/2020-12/schema','$id':'urn:groupe-alterna:exstream:communication:1.0',
 'title':'CommunicationModel - observations partielles','type':'object',
 'required':['schema_version','engine_version','analysis_status','metadata','sources','definitions','inventory','strings','variables','mappings','rules','calculations','pages','blocks','tables','repeat_candidates','input_dictionary','unknowns','xsd'],
 'properties':{
  'schema_version':{'const':'1.0'},'engine_version':{'type':'string'},'analysis_status':{'const':'partial_not_validated'},
  'metadata':{'type':'object','required':['source_name','sha256','size','parser_profile','ordering','deterministic'],
    'properties':{'source_name':{'type':'string'},'sha256':{'type':'string','pattern':'^[0-9a-f]{64}$'},'size':{'type':'integer','minimum':256},'ordering':{'enum':['unknown','document_root_and_nested_counted_sections','partial_page_ownership_only']},'deterministic':{'const':True}}},
  'variables':{'type':'array','items':{'type':'object','required':['id','internal_id','name','source','type','cardinality','sample_value','evidence','warnings'],
     'properties':{'internal_id':{'type':'integer'},'type':{'type':['string','null']},'cardinality':{'enum':['Scalar','Array',None]},'evidence':{'$ref':'#/$defs/evidence_list'}}}},
  'mappings':{'type':'array','items':{'type':'object','required':['variable_id','xml_path','confidence','evidence'],
     'properties':{'xml_path':{'anyOf':[{'type':'null'},{'type':'string','pattern':'^/'}]},'evidence':{'$ref':'#/$defs/evidence_list'}}}},
  'rules':{'type':'array','items':{'type':'object','required':['id','compiled_id','variants','target','scope','target_candidates'],
     'properties':{'compiled_id':{'type':'integer'},'variants':{'type':'array','minItems':1}}}},
  'unknowns':{'type':'array','minItems':1},
  'xsd':{'type':'object','required':['available','reason'],'properties':{'available':{'const':False},'reason':{'type':'string','minLength':1}}},
 },
 '$defs':{'evidence_list':{'type':'array','minItems':1,'items':{'type':'object','required':['offset_start','offset_end','sha256','bytes_hex','decoder'],
    'properties':{'offset_start':{'type':'integer','minimum':0},'offset_end':{'type':'integer','minimum':1},'sha256':{'type':'string','pattern':'^[0-9a-f]{64}$'},'decoder':{'type':'string','minLength':1}}}}}
}
for field in ['sources','definitions','inventory','strings','calculations','pages','blocks','tables','repeat_candidates','input_dictionary']:
    SCHEMA['properties'][field]={'type':'array'}
SCHEMA['$defs']['token_scope']={
    'type':'object','required':['owner_object_id','owner_kind','parent_chain','rule_id','token_slices',
        'rule_reference_offset','owner_record_offset','scope_open_offset','confidence','confidence_reason','evidence',
        'composed_character_start','composed_character_end'],
    'properties':{
        'owner_kind':{'enum':['inline_run','text_paragraph']},
        'confidence':{'enum':['CERTAIN','TRÈS PROBABLE']},
        'evidence':{'$ref':'#/$defs/evidence_list'},
        'composed_character_start':{'type':'null'},'composed_character_end':{'type':'null'},
        'token_slices':{'type':'array','items':{'type':'object','required':[
            'token_index','token_id','kind','start_in_token','end_in_token','text','offset_start','offset_end']}}
    }}
SCHEMA['properties']['content_units']={'type':'array','items':{'type':'object','properties':{
    'rule_targets':{'type':'array','items':{'$ref':'#/$defs/token_scope'}}}}}
SCHEMA['$defs']['source_measure']={
    'type':'object','required':['raw','source_unit','cm','pt','offset','evidence'],
    'properties':{'raw':{'type':'integer','minimum':0},'source_unit':{'const':'1/300 inch'},
                  'cm':{'type':'number','minimum':0},'pt':{'type':'number','minimum':0},
                  'offset':{'type':'integer','minimum':0},'evidence':{'$ref':'#/$defs/evidence_list'}}}
SCHEMA['properties']['table_style_profile']={'type':'string'}
SCHEMA['properties']['table_style_coverage']={'type':'object','additionalProperties':{'type':'integer','minimum':0}}
SCHEMA['properties']['tables']['items']={'type':'object','properties':{
    'presentation':{'type':'object','required':['profile','status','columns','cells','limits'],
        'properties':{'columns':{'type':'array','items':{'type':'object','required':['index','status'],
            'properties':{'width':{'$ref':'#/$defs/source_measure'},'status':{'enum':['decoded','uninterpreted']}},
            'allOf':[{'if':{'properties':{'status':{'const':'decoded'}}},'then':{'required':['width']}}]}},
            'cells':{'type':'array'},'limits':{'type':'array'}}}}}

SCHEMA['properties']['data_sections']={'type':'array','items':{'type':'object',
    'required':['id','name','source_id','element_id','xml_path','bindings','evidence','usage_status'],
    'properties':{'xml_path':{'type':'string','pattern':'^/'},'evidence':{'$ref':'#/$defs/evidence_list'},
                  'usage_status':{'enum':['explicit_selector','within_referenced_xml_subtree','shared_source_no_binding_decoded']}}}}
SCHEMA['properties']['data_section_bindings']={'type':'array','items':{'type':'object',
    'required':['id','owner_kind','owner_id','data_section_name','data_section_id','candidate_ids','status','evidence'],
    'properties':{'owner_kind':{'enum':['section','document']},
                  'status':{'enum':['resolved','ambiguous','declaration_unresolved']},
                  'evidence':{'$ref':'#/$defs/evidence_list'}}}}
SCHEMA['properties']['rule_catalog_audit']={'type':'object','required':['definition_ids','compiled_rule_ids','inventory_reconciled','targeting_exhaustive'],
    'properties':{'targeting_exhaustive':{'const':False}}}

SCHEMA['$defs']['page_rectangle']={'type':'array','minItems':4,'maxItems':4,'items':{'type':'integer'}}
SCHEMA['properties']['page_layouts']={'type':'object','required':['profile','pages','resources'],
    'properties':{'profile':{'type':'string'},'resources':{'type':'object'},
      'pages':{'type':'array','items':{'type':'object','required':['page_id','name','status','objects','template_status','issues'],
        'properties':{'status':{'enum':['decoded','partial','uninterpreted']},'template_status':{'const':'unresolved'},
          'size_raw':{'type':'array','minItems':2,'maxItems':2,'items':{'type':'integer','exclusiveMinimum':0}},
          'units_per_inch':{'const':300},'objects':{'type':'array','items':{'type':'object',
            'required':['index','status','rule_id','images','units','evidence'],
            'properties':{'status':{'enum':['decoded','uninterpreted']},'rotation':{'enum':[0,-90,None]},
              'rect_raw':{'$ref':'#/$defs/page_rectangle'},'evidence':{'$ref':'#/$defs/evidence_list'}},
            'allOf':[{'if':{'properties':{'status':{'const':'decoded'}}},'then':{'required':['name','rect_raw','geometry_kind']}}]}}}}}}}

def validate_model(model):
    from jsonschema import Draft202012Validator
    Draft202012Validator(SCHEMA).validate(model)
    from .document_order import validate_application_document_order
    validate_application_document_order(model)
    from .document_flow import validate_document_flow
    validate_document_flow(model)
    if 'content_integrity' in model:
        from .content_integrity import validate_content
        validate_content(model)
    size=model['metadata']['size'];ids={v['id'] for v in model['variables']}
    for m in model['mappings']:
        if m['variable_id'] not in ids:raise ValueError('Unresolved mapping')
    sections={s['id']:s for s in model.get('data_sections',[])}
    owners={d['id'] for d in model.get('documents',[])}|{s['id'] for s in model.get('document_sections',[])}
    for b in model.get('data_section_bindings',[]):
        if b['owner_id'] not in owners:raise ValueError('Unresolved data-section owner')
        if b['status']=='resolved' and (b['data_section_id'] not in sections or b['candidate_ids']!=[b['data_section_id']]):raise ValueError('Unresolved data-section binding')
        if b['status']!='resolved' and b['data_section_id'] is not None:raise ValueError('Ambiguous data-section binding promoted')
    def walk(value):
        if isinstance(value,dict):
            if 'offset_start' in value and not 0<=value['offset_start']<value['offset_end']<=size:raise ValueError('Invalid evidence bounds')
            for child in value.values():walk(child)
        elif isinstance(value,list):
            for child in value:walk(child)
    walk(model)
    for unit in model.get('content_units',[]):
        parts=unit['parts']
        for target in unit.get('rule_targets',[]):
            if not target.get('evidence') or not target.get('confidence_reason'):raise ValueError('Unjustified scope')
            if target.get('composed_character_start') is not None or target.get('composed_character_end') is not None:raise ValueError('Invented composed position')
            if target['owner_kind'] not in ('inline_run','text_paragraph'):raise ValueError('Unknown scope owner')
            for span in target['token_slices']:
                i=span['token_index']
                if not 0<=i<len(parts):raise ValueError('Invalid target token')
                part=parts[i];a=span['start_in_token'];b=span['end_in_token']
                if not 0<=a<b<=len(part['text']) or span['text']!=part['text'][a:b] or span['token_id']!=part['id']:raise ValueError('Invalid target boundaries')
                if part['kind']=='variable' and (a!=0 or b!=len(part['text'])):raise ValueError('Split variable target')
if __name__=='__main__':
    Path('docs/communication.schema.json').write_text(json.dumps(SCHEMA,ensure_ascii=False,indent=2))
