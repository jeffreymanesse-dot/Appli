from .i18n import tr, note
"""Counted application references and a presentation of established relations."""
import struct
from .binary import occurrences, pascal, u32, evidence, InvalidPackage
from .layout import sig


def application_graph(data, model):
    docs = {d['internal_id']: d for d in model['definitions'] if d['class_code'] == 10}
    data_files = {d['internal_id']: d for d in model['definitions'] if d['class_code'] == 15}
    queues = {d['internal_id']: d for d in model['definitions'] if d['class_code'] == 2}
    applications = []
    common = struct.pack('<IIIIIIIIIII', 0, 0, 2, 102, 0, 103, 4, 0, 104, 4, 0)
    # The application header does not use the object marker of ordinary definitions.
    for q in occurrences(data, struct.pack('<II', 104, 1)):
        try:
            name, _, end = pascal(data, q + 12)
            if not name.startswith('APP_') or data[end:end+44] != common:
                continue
            if data[end+44:end+52] not in (sig(135), sig(136)):
                continue
            app = {'id': '1:' + str(u32(data, q+8)), 'name': name, 'offset': q,
                   'document_ids': [], 'relation_status': 'unresolved',
                   'evidence': [evidence(data, q, end+52, 'OBS-application-header-v1')]}
            # Counted opaque selector list precedes the document list. Its
            # values are preserved without assigning an execution meaning.
            n = u32(data, end+162)
            pos = end+166+4*n
            if n <= 256 and pos+4 <= len(data):
                count = u32(data, pos)
                stop = pos+4+count*4
                if 0 < count <= 1000 and stop+4 <= len(data):
                    ids = [u32(data, pos+4+4*i) for i in range(count)]
                    if len(set(ids)) == count and all(i in docs for i in ids):
                        app.update(document_ids=[docs[i]['id'] for i in ids],
                                   relation_status='counted_references', confidence='TRÈS PROBABLE',
                                   opaque_selectors=[u32(data, end+166+4*i) for i in range(n)])
                        app['evidence'].append(evidence(data, end+162, stop, 'OBS-application-documents-counted-v1'))
                        if stop+4<=len(data):
                            queue_count=u32(data,stop);queue_stop=stop+4+4*queue_count
                            if 0<=queue_count<=1000 and queue_stop+4<=len(data):
                                queue_ids=[u32(data,stop+4+4*i) for i in range(queue_count)]
                                file_count=u32(data,queue_stop);file_stop=queue_stop+4+4*file_count
                                if (len(set(queue_ids))==queue_count and all(i in queues for i in queue_ids)
                                        and 0<file_count<=1000 and file_stop<=len(data)):
                                    file_ids=[u32(data,queue_stop+4+4*i) for i in range(file_count)]
                                    if len(set(file_ids))==file_count and all(i in data_files for i in file_ids):
                                        app['output_queue_ids']=[queues[i]['id'] for i in queue_ids]
                                        app['data_file_ids']=[data_files[i]['id'] for i in file_ids]
                                        app['data_file_reference_status']='counted_references'
                                        app['evidence'].append(evidence(data,stop,file_stop,'OBS-application-data-files-counted-v1'))
            applications.append(app)
        except (InvalidPackage, UnicodeError, struct.error):
            continue
    model['applications'] = applications
    app_files={ident for app in applications for ident in app.get('data_file_ids',[])}
    for source in model.get('data_files',[]):
        source['application_referenced']=source['id'] in app_files


def hierarchy_rows(model):
    """Retain section instances and sibling order, without invented page parents."""
    definitions = {d['id']: d for d in model.get('definitions', [])}
    documents = {d['id']: d for d in model.get('documents', [])}
    sections = {s['id']: s for s in model.get('document_sections', [])}
    campaigns = {c['id']: c for c in model.get('campaigns', [])}
    page_instances={}
    for c in model.get('page_component_instances',[]):page_instances.setdefault(c['page_id'],[]).append(c)
    page_rules={}
    for a in model.get('page_analysis',{}).get('rule_uses',[]):page_rules.setdefault(a['page_id'],[]).append(a['compiled_id'])
    rows = []
    used_documents, used_pages, used_paragraphs, used_campaigns = set(), set(), set(), set()

    def row(depth, kind, name, note='', object_id=None):
        rows.append({'depth': depth, 'kind': kind, 'name': name, 'note': note, 'object_id': object_id})

    def member(ident, depth, ordinal, stack=()):
        d = definitions.get(ident)
        if ident in stack:
            row(depth, 'Référence', ident, 'Cycle détecté ; développement arrêté', ident)
            return
        if ident in sections:
            s = sections[ident]
            row(depth, 'Section', s['name'], f'Position {ordinal}', ident)
            for item in s['members']:
                member(item['target_id'], depth+1, item['ordinal']+1, stack+(ident,))
        elif d and d['class_code'] == 21:
            used_paragraphs.add(ident)
            row(depth, 'Paragraphe', d['name'], f'Position {ordinal}', ident)
        else:
            row(depth, 'Référence non résolue', d['name'] if d else ident,
                f'Position {ordinal} ; contenu ou relation non décodé', ident)

    def document(ident, depth, ordinal=None):
        used_documents.add(ident)
        d = documents.get(ident)
        name = (d or definitions.get(ident, {})).get('name', ident)
        row(depth, 'Document', name, f'Position {ordinal}' if ordinal else 'Rattachement à une application non établi', ident)
        if not d:
            row(depth+1, 'Limite', 'Sections et première page non décodées')
            return
        pages = d.get('page_ids') or ([d['first_page_id']] if d.get('first_page_id') else [])
        for page_index,page in enumerate(pages):
            used_pages.add(page)
            page_kind='Page initiale' if page_index==0 else 'Page de débordement' if d.get('page_flow_status')=='resolved' else 'Page référencée'
            row(depth+1,page_kind,definitions.get(page,{}).get('name',page),object_id=page)
        for index, sid in enumerate(d.get('root_section_ids', []), 1):
            member(sid, depth+1, index)

    def campaign(ident, depth):
        c=campaigns[ident];used_campaigns.add(ident)
        row(depth,'Campagne',c['name'],object_id=ident)
        for message in c['message_ids']:
            used_paragraphs.add(message)
            row(depth+1,'Message',definitions[message]['name'],object_id=message)

    for app in model.get('applications', []):
        row(0, 'Application', app['name'],
            '' if app.get('document_ids') else 'Liens vers les documents non décodés', app['id'])
        for ordinal, ident in enumerate(app.get('document_ids', []), 1):
            document(ident, 1, ordinal)
        for ident in app.get('campaign_ids', []):
            if ident in campaigns:campaign(ident,1)
    if not model.get('applications'):
        row(0, 'Application', 'Nom non décodé')
    for d in model.get('definitions', []):
        if d['class_code'] == 10 and d['id'] not in used_documents:
            document(d['id'], 0)
    if not used_documents:
        row(0, 'Document', 'Aucune relation documentaire décodée')
    other_pages = [p for p in model.get('page_components', []) if p['id'] not in used_pages]
    if other_pages:
        row(0, 'Autres composants de page', '')
        for p in other_pages:
            row(1, 'Page', p['name'], object_id=p['id'])
    for ident in campaigns:
        if ident not in used_campaigns:campaign(ident,0)
    other_paragraphs = [d for d in model.get('definitions', [])
                        if d['class_code'] == 21 and d['id'] not in used_paragraphs]
    if other_paragraphs:
        row(0, 'Autres composants de paragraphe', '')
        for d in other_paragraphs:
            row(1, 'Paragraphe', d['name'], object_id=d['id'])
    return rows


def append_hierarchy(story, rows, colors):
    from xml.sax.saxutils import escape
    from reportlab.lib.styles import ParagraphStyle
    from reportlab.platypus import Paragraph, CondPageBreak
    title = ParagraphStyle('hierarchy-title', fontName='AlternaBold', fontSize=12, leading=16,
                           textColor=colors['primary'], spaceBefore=12, spaceAfter=8, keepWithNext=True)
    note_style = ParagraphStyle('hierarchy-note', fontName='Alterna', fontSize=8, leading=11,
                          textColor=colors['navy'], spaceAfter=8)
    story.extend([CondPageBreak(95), Paragraph(tr('Structure de l’application'), title)])
    for i, row in enumerate(rows):
        style = ParagraphStyle('hierarchy-row', parent=note_style, leftIndent=min(row['depth'], 12)*12,
                               fontSize=8.2, leading=11.5, spaceBefore=2, spaceAfter=2,
                               keepWithNext=bool(i+1 < len(rows) and rows[i+1]['depth'] > row['depth']))
        kind = tr(row['kind']); detail = note(row.get('note', ''))
        if detail.startswith('Position ') and detail[9:].isdigit():
            kind += ' '+detail[9:]; detail = ''
        text = '<b>'+escape(kind)+'</b>'
        if row['name']:text += ' : '+escape(row['name'] if row.get('object_id') else note(row['name']))
        if detail:
            text += '<br/><font size="7.3">'+escape(detail)+'</font>'
        story.append(Paragraph(text, style))
