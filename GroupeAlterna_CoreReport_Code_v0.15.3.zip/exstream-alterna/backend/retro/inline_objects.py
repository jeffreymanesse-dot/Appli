"""Bind a counted inline object to its independent frame and rich-text owner.

This bounded singleton directory profile does not assign objects by name or
nearest text. Its count, opcode index, dimensions and full frame chain agree.
"""
import struct
from .binary import evidence, u32
from .table_frames import object_frame_owner


def empty_object_anchors(data, unit):
    rt=unit.get('richtext') or {};controls=rt.get('opaque_controls',[])
    result=[]
    for i,c in enumerate(controls[:-1]):
        end=controls[i+1]
        if (c['opcode']!=-251 or end['opcode']!=-106 or end['arguments']!=[0]
            or end['offset']!=c['offset']+8):continue
        matches=[p for p in rt.get('paragraphs',[]) if p['start']==p['end']==c['design_position']
            and data[p['offset']:p['offset']+8]==struct.pack('<ii',-244,p['index'])
            and p['offset']+8<=c['offset']<=p['offset']+16
            and all(x[0] in (-62,-63) for x in struct.iter_unpack('<i',data[p['offset']+8:c['offset']]))]
        if len(matches)!=1:continue
        if data[c['offset']:end['offset']+8]!=struct.pack('<4i',-251,c['arguments'][0],-106,0):continue
        result.append((c['arguments'][0],matches[0],c,end))
    return result


def decode_inline_objects(data, model):
    units=model.get('content_units',[]);rules={r['compiled_id']:r for r in model['rules']}
    for owner in units:
        if owner.get('grid_id'):continue
        anchors=empty_object_anchors(data,owner);rt=owner.get('richtext') or {}
        if len(anchors)!=1 or anchors[0][0]!=0:continue
        end_rules=rt['rule_list_offset']+8+4*len(rt['rule_ids'])
        if data[end_rules:end_rules+40]!=bytes(20)+struct.pack('<I',5)+bytes(12)+struct.pack('<I',1):continue
        q=end_rules+40
        if q+32>len(data) or u32(data,q)!=14:continue
        x,b,h,w=struct.unpack_from('<4i',data,q+8)
        if not (0<w<100000 and 0<h<100000):continue
        matches=[]
        for child in units:
            if child['parent_id']!=owner['parent_id'] or child.get('grid_id') or child['offset']<=q:continue
            outer=(child.get('richtext') or {}).get('outer_offset')
            if outer is None:continue
            frame=object_frame_owner(data,outer+4,object_types=(8,9))
            if frame is None or frame<=q:continue
            if list(struct.unpack_from('<4i',data,frame+20))!=[x,b-h,x+w,b]:continue
            if list(struct.unpack_from('<2i',data,frame+245))!=[w,h]:continue
            matches.append((child,frame))
        if len(matches)!=1:continue
        child,frame=matches[0];index,paragraph,start,end=anchors[0]
        ev=[evidence(data,end_rules,q+32,'OBS-single-inline-framed-object-v1'),
            evidence(data,frame,child['offset'],'OBS-single-inline-framed-object-v1'),
            evidence(data,paragraph['offset'],end['offset']+8,'OBS-single-inline-framed-object-v1')]
        child['inline_object_anchor']={'content_id':owner['id'],'paragraph_index':paragraph['index'],
            'object_index':index,'rect_raw':[x,b-h,x+w,b],'evidence':ev}
        ids=list(dict.fromkeys(t['rule_id'] for t in owner.get('rule_targets',[]) if
            t['kind']=='text_paragraph' and t['text_paragraph_index']==paragraph['index']))
        child['inline_object_rule_ids']=ids
        for rid in ids:
            assoc={'kind':'inline_object','paragraph_id':owner['parent_id'],'content_id':child['id'],
                'anchor_content_id':owner['id'],'text_paragraph_index':paragraph['index'],
                'rule_id':rid,'evidence':ev,'scope_resolved':True}
            rules[rid].setdefault('associations',[]).append(assoc)
            rules[rid].setdefault('targets',[]).append(assoc)
