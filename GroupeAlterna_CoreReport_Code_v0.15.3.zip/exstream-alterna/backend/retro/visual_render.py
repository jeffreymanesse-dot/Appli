from .i18n import tr, note
"""A second, standalone PDF reconstructed from the current package only."""
from pathlib import Path
import json,re,collections,hashlib,threading
from xml.sax.saxutils import escape
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import SimpleDocTemplate,Paragraph,Table,TableStyle,Spacer,PageBreak,Flowable,CondPageBreak,KeepTogether
from reportlab.lib.pagesizes import A4
from . import __version__
from .scoped_borders import ScopedBorderTable, scoped_lines
ROOT=Path(__file__).resolve().parents[2]
BLUE=colors.HexColor('#00008f');GREY=colors.HexColor('#69747f');PALE=colors.HexColor('#e8ebef')
FONT_LOCK=threading.RLock()

def rounded_cell_path(canv, x, y, w, h, radius, kind):
    """Bezier corners selected by the source shape; radius is a display estimate."""
    r = min(radius, w / 2, h / 2)
    left = r if kind in ('rounded', 'rounded_left') else 0
    right = r if kind in ('rounded', 'rounded_right') else 0
    k = 0.5522847498307936
    p = canv.beginPath(); p.moveTo(x + left, y); p.lineTo(x + w - right, y)
    p.curveTo(x+w-right+k*right,y,x+w,y+right-k*right,x+w,y+right)
    p.lineTo(x+w,y+h-right)
    p.curveTo(x+w,y+h-right+k*right,x+w-right+k*right,y+h,x+w-right,y+h)
    p.lineTo(x+left,y+h)
    p.curveTo(x+left-k*left,y+h,x,y+h-left+k*left,x,y+h-left)
    p.lineTo(x,y+left)
    p.curveTo(x,y+left-k*left,x+left-k*left,y,x+left,y)
    p.close(); return p
def setup_fonts():
    with FONT_LOCK:
        for weight in ('Regular','Bold','Light'):
            if 'SSP'+weight not in pdfmetrics.getRegisteredFontNames():
                pdfmetrics.registerFont(TTFont('SSP'+weight,str(ROOT/f'assets/fonts/SourceSansPro-{weight}.ttf')))
        if 'GlyphFallback'not in pdfmetrics.getRegisteredFontNames():
            pdfmetrics.registerFont(TTFont('GlyphFallback','/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'))
        for suffix,file in (('Regular','DejaVuSans.ttf'),('Bold','DejaVuSans-Bold.ttf'),('Italic','DejaVuSans-Oblique.ttf'),('BoldItalic','DejaVuSans-BoldOblique.ttf')):
            if 'SourceFallback'+suffix not in pdfmetrics.getRegisteredFontNames():
                pdfmetrics.registerFont(TTFont('SourceFallback'+suffix,str(ROOT/'assets/fonts/fallback'/file)))
        pdfmetrics.registerFontFamily('SSPRegular',normal='SSPRegular',bold='SSPBold',italic='SourceFallbackItalic',boldItalic='SourceFallbackBoldItalic')

def normalized_variable(name):
    return re.sub(r'(?i)(jpg|seg)ph$','GraphicPh',name)

STY = {'body': ParagraphStyle('body', fontName='SSPRegular', fontSize=10, leading=13.5, spaceAfter=7), 'small': ParagraphStyle('small', fontName='SSPRegular', fontSize=8, leading=10.5, textColor=GREY, spaceAfter=5), 'title': ParagraphStyle('title', fontName='SSPBold', fontSize=25, leading=28, textColor=BLUE, spaceAfter=14), 'heading': ParagraphStyle('heading', fontName='SSPBold', fontSize=11, leading=14, textColor=BLUE, spaceAfter=8, keepWithNext=True), 'technical': ParagraphStyle('technical', fontName='SSPRegular', fontSize=7, leading=9, textColor=GREY, spaceAfter=6, keepWithNext=True, splitLongWords=True)}

class ReservedGraphic(Flowable):
    """No word inside the image zone. Crossed frame is an annotation convention."""

    def __init__(self, width, height, uid):
        Flowable.__init__(self)
        self.width = max(12, width)
        self.height = max(16, min(height, 85))
        self.uid = uid

    def draw(self):
        c = self.canv
        c.saveState()
        c.setStrokeColor(colors.HexColor('#8d99a7'))
        c.setFillColor(colors.HexColor('#f5f7fa'))
        c.setLineWidth(0.55)
        c.setDash(3, 2)
        c.rect(0, 0, self.width, self.height, fill=1, stroke=1)
        c.setDash()
        c.setStrokeColor(colors.HexColor('#c1cad4'))
        c.line(0, 0, self.width, self.height)
        c.line(0, self.height, self.width, 0)
        c.restoreState()

class SourceWidthFlowable(Flowable):
    """Keep a source width while allowing ordinary text to split across pages."""
    def __init__(self,flow,width):
        super().__init__();self.flow=flow;self.source_width=width
        self.spaceBefore=flow.getSpaceBefore();self.spaceAfter=flow.getSpaceAfter()
        self.keepWithNext=flow.getKeepWithNext()
    def wrap(self,availWidth,availHeight):
        self.width,self.height=self.flow.wrap(min(self.source_width,availWidth),availHeight)
        return self.width,self.height
    def split(self,availWidth,availHeight):
        return [SourceWidthFlowable(f,self.source_width) for f in self.flow.split(min(self.source_width,availWidth),availHeight)]
    def draw(self):self.flow.drawOn(self.canv,0,0)


class VisualRenderer:
    def __init__(self,model,*,language="fr",rule_labels=None):
        from .i18n import normalize_language
        self.language=normalize_language(language)
        self.rule_labels=rule_labels or {}
        setup_fonts()
        self.MODEL=model;self.G=model['graphics']
        self.UNITS={u['id']:u for u in model['content_units']}
        self.PS={p['id']:p for p in model['paragraphs']}
        self.PS.update({p['id']:p for p in model.get('visual_page_containers',[])})
        self.GRIDS={t['id']:t for t in model['tables']}
        self.COMPOSITIONS={c['id']:c for c in model.get('object_compositions',[])}
        self.ANCHORS={(t['inline_anchor']['content_id'],t['inline_anchor']['paragraph_index']):t['id'] for t in model['tables'] if t.get('inline_anchor')}
        self.OBJECT_ANCHORS={(u['inline_object_anchor']['content_id'],u['inline_object_anchor']['paragraph_index']):u['id'] for u in model['content_units'] if u.get('inline_object_anchor')}
        self.W=508;self.PLACED=[];self.WARNINGS=[];self.SPLITS=[];self.RUNS=[]
        self.calibration=model.get('calibration')
        self.NATIVE={'backgrounds':self.G['backgrounds'],'borders':self.G['borders'],
            'example':{'rounded_fill_calibration':self.calibration.get('rounded_fill_calibration')if self.calibration else None}}
        self.TABLE_STYLES = self.G.get('table_styles', {})
        self.CELL_STYLES = {c['offset']: c for t in self.TABLE_STYLES.values() for c in t['cells']}
        self.UNIT_STYLES = {c['content_id']: c for c in self.CELL_STYLES.values() if c.get('content_id')}
        self.TABLE_LAYOUTS = []; self.ESTIMATED_ROUNDS = set()

    def footer(self,c,doc):
        c.saveState();c.setFont('SSPRegular',6.5);c.setFillColor(GREY)
        c.drawString(43.5,23,tr('Visuel de conception - moteur ')+__version__)
        c.drawRightString(A4[0]-43.5,23,str(doc.page));c.restoreState()

    def render(self,path):
        from .i18n import use_language
        with use_language(self.language):return self._render(path)

    def _render(self,path):
        occurrences,removed=self.occurrence_projection();story=[];previous_document=None
        kept=[o['source_id'] for o in occurrences]
        # PAGE contents remain in the analysis and the main report appendix.
        # This standalone visual contains only the reconstructed letter flow.
        page_ids={p['id'] for p in self.MODEL.get('visual_page_containers',[])}-set(kept)
        excluded_page_units={uid for uid,u in self.UNITS.items() if u['parent_id'] in page_ids}
        occurrence_errors=[]
        for occurrence in occurrences:
            pid=occurrence['source_id'];document=occurrence['source_document_id']
            if story and previous_document is not None and document!=previous_document:
                self.page_break(story)
            previous_document=document
            start=len(self.PLACED)
            story.extend(self.clean_section(pid))
            actual=collections.Counter(self.PLACED[start:])
            expected=collections.Counter(u['id'] for u in self.UNITS.values() if u['parent_id']==pid)
            if actual!=expected:
                occurrence_errors.append({'occurrence_id':occurrence['occurrence_id'],
                    'missing':list((expected-actual).elements()),'duplicates':list((actual-expected).elements())})
        if not story:
            story.append(self.p(tr('Aucun contenu visuel rattaché à un courrier n’a pu être reconstruit à partir des structures reconnues de ce package.')))
        doc=SimpleDocTemplate(str(path),pagesize=A4,leftMargin=43.5,rightMargin=43.5,topMargin=35,bottomMargin=40,
            title=tr('Visuel du courrier - reconstruction de conception'),author='Groupe Alterna')
        doc.build(story,onFirstPage=self.footer,onLaterPages=self.footer)
        excluded={r['removed_id']for r in removed}-set(kept)
        expected=set(self.UNITS)
        intentionally_removed={u['id']for u in self.UNITS.values()if u['parent_id']in excluded}|excluded_page_units
        missing=expected-intentionally_removed-set(self.PLACED)
        visits=collections.Counter(kept)
        expected_counts=collections.Counter({uid:visits.get(u['parent_id'],1)
            for uid,u in self.UNITS.items() if uid not in intentionally_removed})
        actual_counts=collections.Counter(self.PLACED)
        duplicates=list((actual_counts-expected_counts).elements())
        if missing or duplicates or occurrence_errors or expected_counts-actual_counts:
            raise ValueError('Visual coverage mismatch: '+str({'missing':sorted(missing),
                'duplicates':duplicates,'occurrences':occurrence_errors,'missing_occurrences':list((expected_counts-actual_counts).elements())}))
        return dict(pages=doc.page,units_source=len(expected),units_rendered=len(set(self.PLACED)),
            unit_occurrences_rendered=len(self.PLACED),paragraph_occurrences=occurrences,occurrence_errors=occurrence_errors,
            removed_paragraphs=removed,page_duplicates=[],excluded_page_units=sorted(excluded_page_units),
            intentionally_removed_units=sorted(intentionally_removed),
            missing=sorted(missing),duplicate_placements=duplicates,long_paragraphs=self.WARNINGS,split_rows=self.SPLITS,
            calibrated_rounding=bool(self.calibration), table_layouts=self.TABLE_LAYOUTS,
            estimated_corner_radius_pt=3, estimated_rounding_units=sorted(self.ESTIMATED_ROUNDS),
            table_style_coverage=self.G.get('table_style_coverage', {}))

    @staticmethod
    def page_break(story):
        # Trailing whitespace has no ink to preserve across a forced boundary.
        # A native minimum-height spacer alone must not create an empty page.
        while story and isinstance(story[-1],Spacer):story.pop()
        if story:story.append(PageBreak())

    def p(self, text, sty='body'):
        return Paragraph(escape(text).replace('\n', '<br/>'), STY[sty])

    def source_font(self, name, bold=None, italic=None):
        if name.startswith('Wingdings'):
            return 'GlyphFallback'
        bold=bool(bold) or any(k in name.lower() for k in ('bold','demi'))
        italic=bool(italic) or any(k in name.lower() for k in ('italic','oblique'))
        if name.startswith('Source Sans Pro ') and not italic:
            return 'SSPBold' if bold else 'SSPLight' if name.endswith('Light') else 'SSPRegular'
        return 'SourceFallback'+('BoldItalic' if bold and italic else 'Bold' if bold else 'Italic' if italic else 'Regular')

    def rule_mark(self, rid, close=False):
        if not self.rule_labels:
            return '<font color="#536476">'+('] ' if close else '[')+'</font>'
        return '<super><font name="SSPRegular" size="6" color="#087E8B">['+('/' if close else '')+escape(self.rule_labels.get(rid,'rule'+str(rid)))+']</font></super>'

    def is_picture(self, unit):
        names = unit.get('variable_names', [])
        return bool(names) and all((re.search('(?:JpgPh|SegPh|jpgPh|segPh)$', n or '') for n in names)) and all((t['kind'] == 'variable' or not t['text'].strip() for t in unit['parts']))

    def ruled_object(self, flows, rule_ids):
        ids=list(dict.fromkeys(rule_ids))
        if not self.rule_labels or not ids:return flows
        return [Paragraph(' '.join(self.rule_mark(r) for r in ids),STY['small']),
            *flows,Paragraph(' '.join(self.rule_mark(r,True) for r in reversed(ids)),STY['small'])]

    def calibrated_background(self, uid):
        if uid in self.UNIT_STYLES:
            bg = self.UNIT_STYLES[uid]['background']
            return bg if bg.get('status') == 'decoded' else None
        if not self.NATIVE:
            return None
        bg = self.NATIVE['backgrounds'].get(uid, {})
        return bg.get('fill')

    def fill_command(self, uid, start, end):
        fill = self.calibrated_background(uid)
        if not fill or not fill.get('rgb'):
            return None
        rgb = fill['rgb']
        profile = self.NATIVE['example']['rounded_fill_calibration']
        shape = self.UNIT_STYLES.get(uid, {}).get('shape', {})
        kind = shape.get('kind') if shape.get('status') == 'decoded' else None
        radius = profile['radius_pt'] if not kind and profile and rgb == profile['rgb'] else 0
        if kind in ('rounded', 'rounded_left', 'rounded_right'):
            self.ESTIMATED_ROUNDS.add(uid)
    
        def paint(table, canv, x, y, w, h):
            canv.saveState()
            canv.setFillColor(colors.HexColor(rgb))
            yy = min(y, y + h)
            hh = abs(h)
            if kind in ('rounded', 'rounded_left', 'rounded_right'):
                canv.drawPath(rounded_cell_path(canv,x,yy,w,hh,3,kind),fill=1,stroke=0)
            elif radius:
                template = profile['path_template']
                rect = template['rect']
                tw = rect[2] - rect[0]
                th = rect[3] - rect[1]
                scale = min(1, w / (2 * radius), hh / (2 * radius))
                path = canv.beginPath()
                for index, (px, py) in enumerate(template['polygon_points']):
                    xx = px * scale if px < tw / 2 else w - (tw - px) * scale
                    ydown = py * scale if py < th / 2 else hh - (th - py) * scale
                    if index == 0:
                        path.moveTo(x + xx, yy + hh - ydown)
                    else:
                        path.lineTo(x + xx, yy + hh - ydown)
                path.close()
                canv.drawPath(path, fill=1, stroke=0)
            else:
                canv.rect(x, yy, w, hh, fill=1, stroke=0)
            canv.restoreState()
        return ('BACKGROUND', start, end, paint)

    def decorated_text(self, uid, width):
        obj=self.G.get('text_boxes',{}).get(uid)
        native=self.NATIVE['backgrounds'].get(uid,{})
        dims=native.get('dimensions_raw') or []
        rt=self.UNITS[uid].get('richtext') or {}
        if any(c['opcode'] in (-251,-106) for c in rt.get('opaque_controls',[])):
            # Parent geometry includes anchored children, rendered separately.
            # Reserving that full height here would count their height twice.
            dims=[]
        if obj:width=min(width,obj['width_pt'])
        elif len(dims)==2:width=min(width,dims[0]*.24)
        frame=(obj or {}).get('frame',{})
        command = self.fill_command(uid, (0, 0), (0, 0))
        framed=frame.get('renderable',False)
        padding=obj['uniform_padding_pt'] if obj and obj.get('uniform_padding_pt') is not None else 2.5
        items = self.text_flow(uid, max(1,width-2*padding) if command or framed else width)
        minimum=obj['height_pt'] if obj else dims[1]*.24 if len(dims)==2 else 0
        if not command and not framed and not dims:return items
        if not command and not framed:
            height=self.height_of(items,width)
            return [SourceWidthFlowable(item,width) for item in items]+([Spacer(1,minimum-height)] if height<minimum<=570 else [])
        # Preserve the design extent as a minimum, never clip expanded variables.
        minimum=minimum if 0<=minimum<=570 else 0
        table = Table([[items]], colWidths=[width], minRowHeights=[minimum], hAlign='LEFT', splitInRow=0)
        commands=[('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),padding),
                  ('RIGHTPADDING',(0,0),(-1,-1),padding),('TOPPADDING',(0,0),(-1,-1),padding if obj else 3),
                  ('BOTTOMPADDING',(0,0),(-1,-1),padding if obj else 3)]
        if command:commands.append(command)
        if framed:commands.append(('BOX',(0,0),(-1,-1),frame['thickness']['pt'],colors.HexColor(frame['color']['rgb'])))
        table.setStyle(TableStyle(commands))
        return [table]

    def text_flow(self, uid, width):
        unit = self.UNITS[uid]
        gx = self.G['units'].get(uid, {})
        self.PLACED.append(uid)
        if self.is_picture(unit):
            height = 30
            if unit.get('grid_id') in self.GRIDS:
                grid = self.GRIDS[unit['grid_id']]
                row = unit.get('grid_position', {}).get('row', 0)
                height = grid['rows'][row]['raw_dimension'] * 0.24
            flows=[ReservedGraphic(min(width, 180), height, uid)]
            if self.rule_labels:
                flows.append(self.p(tr('Image : ')+', '.join('['+n+']' for n in unit['variable_names']),'small'))
            ids=unit.get('row_rule_ids',[])+[unit[k] for k in ('row_rule_id','column_rule_id') if unit.get(k)]
            ids += [t['rule_id'] for t in unit.get('rule_targets',[]) if t.get('token_slices')]
            return self.ruled_object(flows,ids)
        parts = unit['parts']
        rt = unit.get('richtext') or unit.get('text_structure') or {}
        ranges = gx.get('paragraphs') or rt.get('paragraphs') or [dict(start=0, end=sum((len(t['text']) for t in parts)))]
        cursor = 0
        tokens = []
        for part in parts:
            tokens.append((cursor, cursor + len(part['text']), part))
            cursor += len(part['text'])
        opens=collections.defaultdict(list);closes=collections.defaultdict(list)
        breaks={b['design_position'] for b in gx.get('inline_breaks',[])}
        raised=gx.get('superscript_spans',[])
        script_cuts={p[k] for p in raised for k in ('start','end')}
        if self.rule_labels or unit.get('rule_targets'):
            for target in unit.get('rule_targets',[]):
                spans=target.get('token_slices',[])
                if not spans:continue
                first,last=spans[0],spans[-1]
                lo=tokens[first['token_index']][0]+first['start_in_token']
                hi=tokens[last['token_index']][0]+last['end_in_token']
                opens[lo].append(target['rule_id']);closes[hi].append(target['rule_id'])
            for rid in (dict.fromkeys(unit.get('row_rule_ids',[])+[unit[k] for k in ('row_rule_id','column_rule_id') if unit.get(k)]) if self.rule_labels else []):
                opens[0].append(rid);closes[cursor].append(rid)
        result = []
        for ri, ran in enumerate(ranges):
            a, z = (ran['start'], ran['end'])
            if a == z:
                key=(uid,ran.get('index',ri))
                ids=[t['rule_id'] for t in unit.get('rule_targets',[]) if t['kind']=='text_paragraph' and t['text_paragraph_index']==key[1]]
                child=self.OBJECT_ANCHORS.get(key)
                if child:
                    result.extend(self.ruled_object(self.decorated_text(child,width),ids));continue
                anchored=self.ANCHORS.get(key)
                if anchored:
                    table_flows=self.ruled_object(self.visual_table(anchored,width,documentary_guides=False,continuation_notes=False),ids)
                    compact=self.height_of(table_flows,width)<260
                    if compact and result and isinstance(result[-1],Paragraph):
                        first=len(result)-1
                        while first and isinstance(result[first-1],Paragraph) and result[first-1].getKeepWithNext():
                            first-=1
                        preceding=result[first:]
                        if self.height_of(preceding,width)+self.height_of(table_flows,width)<500:
                            result[first:]=[KeepTogether(preceding+table_flows)]
                        else:result.append(KeepTogether(table_flows))
                    else:result.extend([KeepTogether(table_flows)] if compact else table_flows)
                    result.append(Spacer(1,4))
                    continue
                if 0 < ri < len(ranges) - 1:
                    result.append(Spacer(1, 3))
                continue
            runs = []
            for start, end, part in tokens:
                lo, hi = (max(a, start), min(z, end))
                if lo >= hi:
                    continue
                if part['kind'] == 'variable':
                    pieces = [(lo, hi, '[' + part.get('variable_name', part['text']) + ']')]
                else:
                    pieces = []
                    at = lo
                    while at < hi:
                        style = gx.get('styles', [])[at] if at < len(gx.get('styles', [])) else None
                        j = at + 1
                        while j < hi and j not in opens and j not in closes and j not in breaks and j not in script_cuts and (gx.get('styles', [])[j] if j < len(gx.get('styles', [])) else None) == style:
                            j += 1
                        pieces.append((at, j, part['text'][at - start:j - start]))
                        at = j
                for pos, stop, text in pieces:
                    fs, cs = gx.get('styles', [])[pos] if pos < len(gx.get('styles', [])) else (None, None)
                    font = gx['fonts'][fs] if fs is not None else dict(name=tr('Non interprétée'), size=10, offset=None)
                    col = gx['colors'][cs] if cs is not None else dict(rgb='#000000', offset=None)
                    original = text
                    if font['name'].startswith('Wingdings'):
                        if part['kind'] == 'variable':
                            font = {**font, 'name': 'Source Sans Pro Regular'}
                        else:
                            text = ''.join(('✓' if self.calibration and font['name'] == 'Wingdings 2' and (ch == 'P') else '□' if ch.strip() else ch for ch in text))
                    runs.append((pos,stop,text,font,col))
                    self.RUNS.append(dict(unit=uid, parent=unit['parent_id'], start=pos, text=original, font=font['name'], size=font['size'], color=col.get('rgb'), font_offset=font.get('offset'), color_offset=col.get('offset'), render_font=self.source_font(font['name'],font.get('bold'),font.get('italic'))))
            if not runs:
                continue
            size = max(f['size'] for _,_,_,f,_ in runs)
            markup=''
            for pos,stop,text,font,color in runs:
                if pos in breaks:markup+='<br/>'
                markup+=''.join(self.rule_mark(rid) for rid in opens.get(pos,[]))
                content=escape(text).replace('\r\n','<br/>').replace('\n','<br/>')
                # Underline is only consumed if supplied by a proven decoder;
                # uncalibrated decoration flags do not invent an underline.
                if font.get('underline') is True:content='<u>'+content+'</u>'
                styled='<font name="%s" size="%s" color="%s">%s</font>' % (self.source_font(font['name'],font.get('bold'),font.get('italic')),font['size'],color.get('rgb') or '#000000',content)
                if any(p['start']<=pos<stop<=p['end'] for p in raised):
                    # Size and rise follow the observed small callout profile.
                    styled='<super rise="%s" size="%s">%s</super>'%(font['size']*.3,max(4,font['size']-2),styled.replace('size="%s"'%font['size'],'size="%s"'%max(4,font['size']-2)))
                markup+=styled
                markup+=''.join(self.rule_mark(rid,True) for rid in reversed(closes.get(stop,[])))
            alignment={'left':0,'center':1,'right':2,'justify':4}.get(ran.get('alignment'),0)
            # Source spacing is expressed on the same 300/inch design grid.
            before=ran.get('spacing_before_raw',0)*.24
            after=ran.get('spacing_after_raw',0)*.24
            if not 0<=before<=100:before=0
            if not 0<=after<=100:after=2.5
            bullet=ran.get('bullet',{});bullet_text=None
            left=right=first=0
            if bullet.get('status')=='decoded':
                raw=ran.get('indent_raw',[0,0,0])
                if all(0<=v<=1500 for v in raw):left=(raw[0]+raw[2])*.24;right=raw[1]*.24
                bullet_text=bullet['glyph']
            leading=ran.get('leading_pt',max(7,size*1.18))
            if not size*.8<=leading<=size*3:leading=max(7,size*1.18)
            style = ParagraphStyle(uid + str(ri), fontName='SSPRegular', fontSize=size, leading=leading, leftIndent=left,rightIndent=right,firstLineIndent=first,
                                   bulletFontName=bullet.get('render_font','SSPRegular'),bulletFontSize=bullet.get('size_pt',size),bulletIndent=0,spaceBefore=before, spaceAfter=after,
                                   alignment=alignment, keepWithNext=bool(ran.get('keep_with_next')), splitLongWords=True, allowWidows=0, allowOrphans=0)
            para = Paragraph(markup, style, bulletText=bullet_text)
            h = para.wrap(width, 100000)[1]
            if h > 625:
                self.WARNINGS.append(dict(unit=uid, paragraph=ri, height=h, width=width))
            result.append(para)
        if not result:
            result = [Spacer(1,0)] if rt and not parts else [self.p(tr('Contenu conservé ; rendu non interprété.'), 'small')]
        return result

    def height_of(self, items, width):
        return sum(((self.height_of(x._content, width) if isinstance(x, KeepTogether) else x.wrap(max(8, width), 100000)[1]) + getattr(x, 'spaceAfter', 0) + getattr(x, 'spaceBefore', 0) for x in items))

    def split_cell(self, items, width, limit):
        chunks = []
        curr = []
        h = 0
        for it in items:
            ih = self.height_of([it], width)
            if curr and h + ih > limit:
                chunks.append(curr)
                curr = []
                h = 0
            curr.append(it)
            h += ih
        if curr or not chunks:
            chunks.append(curr)
        return chunks

    def visual_table(self, tid, width, depth=0, documentary_guides=True, continuation_notes=True):
        if depth>24:raise ValueError('Table nesting limit exceeded')
        t = self.GRIDS[tid]
        gt = self.G['tables'][tid]
        nc = len(t['columns'])
        nr = len(t['rows'])
        source = self.TABLE_STYLES.get(tid, {})
        has_source_border = bool(source.get('frame',{}).get('renderable')) or any(
            pen.get('renderable') for key in ('rows','columns','cells')
            for item in source.get(key,[]) for pen in item.get('borders',[]))
        has_source_border = has_source_border or any(
            str(cell['offset']) in self.NATIVE['borders'] for cell in t['cells'])
        columns = source.get('columns', [])
        if len(columns) == nc and all(c.get('status') == 'decoded' and c['width']['pt'] > 0 for c in columns):
            natural = [c['width']['pt'] for c in columns]
            scale = min(1, width / sum(natural))
            widths = [n * scale for n in natural]
        else:
            raw = [max(1, c['raw_dimension']) for c in t['columns']]
            widths = [width * n / sum(raw) for n in raw]
            natural = None; scale = None
        self.TABLE_LAYOUTS.append(dict(table=tid, source_widths_pt=natural, display_widths_pt=widths,
                                       scale=scale, policy='source_fit' if natural else 'proportional_fallback'))
        def padding(cell, available=None):
            inset = self.CELL_STYLES.get(cell['offset'], {}).get('uniform_inset')
            value = inset['pt'] * (scale or 1) if inset else 2.5
            # Empty source gutters may be narrower than the default padding.
            # Keep the source width and leave a positive interior for ReportLab.
            return min(value, max(0, (available-1)/2)) if available is not None else value
        cellg = {c['offset']: c for c in gt['cells']}
        rows = []
        spans = []
        rowmaps = []
        for ri in range(nr):
            contents = [[] for _ in range(nc)]
            localspans = []
            cells = sorted([c for c in t['cells'] if c['row'] == ri], key=lambda c: c['column'])
            for cell in cells:
                col = cell['column']
                cg = cellg.get(cell['offset'], {})
                span = cg.get('column_span', cell.get('column_span', 1))
                if not 1 <= span <= nc - col:
                    span = 1
                if any((col < other['column'] < col + span for other in cells)):
                    span = cell.get('column_span', 1)
                available = sum(widths[col:col + span])
                cw = max(1, available - 2 * padding(cell, available))
                if cell.get('content_id') in self.UNITS:
                    contents[col] = self.text_flow(cell['content_id'], cw)
                elif cell.get('nested_table_id') in self.GRIDS:
                    contents[col] = self.visual_table(cell['nested_table_id'], cw, depth + 1, documentary_guides, continuation_notes)
                if span > 1:
                    localspans.append((col, col + span - 1))
            batches = []
            for ci, content in enumerate(contents):
                end = next((z for a, z in localspans if a == ci), ci)
                owner = next((c for c in cells if c['column'] == ci), None)
                available = sum(widths[ci:end + 1])
                pad = padding(owner, available) if owner else min(2.5,max(0,(available-1)/2))
                batches.append(self.split_cell(content, max(1, sum(widths[ci:end + 1]) - 2 * pad), 570 if depth == 0 else 510))
            n = max((len(x) for x in batches))
            if n > 1:
                self.SPLITS.append(dict(table=tid, row=ri, parts=n))
            for j in range(n):
                ridx = len(rows)
                rowmaps.append((ri, j, n))
                rows.append([batch[j] if j < len(batch) else [] for batch in batches])
                for a, z in localspans:
                    spans.append(('SPAN', (a, ridx), (z, ridx)))
        rendered = []
        for ri, row in enumerate(rows):
            orig, chunk, n = rowmaps[ri]
            if chunk > 0 and depth == 0 and continuation_notes:
                rendered.append(self.p(tr('Suite de la ligne ') + str(orig + 1) + tr(' - contenus conditionnels non évalués'), 'small'))
            table = ScopedBorderTable([row], colWidths=widths, hAlign='LEFT', splitInRow=0,
                scope_lines=scoped_lines(source,widths,orig,nr,chunk,n),border_scale=scale or 1,
                guide_sides=() if has_source_border else ('left','right')+
                    (('top',) if ri==0 else ())+(('bottom',) if ri==len(rows)-1 else ()),
                minRowHeights=[t['rows'][orig]['raw_dimension']*.24*(scale or 1) if n==1 and 0<t['rows'][orig]['raw_dimension']*.24*(scale or 1)<=510 else 0])
            commands = [('VALIGN', (0, 0), (-1, -1), 'TOP'), ('LEFTPADDING', (0, 0), (-1, -1), 2.5), ('RIGHTPADDING', (0, 0), (-1, -1), 2.5), ('TOPPADDING', (0, 0), (-1, -1), 3), ('BOTTOMPADDING', (0, 0), (-1, -1), 3)]
            for col, available in enumerate(widths):
                if available < 6:
                    commands += [(k,(col,0),(col,0),max(0,(available-1)/2)) for k in ('LEFTPADDING','RIGHTPADDING')]
            if any(row) and documentary_guides:
                commands += [('LINEBELOW', (0, 0), (-1, -1), 0.25, colors.HexColor('#b9c3ce'), 1, (1, 2))]
            for _, a, z in spans:
                if a[1] == ri:
                    commands.append(('SPAN', (a[0], 0), (z[0], 0)))
            if self.NATIVE:
                for cell in t['cells']:
                    if cell['row'] != orig:
                        continue
                    col = cell['column']
                    end = next((z[0] for _, a, z in spans if a == (col, ri)), col)
                    pad = padding(cell, sum(widths[col:end+1]))
                    commands += [(k, (col,0), (end,0), pad) for k in ('LEFTPADDING','RIGHTPADDING')]
                    if self.CELL_STYLES.get(cell['offset'], {}).get('uniform_inset'):
                        commands += [(k, (col,0), (end,0), padding(cell)) for k in ('TOPPADDING','BOTTOMPADDING')]
                    bg = self.fill_command(cell.get('content_id'), (col, 0), (end, 0))
                    if bg:
                        commands.append(bg)
                    decoded = self.CELL_STYLES.get(cell['offset'])
                    if decoded:
                        for pen in decoded['borders']:
                            if pen['renderable'] and (pen['side'] in ('left','right') or (pen['side']=='top' and chunk==0) or (pen['side']=='bottom' and chunk==n-1)):
                                command={'top':'LINEABOVE','bottom':'LINEBELOW','left':'LINEBEFORE','right':'LINEAFTER'}[pen['side']]
                                edge_col=col if pen['side']=='left' else end if pen['side']=='right' else col
                                edge_end=edge_col if pen['side'] in ('left','right') else end
                                commands.append((command,(edge_col,0),(edge_end,0),pen['thickness']['pt']*(scale or 1),colors.HexColor(pen['color']['rgb'])))
                    else:
                        border = self.NATIVE['borders'].get(str(cell['offset']))
                        if border and chunk == n - 1:
                            commands.append(('LINEBELOW', (col, 0), (end, 0), border['width_pt'], colors.HexColor(border['color'])))
            table.setStyle(TableStyle(commands))
            rendered.append(table)
        return rendered

    def unit_fingerprint(self, uid):
        unit = self.UNITS[uid]
        gx = self.G['units'].get(uid, {})
        if self.is_picture(unit):
            return ['graphic', [normalized_variable(n) for n in unit['variable_names']]]
        rt = unit.get('richtext') or unit.get('text_structure') or {}
        bounds = {p['start'] for p in rt.get('paragraphs', [])[1:]}
        result = []
        cursor = 0
        for part in unit['parts']:
            styles = []
            for i in range(len(part['text'])):
                fi, ci = gx.get('styles', [])[cursor + i] if cursor + i < len(gx.get('styles', [])) else (None, None)
                font = gx['fonts'][fi] if fi is not None else {}
                col = gx['colors'][ci] if ci is not None else {}
                value = [font.get('name'), font.get('size'), font.get('bold'),font.get('italic'),font.get('underline'),col.get('rgb')]
                if not styles or styles[-1] != value:
                    styles.append(value)
            result.append(['variable' if part['kind'] == 'variable' else 'text', part.get('variable_name', part['text']) if part['kind'] == 'variable' else part['text'], styles, [i - cursor for i in sorted(bounds) if cursor <= i < cursor + len(part['text'])]])
            cursor += len(part['text'])
        result.append(['paragraph_styles',[[p.get('alignment'),p.get('spacing_before_raw'),p.get('spacing_after_raw'),p.get('bullet'),p.get('indent_raw'),p.get('leading_pt')] for p in gx.get('paragraphs',[])]])
        result.append(['inline_breaks',[b['design_position'] for b in gx.get('inline_breaks',[])]])
        result.append(['superscripts',[[s['start'],s['end']] for s in gx.get('superscript_spans',[])]])
        result.append(['anchored_tables',[[index,self.table_fingerprint(tid)] for (owner,index),tid in sorted(self.ANCHORS.items()) if owner==uid]])
        result.append(['anchored_objects',[[index,self.unit_fingerprint(child)] for (owner,index),child in sorted(self.OBJECT_ANCHORS.items()) if owner==uid]])
        if self.NATIVE:
            bg = self.NATIVE['backgrounds'].get(uid, {})
            result.append(['background', bg.get('fill', {}).get('rgb') if bg.get('fill') else None])
        return result

    def descendants(self, t):
        return [uid for c in t['cells'] for uid in ([c['content_id']] if c.get('content_id') else self.descendants(self.GRIDS[c['nested_table_id']]) if c.get('nested_table_id') in self.GRIDS else [])]

    def entries_for(self, pid):
        compositions=[c for c in self.COMPOSITIONS.values() if c['paragraph_id']==pid]
        covered=[(o['offset'],o['end']) for c in compositions for o in c['objects']]
        grids = [t for t in self.MODEL['tables'] if t['paragraph_id'] == pid and (not t.get('parent_table_id'))]
        placed = set()
        entries = [(c['owner_offset'],'composition',c['id']) for c in compositions]
        for t in grids:
            placed.update(self.descendants(t))
            if t.get('inline_anchor'):continue
            entries.append((t.get('start') or min((self.UNITS[uid]['offset'] for uid in self.descendants(t)),default=0), 'table', t['id']))
        for u in self.MODEL['content_units']:
            if u.get('parent_id') == pid and u['id'] not in placed and not u.get('inline_object_anchor') and not any(a<=u['offset']<b for a,b in covered):
                entries.append((u['offset'], 'text', u['id']))
        return [(kind, key) for _, kind, key in sorted(entries)]

    def table_fingerprint(self, tid):
        t = self.GRIDS[tid]
        cg = {c['offset']: c for c in self.G['tables'][tid]['cells']}
        cells = []
        for c in sorted(t['cells'], key=lambda c: (c['row'], c['column'])):
            content = self.unit_fingerprint(c['content_id']) if c.get('content_id') else self.table_fingerprint(c['nested_table_id']) if c.get('nested_table_id') else []
            geom = cg.get(c['offset'], {})
            cells.append([c['row'], c['column'], geom.get('column_span', c.get('column_span', 1)), geom.get('raw_mode'), geom.get('leading_raw_style'), geom.get('leading_color', {}).get('rgb'), content])
        normalized = self.TABLE_STYLES.get(tid, {})
        styles = [[c['row'],c['column'],c['background'].get('status'),c['background'].get('rgb'),
                   c['shape'].get('raw_code'), c.get('insets_raw'),
                   [[e['group_code'],e['thickness']['raw'],e['color'].get('rgb'),e['raw_selector'],e['renderable']]
                    for e in c['borders']]] for c in normalized.get('cells', [])]
        frame=normalized.get('frame',{})
        return ['frame',frame.get('enabled_raw'),frame.get('line_pattern_raw'),frame.get('thickness',{}).get('raw'),frame.get('color',{}).get('rgb'),'table', len(t['rows']), [c['raw_dimension'] for c in t['columns']], cells, styles,[[[p['side'],p['line_pattern_raw'],p['color'].get('rgb'),p['thickness']['raw']] for p in a.get('borders',[])] for k in ('columns','rows') for a in normalized.get(k,[])]]

    def occurrence_projection(self):
        from .document_flow import paragraph_occurrences
        cache={};removed=[]
        def paragraph_digest(pid):
            if pid in cache:return cache[pid]
            value = [self.unit_fingerprint(k) if typ == 'text' else self.COMPOSITIONS[k] if typ=='composition' else self.table_fingerprint(k) for typ, k in self.entries_for(pid)]
            # Keep the existing visual equivalence; only its adjacency scope changes.
            # Unresolved references have a separate occurrence-specific fingerprint.
            cache[pid]=hashlib.sha256(json.dumps(value,ensure_ascii=False,sort_keys=True).encode()).hexdigest()
            return cache[pid]
        def fingerprint(node):
            if node['kind']=='paragraph' and node.get('resolved'):
                return ('paragraph',paragraph_digest(node['source_id']))
            if node['kind']=='section' and node.get('resolved'):
                # Only the same section reference is folded; no inferred equivalence
                # between independently conditioned/data-bound section definitions.
                return ('section',node['source_id'],tuple(fingerprint(c) for c in node['children']))
            return ('separator',node['occurrence_id'])
        def leaves(node):
            if node['kind']=='paragraph':return [node] if node.get('resolved') else []
            return [p for c in node.get('children',[]) for p in leaves(c)]
        def siblings(nodes):
            kept=[];previous=None;previous_key=None
            for node in nodes:
                key=fingerprint(node)
                if previous is not None and key==previous_key:
                    for current,representative in zip(leaves(node),leaves(previous)):
                        pid=current['source_id'];rid=representative['source_id']
                        removed.append(dict(removed_id=pid,removed_name=self.PS[pid]['name'],
                            representative_id=rid,representative_name=self.PS[rid]['name'],
                            occurrence_id=current['occurrence_id'],representative_occurrence_id=representative['occurrence_id'],
                            fingerprint=paragraph_digest(pid),reason=tr('Même contenu, variables métier, styles de texte et topologie ; formats JPG/SEG du même emplacement normalisés')))
                elif node['kind']=='paragraph':
                    if node.get('resolved'):kept.append(node)
                else:kept.extend(siblings(node.get('children',[])))
                if previous_key!=key:previous=node;previous_key=key
            return kept
        flow=self.MODEL.get('document_flow',[])
        kept=[p for doc in flow for p in siblings(doc['children'])] if flow else siblings(paragraph_occurrences(self.MODEL))
        return kept,removed

    def projection(self):
        occurrences,removed=self.occurrence_projection()
        return [p['source_id'] for p in occurrences],removed

    def clean_section(self, pid):
        flows = []
        for kind, key in self.entries_for(pid):
            if kind == 'composition':
                flows.extend(self.composition_flow(key,self.W))
            elif kind == 'table':
                flows.extend(self.visual_table(key, self.W, documentary_guides=False, continuation_notes=False))
            else:
                flows.extend(self.decorated_text(key, self.W) if self.NATIVE else self.text_flow(key, self.W))
            flows.append(Spacer(1, 4))
        flows.append(Spacer(1, 9))
        return [KeepTogether(flows)] if self.height_of(flows, self.W) < 255 else flows

    def composition_flow(self,key,width):
        from .object_render import ObjectComposition
        comp=self.COMPOSITIONS[key]
        for unit in self.MODEL['content_units']:
            if unit.get('parent_id')==comp['paragraph_id'] and any(o['offset']<=unit['offset']<o['end'] for o in comp['objects']):
                self.PLACED.append(unit['id'])
        result=[ObjectComposition(comp,width,self.source_font)]
        if comp['image_resources']=='unresolved':
            result.append(self.p(tr('Image : emplacement source conservé ; ressource non résolue.'),'small'))
        return result
