"""Counted campaign/message links; no relationship inferred from a name."""
import struct
from .binary import u32, evidence, InvalidPackage
from .layout import sig


def campaign_graph(data, model):
    definitions = {d['id']: d for d in model['definitions']}
    campaigns = []
    common = struct.pack('<11I', 0, 0, 2, 102, 0, 103, 4, 0, 104, 4, 0)
    for d in model['definitions']:
        if d['class_code'] != 6:
            continue
        a, end = d['name_end'], d['end']
        try:
            if a+160 > end or data[a:a+44] != common or data[a+44:a+52] != sig(108):
                continue
            n = u32(data, a+156)
            stop = a+160+4*n
            if not 0 < n <= 1000 or stop+28 > end or data[stop:stop+28] != bytes(28):
                continue
            ids = [f'21:{u32(data, a+160+4*i)}' for i in range(n)]
            if any(ident not in definitions for ident in ids):
                continue
            campaigns.append({'id': d['id'], 'name': d['name'], 'message_ids': ids,
                'relation_status': 'counted_references',
                'evidence': [evidence(data, a+44, stop+28, 'OBS-campaign-message-list-v1')]})
        except (InvalidPackage, struct.error):
            continue
    model['campaigns'] = campaigns
    known = {c['id'] for c in campaigns}
    for app in model.get('applications', []):
        ids = [f'6:{ident}' for ident in app.get('opaque_selectors', [])]
        if ids and all(ident in known for ident in ids):
            app['campaign_ids'] = ids
            app['campaign_reference_status'] = 'counted_references'

