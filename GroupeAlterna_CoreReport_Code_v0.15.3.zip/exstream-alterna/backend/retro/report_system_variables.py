"""Presentation of documentary system-variable knowledge, without evaluation."""
from .i18n import LANGUAGE
from .system_variables import FAMILY_LABELS
from reportlab.platypus import KeepTogether


def system_variable_lines(variable):
    detail = variable.get('system_variable_details')
    if not detail:
        return []
    en = LANGUAGE.get() == 'en'
    if detail['status'] == 'documented':
        labels = [FAMILY_LABELS[x][int(en)] for x in detail['families']]
        pages = list(dict.fromkeys(x['printed_page'] for x in detail['source_occurrences']))
        lines = [('Documented Exstream system variable. Families: ' if en else 'Variable système Exstream documentée. Familles : ') + ', '.join(labels) + '.',
                 detail['description_en' if en else 'description_fr'],
                 'VariableSystem.pdf, p. ' + ', '.join(pages) + '.']
        note = detail.get('note_en' if en else 'note_fr')
        if note:
            lines.append(note)
    elif detail['status'] == 'mention_only':
        lines = [('Name mentioned only in a description on p. 3-20, not listed as a separate variable. Alias unconfirmed.' if en else
                  'Nom cité seulement dans une description p. 3-20, sans entrée propre dans les tableaux. Alias non confirmé.')]
    else:
        lines = [('SYS_ naming convention retained; name not listed in the supplied reference.' if en else
                  'Convention de nommage SYS_ conservée ; nom non listé dans le référentiel fourni.')]
    return lines


def append_system_catalog(model, add, *, document_only=False, story=None):
    catalog = model.get('system_variable_catalog')
    if not catalog:
        return
    en = LANGUAGE.get() == 'en'
    add('Exstream system-variable reference' if en else 'Référentiel des variables système Exstream', 'sub')
    add((f"{catalog['documented_name_count']} listed names; {catalog['family_membership_count']} family memberships. " if en else
         f"{catalog['documented_name_count']} noms listés ; {catalog['family_membership_count']} appartenances de famille. ") +
        ('A prose-only mention is kept separately and is not treated as a confirmed alias.' if en else
         'Une mention dans le texte est conservée séparément, sans assimilation à un alias confirmé.'), 'small')
    scope = set(model.get('document_variable_ids', [])) if document_only else None
    variables = [v for v in model['variables'] if v.get('system_variable_details') and (scope is None or v['id'] in scope)]
    names = sorted({v['name'] for v in variables})
    documented = {v['name'] for v in variables if v['system_variable_details']['status'] == 'documented'}
    add((f'{len(names)} system names observed in this scope, including {len(documented)} catalog matches.' if en else
         f'{len(names)} noms système observés dans ce périmètre, dont {len(documented)} correspondances au catalogue.'), 'small')
    for name in names:
        start = len(story) if story is not None else None
        variable = next(v for v in variables if v['name'] == name)
        # The heading style keeps the variable name with its first explanation.
        add(name, 'sub')
        for line in system_variable_lines(variable):
            add(line, 'small')
        if story is not None:
            story[start:] = [KeepTogether(story[start:])]
    start = len(story) if story is not None else None
    add(('Values are supplied at Exstream execution time and are not evaluated here. Design samples are not runtime values. Page counts, physical pages, sheets and printed numbering are not interchangeable.' if en else
         'Les valeurs sont fournies lors de l’exécution Exstream et ne sont pas évaluées ici. Les exemples de conception ne sont pas des valeurs d’exécution. Pages comptées, pages physiques, feuilles et numérotation imprimée ne sont pas interchangeables.'), 'small')
    if story is not None:
        story[start:] = [KeepTogether(story[start:])]
