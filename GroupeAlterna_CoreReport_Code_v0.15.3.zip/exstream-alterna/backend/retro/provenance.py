"""Lexical call sites and explicit reference triggers, without execution."""
import re
from .binary import evidence


def enrich_provenance(data,model):
    calculations={x['id']:x for x in model['calculations']}
    for c in calculations.values():
        c['calls']=[];c['triggers']=[]
        for hit in re.finditer(r"UserLogic\.callSubfunction\('([^']+)'",c['source_code']):
            target=hit.group(1);p=c['offset']+hit.start()
            c['calls'].append({'callee_id':target,'callee_name':calculations.get(target,{}).get('definition_name'),
                'lexical_order':len(c['calls'])+1,'offset':p,'evidence':[evidence(data,p,p+len(hit.group()),'OBS-call-site-v1')],
                'limitation':'Ordre lexical ; branches, boucles et ordre événementiel global non évalués.'})
        for hit in re.finditer(r"UserLogic\.callBuiltin\('TRIGGER',\s*\"([^\"]+)\"",c['source_code']):
            p=c['offset']+hit.start();c['triggers'].append({'source_name':hit.group(1),'offset':p,
                'evidence':[evidence(data,p,p+len(hit.group()),'OBS-reference-trigger-v1')]})
    chains=[]
    visible={name for u in model.get('content_units',[]) if u['id'] in set(model.get('document_content_ids',[])) for name in u['variable_names']}
    byid={v['id']:v for v in model['variables']}
    for m in model['mappings']:
        if m.get('source_classification')!='reference_candidate' or byid[m['variable_id']]['name'] not in visible:continue
        providers=[c for c in calculations.values() if any(t['source_name']==m['data_source_name'] for t in c['triggers'])]
        chains.append({'variable_id':m['variable_id'],'mapping_id':m['id'],'reference_source':m['data_source_name'],
            'provider_calculation_ids':[c['id'] for c in providers],
            'caller_ids':[c['id'] for c in calculations.values() if any(call['callee_id'] in {p['id'] for p in providers} for call in c['calls'])],
            'confidence':'TRÈS PROBABLE','limitation':'Déclenchement de source nommé démontré ; résultat lookup et clés disponibles à cet instant non exécutés.'})
    model['reference_chains']=chains

    for u in model.get('unknowns',[]):
        if u['code']=='LOOKUP':u['detail']='Mappings de référence, fonctions déclencheuses et appelants reliés pour le profil reconnu ; ressources externes et résultats effectifs non vérifiés.'
        if u['code']=='VISUAL':u['detail']='Vue documentaire reconstruite à partir des contenus et des grilles ; styles fins, pagination Exstream, ressources externes et valeurs client non reproduits.'
