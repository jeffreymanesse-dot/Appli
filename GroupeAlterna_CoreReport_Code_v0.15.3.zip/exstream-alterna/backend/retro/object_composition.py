"""Bounded compiled display lists; names and package hashes never select a profile.

A counted 107 list contains A0 commands. Table/row/cell semantics are proved by
balanced role tags (9/8/7), not captions. Source polygons and glyph positions are
retained, including already-composed rounded corners. Images remain unresolved
unless their resource bytes are independently linked.
"""
import re, struct
from .binary import MARKER, evidence

PROFILE='OBS-counted-display-list-A0-v1'
class Unresolved(ValueError): pass

def require(ok):
    if not ok: raise Unresolved('Unsupported or unbounded display list')

def command(data,p,limit,fonts,palette,record_tag=160):
    require(record_tag in (160,163) and p+9<=limit and data[p:p+4]==struct.pack('<I',record_tag))
    op=data[p+4];v={'offset':p,'opcode':op}
    if op==42:
        opened=data[p+5];role=struct.unpack_from('<I',data,p+6)[0]
        flags,n=struct.unpack_from('<HI',data,p+10);end=p+44+n
        require(opened in (0,1) and role in (7,8,9,26) and n<=1024 and end<=limit)
        require(data[p+16+n:end]==b'\0'*28 and ((opened and flags in (10000,10001)) or (not opened and flags==0 and n==0)))
        v.update(kind='role',opened=bool(opened),role=role,label=data[p+16:p+16+n].decode('cp1252'),flags=flags)
    elif op==4:
        n=struct.unpack_from('<H',data,p+5)[0];q=p+7+8*n;end=q+44
        require(3<=n<=4096 and end<=limit)
        points=[list(struct.unpack_from('<ii',data,p+7+8*i)) for i in range(n)]
        require(points[0]==points[-1] and all(abs(c)<1000000 for point in points for c in point))
        # Filled, unoutlined polygon profile; other pen profiles remain opaque.
        require(data[q:q+7]==bytes.fromhex('00010000000000') and data[q+11:q+19]==bytes.fromhex('ffffff0000000000') and data[q+27:end]==b'\0'*17)
        require(struct.unpack_from('<I',data,q+7)[0] in (0,1))
        value,kind=struct.unpack_from('<II',data,q+19)
        rgb=colour(kind,value,palette);require(rgb is not None)
        v.update(kind='polygon',points=points,fill=rgb,colour_kind=kind,colour_value=value)
    elif op==1:
        n,duplicate=struct.unpack_from('<HH',data,p+5);q=p+9+n;end=q+13*n+22
        require(0<n<=10000 and n==duplicate and end<=limit)
        raw=data[p+9:q];require(all(c>=32 or c in (9,10,13) for c in raw))
        glyphs=[]
        for i in range(n):
            at=q+13*i;require(data[at+8:at+13]==bytes.fromhex('0100ff0000'))
            glyphs.append(list(struct.unpack_from('<ii',data,at)))
        require(all(abs(c)<1000000 for point in glyphs for c in point))
        at=q+13*n;fid=struct.unpack_from('<I',data,at)[0]
        value,kind=struct.unpack_from('<II',data,at+6)
        require(data[at+4:at+6]==b'\0'*2 and data[at+14:end]==b'\0'*8 and str(fid) in fonts)
        rgb=colour(kind,value,palette);require(rgb is not None and not fonts[str(fid)].get('ambiguous'))
        v.update(kind='text',text=raw.decode('cp1252'),glyphs=glyphs,font=dict(fonts[str(fid)]),color=rgb)
    elif op==30 and record_tag==163:
        # A3 horizontal line: explicit endpoints, solid pen and palette/RGB.
        end=p+44;require(end<=limit)
        x1,x2,y1,y2=struct.unpack_from('<4i',data,p+5)
        require(0<x2-x1<100000 and y1==y2 and abs(y1)<100000)
        require(data[p+21:p+24]==b'\x01\0\0' and data[p+36:end]==bytes(8))
        width,value,kind=struct.unpack_from('<3I',data,p+24)
        rgb=colour(kind,value,palette);require(0<width<=100 and rgb is not None)
        v.update(kind='line',points=[[x1,y1],[x2,y2]],width_raw=width,color=rgb)
    elif op==5:
        end=p+182;require(end<=limit)
        require(all(data[p+i:p+i+4]==MARKER for i in (49,65,81,165)))
        require(all(struct.unpack_from('<I',data,p+i)[0]==101 for i in (37,53,69,153)))
        x,y,r,b=struct.unpack_from('<4i',data,p+5);require(0<r-x<100000 and 0<b-y<100000)
        v.update(kind='image',rect=[x,y,r,b],status='resource_unresolved',resource_fields=list(struct.unpack_from('<3I',data,p+85)))
    else:raise Unresolved('Unsupported display opcode')
    v['end']=end
    return v

def colour(kind,value,palette):
    from .visual_graphics import source_rgb
    return source_rgb(kind,value,palette)

def display_object(data,q,limit,fonts,palette):
    require(q>=16 and data[q-4:q]==struct.pack('<I',1) and MARKER in (data[q-12:q-8],data[q-16:q-12]))
    tag,x,y,n=struct.unpack_from('<4I',data,q)
    require(tag==107 and 0<n<=4096 and data[q+16:q+25]==b'\0'*9)
    p=q+25;commands=[];stack=[]
    require(p+4<=limit)
    record_tag=struct.unpack_from('<I',data,p)[0]
    for _ in range(n):
        cmd=command(data,p,limit,fonts,palette,record_tag);p=cmd['end'];commands.append(cmd)
        if cmd['kind']=='role':
            if cmd['opened']:stack.append(cmd['role'])
            else:require(stack and stack.pop()==cmd['role'])
    require(not stack)
    if record_tag==160:
        trailer=11;require(data[p:p+trailer]==b'\x10'+b'\0'*10)
    else:
        trailer=11;require(data[p:p+trailer]==bytes(trailer))
    require(p+trailer+4<=limit and data[p+trailer:p+trailer+4]==MARKER)
    table=any(c['kind']=='role' and c['role']==9 and c['opened'] for c in commands)
    if table:require([c['role'] for c in commands if c['kind']=='role' and c['opened']][:3]==[9,8,7])
    return {'offset':q,'end':p+trailer,'kind':'compiled_table' if table else 'compiled_object','origin_raw':[x,y],
            **({'record_tag':record_tag} if record_tag==163 else {}),'commands':commands,'evidence':[evidence(data,q-16,p+trailer+4,
                PROFILE if record_tag==160 else 'OBS-counted-display-list-A3-v1')]}

def decode_compositions(data,model):
    from .visual_graphics import GraphicsDecoder
    from .scopes import read_richtext
    gd=GraphicsDecoder(data,model);out=[]
    variables={v['internal_id']:v for v in model.get('variables',[])};rules={r['compiled_id']:r for r in model.get('rules',[])}
    owners=list(model.get('paragraphs',[]))+list(model.get('visual_page_containers',[]))
    for par in owners:
        a,z=par['offset'],par['end'];objects=[]
        for h in re.finditer(re.escape(struct.pack('<I',107)),data[a:z]):
            q=a+h.start()
            try:objects.append(display_object(data,q,z,gd.fonts,gd.palette))
            except (Unresolved,struct.error,IndexError,UnicodeError):continue
        if not objects:continue
        # A bounded empty text owner independently enumerates every inline object.
        owners=[]
        for h in re.finditer(re.escape(MARKER),data[a:objects[0]['offset']]):
            p=a+h.start()
            try:
                n=struct.unpack_from('<I',data,p+4)[0]
                if not 4<=n<=4096 or p+12+n>=objects[0]['offset']:continue
                raw=data[p+8:p+8+n]
                if any(c>4 for c in raw) or data[p+8+n:p+12+n]!=data[p+4:p+8]:continue
                item=dict(id=f'object-owner:{p}',offset=p,parent_offset=a,decode_end=z,parts=[],evidence=[evidence(data,p,p+12+n,PROFILE)])
                rt=read_richtext(data,item,variables,rules)
                controls=rt['opaque_controls'];pairs=[]
                for i in range(0,len(controls),2):
                    c,d=controls[i:i+2]
                    require(c['opcode']==-251 and d['opcode']==-106 and d['offset']==c['offset']+8 and c['design_position']==d['design_position']==0)
                    pairs.append((c['arguments'][0],d['arguments'][0]))
                relative_chain=(len(rt['paragraphs'])==1 and
                    pairs==[(i,o['origin_raw'][0]-objects[0]['origin_raw'][0]) for i,o in enumerate(objects)])
                single_a3=(len(objects)==1 and objects[0].get('record_tag')==163 and len(pairs)==1
                    and pairs[0][0]==0 and 0<=pairs[0][1]<100000
                    and len(rt['paragraphs']) in (1,2)
                    and all(p['start']==p['end']==0 for p in rt['paragraphs']))
                require(relative_chain or single_a3)
                require(len(set(o['origin_raw'][1] for o in objects))==1)
                owners.append((item,rt))
            except (ValueError,struct.error,IndexError,KeyError):continue
        if len(owners)!=1:continue
        owner,rt=owners[0];points=[]
        for o in objects:
            if o.get('record_tag')==163:points.append(o['origin_raw'])
            for c in o['commands']:
                if c['kind'] in ('polygon','line'):points+=c['points']
                elif c['kind']=='image':x,y,r,b=c['rect'];points +=[[x,y],[r,b]]
                elif c['kind']=='text':points+=c['glyphs']
        if not points:continue
        bounds=[min(p[0] for p in points),min(p[1] for p in points),max(p[0] for p in points),max(p[1] for p in points)]
        if not (0<bounds[2]-bounds[0]<100000 and 0<bounds[3]-bounds[1]<100000):continue
        is_page=any(x['id']==par['id'] for x in model.get('visual_page_containers',[]))
        out.append({'id':f'composition:{owner["offset"]}','paragraph_id':par['id'],'owner_kind':'page' if is_page else 'paragraph','owner_offset':owner['offset'],
                    'profile':('OBS-counted-display-list-A3-v1' if any(o.get('record_tag')==163 for o in objects) else PROFILE),
                    'bounds_raw':bounds,'objects':objects,'unit':'1/300 inch',
                    'image_resources':'unresolved' if any(c['kind']=='image' for o in objects for c in o['commands']) else 'none',
                    'evidence':owner['evidence']+[evidence(data,rt['stream_start'],rt['stream_end'],PROFILE)]})
    model['object_compositions']=out
