"""Versioned empirical rich-text profile: ownership, never nearest-text targeting.

Design positions count CP1252 payload characters, including variable *names*.
They are not character positions in an evaluated communication. All navigation
must consume a bounded grammar and agree with the independent variable table.
"""
import struct
from .binary import MARKER, InvalidPackage, evidence, u32, occurrences
from .layout import sig

PROFILE = 'OBS-richtext-bounded-properties-v2'


def colour_prelude(data, start, count):
    """Validate counted RGB/palette colour slots, including a non-black first slot."""
    at=start-20-16*(count-1)
    if at<0 or data[at:at+12]!=sig(count,101):return False
    for i in range(count):
        q=at+8 if i==0 else at+24+16*(i-1)
        if i and data[q-4:q]!=MARKER:return False
        if u32(data,q)!=101:return False
        kind,value=u32(data,q+4),u32(data,q+8)
        if not (kind==0 and value<=0xffffff or kind==50 and value>0):return False
    return True


def require(condition, message):
    if not condition:
        raise InvalidPackage(message)


def slices(parts, start, end):
    result=[];cursor=0
    for i,part in enumerate(parts):
        stop=cursor+len(part['text'])
        if start<stop and end>cursor:
            a=max(0,start-cursor);b=min(stop,end)-cursor
            require(part['kind']!='variable' or (a==0 and b==len(part['text'])), 'Variable partiellement ciblée')
            result.append({'token_index':i,'token_id':part['id'],'kind':part['kind'],
                           'start_in_token':a,'end_in_token':b,'text':part['text'][a:b],
                           'offset_start':part['offset']+a,'offset_end':part['offset']+b})
        cursor=stop
    require(sum(len(s['text']) for s in result)==end-start, 'Frontières de contenu non résolues')
    return result


def paragraph_prefix_length(data,x):
    """Length-delimited bullet styles and the bounded extra-word variant."""
    if x<0 or x+128>len(data):return None
    mode=u32(data,x+88)
    if mode in (1,2,3,4,5):
        n=u32(data,x+92)
        if n>1024:return None
        length=124+n
    elif mode==0 and u32(data,x+92)==0 and u32(data,x+96)==0xffffffff:
        length=128
    else:length=120
    if x+length>len(data) or data[x+length-16:x+length]!=struct.pack('<IIII',1,101,0,0):return None
    return length


def owner_colour_header(data,base):
    if base<24 or data[base-24:base-16]!=sig(0) or u32(data,base-12)!=101:return False
    kind,value=u32(data,base-8),u32(data,base-4)
    return (kind==0 and value<=0xffffff) or (kind==50 and value<65536)


def paragraph_chain_headers(data,first,count,lower):
    headers=[];start=max(lower,first-1500)
    for rel in occurrences(data[start:first],sig(1)):
        base=start+rel
        if not owner_colour_header(data,base):continue
        for lead in (136,152):
            x=base+lead
            if x+8>first or u32(data,x)!=count or u32(data,x+4)!=108:continue
            length=paragraph_prefix_length(data,x)
            if length and x+length==first:headers.append(base-64)
    return list(dict.fromkeys(headers))


def read_richtext(data, item, variables, rules, content_only=False):
    start=item['offset'];n=u32(data,start+4);body_end=start+12+n
    raw_parts=item.get('serialized_parts',item['parts'])
    limit=item.get('decode_end',item.get('cell_trailer_offset',len(data)))
    style=limit
    require(data[start:start+4]==MARKER and body_end==item['evidence'][0]['offset_end'], 'Enveloppe texte inconnue')
    require(data[start+8+n:body_end]==data[start+4:start+8], 'Longueurs texte divergentes')
    require(body_end<limit<=len(data), 'Bornes de texte invalides')
    # The local rule table is reached only after consuming glyphs, lines and fonts.
    count=128
    # Consume glyph instructions, NOT a scan for negative integers.
    p=body_end;cursor=0;paragraphs=[];inlines=[];stack=[];var=None;var_events=[];opaque_controls=[];opaque_pair=None
    text_length=sum(len(x['text']) for x in raw_parts)
    while p+4<=style:
        at=p;op=struct.unpack_from('<i',data,p)[0];p+=4
        if op>=0:
            cursor+=1
            require(cursor<=text_length, 'Trop de positions de glyphes')
            continue
        if op==-64:
            require(not stack and var is None and opaque_pair is None, 'Run non fermé')
            break
        arity={-244:1,-254:1,-384:3,-111:1,-110:1,-62:0,-63:0,-246:1,-251:1,-106:1,-156:1,-157:1,-158:1,-247:1,-159:1,-252:1,-109:1}.get(op)
        require(arity is not None and p+4*arity<=style, f'Opcode de composition non interprété : {op} à {at}')
        args=[u32(data,p+4*i) for i in range(arity)];p+=4*arity
        if op==-244:
            require(var is None and args[0]==len(paragraphs), 'Parentage de paragraphe ambigu')
            if paragraphs:paragraphs[-1]['end']=cursor
            paragraphs.append({'index':args[0],'start':cursor,'offset':at})
        elif op==-254:
            require(paragraphs and var is None and args[0]<count, 'Index de règle inline invalide')
            stack.append({'slot':args[0],'start':cursor,'offset':at,'paragraph_index':len(paragraphs)-1})
        elif op==-110:
            require(stack and var is None, 'Fermeture inline sans ouverture')
            run=stack.pop();run.update(end=cursor,end_offset=p)
            # An explicitly closed zero-length run has no text target, but
            # must not prevent decoding later variable events. Its slot is
            # validated against the independent rule table like any other run.
            require(run['end']>=run['start'], 'Run conditionnel inversé')
            inlines.append(run)
        elif op in (-246,-251,-106,-156,-157,-158,-247,-159):
            if op==-159:cursor+=1
            opaque_controls.append({'opcode':op,'arguments':args,'offset':at,'design_position':cursor,'semantics':'uninterpreted_layout_control'})
        elif op==-252:
            require(opaque_pair is None and args==[0] and data[p:p+4]==struct.pack('<i',-62),'Ouverture de contrôle opaque non reconnue')
            opaque_pair=at
            opaque_controls.append({'opcode':op,'arguments':args,'offset':at,'design_position':cursor,'semantics':'uninterpreted_paired_control'})
        elif op==-109:
            require(opaque_pair is not None and args[0]<0x80000000,'Fermeture de contrôle opaque non reconnue')
            opaque_controls.append({'opcode':op,'arguments':args,'offset':at,'design_position':cursor,'open_offset':opaque_pair,'semantics':'uninterpreted_paired_control'})
            opaque_pair=None
        elif op==-384:
            require(paragraphs and var is None and args[1]==0 and 0<=args[2]<=128 and args[0] in variables, f'Référence variable inconnue ou mode non interprété : {args} à {at}')
            var={'internal_id':args[0],'start':cursor,'offset':at,'raw_format_index':args[2]}
        elif op==-111:
            require(var is not None, 'Fermeture variable sans ouverture')
            var.update(end=cursor,end_offset=p)
            var_events.append(var);var=None
    else:
        raise InvalidPackage('Terminaison du flux de glyphes absente')
    require(paragraphs, 'Paragraphes absents du flux de glyphes')
    paragraphs[-1]['end']=cursor
    # The layout line table is consumed solely to reach the independent variable
    # directory. Its widths, heights and rendering coordinates stay uninterpreted.
    require(p+4<=style, 'Table de lignes tronquée')
    line_count=u32(data,p);p+=4
    require(0<line_count<=65536 and p+44*line_count+4<=style, 'Table de lignes invalide')
    line_table_offset=p-4
    p+=44*line_count;nv=u32(data,p);p+=4
    require(nv==len(var_events) and p+16*nv+4<=style, 'Répertoire des variables incohérent')
    directories=[]
    for event in var_events:
        vid,a,b,flag=struct.unpack_from('<IIII',data,p)
        require(vid==event['internal_id'] and flag==(event['raw_format_index']-1)&0xffffffff and 0<=a<a+4<b<=n, 'Répertoire variable : ID, format ou bornes incohérents')
        event.update(directory_offset=p,raw_directory_flag=flag,raw_prefix_start=start+8+a,raw_value_start=start+8+a+4,raw_value_end=start+8+b-1)
        directories.append(event);p+=16
    # A variable's four-byte format header can contain a printable byte (e.g.
    # 100 = "d"). Remove it only when the independent directory bounds prove it.
    parts=[]
    # Segment at independently corroborated directory boundaries: a printable
    # header byte can be contiguous with genuine prose in the raw scanner.
    headers=sorted((v['raw_prefix_start'],v['raw_value_start']) for v in directories)
    require(all(a2>=b1 for (_,b1),(a2,_) in zip(headers,headers[1:])), 'En-têtes variables superposés')
    for part in raw_parts:
        a=part['offset'];b=a+len(part['text'])
        cuts=sorted({a,b}|{x for h in headers for x in h if a<x<b})
        for x,y in zip(cuts,cuts[1:]):
            if any(h<=x and y<=z for h,z in headers):continue
            parts.append({**part,'offset':x,'text':part['text'][x-a:y-a]})
    for i,part in enumerate(parts):part['id']=f"{item['id']}:token:{i}"
    for event in directories:
        matching=[(i,part) for i,part in enumerate(parts) if part['offset']==event['raw_value_start'] and part['offset']+len(part['text'])==event['raw_value_end']]
        require(len(matching)==1,'Valeur de conception variable non délimitée')
        i,part=matching[0];expected=variables[event['internal_id']]['name']
        require(part['kind']!='variable' or part['text']==expected,'Variable nommée différente de son ID sérialisé')
        part['kind']='variable';part['variable_name']=expected;part['variable_internal_id']=event['internal_id']
        if part['text']!=expected:part['design_value']=part['text']
        event['token_index']=i
        spans=slices(parts,event['start'],event['end'])
        require(len(spans)==1 and spans[0]['token_index']==i,'Glyphes et répertoire variable ne concordent pas')
    require(cursor==sum(len(x['text']) for x in parts),'Comptage des glyphes différent du texte')
    fonts=u32(data,p)
    require(0<fonts<=128 and p+28+40*(fonts-1)+33+n+20<=limit, 'Frontière du record de style incohérente')
    require(data[p+16:p+28]==struct.pack('<III',101,0,0), 'Police compacte non reconnue')
    for f in range(fonts-1):
        q=p+28+40*f
        require(data[q:q+4]==MARKER and 0<(u32(data,q+4)&0xffff)<4096 and u32(data,q+12)==0x80000000 and u32(data,q+28)==101, f'Police étendue non reconnue à {q}')
    style=p+28+40*(fonts-1)
    require(data[style:style+4]==MARKER and 0<(u32(data,style+4)&0xffff)<4096 and u32(data,style+12)==0x80000000, 'Record de style final absent')
    if content_only:
        # Glyph boundaries and the independent variable directory are valid even
        # when a later targeting/property variant cannot be interpreted.
        preludes=[nf for nf in range(1,129) if colour_prelude(data,start,nf)]
        return {'profile':'OBS-independent-text-payload-v1','paragraphs':paragraphs,
                'decoded_parts':parts,'variable_events':var_events,'style_offset':style,
                'stream_start':body_end,'stream_end':p,'style_prelude_count':preludes[0] if len(preludes)==1 else None,
                'opaque_controls':opaque_controls,'design_length':cursor,'line_count':line_count,'line_table_offset':line_table_offset,
                'evidence':[evidence(data,body_end,style,'OBS-independent-text-payload-v1')]}
    lp=style+33+n+12
    normal=data[lp-12:lp]==struct.pack('<III',1,1,0)
    empty_variant=(data[lp-12:lp]==struct.pack('<III',2,1,0) and data[lp:lp+32]==b'\0'*28+struct.pack('<I',5))
    require(normal or empty_variant, 'Table de ciblage non encadrée')
    count=u32(data,lp)
    require(count<=128 and count==u32(data,lp+4) and lp+8+4*count<=limit, 'Compteurs de règles divergents')
    rule_ids=[u32(data,lp+8+4*i) for i in range(count)]
    require(all(r in rules for r in rule_ids), 'Règle référencée absente')
    require(all(r['slot']<count for r in inlines), 'Index de règle inline invalide')
    # The suffix after an empty rule table may carry numeric/text formatting.
    # It is retained as opaque evidence, never interpreted as a rule or a span.
    # Before the payload: a counted style prelude and one fixed property record
    # per -244 paragraph. Two observed versions differ by a property 109 (12 B).
    candidates=[]
    for nf in range(1,129):
        footer=20+16*(nf-1);at=start-footer
        if not colour_prelude(data,start,nf):continue
        if not all(data[at+20+16*j:at+28+16*j]==sig(101) for j in range(nf-1)):continue
        for tail in (226,214):
            suffix=sig(106,4,0,107,4,0,108,4,0)+(struct.pack('<III',109,4,0) if tail==226 else b'')
            q=at-tail;reverse=[];valid=True
            for index in range(len(paragraphs)-1,-1,-1):
                if q<item.get('parent_offset',0) or data[q:q+4]!=MARKER or data[q+174:q+tail]!=suffix:valid=False;break
                slot=u32(data,q+56)
                if slot!=0xffffffff and slot>=count:valid=False;break
                reverse.append((q,None if slot==0xffffffff else slot))
                if not index:break
                prefixes=[]
                for rel in occurrences(data[max(0,q-1200):q],sig(108)):
                    x=max(0,q-1200)+rel
                    if x+120>q:continue
                    length=paragraph_prefix_length(data,x)
                    if length and x+length==q:prefixes.append(x)
                if len(prefixes)!=1:valid=False;break
                q=prefixes[0]-tail
            if not valid:continue
            first=q
            headers=paragraph_chain_headers(data,first,len(paragraphs),item.get('parent_offset',0))
            if len(headers)!=1:continue
            props=list(reversed(reverse));stride=tail+120
            candidates.append((headers[0],props,stride,nf))
    # Retain the fixed-chain profile as an independent alternative. Some font
    # prefixes have a different last word but a fully verified enclosing chain.
    for nf in range(1,129):
        footer=20+16*(nf-1);at=start-footer
        if not colour_prelude(data,start,nf):continue
        if not all(data[at+20+16*j:at+28+16*j]==sig(101) for j in range(nf-1)):continue
        for stride,tail in ((346,226),(334,214)):
            first=at-tail-stride*(len(paragraphs)-1)
            if first<item.get('parent_offset',0):continue
            heads=[first-h-64 for h in (256,272) if data[first-h:first-h+8]==sig(1) and owner_colour_header(data,first-h)]
            if len(heads)!=1:continue
            props=[]
            for i in range(len(paragraphs)):
                q=first+stride*i;suffix=sig(106,4,0,107,4,0,108,4,0)+(struct.pack('<III',109,4,0) if stride==346 else b'')
                if data[q:q+4]!=MARKER or data[q+174:q+tail]!=suffix:break
                slot=u32(data,q+56)
                if slot!=0xffffffff and slot>=count:break
                if i<len(paragraphs)-1 and data[q+tail:q+tail+8]!=sig(108):break
                props.append((q,None if slot==0xffffffff else slot))
            if len(props)==len(paragraphs):candidates.append((heads[0],props,stride,nf))
    unique={tuple((q,s) for q,s in c[1]):c for c in candidates};candidates=list(unique.values())
    require(len(candidates)==1, 'Chaîne propriétaire/propriétés non résolue ou index de ciblage invalide')
    outer,props,stride,nf=candidates[0]
    owner113=data[outer:outer+8]==sig(113)
    if owner113:require(u32(data,outer+8)==n, 'Longueur propriétaire texte divergente')
    for para,(q,slot) in zip(paragraphs,props):para.update(properties_offset=q,slot=slot,raw_leading_property=u32(data,q+4),targeting_field_offset=q+56)
    return {'profile':PROFILE,'outer_offset':outer,'stream_start':body_end,'stream_end':p,
            'style_offset':style,'property_stride':stride,'style_prelude_count':nf,'owner_profile':'113' if owner113 else 'property_chain',
            'rule_list_offset':lp,'rule_ids':rule_ids,'paragraphs':paragraphs,'inlines':inlines,
            'decoded_parts':parts,'opaque_controls':opaque_controls,'variable_events':var_events,'design_length':cursor,'line_count':line_count,'line_table_offset':line_table_offset,
            'position_semantics':'serialized_design_payload_not_composed_characters'}


def decode_scopes(data, model):
    rules={r['compiled_id']:r for r in model['rules']};variables={v['internal_id']:v for v in model['variables']}
    model['metadata']['targeting_profile']=PROFILE
    for item in model['content_units']:
        for i,part in enumerate(item['parts']):part['id']=f"{item['id']}:token:{i}"
        if item['evidence'][0]['decoder']!='OBS-content-redundant-length-v1':continue
        try:
            require(item.get('parent_id'), 'Propriétaire du contenu non établi')
            rich=read_richtext(data,item,variables,rules)
            item.setdefault('serialized_parts',item['parts']);item['parts']=rich.pop('decoded_parts')
            item['variable_names']=list(dict.fromkeys(p.get('variable_name',p['text']) for p in item['parts'] if p['kind']=='variable'))
            prepared=[]
            for kind,ranges in [('text_paragraph',rich['paragraphs']),('inline_run',rich['inlines'])]:
                for run in ranges:
                    if run['slot'] is None or (kind=='inline_run' and run['end']==run['start']):continue
                    spans=slices(item['parts'],run['start'],run['end'])
                    rid=rich['rule_ids'][run['slot']];para_index=run.get('paragraph_index',run.get('index'))
                    run_ev=evidence(data,run['offset'],run.get('end_offset',run['offset']+8),PROFILE)
                    ev=[*item['parent_evidence'],item['evidence'][0],
                        evidence(data,rich['outer_offset'],item['offset'],PROFILE,'Chaîne de propriétés et préambule entièrement contrôlés ; extrait brut borné et empreinte.'),
                        evidence(data,rich['stream_start'],rich['stream_end'],PROFILE),
                        evidence(data,rich['rule_list_offset'],rich['rule_list_offset']+8+4*len(rich['rule_ids']),PROFILE),run_ev]
                    if kind=='text_paragraph':ev.append(evidence(data,run['properties_offset'],run['properties_offset']+64,PROFILE))
                    ev.extend(evidence(data,s['offset_start'],s['offset_end'],PROFILE) for s in spans)
                    owner=f"{item['id']}:paragraph:{para_index}" if kind=='text_paragraph' else f"{item['id']}:run:{run['offset']}"
                    variants=rules[rid]['variants']
                    identity=all(v.get('name') and v.get('condition_readable') for v in variants) and len({v['name'] for v in variants})==1
                    if identity:ev.extend(e for v in variants for e in v['evidence'])
                    prepared.append({'kind':kind,'owner_object_id':owner,'owner_kind':kind,
                        'content_id':item['id'],'paragraph_id':item['parent_id'],'text_paragraph_index':para_index,
                        'rule_id':rid,'rule_slot':run['slot'],'target_token_start':spans[0]['token_index'] if spans else None,
                        'rule_reference_offset':rich['rule_list_offset']+8+4*run['slot'],
                        'scope_open_offset':run['offset'],'scope_close_offset':run.get('end_offset'),
                        'owner_record_offset':run.get('properties_offset',run['offset']),
                        'parent_chain':[item['parent_id'],item['id'],f"{item['id']}:paragraph:{para_index}"]+([owner] if kind=='inline_run' else []),
                        'target_token_end':spans[-1]['token_index']+1 if spans else None,'token_slices':spans,
                        'target_fragment_text':''.join(s['text'] for s in spans),'composed_character_start':None,
                        'composed_character_end':None,'confidence':'CERTAIN' if identity else 'TRÈS PROBABLE','scope_resolved':True,
                        'confidence_reason':('Nom, condition et ID concordants ; ' if identity else 'Identité/condition de règle encore partielle ; ')+'chaîne de propriétés bornée, index de ciblage, frontières -244 ou -254/-110, compteurs et répertoire variable concordants. Certitude limitée au profil empirique versionné.',
                        'evidence':ev,'profile':PROFILE})
            item['richtext']=rich;item['rule_targets']=prepared
            if 'style_offset' in item:item['layout_style_offset']=item['style_offset']
            item['style_offset']=rich['style_offset']
            item['inline_rule_ids']=rich['rule_ids']
            for event in rich['variable_events']:
                v=variables[event['internal_id']]
                if not any(x.get('id')==item['id'] for x in v['usage_evidence']):v['usage_evidence'].append({'kind':'content','id':item['id'],'offset':item['offset'],'origin':'independent_variable_directory'})
            used_slots={a['rule_slot'] for a in prepared}
            rich['unresolved_rule_slots']=[i for i in range(len(rich['rule_ids'])) if i not in used_slots]
            item['limitation']='Paragraphes et tokens de conception décodés ; pagination et styles Exstream non reproduits.'
            for rid in set(rich['rule_ids']):
                rule=rules[rid]
                if all(rich['rule_ids'][i]!=rid for i in rich['unresolved_rule_slots']):
                    rule['associations']=[a for a in rule.get('associations',[]) if not(a['kind']=='text_inline_span_unknown' and a.get('content_id')==item['id'])]
                rule.setdefault('associations',[]).extend(a for a in prepared if a['rule_id']==rid)
        except InvalidPackage as exc:
            issue_start=item['evidence'][0]['offset_end']
            issue_end=item.get('decode_end',item.get('cell_trailer_offset',issue_start))
            if issue_end<=issue_start:issue_start=item['offset'];issue_end=item['evidence'][0]['offset_end']
            item['scope_decode_issue']={'profile':PROFILE,'reason':str(exc),
                'evidence':[evidence(data,issue_start,issue_end,PROFILE,'Non interprété ; aucune portée déduite.') ]}
            try:
                payload=read_richtext(data,item,variables,rules,content_only=True)
                item.setdefault('serialized_parts',item['parts']);item['parts']=payload.pop('decoded_parts')
                item['text_structure']=payload
                item['variable_names']=list(dict.fromkeys(p.get('variable_name',p['text']) for p in item['parts'] if p['kind']=='variable'))
                if 'style_offset' in item:item['layout_style_offset']=item['style_offset']
                item['style_offset']=payload['style_offset']
                for event in payload['variable_events']:
                    variables[event['internal_id']]['usage_evidence'].append({'kind':'content','id':item['id'],'offset':item['offset'],'origin':'independent_variable_directory'})
            except InvalidPackage:
                pass
    model['content_variable_ids']=sorted({variables[p['variable_internal_id']]['id'] if p.get('variable_internal_id') in variables else next(v['id'] for v in variables.values() if v['name']==p.get('variable_name',p['text'])) for u in model['content_units'] for p in u['parts'] if p['kind']=='variable'})
    # Classify observed binary references only where a concrete structure proves
    # their role. Unknown late occurrences are NOT silently labelled metadata.
    for rule in model['rules']:
        for candidate in rule['target_candidates']:
            off=candidate['offset'];candidate['classification']='unresolved_numeric_occurrence'
            header=off-12
            if header>=0 and data[header:off+4]==sig(108,30,rule['compiled_id']):
                candidate['classification']='definition';candidate['confidence']='CERTAIN'
                candidate['reason']='Champ ID du record 108/classe 30.'
            for assoc in rule.get('associations',[]):
                refs=[e for e in assoc['evidence'] if e['decoder'] in ('OBS-inline-counted-rule-list-v1','OBS-row-rule-duplicate-v1','OBS-row-rule-duplicate-v2','OBS-column-targeting-v1','OBS-paragraph-global-rule-136-v1','OBS-page-component-rule-v1')]
                if assoc['kind'] in ('inline_run','text_paragraph'):
                    refs=[e for e in assoc['evidence'] if e['offset_start']<=off<e['offset_end'] and e['offset_end']-e['offset_start']<=520 and e['offset_start']==next(u['richtext']['rule_list_offset'] for u in model['content_units'] if u['id']==assoc['content_id'])]
                if any(e['offset_start']<=off<e['offset_end'] for e in refs):
                    candidate['classification']='targeting_reference';candidate['confidence']='TRÈS PROBABLE'
                    candidate['reason']='Référence dans une propriété structurelle de ciblage.'
        resolved=[a for a in rule.get('associations',[]) if a['kind'] in ('inline_run','text_paragraph','grid_row','grid_column','paragraph_global','section_global','document_global','page_component_rule')]
        if resolved:
            rule['targets']=resolved
            rule['scope_resolution']='resolved_on_empirical_profile'
            rule['limitations']=['Les portées sont des objets de conception, pas des positions dans un document évalué. Les autres occurrences non classées restent conservées.']
    for unknown in model['unknowns']:
        if unknown['code']=='SCOPE':unknown['detail']='Portées de ligne, paragraphe et inline décodées uniquement lorsque le profil structurel et les compteurs concordent. Les formes non reconnues restent non interprétées, sans coloration.'
