"""Reusable reporting scope and provenance; unknown does not mean absent."""
from collections import Counter


def finalize(model):
    vi={v['internal_id']:v for v in model['variables']};vn={v['name']:v for v in model['variables']}
    units={u['id']:u for u in model.get('content_units',[])};paragraphs={p['id']:p for p in model.get('paragraphs',[])}
    # A free text object must not inherit a later cell's coordinate trailer.
    rejected=set()
    for u in units.values():
        if 'layout_style_offset' in u and u['layout_style_offset']!=u['style_offset']:
            u['rejected_grid_association']={'position':u.get('grid_position'),'reason':'Le style consommé ne correspond pas au style devant le trailer de cellule.'}
            u.pop('grid_position',None);u.pop('row_rule_id',None);u.pop('column_rule_id',None);u['document_order']=None;rejected.add(u['id'])
    for table in model['tables']:
        table['cells']=[c for c in table['cells'] if c.get('content_id') not in rejected]
        for axis in table['rows']+table['columns']:axis['content_ids']=[i for i in axis.get('content_ids',[]) if i not in rejected]
    for rule in model['rules']:
        for a in rule.get('associations',[]):
            if a['kind'] in ('grid_row','grid_column'):a['content_ids']=[i for i in a['content_ids'] if i not in rejected]
    main=model.get('document_paragraph_ids',[]);rids=[]
    for index,pid in enumerate(main):
        block=paragraphs[pid];block['document_id']=f'P{index:02d}'
        for rid in block.get('global_rule_ids',[]):
            if rid not in rids:rids.append(rid)
        members=sorted((units[x] for x in block['content_ids']),key=lambda u:tuple(u.get('document_order') or [999999,u['offset']]))
        for j,u in enumerate(members):
            u['document_id']=f'P{index:02d}.{j+1:02d}'
            for rid in ([u['row_rule_id']] if u.get('row_rule_id') else [])+([u['column_rule_id']] if u.get('column_rule_id') else [])+u.get('inline_rule_ids',[])+[t['rule_id'] for t in u.get('rule_targets',[])]:
                if rid not in rids:rids.append(rid)
        # Rules on empty axes/objects are still structural rules of this block.
        for table in model['tables']:
            if table['paragraph_id']!=pid:continue
            for axis in table['rows']+table['columns']:
                rid=axis.get('rule_id')
                if rid and rid not in rids:rids.append(rid)
    parent_ids={d['id'] for d in model.get('documents',[])}|{s['id'] for s in model.get('document_sections',[]) if set(s.get('paragraph_ids',[])).intersection(main)}
    for rule in model['rules']:
        if rule['compiled_id'] not in rids and any(a.get('owner_id') in parent_ids for a in rule.get('associations',[]) if a['kind'] in ('document_global','section_global')):
            rids.append(rule['compiled_id'])
    document_pages={page for d in model.get('documents',[]) if set(d.get('paragraph_ids',[])).intersection(main) for page in d.get('page_ids',[])}
    for rule in model['rules']:
        if rule['compiled_id'] not in rids and any(a.get('kind') in ('page_component_rule','page_global') and a.get('page_id') in document_pages for a in rule.get('associations',[])):
            rids.append(rule['compiled_id'])
    model['document_rule_ids']=rids
    allr=rids+[r['compiled_id'] for r in model['rules'] if r['compiled_id'] not in rids]
    for r in model['rules']:r['document_id']='R'+str(allr.index(r['compiled_id'])+1)
    for axis,prefix in [('row','REP-L'),('column','REP-C')]:
        reps=[r for r in model.get('repetitions',[]) if r['axis']==axis]
        reps.sort(key=lambda r:(0 if next((t['paragraph_id'] for t in model['tables'] if t['id']==r['table_id']),None) in main else 1,r['offset']))
        for n,r in enumerate(reps,1):r['document_id']=prefix+str(n)
    calculations=model['calculations'];bycalc={c['id']:c for c in calculations}
    sites={v['id']:[] for v in vi.values()}
    for c in calculations:
        result=c.get('result_variable_id')
        if result in sites:
            sites[result].append({'calculation_id':c['id'],'owner_name':c.get('definition_name',c['id']),
                'owner_kind':'formula','offset':c['offset'],'relation':'formula_result','algorithm_source':'source_expression' if c.get('source_expression') else 'compiled_code',
                'global_execution_order':None,'evidence':c['evidence']})
        for a in c.get('assignments',[]):
            sites[a['variable_id']].append({**a,'calculation_id':c['id'],'owner_name':c.get('definition_name',c['id']),
                'owner_kind':'calculation','relation':'explicit_assignment','global_execution_order':None})
    for r in model['rules']:
        for variant in r['variants']:
            for a in variant.get('assignments',[]):
                sites[a['variable_id']].append({**a,'calculation_id':'rule'+str(r['compiled_id']),
                    'owner_name':variant.get('name') or 'rule'+str(r['compiled_id']),'owner_kind':'rule',
                    'rule_id':r['compiled_id'],'document_rule_id':r['document_id'],
                    'rule_in_document':r['compiled_id'] in rids,'relation':'conditional_rule_assignment',
                    'targets':[{k:a[k] for k in ('kind','paragraph_id','column','row','table_id','owner_id','owner_name') if k in a} for a in r.get('associations',[])],
                    'global_execution_order':None})
    for v in vi.values():
        v['valuation_sites']=sites[v['id']]
        v['origin_class']='system' if v['name'].startswith('SYS_') else 'input' if v['source']=='mapped_xml_flow' else 'reference' if v['source']=='mapped_reference_candidate' else 'initialization' if v['source']=='mapped_initialization_candidate' else 'report' if v['source']=='mapped_report_candidate' else 'calculated' if v['valuation_sites'] else 'unresolved'
        v['technical_name_hint']=v['name'].startswith(('DF_WRK_','SYS_','DF_PAR_','DF_CMP_'))
        v['origin_limitation']='Les préfixes techniques sont des indices de nom ; ils ne prouvent pas le mécanisme de valorisation.' if v['technical_name_hint'] else None
    selected_vars={vn[n]['internal_id'] for u in units.values() if u['id'] in model.get('document_content_ids',[]) for n in u['variable_names'] if n in vn}
    for u in units.values():
        if u.get('parent_id') in document_pages:
            selected_vars.update(vn[n]['internal_id'] for n in u.get('variable_names',[]) if n in vn)
    for r in model['rules']:
        if r['compiled_id'] in rids:
            for variant in r['variants']:selected_vars.update(variant['reads']+variant.get('writes',[]))
    from .formula_timing import event_formula_ids
    scheduled=event_formula_ids(model)
    model['event_calculation_ids']=[c['id'] for c in calculations if c['id'] in scheduled]
    selected_calcs={cid for chain in model.get('reference_chains',[]) for cid in chain.get('provider_calculation_ids',[])} | scheduled
    changed=True
    while changed:
        before=(len(selected_vars),len(selected_calcs))
        for c in calculations:
            result=c.get('result_variable_id');resultid=int(result.split(':')[1]) if result else None
            if c['id'] in selected_calcs or resultid in selected_vars or (c['id'].startswith('formula') and selected_vars.intersection(c['writes'])):
                selected_calcs.add(c['id']);selected_vars.update(c['reads'])
                if resultid is not None:selected_vars.add(resultid)
                selected_calcs.update(x['callee_id'] for x in c.get('calls',[]) if x['callee_id'] in bycalc)
        changed=before!=(len(selected_vars),len(selected_calcs))
    model['document_variable_ids']=[v['id'] for v in vi.values() if v['internal_id'] in selected_vars]
    model['document_calculation_ids']=[c['id'] for c in calculations if c['id'] in selected_calcs]
    from .system_variables import enrich_system_variables
    enrich_system_variables(model)
    # Declarations from a shared source are shown only when their XML path
    # or an explicit binding intersects this document's dependency closure.
    docvars=set(model['document_variable_ids'])
    docowners={d['id'] for d in model.get('documents',[]) if set(d.get('paragraph_ids',[])).intersection(main)}
    docowners.update(s['id'] for s in model.get('document_sections',[]) if set(s.get('paragraph_ids',[])).intersection(main))
    used=[]
    for section in model.get('data_sections',[]):
        path=section.get('xml_path','')
        mapped=any(m.get('source_classification')=='input_candidate' and m['variable_id'] in docvars and m.get('xml_path') and
                   (m['xml_path']==path or m['xml_path'].startswith(path+'/')) for m in model.get('mappings',[]))
        bound=any(b.get('data_section_id')==section['id'] and b.get('owner_id') in docowners for b in model.get('data_section_bindings',[]))
        if mapped or bound:used.append(section)
    model['used_data_sections']=used
    model['coverage']={'all_content_units':len(units),'document_content_units':len(model.get('document_content_ids',[])),
      'richtext_decoded':sum('richtext'in u for u in units.values()),'document_richtext_decoded':sum('richtext'in units[x] for x in model.get('document_content_ids',[])),
      'unplaced_content_ids':[u['id'] for u in units.values() if not u.get('parent_id')],
      'scope_issues':dict(Counter(u['scope_decode_issue']['reason'] for u in units.values() if u.get('scope_decode_issue'))),
      'column_properties_inspected':sum(len(t['columns']) for t in model['tables']),
      'independent_text_payloads':sum(bool(u.get('richtext') or u.get('text_structure')) for u in units.values()),
      'global_paragraph_rules':sum(bool(p.get('global_rule_ids')) for p in paragraphs.values()),
      'horizontal_cell_extents':sum(c.get('column_span',1)>1 for t in model['tables'] for c in t['cells']),
      'limits':['Seul un profil borné d’étendue horizontale de cellule est décodé ; autres fusions et styles fins non interprétés.','Les valeurs du flux, l’ordre global des événements et les paramètres externes ne sont pas fournis.']}
    for p in paragraphs.values():
        if p.get('table_id') and any(not units[i].get('grid_position') for i in p['content_ids']):p['order_status']='grid_coordinates_with_unplaced_text_order_unknown'
        p['order_status']=p.get('order_status') or ('grid_coordinates' if p.get('table_id') else 'text_objects_without_proven_local_order' if len(p['content_ids'])>1 else 'single_text_object')
