from pathlib import Path
from contextlib import contextmanager
from sqlalchemy import create_engine,Column,String,Float,Boolean,JSON,text,Integer
from sqlalchemy.orm import declarative_base,sessionmaker
from .config import settings
Base=declarative_base()
class Job(Base):
    __tablename__='jobs'
    id=Column(String(64),primary_key=True)
    owner=Column(String(64),nullable=False,index=True)
    mode=Column(String(16),nullable=False)
    state=Column(String(32),nullable=False,index=True)
    created=Column(Float,nullable=False,index=True)
    updated=Column(Float,nullable=False)
    expires=Column(Float,nullable=False,index=True)
    cancelled=Column(Boolean,default=False,nullable=False)
    inputs=Column(JSON,default=list,nullable=False)
    outputs=Column(JSON,default=list,nullable=False)
    history=Column(JSON,default=list,nullable=False)
    summary=Column(JSON,default=dict,nullable=False)
    error=Column(String(64),nullable=True)
    engine_version=Column(String(32),nullable=False)
    reserved_bytes=Column(Integer,nullable=False,default=0)

if settings.database_url.startswith('sqlite:///'):
    Path(settings.database_url.removeprefix('sqlite:///')).resolve().parent.mkdir(parents=True,exist_ok=True)
engine=create_engine(settings.database_url,connect_args={'check_same_thread':False,'timeout':30} if settings.database_url.startswith('sqlite') else {},pool_pre_ping=True)
Session=sessionmaker(bind=engine,expire_on_commit=False)

def initialize():
    settings.validate();settings.storage.mkdir(parents=True,exist_ok=True,mode=0o700)
    with engine.connect() as connection:
        if engine.dialect.name=='sqlite':connection.exec_driver_sql('BEGIN IMMEDIATE')
        else:connection.execute(text('SELECT pg_advisory_xact_lock(48371932)'))
        connection.execute(text('CREATE TABLE IF NOT EXISTS schema_migrations (version INTEGER PRIMARY KEY)'))
        version=connection.execute(text('SELECT MAX(version) FROM schema_migrations')).scalar()
        if version not in (None,1):raise RuntimeError('Version de base non prise en charge')
        if version is None:
            Base.metadata.create_all(connection)
            connection.execute(text('INSERT INTO schema_migrations (version) VALUES (1)'))
        connection.commit()
    if engine.dialect.name=='sqlite':
        with engine.connect() as c:c.execute(text('PRAGMA journal_mode=WAL'));c.commit()

@contextmanager
def transaction():
    with Session() as s:
        if engine.dialect.name=='sqlite':s.execute(text('BEGIN IMMEDIATE'))
        else:s.execute(text('SELECT pg_advisory_xact_lock(48371931)'))
        try:yield s;s.commit()
        except BaseException:s.rollback();raise
