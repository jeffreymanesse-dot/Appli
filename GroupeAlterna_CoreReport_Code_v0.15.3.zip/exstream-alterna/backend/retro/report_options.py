from .i18n import tr, note
"""Independent presentation choices; the evidence model is always complete."""

OPTIONAL_CHAPTERS = (
    ('valuation', 'Variables et fonctions'),
    ('input_dictionary', 'Annuaire des données du flux'),
    ('reconstruction', 'Inventaire et limites de reconstruction'),
    ('template_pages', 'Template et Page'),
)
DEFAULT_CHAPTERS = tuple(key for key, _ in OPTIONAL_CHAPTERS)


def normalize_chapters(chapters=None):
    if chapters is None:
        return DEFAULT_CHAPTERS
    if isinstance(chapters, (str, bytes)):
        raise ValueError('La sélection des chapitres doit être une liste')
    values = list(chapters)
    if any(key not in DEFAULT_CHAPTERS for key in values):
        raise ValueError('Chapitre inconnu')
    return tuple(key for key in DEFAULT_CHAPTERS if key in values)


def chapter_plan(chapters=None, *, fallback=False):
    required = ([('overview', tr('Vue détaillée')),
                 ('contents', tr('Contenus extraits et usages directs')),
                 ('tables', tr('Répétitions et tables : preuves disponibles')),
                 ('rules', tr('Catalogue des règles'))] if fallback else
                [('overview', tr('Vue détaillée')),
                 ('tables', tr('Mise en forme des tableaux')),
                 ('rules', tr('Catalogue des règles du courrier'))])
    chosen = normalize_chapters(chapters)
    plan = {key: f'{i}. {tr(name)}' for i, (key, name) in enumerate(
        required + [(key, name) for key, name in OPTIONAL_CHAPTERS if key in chosen and key!='template_pages'], 1)}
    if 'template_pages' in chosen:plan['template_pages']=tr('Annexe - Template et Page')
    return plan


def public_outputs(outputs):
    """Also hide technical artifacts of tasks created by older versions."""
    return [name for name in outputs if name.endswith('.pdf')]
