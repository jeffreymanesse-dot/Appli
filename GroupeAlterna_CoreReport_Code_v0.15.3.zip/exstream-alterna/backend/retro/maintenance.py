import time
from .db import initialize
from .jobs import purge
if __name__=='__main__':
    initialize()
    while True:purge();time.sleep(30)
