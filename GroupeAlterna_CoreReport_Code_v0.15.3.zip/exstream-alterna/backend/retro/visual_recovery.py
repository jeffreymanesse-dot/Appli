"""Project the shared, already decoded content model without reinterpreting it."""
import copy

def recover(data, original):
    m=copy.deepcopy(original)
    m.setdefault('visual_page_containers',[])
    m['visual_recovery']=copy.deepcopy(m.get('content_recovery',{}))
    return m
