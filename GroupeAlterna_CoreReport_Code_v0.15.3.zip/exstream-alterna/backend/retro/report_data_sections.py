"""Expose decoded selectors and unresolved row automation in the report."""
from .i18n import tr


def append_data_sections(model,story,add,table):
    sections=model.get('used_data_sections',[])
    if not sections:return
    visible=sections
    add(tr('Data sections utilisées dans le courrier'),'sub')
    add(tr('Seules les data sections reliées à un document, une section, une ligne ou une variable du périmètre sont présentées.'),'small')
    rows=[[tr('Data section'),tr('Source XML')]]
    for s in visible:
        rows.append([s['name'],s['xml_path']])
    if visible:story.append(table(rows,[190,301]))
    bindings=model.get('data_section_bindings',[])
    if bindings:
        rows=[[tr('Composant / document'),tr('Data section')]]
        for b in bindings:rows.append([b['owner_name'],b['data_section_name']])
        story.append(table(rows,[285,206]))


def append_row_automation(grid,story,add,table,rule_labels=None,repetitions=()):
    rows=[r for r in grid['rows'] if r.get('property_profile')=='OBS-row-extended-fields-v1' or r.get('rule_id') or r.get('repeat')]
    if not rows:return
    add(tr('Organisation et répétition des lignes'),'label')
    content=[[tr('Ligne'),tr('Type de ligne'),tr('Propriétés / répétition'),tr('Règle')]]
    for row in rows:
        details=[]
        if row.get('first_row_of_table_section'):details.append(tr('First row of table section'))
        if row.get('break_method')=='when_variable_value_changes':
            details.append(tr('Break method : When variable value change')+'\n'+row['break_variable_name'])
        elif row.get('automation_driver_name'):details.append(row['automation_driver_name'])
        if row.get('group_with_previous_row'):details.append(tr('Group with previous row'))
        if row.get('repeat'):
            rep=next((r for r in repetitions if r['id']==row['repeat']),None)
            if rep and not row.get('automation_driver_name'):details.append(rep['driver_name'])
            details.append(tr('Répète selon le nombre d’éléments du tableau'))
        rule=(rule_labels or {}).get(row.get('rule_id'),'')
        typ=row.get('row_type_label') or (tr('Type brut : ')+str(row['row_type_code']) if row.get('row_type_code') is not None else '')
        content.append([row['index']+1,typ,'\n'.join(details),rule])
    story.append(table(content,[45,145,258,43]))
