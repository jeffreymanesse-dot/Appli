"""Link counted tables to empty rich-text paragraphs with an object opcode pair."""
import struct
from .binary import evidence
from .inline_objects import empty_object_anchors

def decode_table_anchors(data,model):
    for paragraph in model['paragraphs']:
        roots=sorted((t for t in model['tables'] if t['paragraph_id']==paragraph['id'] and t.get('counted_structure') and not t.get('parent_table_id')),key=lambda t:t['start'])
        if not roots:continue
        candidates=[]
        for unit in model['content_units']:
            if unit.get('parent_id')!=paragraph['id'] or unit.get('grid_id'):continue
            rt=unit.get('richtext') or {};anchors=empty_object_anchors(data,unit)
            if len(anchors)!=len(roots) or sorted(a[0] for a in anchors)!=list(range(len(roots))):continue
            if rt.get('rule_list_offset',len(data))>=roots[0]['start']:continue
            candidates.append((unit,anchors))
        if len(candidates)!=1:continue
        unit,anchors=candidates[0]
        paragraph['presentation_order_status']='bounded_inline_table_anchor'
        for index,ep,start,end in anchors:
            roots[index]['inline_anchor']={'content_id':unit['id'],'paragraph_index':ep['index'],
                'design_position':ep['start'],'object_index':index,'status':'decoded_on_bounded_profile',
                'evidence':[evidence(data,ep['offset'],end['offset']+8,'OBS-empty-paragraph-table-anchor-v1'),
                            evidence(data,roots[index]['start']-44,roots[index]['start']+20,'OBS-empty-paragraph-table-anchor-v1')]}
