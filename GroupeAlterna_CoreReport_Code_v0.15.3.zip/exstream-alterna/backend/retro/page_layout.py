"""Counted Page objects, native geometry and bounded embedded JPEG resources.

The decoder uses identities, counters and repeated properties, never a package
name, hash, component spelling, or an absolute binary position. Existing rule
identities/algorithms and document numbering remain untouched.
"""
import base64
from io import BytesIO
import re
import struct
from PIL import Image
from .binary import MARKER, evidence, u32, InvalidPackage

PROFILE = 'OBS-page-counted-layout-v1'


def ints(data, p, n):
    return list(struct.unpack_from('<'+'i'*n, data, p))


def jpeg_resources(data):
    resources = {}; ambiguous = set()
    signature = MARKER + struct.pack('<i', -120)
    for hit in re.finditer(re.escape(signature), data):
        p = hit.start()
        try:
            if data[p+12:p+16] != b'\x03PDF': continue
            ident = u32(data, p+8); size = u32(data, p+16); a = p+20; b = a+size
            if not 4 <= size <= 16_000_000 or b+120 > len(data): continue
            if data[a:a+3] != b'\xff\xd8\xff' or data[b-2:b] != b'\xff\xd9': continue
            dimensions = ints(data, b, 2)
            if not all(0 < v <= 20000 for v in dimensions) or dimensions[0]*dimensions[1] > 25_000_000: continue
            k = b+68
            if ints(data,k,1) != [-112]: continue
            length = u32(data,k+4); n = u32(data,k+8)
            if not 0 < n <= 255 or length != n+4: continue
            name = data[k+12:k+12+n].decode('cp1252')
            if any(ord(c)<32 for c in name): continue
            image = Image.open(BytesIO(data[a:b]))
            if list(image.size) != dimensions or image.format != 'JPEG': continue
            image.verify()
            if ident in resources: ambiguous.add(ident)
            resources[ident] = {'id':ident,'name':name,'pixels':dimensions,
                'mime_type':'image/jpeg','data_base64':base64.b64encode(data[a:b]).decode('ascii'),
                'evidence':[evidence(data,p,b+8,PROFILE+'-jpeg')]}
        except (ValueError, InvalidPackage, struct.error, OSError, IndexError):
            continue
    return {i:v for i,v in resources.items() if i not in ambiguous}


def object_images(data, start, end, resources):
    from .object_composition import command, Unresolved
    images = []
    for hit in re.finditer(b'\xa3\x00\x00\x00\x05',data[start:end]):
        p=start+hit.start()
        try:
            item=command(data,p,end,{}, {},163)
            if data[p+85:p+93] != struct.pack('<II',512,36): continue
            ident=u32(data,p+108);rect=item['rect'];resource=resources.get(ident)
            resolved=resource and resource['pixels']==[rect[2]-rect[0],rect[3]-rect[1]]
            images.append({'rect_raw':rect,'resource_id':ident if resolved else None,
                'resource_name':resource['name'] if resolved else None,
                'status':'resolved' if resolved else 'resource_unresolved',
                'evidence':[evidence(data,p,item['end'],PROFILE+'-image')]})
        except (Unresolved,ValueError,struct.error,IndexError): continue
    return images


def object_frame(data, start, end, typ):
    p=start
    if p+341>end or ints(data,p+96,1)!=[-184]: return None
    rect=ints(data,p+104,4);x,y,r,b=rect
    if not (0<r-x<100000 and 0<b-y<100000 and all(abs(v)<100000 for v in rect)): return None
    polygon=ints(data,p+120,8);angle=ints(data,p+152,1)[0]
    expected={0:[x,y,r,y,r,b,x,b],-90:[x,b,x,y,r,y,r,b]}.get(angle)
    if polygon!=expected or u32(data,p+172)!=300: return None
    names=[]
    signature=struct.pack('<iii',typ,r-x,b-y)
    for hit in re.finditer(re.escape(signature),data[p+296:end]):
        at=p+296+hit.start()
        if at+17>=end: continue
        n=data[at+16]
        if not n or at+17+n>end: continue
        name=data[at+17:at+17+n].decode('cp1252',errors='replace').rstrip('\x00')
        if name and all(ord(c)>=32 and c!='\ufffd' for c in name):
            names.append((name,at,at+17+n))
    if len(names)!=1:return None
    name,a,bname=names[0]
    return {'name':name,'rect_raw':rect,'corners_raw':polygon,'rotation':angle,'geometry_kind':'frame',
        'evidence':[evidence(data,p,p+176,PROFILE+'-frame'),evidence(data,a,bname,PROFILE+'-name')]}


def display_name(data,start,end):
    """The direct image object's counted display list carries a named role."""
    names=[]
    for hit in re.finditer(re.escape(b'\xa3\x00\x00\x00\x2a\x01'),data[start:end]):
        try:
            p=start+hit.start()
            if p+16>end:continue
            role=u32(data,p+6);flag,n=struct.unpack_from('<HI',data,p+10)
            if role!=9 or flag!=10010 or not 0<n<=255 or p+20+n>end:continue
            size=u32(data,p+16+n);tail=p+20+n+size
            if not 0<=size<=1024 or tail+28>end or data[tail:tail+24]!=bytes(24) or u32(data,tail+24)!=163:continue
            name=data[p+16:p+16+n].decode('cp1252',errors='replace').rstrip('\x00')
            if all(ord(c)>=32 and c!='\ufffd' for c in name):names.append(name)
        except (ValueError,struct.error,IndexError):continue
    return names[0] if len(names)==1 else None


def unit_details(unit, graphics):
    g=graphics.get(unit['id'],{});styles=sorted(set(tuple(s) for s in g.get('styles',[])))
    fonts=[g['fonts'][j] for j in sorted({s[0] for s in styles}) if 0<=j<len(g.get('fonts',[]))]
    colors=[g['colors'][j] for j in sorted({s[1] for s in styles}) if 0<=j<len(g.get('colors',[]))]
    return {'content_id':unit['id'],
        'parts':[{k:v for k,v in part.items() if k in ('kind','text','variable_name','variable_internal_id')} for part in unit.get('parts',[])],
        'fonts':[{'name':f['name'],'size':f['size']} for f in fonts],
        'colors':[{k:c.get(k) for k in ('name','rgb','kind')} for c in colors],
        'alignments':list(dict.fromkeys(p.get('alignment') for p in g.get('paragraphs',[]) if p.get('alignment'))),
        'rule_ids':unit.get('inline_rule_ids',[])}


def decode_page_layouts(data, model):
    """Add observations only; reject incoherent lists without guessing owners."""
    definitions={d['id']:d for d in model.get('definitions',[])}
    rules={r['compiled_id'] for r in model.get('rules',[])}
    resources=jpeg_resources(data);used_resources=set();pages=[]
    graphics=model.get('visual',{}).get('graphics',{}).get('units',{})
    for page in model.get('page_components',[]):
        item={'page_id':page['id'],'name':page['name'],'status':'uninterpreted','objects':[],
              'template_status':'unresolved','flow_mode':page.get('flow_mode'),
              'overflow_page_id':page.get('overflow_page_id'),'issues':[]}
        pages.append(item)
        d=definitions.get(page['id']);a=page.get('owner_offset');end=page.get('owner_end')
        if not d or a is None or end is None: item['issues'].append('page_owner_unresolved');continue
        try:
            q=d['name_end']+44
            if not (a+84<=end and end==d['offset'] and end-a<=2_000_000
                and data[a:a+16]==MARKER+struct.pack('<III',111,24,d['internal_id'])
                and data[q:q+8] in (MARKER+struct.pack('<I',136),MARKER+struct.pack('<I',139))
                and q+84<=d['end'] and u32(data,a+28)==300 and u32(data,q+12)==4
                and u32(data,q+20)==600 and u32(data,q+72)==11):
                item['issues'].append('page_profile_unrecognized');continue
            size=ints(data,a+44,2)
            if size!=ints(data,q+24,2) or not all(0<v<100000 for v in size):
                item['issues'].append('page_size_mismatch');continue
            count=u32(data,a+80)
            if count>4096:item['issues'].append('object_count_outside_domain');continue
            heads=([a+84] if count else [])+[a+84+h.start()+4 for h in re.finditer(re.escape(MARKER)+rb'(?:\xfc|\xfd)\x03\x00\x00',data[a+84:end])
                if a+84+h.start()+12<=end and u32(data,a+84+h.start()+8) in (5,14,43)]
            if len(heads)!=count or (count and u32(data,heads[0]) not in (1020,1021)):
                item['issues'].append('object_count_mismatch');continue
            item.update(status='decoded',size_raw=size,units_per_inch=300,object_count=count,
                page_rule_id=u32(data,q+48) if u32(data,q+48) in rules else None,
                evidence=[evidence(data,a,a+84,PROFILE),evidence(data,q,q+84,PROFILE)])
            if end>=25 and data[end-25:end-17]==struct.pack('<II',109,16):
                item['page_rectangle_raw']=ints(data,end-17,4)
                item['page_rectangle_status']='semantic_role_unconfirmed'
            for index,p in enumerate(heads):
                stop=heads[index+1]-4 if index+1<len(heads) else end
                if p+96>stop:
                    item['issues'].append('short_object_record');item['status']='partial';continue
                typ=u32(data,p+16);rid=u32(data,p+80)
                obj={'id':f"page-object:{page['id']}:{index+1}",'index':index+1,'type_code':typ,
                     'name':None,'status':'uninterpreted','rule_id':rid if rid in rules else None,
                     'record_offset':p,'record_end':stop,'images':object_images(data,p,stop,resources),
                     'units':[unit_details(u,graphics) for u in model.get('content_units',[]) if p<=u.get('offset',-1)<stop],
                     'evidence':[evidence(data,p,p+96,PROFILE+'-object')]}
                frame=object_frame(data,p,stop,typ)
                if frame:
                    obj.update(frame);obj['status']='decoded'
                elif typ==2 and obj['images']:
                    name=display_name(data,p,stop)
                    if name and len(obj['images'])==1:
                        obj.update(name=name,rect_raw=obj['images'][0]['rect_raw'],rotation=None,
                            status='decoded',geometry_kind='image',vertical_extent_raw=ints(data,p+28,2))
                if obj['status']!='decoded':item['status']='partial'
                for image in obj['images']:
                    if image['resource_id'] is not None:used_resources.add(image['resource_id'])
                item['objects'].append(obj)
        except (ValueError,InvalidPackage,struct.error,IndexError):
            item.update(status='uninterpreted',objects=[]);item['issues'].append('invalid_page_record')
    result={'profile':PROFILE,'pages':pages,'resources':{str(i):resources[i] for i in sorted(used_resources)}}
    model['page_layouts']=result
    return result


def selected_pages(model):
    pages=model.get('page_layouts',{}).get('pages',[])
    referenced=list(dict.fromkeys(p for d in model.get('documents',[]) for p in d.get('page_ids',[])))
    return sorted((p for p in pages if not referenced or p['page_id'] in referenced),
                  key=lambda p:referenced.index(p['page_id']) if p['page_id'] in referenced else pages.index(p))
