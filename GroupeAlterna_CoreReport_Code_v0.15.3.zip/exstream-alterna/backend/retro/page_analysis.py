"""Bounded PAGE/overflow links and components embedded in page owners."""
import struct
from .binary import MARKER, evidence, occurrences, pascal, u32, InvalidPackage


def analyze_pages(data, model):
    pages={p['id']:p for p in model.get('page_components',[])}
    defs={d['id']:d for d in model.get('definitions',[])}
    rules={r['compiled_id']:r for r in model.get('rules',[])}
    page_props=[];instances=[];rule_uses=[]
    for ident,page in pages.items():
        d=defs[ident];q=d['name_end']+44
        props={'page_id':ident,'name':d['name'],'flow_status':'not_decoded','page_template_status':'not_decoded'}
        try:
            # PAGE dimensions plus the repeated terminal fields have been
            # corroborated across the available PAGE-bearing packages.
            if (data[q:q+8] in (MARKER+struct.pack('<I',136),MARKER+struct.pack('<I',139)) and q+84<=d['end']
                and u32(data,q+12)==4 and u32(data,q+20)==600 and u32(data,q+72)==11):
                mode=u32(data,q+76);target=u32(data,q+80)
                props.update(flow_mode=mode,overflow_page_internal_id=target,
                    evidence=[evidence(data,q,q+84,'OBS-page-geometry-flow-v2')])
                rid=u32(data,q+48)
                if rid in rules:
                    props['global_rule_ids']=[rid]
                    assoc={'kind':'page_global','owner_id':ident,'owner_name':d['name'],
                        'page_id':ident,'rule_id':rid,
                        'evidence':[evidence(data,q,q+84,'OBS-page-global-rule-v1')]}
                    rules[rid].setdefault('associations',[]).append(assoc)
                    rules[rid].setdefault('targets',[]).append(assoc)
                target_id=f'24:{target}'
                if mode==2 and target_id in pages:
                    props.update(flow_status='overflow_target_resolved',overflow_page_id=target_id)
                elif mode==1:
                    props['flow_status']='continuation_page_without_direct_target'
                elif mode==0:
                    props['flow_status']='no_flow_target_on_profile'
        except (InvalidPackage,IndexError,struct.error):pass
        page_props.append(props);page.update(props)

        # Page content is bounded by the counted owner start and its PAGE
        # definition. Component names must have their own marker/type/ID header.
        opening=list(occurrences(data[:d['offset']],MARKER+struct.pack('<II',111,24)+struct.pack('<I',d['internal_id'])))
        if len(opening)!=1:continue
        start=opening[0];end=d['offset']
        if end-start>2_000_000 or any(start<x['offset']<end for x in model['definitions']):continue
        page['owner_offset']=start;page['owner_end']=end
        for hit in occurrences(data[start:end],b'DF_CMP_'):
            p=start+hit
            if p<start+21 or data[p-21:p-17]!=MARKER:continue
            try:
                tag=u32(data,p-17);component_id=u32(data,p-13)
                name,_,name_end=pascal(data,p-1)
                if tag not in (10,11) or not name.startswith('DF_CMP_') or name_end!=p+len(name):continue
                item={'id':f'page-component:{ident}:{p}','page_id':ident,'name':name,
                    'component_type_code':tag,'serialized_id':component_id,'offset':p-21,
                    'confidence':'TRÈS PROBABLE','evidence':[evidence(data,p-21,name_end,'OBS-page-component-name-v1')]}
                instances.append(item)
            except (InvalidPackage,IndexError,UnicodeError):continue

        # Both bounded component-property tags occur in PAGE owners. A rule is
        # accepted only when its component type and compiled ID validate.
        for tag in (1020,1021):
            needle=MARKER+struct.pack('<II',tag,14)
            for marker_at in occurrences(data[start:end],needle):
                p=start+marker_at
                if p+96>end:continue
                shift=80 if p>=4 and u32(data,p-4)==22 else 84
                rid=u32(data,p+shift)
                if u32(data,p+20) not in (10,11) or rid not in rules:continue
                assoc={'kind':'page_component_rule','page_id':ident,'page_name':d['name'],
                    'compiled_id':rid,'evidence':[evidence(data,p,p+shift+4,'OBS-page-component-rule-v2')]}
                rule_uses.append(assoc);rules[rid].setdefault('associations',[]).append(assoc)

    # Follow only explicit overflow-page references, with a cycle guard.
    by_internal={p['internal_id']:p['id'] for p in model.get('page_components',[])}
    for doc in model.get('documents',[]):
        first=doc.get('first_page_id');chain=[];seen=set();current=first
        while current in pages and current not in seen:
            seen.add(current);chain.append(current)
            props=pages[current]
            target=props.get('overflow_page_id')
            if not target:break
            current=target
        if chain:
            doc['page_ids']=chain;doc['overflow_page_ids']=chain[1:]
            doc['page_flow_status']='resolved' if len(chain)>1 else pages[chain[0]].get('flow_status','not_decoded')
    model['page_analysis']={'pages':page_props,'component_instances':instances,
        'rule_uses':rule_uses,'page_templates':[],
        'page_template_status':'Référence de Page template non décodée ; aucun modèle n’est déduit du nom de la page.',
        'limits':['Ordre et placement des composants PAGE non décodés dans l’espace natif.','Aucun Page template n’est associé sans référence sérialisée validée.']}
    model['page_component_instances']=instances
