"""Occurrence paths retain repeated references without duplicating source objects."""


def build_document_flow(model):
    sections={s['id']:s for s in model.get('document_sections',[])}
    known={p['id'] for p in model.get('paragraphs',[])}
    def visit(ident,path,doc,stack=()):
        node={'source_id':ident,'occurrence_id':path,'source_document_id':doc}
        if ident.startswith('206:'):
            node['kind']='section'
            if ident in stack or ident not in sections:
                node.update(resolved=False,children=[])
            else:
                node.update(resolved=True,children=[visit(m['target_id'],f'{path}/{i}',doc,stack+(ident,))
                    for i,m in enumerate(sections[ident]['members'])])
        else:node.update(kind='paragraph',resolved=ident in known)
        return node
    result=[]
    for i,doc in enumerate(model.get('documents',[])):
        path=f'document/{i}'
        refs=doc.get('root_section_ids',doc.get('paragraph_ids',[]))
        result.append({'kind':'document','source_id':doc['id'],'source_document_id':doc['id'],
                       'occurrence_id':path,'children':[visit(s,f'{path}/{j}',doc['id']) for j,s in enumerate(refs)]})
    return result


def paragraph_occurrences(model):
    def walk(node):
        if node['kind']=='paragraph':
            if node['resolved']:yield node
        else:
            for child in node.get('children',[]):yield from walk(child)
    flow=model.get('document_flow',[])
    if flow:
        return [p for doc in flow for p in walk(doc)]
    # Page-only/older models keep their established diagnostic sequence.
    return [{'kind':'paragraph','source_id':pid,'source_document_id':None,
             'occurrence_id':f'diagnostic/{i}','resolved':True}
            for i,pid in enumerate(model.get('document_paragraph_ids',[]))]


def validate_document_flow(model):
    if 'document_flow' not in model:return
    if model['document_flow']!=build_document_flow(model):
        raise ValueError('Document occurrences differ from decoded section references')
    if 'visual' in model and model['visual'].get('document_flow')!=model['document_flow']:
        raise ValueError('Visual occurrences differ from decoded document flow')


def report_events(model):
    """Expose container entries without assigning sections to computed pages."""
    documents={d['id']:d for d in model.get('documents',[])}
    def visit(node):
        if node['kind']=='paragraph':
            if node.get('resolved'):yield node
            return
        yield node
        if node['kind']=='document':
            doc=documents.get(node['source_id'],{})
            for pid in dict.fromkeys(doc.get('page_ids',[])):
                yield {'kind':'page','source_id':pid,'source_document_id':node['source_id'],
                    'page_role':'initial' if pid==doc.get('first_page_id') else
                        'overflow' if pid in doc.get('overflow_page_ids',[]) else 'reference'}
        for child in node.get('children',[]):yield from visit(child)
    flow=model.get('document_flow',[])
    if flow:
        for doc in flow:yield from visit(doc)
    else:yield from paragraph_occurrences(model)
