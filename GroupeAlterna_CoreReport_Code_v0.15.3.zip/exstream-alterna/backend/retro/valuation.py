"""Static, bounded assignment sites in calculations AND rules; no evaluation."""
import re
from .binary import evidence
from .rules import TOKEN


def skeleton(code):
    # Preserve offsets while masking literals/comments; calls inside them are not code.
    return TOKEN.sub(lambda m: ' ' * len(m.group()) if m.group().startswith(('"', "'", '//', '/*')) else m.group(), code)


def close_at(mask,start,left='(',right=')'):
    depth=0
    for p in range(start,len(mask)):
        if mask[p]==left:depth+=1
        elif mask[p]==right:
            depth-=1
            if depth==0:return p
    return None


def calls(code,method):
    mask=skeleton(code)
    for hit in re.finditer(r'\bUserLogic\.'+method+r'\s*\(',mask):
        a=hit.end()-1;b=close_at(mask,a)
        if b is None:continue
        cuts=[a+1];depth=0
        for p in range(a+1,b):
            if mask[p] in '([{':depth+=1
            elif mask[p] in ')]}':depth-=1
            elif mask[p]==',' and depth==0:cuts.append(p+1)
        ends=[p-1 for p in cuts[1:]]+[b]
        yield hit.start(),b+1,[code[p:q].strip() for p,q in zip(cuts,ends)]


def resolve(arg,byid,byname):
    if re.fullmatch(r'\d+',arg):return byid.get(int(arg))
    if len(arg)>=2 and arg[0]==arg[-1] and arg[0] in '\"\'':return byname.get(arg[1:-1])


def readable(expr,byid,byname):
    result=expr
    # Inner calls first: exact variable ID/name lookups only, no arbitrary evaluation.
    for _ in range(6):
        edits=[]
        for a,b,args in calls(result,r'getValue(?:At|WithType)?'):
            if not args:continue
            v=resolve(args[0],byid,byname)
            if not v:continue
            suffix='('+', '.join(args[1:])+')' if len(args)>1 else ''
            edits.append((a,b,v['name']+suffix))
        if not edits:break
        # Apply non-overlapping innermost spans only; outer calls are revisited.
        inner=[x for x in edits if not any(x[0]<y[0]<y[1]<=x[1] for y in edits)]
        for a,b,rep in sorted(inner,reverse=True):result=result[:a]+rep+result[b:]
    return result


def assignment_sites(data,code,base,variables):
    byid={v['internal_id']:v for v in variables};byname={v['name']:v for v in variables};mask=skeleton(code)
    guards=[]
    for hit in re.finditer(r'\bif\s*\(',mask):
        a=hit.end()-1;b=close_at(mask,a)
        if b is None:continue
        q=b+1
        while q<len(mask) and mask[q].isspace():q+=1
        if q==len(mask) or mask[q]!='{':continue
        e=close_at(mask,q,'{','}')
        if e is None:continue
        guards.append((q,e,code[a+1:b].strip()))
        tail=re.match(r'\s*else\s*\{',mask[e+1:])
        if tail:
            q2=e+1+tail.end()-1;e2=close_at(mask,q2,'{','}')
            if e2:guards.append((q2,e2,'ELSE du IF ('+code[a+1:b].strip()+')'))
    sites=[]
    for a,b,args in calls(code,r'setValue(?:At)?'):
        if len(args)<2:continue
        v=resolve(args[0],byid,byname)
        if v is None:continue
        expr=args[-1];reads=[]
        for _,_,rargs in calls(expr,r'getValue(?:At|WithType)?'):
            if rargs:
                rv=resolve(rargs[0],byid,byname)
                if rv and rv['id'] not in reads:reads.append(rv['id'])
        sites.append({'variable_id':v['id'],'variable_name':v['name'],'offset':base+a,
            'lexical_order':len(sites)+1,'compiled_statement':code[a:b],
            'expression_raw':expr,'expression_readable':readable(expr,byid,byname),
            'index_expression':args[1] if len(args)>2 else None,'read_variable_ids':reads,
            'branch_conditions':[readable(cond,byid,byname) for q,e,cond in guards if q<a<e],
            'evidence':[evidence(data,base+a,base+b,'OBS-static-assignment-v1')],
            'limitation':'Site statique ; branche et ordre lexical conservés. Déclenchement global et valeur effective non évalués.'})
    return sites


def enrich_valuations(data,model):
    for c in model['calculations']:
        c['assignments']=assignment_sites(data,c['source_code'],c['offset'],model['variables'])
        c['writes']=sorted({int(s['variable_id'].split(':')[1]) for s in c['assignments']})
        c['write_names']=list(dict.fromkeys(s['variable_name'] for s in c['assignments']))
    for r in model['rules']:
        for v in r['variants']:
            v['assignments']=assignment_sites(data,v['compiled_code'],v['offset'],model['variables'])
            v['writes']=sorted({int(s['variable_id'].split(':')[1]) for s in v['assignments']})
    defs={d['id']:d for d in model['definitions']}
    model['page_components']=[{'id':d['id'],'name':d['name'],'internal_id':d['internal_id'],'offset':d['offset'],
        'first_page_of':[x['name'] for x in model.get('documents',[]) if x.get('first_page_id')==d['id']],
        'evidence':d['evidence'],'limitation':'Définition de page prouvée ; ordre de sortie et instanciation non déduits du nom.'}
        for d in defs.values() if d['class_code']==24]

    byid={v['internal_id']:v for v in model['variables']};byname={v['name']:v for v in model['variables']}
    for c in model['calculations']:
        parsed={c['offset']+a:args for a,_,args in calls(c['source_code'],r'callSubfunction')}
        for call in c.get('calls',[]):
            args=parsed.get(call['offset'])
            if args:call['arguments_raw']=args[1:];call['arguments_readable']=[readable(x,byid,byname) for x in args[1:]]
