from .report_cover import build_with_cover
from .i18n import tr, note
"""Rapport de diagnostic : n'annonce jamais une rétro-documentation complète."""
from pathlib import Path
from xml.sax.saxutils import escape
import json
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.units import mm
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,PageBreak,Table,TableStyle,KeepTogether
ROOT=Path(__file__).resolve().parents[2]
FONT=Path('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf')
BOLD=Path('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf')

def setup():
    if 'Alterna' not in pdfmetrics.getRegisteredFontNames():
        pdfmetrics.registerFont(TTFont('Alterna',str(FONT)))
        pdfmetrics.registerFont(TTFont('AlternaBold',str(BOLD)))
    if 'AlternaMono' not in pdfmetrics.getRegisteredFontNames():
        pdfmetrics.registerFont(TTFont('AlternaMono',str(FONT.with_name('DejaVuSansMono.ttf'))))
    tokens=json.loads((ROOT/'assets/alterna.tokens.json').read_text())
    return {k:colors.HexColor(v['value']) for k,v in tokens['colors'].items()}

def report(model,path,chapters=None,*,language="fr"):
    from .i18n import use_language
    with use_language(language):
        result=_report(model,path,chapters)
        from .report_options import normalize_chapters
        if model.get('kind')!='comparison' and 'template_pages' in normalize_chapters(chapters):
            from .report_pages import append_page_annex
            append_page_annex(model,path)
        from .source_archive import attach_design_archive
        attach_design_archive(model,path)
        return result

def _report(model,path,chapters=None):
    if model.get("kind") != "comparison" and model.get("document_paragraph_ids"):
        from .report_structure import report_structure
        return report_structure(model, path, chapters=chapters)
    if model.get("kind") != "comparison":
        from .report_detail import report_detail
        return report_detail(model,path,chapters=chapters)
    c=setup(); styles={
      'body':ParagraphStyle('body',fontName='Alterna',fontSize=12,leading=16,textColor=c['navy'],spaceAfter=9,splitLongWords=True),
      'small':ParagraphStyle('small',fontName='Alterna',fontSize=10,leading=14,textColor=c['navy'],spaceAfter=6,splitLongWords=True),
      'title':ParagraphStyle('title',fontName='AlternaBold',fontSize=20,leading=25,textColor=c['navy'],spaceAfter=16),
      'h':ParagraphStyle('h',fontName='AlternaBold',fontSize=16,leading=21,textColor=c['navy'],spaceBefore=10,spaceAfter=12)}
    story=[]
    def p(text,style='body'):return Paragraph(escape(str(text)).replace('\n','<br/>'),styles[style])
    def add(text,style='body'):story.append(p(text,style))
    def new(title):
        if story:story.append(PageBreak())
        add(title,'title')
    def table(rows,widths):
        data=[[p(v,'small') for v in row] for row in rows]
        tab=Table(data,colWidths=widths,repeatRows=1,hAlign='LEFT')
        tab.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),c['surface']),('VALIGN',(0,0),(-1,-1),'TOP'),
            ('LINEBELOW',(0,0),(-1,0),1,c['primary']),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,c['surface']]),
            ('LEFTPADDING',(0,0),(-1,-1),8),('RIGHTPADDING',(0,0),(-1,-1),8),('TOPPADDING',(0,0),(-1,-1),7),('BOTTOMPADDING',(0,0),(-1,-1),7)]))
        story.append(tab)
    if model.get('kind')=='comparison':
        new(tr('Comparaison de packages'))
        add(tr('Diagnostic partiel • moteur ')+model['engine_version'])
        for label,source in zip(('Version A','Version B'),model['sources']):
            add(label+' : '+source['source_name'])
        table([[tr('Classement'),tr('Nombre')]]+[[tr(k),v] for k,v in model['counts'].items()],[340,110])
        add(tr('Les différences sont établies sur les observations décodées. Elles ne représentent pas une validation du comportement des courriers.'))
        from .hierarchy import append_hierarchy
        for label,rows in zip(('Version A','Version B'),model.get('application_structures',[])):
            add(label,'h');append_hierarchy(story,rows,c)
        new(tr('Écarts observés'))
        changed=[x for x in model['changes'] if x['status']!='inchangé']
        for item in changed[:12]:add(f"{tr(item['status'])} • {item['kind']} • {item['id']}",'small')
        add(tr('{0} écarts au total. Cette vue synthétique présente les douze premiers écarts ; les rapports des versions A et B détaillent leurs observations.').format(len(changed)))
        new(tr('Limites de la comparaison'))
        for text in model['unknowns']:add(note(text))
        add(tr('Une différence de position binaire est enregistrée comme changement de représentation, jamais comme changement d’ordre documentaire.'))
        add(tr('XSD non disponible : ')+note(model['xsd']['reason']))
    def header(canvas,doc):
        canvas.saveState();canvas.drawImage(str(ROOT/'assets/Logo_GroupeAlterna_825px.png'),(595.27-42*mm)/2,755,width=42*mm,height=42*mm*416/825,mask='auto')
        canvas.setFont('Alterna',9);canvas.setFillColor(c['muted']);canvas.drawString(25*mm,15*mm,tr('Groupe Alterna | Diagnostic partiel'));canvas.drawRightString(570,15*mm,str(doc.page-1));canvas.restoreState()
    doc=SimpleDocTemplate(str(path),pagesize=(595.276,841.89),leftMargin=25*mm,rightMargin=25*mm,topMargin=43*mm,bottomMargin=25*mm,
        title='Core Report | '+tr('Rétro-analyse Exstream - diagnostic partiel'),author='Groupe Alterna')
    build_with_cover(doc, story, model, header)
