"""Worker local de développement, processus séparés et arrêt réel des jobs."""
import multiprocessing,time
from .db import initialize,transaction,Session,Job
from .config import settings
from .jobs import run_job,purge,mark_failure,TERMINAL

def main():
    initialize()
    if settings.queue_backend!='local':raise SystemExit('Utiliser rq worker pour QUEUE_BACKEND=rq')
    while True:
        purge();jid=None
        with transaction() as db:
            j=db.query(Job).filter(Job.state=='attente').order_by(Job.created).first()
            if j:j.state='controle';j.updated=time.time();jid=j.id
        if not jid:time.sleep(.5);continue
        process=multiprocessing.Process(target=run_job,args=(jid,));process.start();start=time.monotonic()
        while process.is_alive():
            with Session() as db:
                j=db.get(Job,jid);stop=not j or j.cancelled or j.state=='expire'
            if stop or time.monotonic()-start>settings.max_job_seconds:
                process.terminate();process.join(5)
                if process.is_alive():process.kill();process.join()
                mark_failure(jid,'WORKER_TIMEOUT');break
            process.join(.5)
        if process.exitcode not in (0,None):mark_failure(jid)
if __name__=='__main__':main()
