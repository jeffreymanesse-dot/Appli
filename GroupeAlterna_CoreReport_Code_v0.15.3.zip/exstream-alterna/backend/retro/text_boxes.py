"""Text boxes retain their own frame, fill, geometry and paragraph rules."""
import struct
from .binary import u32,pascal,evidence
from .table_frames import object_frame_owner,object_frame

def text_box_frame(data,item,decoder):
    """Bounded text-box object with a rich-text payload; never a table/grid."""
    rt=item.get('richtext') or {};outer=rt.get('outer_offset')
    if outer is None or data[outer+4:outer+8]!=struct.pack('<I',113):return None
    if u32(data,outer+8)!=u32(data,item['offset']+4):return None
    p=object_frame_owner(data,outer+4)
    if p is None:return None
    x,y,r,b=struct.unpack_from('<4i',data,p+20)
    if not (0<r-x<100000 and 0<b-y<100000):return None
    frame=object_frame(data,p,outer+4,decoder,'text_box','OBS-text-box-frame-v1')
    name,_,_=pascal(data,p+257)
    insets=[u32(data,outer+4+k) for k in range(124,140,4)]
    padding=insets[0]*.24 if len(set(insets))==1 and insets[0]<300 else None
    return {'kind':'text_box','profile':'OBS-text-box-richtext-v1','object_offset':p,'content_id':item['id'],
            'name':name,'rect_raw':[x,y,r,b],'width_pt':(r-x)*.24,'height_pt':(b-y)*.24,
            'frame':frame,'uniform_padding_pt':padding,'evidence':[evidence(data,p,item['offset'],'OBS-text-box-richtext-v1')]}
