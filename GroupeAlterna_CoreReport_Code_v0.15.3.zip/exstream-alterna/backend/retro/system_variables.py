"""Documentary reference, not an Exstream evaluator or a binary decoder.

Only names in the left-hand column are catalog entries. A prose-only mention
must never silently become an alias. All PUB identities and values stay intact.
"""
from copy import deepcopy

SOURCE = {
    'filename': 'VariableSystem.pdf',
    'title': 'Designing Communications with Exstream Communications Designer',
    'chapter': '3. Working with data sources',
    'printed_pages': ['3-20', '3-21', '3-22', '3-23', '3-24'],
    'sha256': '7ec138d7ce81b5157aa48f7a05bacbba636aed0c89fcac64e22a12fc33190d18',
}
FAMILY_LABELS = {
    'communication_design': ('Conception de communication', 'Communication design'),
    'counting_numbering': ('Comptage et numérotation', 'Counting and numbering'),
    'customer': ('Client', 'Customer'), 'date': ('Date', 'Date'),
    'design': ('Conception', 'Design'),
    'high_volume_output': ('Traitement de sortie haut volume', 'High-volume output processing'),
    'production': ('Production', 'Production'),
}
# Explicit table rows grouped by family and PDF page; no matches in prose.
SOURCE_ROWS = {
    'communication_design': {
        1: 'DocumentNames PageInDocument PagePhysicalInDocument PagePrintedValue PageStart PageTotalInDocument PageTotalPhysicalInDocument PageTotalPrinted SheetInDocument',
        2: 'SheetTotalInDocument SubDocInDocument TotalSubDocsInDocument',
    },
    'counting_numbering': {
        2: 'ByteInQueue CustomerInRun DocumentTotalInRun PageInBreak PageInDocument PageInQueue PagePhysicalInDocument PagePrintedValue PageStart PageTotalInDocument PageTotalInRun',
        3: 'PageTotalPhysicalInDocument PageTotalPrinted SheetInBreak SheetInDocument SheetInQueue SheetTotalInDocument TableRow TotalSubDocsInDocument',
    },
    'customer': {
        3: 'CustomerInRun DocumentNames LanguageCustomer LanguageDefault LocaleCustomer LocaleDefault',
        4: 'TotalSubDocsInDocument',
    },
    'date': {4: 'DateAsOf DateCurrent'},
    'design': {4: 'LanguageCustomer LanguageDefault LocaleCustomer LocaleDefault TableRow'},
    'high_volume_output': {
        4: 'ByteInQueue DocumentInBreak DocumentInQueue PageInBreak',
        5: 'PageInQueue PrinterInQueue QueueCurrent SheetInBreak SheetInQueue SubDocumentInBreak SubDocumentInQueue',
    },
    'production': {5: 'CustomerInRun DateAsOf DateCurrent DocumentTotalInRun LanguageCustomer LanguageDefault PageTotalInRun SheetTotalInRun'},
}
# Short paraphrases of the supplied documentation, FR / EN. No execution values.
DESCRIPTIONS = {
    'DocumentNames': ('Noms des documents inclus pour le client.', 'Names of documents included for the customer.'),
    'PageInDocument': ('Rang de la page comptée courante dans le document ; distinct du rang de feuille en recto verso.', 'Current counted page position in the document; distinct from sheet position for duplex output.'),
    'PagePhysicalInDocument': ('Rang de la page physique courante ; distinct du comptage logique.', 'Current physical page position; distinct from logical counting.'),
    'PagePrintedValue': ('Numéro à imprimer pour la page courante ; peut différer du compteur après une reprise de numérotation.', 'Page number to print; may differ from the counter after numbering resets.'),
    'PageStart': ('Nombre initial de pages, avant les exclusions par règles ou limites marketing.', 'Initial page count, before rule or marketing-limit exclusions.'),
    'PageTotalInDocument': ('Total de pages comptées dans le document.', 'Total counted pages in the document.'),
    'PageTotalPhysicalInDocument': ('Total de pages physiques dans le document.', 'Total physical pages in the document.'),
    'PageTotalPrinted': ('Numéro de la dernière page du document ; ce n’est pas nécessairement le total physique.', 'Last page number in the document; not necessarily the physical page total.'),
    'SheetInDocument': ('Rang de la feuille courante dans le document.', 'Current sheet position in the document.'),
    'SheetTotalInDocument': ('Total de feuilles du document.', 'Total sheets in the document.'),
    'SubDocInDocument': ('Rang du sous-document de conception dans le document client.', 'Design sub-document position within the customer document.'),
    'TotalSubDocsInDocument': ('Nombre de sous-documents de conception dans le document client.', 'Number of design sub-documents in the customer document.'),
    'ByteInQueue': ('Nombre total d’octets écrits dans la file de sortie courante.', 'Total bytes written to the current output queue.'),
    'CustomerInRun': ('Rang du client courant dans le traitement.', 'Current customer position in the engine run.'),
    'DocumentTotalInRun': ('Nombre total de documents du traitement.', 'Total documents in the engine run.'),
    'PageInBreak': ('Rang de la page dans la rupture de sortie courante.', 'Page position within the current output queue break.'),
    'PageInQueue': ('Total de pages physiques incluses dans la file de sortie courante.', 'Total physical pages included in the current output queue.'),
    'PageTotalInRun': ('Total de pages du traitement.', 'Total pages in the engine run.'),
    'SheetInBreak': ('Rang de la feuille dans la rupture de sortie courante.', 'Sheet position within the current output queue break.'),
    'SheetInQueue': ('Compteur de feuilles de la file de sortie ; les descriptions du guide divergent.', 'Output queue sheet counter; source descriptions differ.'),
    'TableRow': ('Rang de la ligne automatisée ; en répétition, le compteur inclut aussi les lignes non composées.', 'Automated row position; for repeated rows the count also includes rows not composed.'),
    'LanguageCustomer': ('Langue du client courant, pour la sélection des objets et paramètres linguistiques.', 'Current customer language for language-dependent objects and settings.'),
    'LanguageDefault': ('Langue par défaut des clients du traitement.', 'Default language for customers in the engine run.'),
    'LocaleCustomer': ('Paramètres régionaux du client courant.', 'Current customer locale.'),
    'LocaleDefault': ('Paramètres régionaux par défaut du traitement.', 'Default locale for the engine run.'),
    'DateAsOf': ('Date de référence du traitement.', 'As-of date for the engine run.'),
    'DateCurrent': ('Jour où le moteur produit les documents ; non assimilé à la date de rétro-analyse.', 'Day the engine produces documents; not the retro-analysis date.'),
    'DocumentInBreak': ('Rang du document dans la rupture de sortie courante.', 'Document position within the current output queue break.'),
    'DocumentInQueue': ('Rang du client dans la file de sortie, selon la description du guide.', 'Customer position in the output queue, according to the source description.'),
    'PrinterInQueue': ('Nom du périphérique associé à la file de sortie courante.', 'Output device name associated with the current queue.'),
    'QueueCurrent': ('Nom de la file de sortie courante.', 'Current output queue name.'),
    'SubDocumentInBreak': ('Rang du document dans la rupture de sortie, selon le guide.', 'Document position within the output queue break, according to the guide.'),
    'SubDocumentInQueue': ('Rang du document dans la file de sortie, selon le guide.', 'Document position within the output queue, according to the guide.'),
    'SheetTotalInRun': ('Total de feuilles du traitement.', 'Total sheets in the engine run.'),
}
NOTES = {
    'SYS_PageTotalPrinted': ('La description p. 3-20 cite aussi SYS_PageTotalPrintedInDocument, sans ligne propre : alias non confirmé.', 'The description on p. 3-20 also mentions SYS_PageTotalPrintedInDocument without its own row: alias unconfirmed.'),
    'SYS_SheetInQueue': ('Le guide parle de total p. 3-22 et de rang p. 3-24 ; cette divergence est conservée.', 'The guide says total on p. 3-22 and sequence on p. 3-24; this discrepancy is retained.'),
    'SYS_LanguageCustomer': ('La rubrique Production p. 3-24 diffère des rubriques Client/Conception : elle évoque une langue par défaut.', 'Production on p. 3-24 differs from Customer/Design: it describes a default language.'),
    'SYS_LanguageDefault': ('La rubrique Production p. 3-24 évoque une locale par défaut ; Client/Conception indiquent une langue.', 'Production on p. 3-24 describes a default locale; Customer/Design describe a language.'),
}
MENTION_ONLY = {'SYS_PageTotalPrintedInDocument': {'pdf_page': 1, 'printed_page': '3-20', 'row_name': 'SYS_PageTotalPrinted'}}
CATALOG = {}
for family, pages in SOURCE_ROWS.items():
    for page, names in pages.items():
        for suffix in names.split():
            name = 'SYS_' + suffix
            entry = CATALOG.setdefault(name, {'name': name, 'families': [], 'source_occurrences': [],
                'description_fr': DESCRIPTIONS[suffix][0], 'description_en': DESCRIPTIONS[suffix][1]})
            if family not in entry['families']:
                entry['families'].append(family)
            entry['source_occurrences'].append({'family': family, 'pdf_page': page, 'printed_page': f'3-{19 + page}'})
            if name in NOTES:
                entry['note_fr'], entry['note_en'] = NOTES[name]


def enrich_system_variables(model):
    """Add documentary annotations; preserve source, origin, assignments and samples."""
    present = []
    for variable in model['variables']:
        name = variable['name']
        variable['system_variable'] = name.startswith('SYS_')
        if not variable['system_variable']:
            continue
        entry = CATALOG.get(name)
        detail = deepcopy(entry) if entry else {'name': name, 'families': [], 'source_occurrences': []}
        detail['status'] = 'documented' if entry else 'mention_only' if name in MENTION_ONLY else 'not_listed'
        detail['classification_basis'] = 'catalog_exact_name' if entry else 'existing_SYS_prefix_convention'
        detail['runtime_value_status'] = 'not_evaluated'
        if name in MENTION_ONLY:
            detail['mention'] = deepcopy(MENTION_ONLY[name])
        variable['system_variable_details'] = detail
        present.append(variable)
    documented = [v for v in present if v['system_variable_details']['status'] == 'documented']
    docids = set(model.get('document_variable_ids', []))
    model['system_variable_catalog'] = {
        'source': deepcopy(SOURCE), 'documented_name_count': len(CATALOG),
        'family_membership_count': sum(len(e['source_occurrences']) for e in CATALOG.values()),
        'documented_names': sorted(CATALOG), 'mention_only_names': sorted(MENTION_ONLY),
        'present_in_package_names': sorted({v['name'] for v in documented}),
        'present_in_package_variable_ids': [v['id'] for v in documented],
        'present_in_document_names': sorted({v['name'] for v in documented if v['id'] in docids}),
        'uncatalogued_system_names': sorted({v['name'] for v in present if v not in documented}),
    }
