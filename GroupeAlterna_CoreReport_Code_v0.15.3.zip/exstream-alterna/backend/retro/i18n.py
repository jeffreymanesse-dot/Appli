"""Presentation only: explicit messages, isolated per request/render.

Never pass PUB literals, identifiers, algorithms, paths or conditions to tr().
No translation service is called; the evidence model is never rewritten.
"""
import json
import re
from contextlib import contextmanager
from contextvars import ContextVar
from pathlib import Path

LANGUAGE=ContextVar('presentation_language',default='fr')
MESSAGES=json.loads(Path(__file__).with_name('messages_en.json').read_text(encoding='utf-8'))

def normalize_language(language='fr'):
    if language not in ('fr','en'):raise ValueError('Unsupported report language')
    return language

@contextmanager
def use_language(language='fr'):
    token=LANGUAGE.set(normalize_language(language))
    try:yield
    finally:LANGUAGE.reset(token)

def tr(message):
    return MESSAGES.get(message,message) if LANGUAGE.get()=='en' else message

def note(message):
    """Only engine-generated diagnostics; preserve interpolated offsets."""
    if LANGUAGE.get()=='fr':return message
    if message in MESSAGES:return MESSAGES[message]
    patterns=(
        (r'Position (\d+)(.*)',lambda m:'Position '+m[1]+tr(m[2])),
        (r'Opcode de composition non interprété : ([0-9]+) à ([0-9]+)',lambda m:'Uninterpreted composition opcode: '+m[1]+' at '+m[2]),
        (r'Police étendue non reconnue à ([0-9]+)',lambda m:'Unrecognised extended font at '+m[1]),
        (r'Référence variable inconnue ou mode non interprété : ([0-9]+)',lambda m:'Unknown variable reference or uninterpreted mode: '+m[1]),
    )
    for pattern,render in patterns:
        match=re.fullmatch(pattern,message)
        if match:return render(match)
    return message
