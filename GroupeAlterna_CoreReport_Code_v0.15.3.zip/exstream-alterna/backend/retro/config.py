import os
from dataclasses import dataclass
from pathlib import Path
@dataclass(frozen=True)
class Settings:
    database_url:str=os.getenv('DATABASE_URL','sqlite:///./var/jobs.db')
    storage:Path=Path(os.getenv('STORAGE_DIR','./var/private')).resolve()
    queue_backend:str=os.getenv('QUEUE_BACKEND','local')
    redis_url:str=os.getenv('REDIS_URL','redis://redis:6379/0')
    auth_mode:str=os.getenv('AUTH_MODE','dev')
    signing_key:str=os.getenv('APP_SIGNING_KEY','')
    proxy_key:str=os.getenv('PROXY_AUTH_KEY','')
    allowed_origins:tuple=tuple(os.getenv('ALLOWED_ORIGINS','http://localhost:3000,http://127.0.0.1:3000').split(','))
    retention_seconds:int=int(os.getenv('RETENTION_SECONDS','86400'))
    download_seconds:int=int(os.getenv('DOWNLOAD_SECONDS','300'))
    max_job_seconds:int=int(os.getenv('MAX_JOB_SECONDS','300'))
    max_total_jobs:int=int(os.getenv('MAX_TOTAL_JOBS','6'))
    max_user_jobs:int=int(os.getenv('MAX_USER_JOBS','3'))
    disk_quota_bytes:int=int(os.getenv('DISK_QUOTA_BYTES',str(2*1024**3)))
    max_output_bytes:int=int(os.getenv('MAX_OUTPUT_BYTES',str(256*1024**2)))
    max_file_bytes:int=int(os.getenv('MAX_FILE_BYTES',str(32*1024**2)))
    production:bool=os.getenv('APP_ENV','development')=='production'
    def validate(self):
        if self.auth_mode not in ('dev','proxy') or self.queue_backend not in ('local','rq'):raise RuntimeError('Configuration invalide')
        if len(self.signing_key)<32 or self.signing_key.startswith('REPLACE_'):raise RuntimeError('APP_SIGNING_KEY doit contenir au moins 32 caractères aléatoires')
        if self.production and (self.auth_mode!='proxy' or len(self.proxy_key)<32 or self.queue_backend!='rq' or not self.database_url.startswith('postgresql')):
            raise RuntimeError('Production exige proxy authentifiant signé, PostgreSQL et RQ')
        if self.retention_seconds<60 or self.download_seconds<1 or self.max_job_seconds<5:raise RuntimeError('Délais invalides')
        if self.max_file_bytes>32*1024**2 or min(self.max_file_bytes,self.max_total_jobs,self.disk_quota_bytes)<=0:raise RuntimeError('Quotas invalides')
        if '*' in self.allowed_origins:raise RuntimeError('Origines explicites requises')
settings=Settings()
