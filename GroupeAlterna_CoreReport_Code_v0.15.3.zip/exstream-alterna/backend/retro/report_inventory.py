"""Package summary only; the complete inventory remains in the analysis model."""
import re
from .i18n import tr


def inventory_rows(model):
    groups={k:[] for k in ('APP','DOC','PAG','CMP','PAR','STY','RUL')}
    for item in model['inventory']:
        match=re.match(r'(?:DF_)?(APP|DOC|PAG|CMP|PAR|STY|RUL)_',item['name'])
        if match:groups[match[1]].append(item)
    summary=[[tr('Famille'),tr('Noms observés / objets décodés')]]
    classes={'DOC':10,'PAG':24,'CMP':6,'PAR':21}
    for k,items in groups.items():
        summary.append([k,str(len(items))+' / '+(str(sum(d['class_code']==classes[k] for d in model['definitions'])) if k in classes else tr('classe non calibrée'))])
    summary += [[tr('Variables'),str(len(model['variables']))],
                [tr('Règles compilées'),str(len(model['rules']))],
                [tr('Fonctions/formules'),str(len(model['calculations']))],
                [tr('Mappings décodés'),str(len(model['mappings']))]]
    return summary


def inventory_appendix(model,story,p,table,add,rlabels):
    add(tr('Inventaire du package'),'sub')
    story.append(table(inventory_rows(model),[180,311]))
