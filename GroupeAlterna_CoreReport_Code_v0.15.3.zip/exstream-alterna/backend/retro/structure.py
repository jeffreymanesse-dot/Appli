"""Counted document/section graph. No selection by business names or proximity."""
from .binary import u32, evidence, pascal, InvalidPackage
from .layout import sig


def document_record(data, d, defs):
    """Count pages after the optional section selector; do not assume one page."""
    a=d['name_end'];end=d['end']
    try:
        if a+77>end or data[a+44:a+52]!=sig(120):return None
        mode,count=u32(data,a+64),u32(data,a+68)
        if mode not in (0,1) or count not in (0,1):return None
        section,_,stop=pascal(data,a+72)
        if stop>end or bool(section)!=bool(count) or any(not c.isprintable() for c in section):return None
        # One opaque page selector followed by a counted list of 24-byte page records.
        pages_at=stop+4;n=u32(data,pages_at);p=pages_at+4;pages=[]
        if not 1<=n<=256 or p+24*n+89>end:return None
        for i in range(n):
            q=p+24*i;ident=f'24:{u32(data,q)}'
            if ident not in defs or data[q+4:q+24]!=sig(-102,0,0,0)[4:]+sig():return None
            pages.append(ident)
        tail=p+24*n;root_count=u32(data,tail+69);roots_at=tail+73
        if not 0<root_count<=1000 or roots_at+4*root_count+20>end:return None
        roots=[f'206:{u32(data,roots_at+4*i)}' for i in range(root_count)]
        if not all(ident in defs for ident in roots):return None
        suffix=roots_at+4*root_count
        # The middle word is an observed 0/1 option, not a universal zero sentinel.
        if u32(data,suffix)!=0 or u32(data,suffix+4) not in (0,1) or u32(data,suffix+8)!=0:return None
        if data[suffix+12:suffix+20]!=sig(116)[4:]+(4).to_bytes(4,'little'):return None
        return {'id':d['id'],'name':d['name'],'root_section_ids':roots,'first_page_id':pages[0],
                'page_ids':pages,'data_section_name':section or None,
                'data_section_reference_offset':a+72 if section else None,
                'rule_id_raw':u32(data,tail),'root_option_raw':u32(data,suffix+4),
                'evidence':[evidence(data,a+44,suffix+20,'OBS-document-root-120-v2')]}
    except (InvalidPackage,IndexError):return None


def document_graph(data, model):
    defs={d['id']:d for d in model['definitions']};sections={};documents=[];edges=[];issues=[]
    for d in model['definitions']:
        a=d['name_end'];end=d['end']
        if d['class_code']==206:
            if a+72>end or data[a+44:a+52]!=sig(111):continue
            n=u32(data,a+68);p=a+72;members=[]
            if not 0<n<=1000:continue
            for i in range(n):
                if i:
                    if data[p:p+4]!=sig():break
                    p+=4
                if p+12>end or u32(data,p)!=101:break
                kind=u32(data,p+4);iid=u32(data,p+8)
                if kind not in (205,206):break
                target=f'{21 if kind==205 else 206}:{iid}'
                members.append({'target_id':target,'ordinal':i,'offset':p,'resolved':target in defs,
                                'evidence':[evidence(data,p,p+12,'OBS-mixed-section-members-v2')]});p+=12
            if len(members)!=n or data[p:p+8]!=sig(1):
                issues.append({'object_id':d['id'],'reason':'Liste de section incomplète ou terminaison inconnue'});continue
            sections[d['id']]={'id':d['id'],'name':d['name'],'members':members,'paragraph_ids':[],
                                  'confidence':'TRÈS PROBABLE','evidence':[evidence(data,a+44,p+8,'OBS-mixed-section-members-v2')]}
            edges.extend({'source_id':d['id'],**x} for x in members)
        if d['class_code']==10:
            doc=document_record(data,d,defs)
            if doc is None:continue
            documents.append(doc)
            edges.extend({'source_id':d['id'],'target_id':s,'ordinal':i,'resolved':True,'evidence':doc['evidence']} for i,s in enumerate(doc['root_section_ids']))
            edges.extend({'source_id':d['id'],'target_id':page,'role':'first_page' if i==0 else 'page_reference','ordinal':i,'evidence':doc['evidence']} for i,page in enumerate(doc['page_ids']))
    def expand(sid, stack=()):
        if sid in stack:
            issues.append({'object_id':sid,'reason':'Cycle de sections ; ordre non résolu'});return []
        if sid not in sections:
            issues.append({'object_id':sid,'reason':'Section référencée non décodée'});return []
        out=[]
        for member in sections[sid]['members']:
            target=member['target_id']
            if target.startswith('206:'):out.extend(expand(target,stack+(sid,)))
            else:out.append(target)
        return out
    for s in sections.values():s['paragraph_ids']=expand(s['id'])
    order=[]
    for doc in documents:
        doc['paragraph_ids']=[p for s in doc['root_section_ids'] for p in expand(s)]
        order.extend(doc['paragraph_ids'])
    model['documents']=documents;model['document_sections']=list(sections.values());model['structural_edges']=edges;model['structure_issues']=issues
    known={p['id'] for p in model['paragraphs']}
    model['unresolved_document_paragraph_ids']=[p for p in order if p not in known]
    model['document_paragraph_ids']=list(dict.fromkeys(p for p in order if p in known))
    model['document_content_ids']=[u['id'] for u in model['content_units'] if u['parent_id'] in set(order)]
    model['document_rule_ids']=sorted(r['compiled_id'] for r in model['rules'] if any(x.get('paragraph_id') in order for x in r.get('associations',[])))
    model['metadata']['ordering']='document_root_and_nested_counted_sections' if order else 'partial_page_ownership_only'
