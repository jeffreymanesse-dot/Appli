"""Versioned, bounded table graphics profile calibrated on controlled PUB edits.

No source names, hashes, palette constants or absolute offsets select this reader.
Every address comes from a recognized axis, rich-text owner or cell trailer.
The 300/inch conversion is deliberately NOT applied to drawing bounding boxes.
"""
import struct
from collections import Counter
from .binary import MARKER, InvalidPackage, evidence, u32

PROFILE = 'OBS-table-styles-300-2026-v3'
SHAPES = {0: 'rectangle', 5: 'rounded', 9: 'rounded_left', 10: 'rounded_right'}
SIDES = {1: ('top',4), 2: ('right',2), 4: ('bottom',8), 8: ('left',1)}


def measure(data, offset, raw=None):
    value = u32(data, offset)
    if raw is not None and raw != value:
        raise InvalidPackage('Dimension and record disagree')
    if value > 1_000_000:
        raise InvalidPackage('Dimension outside the calibrated numeric domain')
    return {'raw': value, 'source_unit': '1/300 inch', 'cm': value * 2.54 / 300,
            'pt': value * 72 / 300, 'offset': offset,
            'evidence': [evidence(data, offset, offset + 4, PROFILE)]}


def proven_colour(data, decoder, color):
    if not color or not color.get('rgb'):
        return {'status': 'uninterpreted', 'raw': color}
    p = color['offset']
    proof = [evidence(data, p, p + 12, PROFILE)]
    if color.get('kind') == 'palette':
        q = color['palette_offset']
        proof.append(evidence(data, q, q + 32, PROFILE))
    return {**color, 'status': 'decoded', 'evidence': proof}


def shape(data, item):
    rt = item.get('richtext') or {}
    lp = rt.get('rule_list_offset')
    style = rt.get('style_offset')
    end = item.get('cell_trailer_offset', item.get('decode_end', len(data)))
    if lp is None or style is None or not style < lp - 16 < lp + 8 <= end:
        return {'status': 'uninterpreted', 'reason': 'no_bounded_style_tail'}
    if data[lp - 12:lp] not in (struct.pack('<III', 1, 1, 0), struct.pack('<III', 2, 1, 0)):
        return {'status': 'uninterpreted', 'reason': 'style_tail_guard'}
    code = u32(data, lp - 16)
    return {'status': 'decoded' if code in SHAPES else 'uninterpreted', 'raw_code': code,
            'kind': SHAPES.get(code), 'radius_cm': None,
            'radius_status': 'not_decoded', 'offset': lp - 16,
            'evidence': [evidence(data, lp - 16, lp + 8, PROFILE)]}


def cell_style(data, decoder, cell, item, bg, table_end):
    result = {'row': cell['row'], 'column': cell['column'], 'offset': cell['offset'],
              'content_id': cell.get('content_id'), 'status': 'partial',
              'background': {'status': 'uninterpreted'}, 'borders': [],
              'shape': shape(data, item) if item else {'status': 'uninterpreted'},
              'unknowns': ['conflicting_shared_edges', 'corner_radius', 'non_solid_line_patterns']}
    rt = item.get('richtext') or {} if item else {}
    # The header must be the owner consumed by the rich-text grammar, not the
    # nearest occurrence of a color or a printable cell caption.
    if bg and rt.get('outer_offset', -5) + 4 == bg['header_offset']:
        p = bg['header_offset']
        result['background'] = ({'status': 'none', 'evidence': [evidence(data,p+20,p+24,PROFILE)]}
                                if bg['fill_flag'] == 1 else proven_colour(data, decoder, bg['fill']))
        result['content_width'] = measure(data,p+100)
        raw = bg['four_inset_candidates']
        result['insets_raw'] = raw
        if len(set(raw)) == 1 and 0 <= raw[0] <= 3000:
            result['uniform_inset'] = measure(data,p+124)
    cg = decoder.cell_graphics(cell)
    result['raw_mode'] = cg.get('raw_mode')
    result['raw_property_status'] = cg.get('status')
    if cg.get('property_offset', 0) + cg.get('property_size', 0) > table_end:
        result['unknowns'].append('property_outside_table')
        return result
    for edge in cg.get('edge_groups', []):
        q, code = edge['offset'], edge['code']
        # The side identifier is rotated relative to the packed cell mask.
        # Nonzero per-edge selectors are activation data, NOT pen widths.
        side,mask=SIDES[code]
        active=bool(cg.get('raw_mode',0)&mask and edge['raw_width'])
        pattern=edge['line_pattern']
        known=active and edge['pen_profile']==1 and pattern in (0,0xffffffff)
        color = proven_colour(data,decoder,edge['second_color'])
        pen = {'group_code':code,'side':side,'thickness':measure(data,q+72),
               'color':color,'raw_selector':edge['raw_width'],
               'scope':'cell','active':active,'line_pattern_raw':pattern,
               'effective_status':('decoded_local_pen' if pattern==0 else 'explicit_none') if known else 'inactive' if not active else 'uninterpreted',
               'renderable':bool(known and pattern==0 and color['status']=='decoded'
                                 and 0<edge['second_mode']<=300),
               'evidence':[evidence(data,q,q+112,PROFILE)]}
        pen['line_style']='solid_calibrated' if pen['renderable'] else None
        result['borders'].append(pen)
    return result


def axis_borders(data,decoder,axis,kind,table_end):
    """Two independent boundary pens carried by the axis header.

    Pattern -1 means no axis pen, 0 is the observed solid profile. Columns
    have left/right pens and rows top/bottom; thicknesses are at +52/+56.
    Cell-local pens remain separately auditable and take local precedence.
    """
    p=axis['offset'];tag=-109 if kind=='row' else -103
    if p+60>table_end or data[p:p+8]!=MARKER+struct.pack('<i',tag):return []
    if u32(data,p+20)!=101 or data[p+32:p+40]!=MARKER+struct.pack('<I',101) or data[p+48:p+52]!=MARKER:return []
    pens=[]
    for i,side in enumerate(('top','bottom') if kind=='row' else ('left','right')):
        pattern=u32(data,p+12+4*i);width=u32(data,p+52+4*i)
        color=proven_colour(data,decoder,decoder.colour(p+(20 if i==0 else 36)))
        valid=pattern==0 and 0<width<=300 and color.get('status')=='decoded'
        pens.append({'side':side,'scope':kind,'axis_index':axis['index'],'active':pattern!=0xffffffff,
                     'line_pattern_raw':pattern,'color':color,'thickness':measure(data,p+52+4*i),
                     'renderable':valid,'line_style':'solid_calibrated' if valid else None,
                     'effective_status':'decoded_axis_pen' if valid else 'none' if pattern==0xffffffff else 'uninterpreted',
                     'evidence':[evidence(data,p,p+60,PROFILE)]})
    return pens


def effective_borders(cell,style,rows,columns,span):
    # Compatibility field now contains cell-local pens only. Axis strokes
    # are independent, full-length layers; an explicit local None cannot
    # erase a row/column/table stroke.
    return list(style['borders'])


def decode_table_styles(data, model, decoder=None):
    if decoder is None:
        from .visual_graphics import GraphicsDecoder
        decoder = GraphicsDecoder(data, model)
    byunit = {u['id']:u for u in model['content_units']}
    backgrounds = decoder.backgrounds(model['content_units'])
    result, counts = {}, Counter()
    for table in model['tables']:
        table_end = max((e['offset_end'] for e in table.get('evidence', [])), default=len(data))
        out={'profile':PROFILE,'status':'partial','columns':[],'rows':[],'cells':[],
             'limits':['conflicting_shared_edges','unrecognized_table_frame_profiles','radius','conditional_colors','row_height_policy','non_solid_line_patterns']}
        from .table_frames import table_frame
        out['frame']=table_frame(data,table,decoder)
        out['border_policy']='independent_scopes_cell_overpaint_only'
        counts['table_frames_renderable']+=int(out['frame']['renderable'])
        for col in table['columns']:
            try:
                p=col['offset']
                if p + 80 > table_end:
                    raise InvalidPackage('Axis outside its table envelope')
                if data[p:p+8]!=MARKER+struct.pack('<i',-103):
                    raise InvalidPackage('Unknown axis envelope')
                if any(u32(data,p+k) not in (0,0xffffffff) for k in (12,16)):
                    raise InvalidPackage('Unknown axis line profile; width not established')
                if u32(data,p+20)!=101 or data[p+32:p+40]!=MARKER+struct.pack('<I',101):
                    raise InvalidPackage('Unknown axis property envelope')
                if u32(data,p+68)!=0 or u32(data,p+76)!=0:
                    raise InvalidPackage('Dynamic width or minimum constraint; absolute unit not established')
                width=measure(data,p+8,col['raw_dimension'])
                out['columns'].append({'index':col['index'],'status':'decoded','width':width})
                counts['columns_decoded']+=1
            except (InvalidPackage,ValueError,KeyError,IndexError,struct.error) as exc:
                out['columns'].append({'index':col['index'],'status':'uninterpreted','reason':str(exc)})
                counts['columns_uninterpreted']+=1
        if out['columns'] and all(c['status']=='decoded' for c in out['columns']):
            out['total_width_pt']=sum(c['width']['pt'] for c in out['columns'])
            out['total_width_cm']=sum(c['width']['cm'] for c in out['columns'])
        axes={}
        for key,kind in (('rows','row'),('columns','column')):
            axes[key]=[]
            for axis in table.get(key,[]):
                try:pens=axis_borders(data,decoder,axis,kind,table_end)
                except (InvalidPackage,ValueError,AssertionError,struct.error):pens=[]
                axes[key].append(pens)
                if key=='rows':out[key].append({'index':axis['index'],'borders':pens,'height_raw':axis['raw_dimension']})
                else:out[key][axis['index']]['borders']=pens
                counts['axis_pens_renderable']+=sum(p['renderable'] for p in pens)
        for cell in table['cells']:
            try:
                uid=cell.get('content_id'); item=byunit.get(uid)
                s=cell_style(data,decoder,cell,item,backgrounds.get(uid),table_end)
                cg=decoder.cell_graphics(cell);span=cg.get('column_span',cell.get('column_span',1))
                if not 1<=span<=len(table['columns'])-cell['column']:span=1
                s['effective_borders']=effective_borders(cell,s,axes['rows'],axes['columns'],span)
            except (AssertionError,InvalidPackage,ValueError,KeyError,IndexError,struct.error) as exc:
                s={'row':cell['row'],'column':cell['column'],'offset':cell['offset'],
                   'status':'uninterpreted','reason':str(exc),'borders':[],'shape':{},'background':{}}
            out['cells'].append(s); counts['cells_inspected']+=1
            if s['background'].get('status')=='decoded':counts['backgrounds_decoded']+=1
            if s['shape'].get('status')=='decoded':counts['shapes_decoded']+=1
            if s['shape'].get('kind') in ('rounded','rounded_left','rounded_right'):counts['rounded_shapes']+=1
            counts['pens_renderable']+=sum(p['renderable'] for p in s['borders'])
            counts['effective_pens_renderable']+=sum(p['renderable'] for p in s.get('effective_borders',[]))
        result[table['id']]=out
    return {'profile':PROFILE,'tables':result,'coverage':dict(counts)}


def enrich_table_styles(data, model):
    styles=decode_table_styles(data,model)
    model['table_style_profile']=styles['profile']
    model['table_style_coverage']=styles['coverage']
    for table in model['tables']:
        table['presentation']=styles['tables'][table['id']]
        if all(c['status']=='decoded' for c in table['presentation']['columns']):
            table['uninterpreted_properties']=[x for x in table.get('uninterpreted_properties',[]) if x!='units']
        if 'border_inheritance' not in table['uninterpreted_properties']:
            table['uninterpreted_properties'].append('border_inheritance')
