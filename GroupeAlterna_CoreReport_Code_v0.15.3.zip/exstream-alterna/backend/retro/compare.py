"""Différentiel d'observations, sans confondre position binaire et ordre métier."""
import hashlib,json

def scope_semantics(rule,model):
    units={u['id']:u for u in model.get('content_units',[])}
    result=[]
    for t in rule.get('targets',[]):
        u=units.get(t.get('content_id'),{})
        result.append({'kind':t['kind'],'paragraph_id':t.get('paragraph_id'),
            'row':t.get('row'),'column':t.get('column'),'table_id':t.get('table_id'),
            'owner_id':t.get('owner_id'),'affected_paragraph_ids':t.get('affected_paragraph_ids',[]),
            'cell':u.get('grid_position'),
            'text_paragraph_index':t.get('text_paragraph_index'),
            'tokens':[{k:s[k] for k in ('token_index','kind','start_in_token','end_in_token','text')} for s in t.get('token_slices',[])]})
    return sorted(result,key=lambda t:json.dumps(t,sort_keys=True))

def compare(a,b):
    from .hierarchy import hierarchy_rows
    changes=[]
    def pairs(kind,old,new,key,semantic):
        oa={key(x):x for x in old};nb={key(x):x for x in new}
        for ident in sorted(set(oa)|set(nb)):
            x=oa.get(ident);y=nb.get(ident)
            status='ajouté' if x is None else 'supprimé' if y is None else 'inchangé' if semantic(x)==semantic(y) else 'modifié'
            if x and y and x.get('name') and y.get('name') and x['name']!=y['name']:status='incertain'
            changes.append({'kind':kind,'id':ident,'status':status,'old':semantic(x) if x else None,'new':semantic(y) if y else None,
                'old_context':{'offset':x.get('offset')} if x else None,'new_context':{'offset':y.get('offset')} if y else None,
                'representation_changed':bool(x and y and x.get('offset')!=y.get('offset')),
                'business_order_changed':None,'confidence':'CERTAIN' if status=='inchangé' else 'TRÈS PROBABLE',
                'limitation':'Différence observée ; impact métier non établi sans graphe documentaire.'})
    pairs('variable',a['variables'],b['variables'],lambda v:v['id'],lambda v:{k:v[k] for k in ('name','type','cardinality','sample_value')})
    pairs('mapping',a['mappings'],b['mappings'],lambda m:f"{m['variable_id']}:{m['xml_path']}",lambda m:{k:m[k] for k in ('variable_id','xml_path','namespace')})
    pairs('rule',a['rules'],b['rules'],lambda r:r['id'],lambda r:{'compiled_id':r['compiled_id'],'variants':sorted(set(v['compiled_code'] for v in r['variants'])),'target':r['target'],'scope':r['scope']})
    pairs('data_section',a.get('data_sections',[]),b.get('data_sections',[]),lambda s:s['id'],
          lambda s:{k:s[k] for k in ('name','source_id','xml_path')})
    pairs('data_section_binding',a.get('data_section_bindings',[]),b.get('data_section_bindings',[]),
          lambda s:s['owner_kind']+':'+s['owner_id'],
          lambda s:{k:s[k] for k in ('owner_kind','owner_id','data_section_name','data_section_id','status')})
    oldrules={r['id']:r for r in a['rules']};newrules={r['id']:r for r in b['rules']}
    for c in changes:
        if c['kind']!='rule':continue
        if c['old'] is not None:c['old']['resolved_scopes']=scope_semantics(oldrules[c['id']],a)
        if c['new'] is not None:c['new']['resolved_scopes']=scope_semantics(newrules[c['id']],b)
        if c['status']=='inchangé' and c['old']!=c['new']:c['status']='modifié'
    return {'schema_version':'1.0','kind':'comparison','engine_version':a['engine_version'],
       'sources':[a['metadata'],b['metadata']],
       'application_structures':[hierarchy_rows(a),hierarchy_rows(b)],
       'analysis_status':'partial_not_validated','changes':changes,
       'counts':{s:sum(c['status']==s for c in changes) for s in ['ajouté','supprimé','modifié','inchangé','incertain']},
       'unknowns':['Correspondance inter-package des identifiants empirique ; changement de nom au même ID classé incertain.',
                   'Seules les portées structurales résolues sont comparées ; les cibles opaques, la présentation et les propriétés fines des tables restent non comparables.'],
       'xsd':{'available':False,'reason':'Contraintes XML non démontrées dans les modèles sources.'}}
