"""Read function declarations from native design properties, never from JS."""
import re
import struct
from .binary import MARKER, InvalidPackage, evidence, pascal, u32

PROFILE='OBS-function-declaration-103-v1'
ENVELOPE=struct.pack('<11I',0,0,2,102,0,103,4,0,104,4,0)


def read_signature(data,definition,stop):
    """Bounded class-159 declaration and counted, terminated argument records.

    Field meanings are corroborated across native declarations and source use.
    Uninterpreted formatting and passing-mode fields never determine a type.
    Unknown profiles fail closed; missing data never means zero arguments.
    """
    from .parser import TYPES
    a=definition['name_end'];p=a+44
    try:
        if definition['class_code']!=159 or not definition['offset']<a<p+32<=stop<=definition['end']:return None
        if data[a:p]!=ENVELOPE or data[p:p+8]!=MARKER+struct.pack('<I',103):return None
        kind=u32(data,p+12);return_code=u32(data,p+16);return_array=u32(data,p+24);count=u32(data,p+28)
        if kind not in (0,1) or return_code not in TYPES or return_array!=0 or count>256:return None
        q=p+32;arguments=[]
        for index in range(count):
            if q+5>stop or u32(data,q)!=101:return None
            name,_,end=pascal(data,q+4)
            if not re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*',name) or end+17>stop:return None
            passing,type_code,array,optional=(u32(data,end+i) for i in range(0,16,4))
            if passing not in (0,1) or type_code not in TYPES or array not in (0,1) or optional not in (0,1):return None
            default,_,tail=pascal(data,end+16)
            if tail+4>stop or data[tail:tail+4]!=MARKER:return None
            arguments.append({'name':name,'position':index+1,'type_code':type_code,'data_type':TYPES[type_code],
                'is_array':bool(array),'optional':bool(optional),'default_literal':default,
                'passing_mode_code':passing,'evidence':[evidence(data,q,tail+4,PROFILE)]})
            q=tail+4
        # A zero-argument declaration reaches this same block immediately.
        if q+4>stop or u32(data,q)!=1:return None
        if len({a['name'].casefold() for a in arguments})!=count:return None
        return {'profile':PROFILE,'kind':'Function' if kind==0 else 'Subroutine',
            'arguments':arguments,'return_type':TYPES[return_code] if kind==0 else None,
            'evidence':[evidence(data,p,q,PROFILE)]}
    except (InvalidPackage,KeyError,IndexError,struct.error):return None


def signature_lines(calculation):
    """Only proven argument types and Function return types are report metadata."""
    from .i18n import tr
    declaration=calculation.get('design_signature')
    if not declaration:return []
    lines=[]
    if declaration['arguments']:
        lines.append(tr('Arguments en entrée :'))
        for arg in declaration['arguments']:
            dtype=arg['data_type']+('[]' if arg['is_array'] else '')
            lines.append(arg['name']+' : '+dtype+(' ('+tr('facultatif')+')' if arg['optional'] else ''))
    if declaration['kind']=='Function':lines.append(tr('Type de retour : ')+declaration['return_type'])
    return lines


def code_zone(calculation):
    return 'Formula' if calculation.get('result_variable_id') else 'Logic'
