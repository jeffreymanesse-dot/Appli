"""Global PAR rule property, tied to paired class-21 identity, not proximity."""
import struct
from .binary import u32, evidence
from .layout import sig


def paragraph_global_rules(data, model):
    definitions={d['id']:d for d in model['definitions']}
    rules={r['compiled_id']:r for r in model['rules']}
    for block in model['paragraphs']:
        d=definitions.get(block['id'])
        if not d or d['class_code']!=21:continue
        a=d['name_end'];p=a+44
        guarded=(p+252<=d['end'] and data[block['offset']:block['offset']+16]==sig(111,21,d['internal_id'])
                 and data[d['offset']:d['offset']+16]==sig(104,21,d['internal_id'])
                 and data[a+12:a+44]==struct.pack('<IIIIIIII',102,0,103,4,0,104,4,0)
                 and data[p:p+8]==sig(136) and u32(data,p+40)==1 and u32(data,p+44)==1
                 and data[p+200:p+248]==struct.pack('<IIIIIIIIIIII',120,8,0,0,121,4,0,122,4,0,123,4))
        if not guarded:continue
        rid=u32(data,p+48)
        ev=[evidence(data,p,p+252,'OBS-paragraph-global-rule-136-v1'),*block['evidence']]
        block['global_rule_property']={'raw_rule_id':rid,'offset':p+48,'evidence':ev,
                                       'status':'decoded' if rid in rules else 'zero' if rid==0 else 'unresolved_rule_id'}
        if rid not in rules:continue
        block['global_rule_ids']=[rid]
        assoc={'kind':'paragraph_global','paragraph_id':block['id'],'content_ids':block['content_ids'],
               'owner_object_id':block['id'],'rule_id':rid,'rule_reference_offset':p+48,
               'confidence':'TRÈS PROBABLE','profile':'OBS-paragraph-global-rule-136-v1',
               'evidence':ev,'target_description':'Composant paragraphe entier, y compris textes, tables et objets non textuels.'}
        rules[rid].setdefault('associations',[]).append(assoc)
        for unit in model['content_units']:
            if unit['parent_id']==block['id']:unit['global_rule_ids']=[rid]
