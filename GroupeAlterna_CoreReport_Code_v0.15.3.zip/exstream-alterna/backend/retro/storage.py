"""Account retained files without deleting them or following symbolic links."""
import argparse
import json
import os
import stat
from pathlib import Path


def stored_bytes(directory):
    directory=Path(directory)
    try:root=directory.lstat()
    except FileNotFoundError:return 0
    if not stat.S_ISDIR(root.st_mode):raise OSError('Invalid job directory')
    total=0
    with os.scandir(directory) as entries:
        for entry in entries:
            info=entry.stat(follow_symlinks=False)
            if stat.S_ISDIR(info.st_mode):total+=stored_bytes(entry.path)
            else:total+=info.st_size
    return total


def reconcile_retained(db,root,states=('termine',)):
    """Caller holds the admission transaction lock. No live writer is allowed.

    Only successes are provably immutable during ordinary maintenance. Expired
    jobs stay under purge control; failed jobs can still have a terminating
    worker and therefore require an explicit stopped-services repair.
    """
    from .db import Job
    result={'jobs':0,'before_bytes':0,'after_bytes':0,'unreadable':0}
    for job in db.query(Job).filter(Job.state.in_(states)).all():
        result['before_bytes']+=job.reserved_bytes
        try:size=stored_bytes(Path(root)/job.id)
        except OSError:
            result['unreadable']+=1;size=job.reserved_bytes
        job.reserved_bytes=size
        result['after_bytes']+=size;result['jobs']+=1
    return result


def main():
    ap=argparse.ArgumentParser(description='Recalcul des réservations sans suppression de fichiers.')
    ap.add_argument('--reconcile-stopped',action='store_true',required=True,
                    help='À utiliser seulement après arrêt des services api, worker et purge.')
    ap.parse_args()
    from .db import initialize,transaction
    from .config import settings
    initialize()
    with transaction()as db:
        result=reconcile_retained(db,settings.storage,('termine','echec','annule'))
    print(json.dumps(result))
    if result['unreadable']:raise SystemExit('Certaines réservations sont conservées : fichiers illisibles.')


if __name__=='__main__':main()
