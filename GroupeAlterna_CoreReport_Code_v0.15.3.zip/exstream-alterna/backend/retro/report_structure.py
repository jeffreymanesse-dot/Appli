from .report_cover import build_with_cover
from .i18n import tr, note
"""Document-scoped report derived solely from decoded PUB relationships."""
from xml.sax.saxutils import escape
from collections import defaultdict
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,PageBreak,Table,TableStyle,KeepTogether,CondPageBreak
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib import colors
from .render import setup,ROOT
from .design_source import source_available, source_lines, source_markup


def content_markup(unit, rule_labels=None):
    """Exact half-open design spans, including paragraph and sub-token endpoints."""
    pieces=[];cursor=0;rich=unit.get('richtext') or unit.get('text_structure');labels=rule_labels or {}
    breaks=defaultdict(int)
    if rich:
        for p in rich['paragraphs'][1:]:
            if 0<p['start']<rich['design_length']:breaks[p['start']]+=1
    targets=unit.get('rule_targets',[]);prior=None
    def mark(rid,closing=False):
        label=escape(labels.get(rid,'rule'+str(rid)))
        return '<super><font color="#087E8B"><nobr>['+('/' if closing else '')+label+']</nobr></font></super>'
    axes=list(dict.fromkeys(unit.get('row_rule_ids',[])+[unit[k] for k in ('row_rule_id','column_rule_id') if unit.get(k)]))
    conditional=bool(axes or unit.get('global_rule_ids'))
    if rule_labels:
        for rid in axes:pieces.append(mark(rid))
    for i,part in enumerate(unit['parts']):
        if not rich and prior:
            gap=part['offset']-(prior['offset']+len(prior['text']))
            if gap:pieces.append('<br/>' if gap>=5 and prior['kind']=='variable' else ' ')
        ranges=[sp for t in targets for sp in t['token_slices'] if sp['token_index']==i]
        starts={};ends={}
        for t in targets:
            spans=t['token_slices']
            if not spans:continue
            if spans[0]['token_index']==i:starts.setdefault(spans[0]['start_in_token'],[]).append(t['rule_id'])
            if spans[-1]['token_index']==i:ends.setdefault(spans[-1]['end_in_token'],[]).append(t['rule_id'])
        cuts=sorted({0,len(part['text']),*(sp['start_in_token'] for sp in ranges),*(sp['end_in_token'] for sp in ranges),
                     *(pos-cursor for pos in breaks if cursor<=pos<cursor+len(part['text']))})
        for a,b in zip(cuts,cuts[1:]):
            if cursor+a in breaks:pieces.extend(['<br/>']*breaks[cursor+a])
            if rule_labels:
                for rid in starts.get(a,[]):pieces.append(mark(rid))
            text=escape('['+part.get('variable_name',part['text'])+']' if part['kind']=='variable' else part['text'][a:b])
            if conditional or any(sp['start_in_token']<=a and b<=sp['end_in_token'] for sp in ranges):text='<font color="#B42318">'+text+'</font>'
            pieces.append(text)
            if rule_labels:
                for rid in reversed(ends.get(b,[])):pieces.append(mark(rid,True))
        cursor+=len(part['text']);prior=part
    if rule_labels:
        for rid in reversed(axes):pieces.append(mark(rid,True))
    return ''.join(pieces)


def ordered_units(model,paragraph_id):
    us=[u for u in model['content_units'] if u['parent_id']==paragraph_id]
    return sorted(us,key=lambda u:tuple(u.get('document_order') or [999999,u['offset']]))


def document_rules(model):
    ids=[]
    for pid in model['document_paragraph_ids']:
        for u in ordered_units(model,pid):
            for rid in ([u['row_rule_id']] if u.get('row_rule_id') else [])+([u['column_rule_id']] if u.get('column_rule_id') else [])+u.get('inline_rule_ids',[]):
                if rid not in ids:ids.append(rid)
    return ids


def block_rules(model,pid):
    """One rule per block, including global, nested-table and empty-axis targets."""
    used={r['compiled_id'] for r in model['rules'] if any(a.get('paragraph_id')==pid for a in r.get('associations',[]))}
    return [rid for rid in model.get('document_rule_ids',[]) if rid in used]


def content_display_text(unit):
    starts=defaultdict(int);ends=defaultdict(int)
    for target in unit.get('rule_targets',[]):
        spans=target.get('token_slices',[])
        if target.get('kind')!='inline_run' or not spans:continue
        a,z=spans[0],spans[-1]
        starts[(a['token_index'],a['start_in_token'])]+=1
        ends[(z['token_index'],z['end_in_token'])]+=1
    result=[]
    for i,part in enumerate(unit['parts']):
        if part['kind']=='variable':
            result.append('['*starts[(i,0)]+'['+part.get('variable_name',part['text'])+']'+'] '*ends[(i,len(part['text']))])
        else:
            for j,ch in enumerate(part['text']):
                result.append('['*starts[(i,j)]+ch+'] '*ends[(i,j+1)])
    return ''.join(result)


def conditional_axes(table,axis):
    return [x for x in table[axis] if x.get('rule_id') or x.get('repeat')]


def report_structure(model,path,chapters=None):
    from .report_options import chapter_plan
    from .hierarchy import hierarchy_rows, append_hierarchy
    plan=chapter_plan(chapters)
    c=setup();W=491;story=[]
    S={
        'body':ParagraphStyle('body',fontName='Alterna',fontSize=10,leading=14,spaceAfter=6,textColor=c['navy']),
        'small':ParagraphStyle('small',fontName='Alterna',fontSize=8,leading=11,spaceAfter=5,textColor=c['navy']),
        'code':ParagraphStyle('code',fontName='AlternaMono',fontSize=7.2,leading=10,spaceAfter=0,textColor=c['navy']),
        'label':ParagraphStyle('label',fontName='Alterna',fontSize=7.4,leading=10,spaceAfter=4,keepWithNext=True,textColor=c['navy']),
        'mini':ParagraphStyle('mini',fontName='Alterna',fontSize=7.4,leading=10,spaceAfter=4,textColor=c['navy']),
        'h':ParagraphStyle('h',fontName='AlternaBold',fontSize=17,leading=22,spaceAfter=14,keepWithNext=True,textColor=c['navy']),
        'sub':ParagraphStyle('sub',fontName='AlternaBold',fontSize=11,leading=15,spaceBefore=10,spaceAfter=7,keepWithNext=True,textColor=c['primary']),
        'white':ParagraphStyle('white',fontName='AlternaBold',fontSize=8,leading=11,textColor=colors.white),
    }
    ps={p['id']:p for p in model['paragraphs']};us={u['id']:u for u in model['content_units']}
    vs={v['id']:v for v in model['variables']};vn={v['name']:v for v in model['variables']};vi={v['internal_id']:v for v in model['variables']}
    rs={r['compiled_id']:r for r in model['rules']};rids=model.get('document_rule_ids',document_rules(model));rlabel={r['compiled_id']:r['document_id'] for r in model['rules']}
    main_ids=model['document_paragraph_ids'];main_units=[u for pid in main_ids for u in ordered_units(model,pid)]
    grids={t['id']:t for t in model['tables']}
    reps=[r for r in model.get('repetitions',[]) if grids[r['table_id']]['paragraph_id'] in main_ids]
    replabel={r['id']:r.get('document_id',r['id']) for r in reps}
    calc_names={x['id']:x.get('definition_name') or x.get('result_variable_name') or x['id'] for x in model['calculations']}
    from .rule_labels import rule_labels,rule_conditions,rule_algorithms
    labels=rule_labels(model['rules'])
    def rule_name(rid):return labels[rid]
    def p(text,style='body',markup=False):
        value=str(text) if markup else escape(str(text)).replace('\n','<br/>')
        if style=='code' and not markup:
            # Preserve code indentation and literal spaces instead of HTML collapsing them.
            value=source_markup(text)
        return Paragraph(value,S[style])
    def add(text,style='body'):story.append(p(text,style))
    def add_source(item):
        if source_available(item):
            for line in source_lines(item['source_expression']):add(line,'code')
        else:add(tr('Ce script contient des caractères non imprimables. Son texte intégral est conservé dans les sources jointes au PDF.') if item.get('source_expression') else tr('Script non disponible dans ce PUB.'),'small')
    def add_calculation(item):
        from .function_signature import signature_lines, code_zone
        from .formula_timing import compute_time_line
        story.append(CondPageBreak(130));add(calc_names[item['id']],'sub')
        for line in signature_lines(item):add(line,'small')
        timing=compute_time_line(item)
        if timing:add(timing,'small')
        story.append(Paragraph(code_zone(item),ParagraphStyle('zone',fontName='AlternaBold',
            fontSize=8.5,leading=12,spaceBefore=4,spaceAfter=6,keepWithNext=True,textColor=c['navy'])))
        add_source(item)
    def section(text):
        if story:story.append(PageBreak())
        add(text,'h')
    def table(rows,widths=None,header=True,padding=6,split_in_row=False):
        t=Table([[x if isinstance(x,(list,Paragraph)) else p(x,'white' if i==0 and header else 'small') for x in row] for i,row in enumerate(rows)],colWidths=widths,repeatRows=1 if header else 0,hAlign='LEFT',splitInRow=int(split_in_row))
        styles=[('VALIGN',(0,0),(-1,-1),'TOP'),('TOPPADDING',(0,0),(-1,-1),padding),('BOTTOMPADDING',(0,0),(-1,-1),padding),('LINEBELOW',(0,0),(-1,0),.7,c['primary'])]
        if header:styles += [('BACKGROUND',(0,0),(-1,0),c['navy']),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,c['surface']])]
        else:styles += [('BACKGROUND',(0,0),(-1,-1),c['surface']),('BOX',(0,0),(-1,-1),.5,c['primary'])]
        t.setStyle(TableStyle(styles));return t
    from .visual_render import VisualRenderer
    source_renderer=VisualRenderer(model['visual'],rule_labels=rlabel)
    def unit_panel(u,style='small'):
        if u['id'] in source_renderer.UNITS:
            return source_renderer.decorated_text(u['id'],W)
        source_renderer.PLACED.append(u['id'])
        markup=content_markup(u,rlabel)
        return [p(chunk or ' ',style,True) for chunk in markup.split('<br/>')]
    def visual_grid(grid,width=W):
        if grid['id'] in source_renderer.GRIDS:
            flows=source_renderer.visual_table(grid['id'],width,documentary_guides=False)
            h=source_renderer.height_of(flows,width)
            return [KeepTogether(flows)] if h<260 else flows
        return [p(tr('Tableau sans propriétés de présentation interprétées.'),'small')]
    def overview(pid):
        if any(c['paragraph_id']==pid for c in source_renderer.COMPOSITIONS.values()):
            for kind,key in source_renderer.entries_for(pid):
                if kind=='composition':story.extend(source_renderer.composition_flow(key,W))
                elif kind=='text':story.extend(source_renderer.decorated_text(key,W))
                elif kind=='table':story.extend(source_renderer.visual_table(key,W,documentary_guides=False))
            return
        uu=ordered_units(model,pid)
        if not uu:
            add(tr('Objet référencé ; aucun contenu textuel décodé. Preuve conservée dans le modèle.'),'small');return
        roots=[t for t in model['tables'] if t['paragraph_id']==pid and not t.get('parent_table_id')]
        entries=[];placed=set()
        for grid in roots:
            def descendants(t):
                return [uid for cell in t['cells'] for uid in ([cell['content_id']] if cell.get('content_id') else descendants(grids[cell['nested_table_id']]) if cell.get('nested_table_id') in grids else [])]
            ids=descendants(grid);placed.update(ids)
            if grid.get('inline_anchor'):continue
            key=(grid.get('start') or min((us[i]['offset'] for i in ids),default=999999),)
            entries.append((key,'table',grid))
        for u in uu:
            if u['id'] not in placed and not u.get('inline_object_anchor'):entries.append(((u['offset'],),'text',u))
        for _,kind,obj in sorted(entries,key=lambda x:x[0]):
            if kind=='table':story.extend(visual_grid(obj))
            else:
                story.extend(unit_panel(obj,'body'))
            story.append(Spacer(1,5))
    def append_repetitions(grid):
        for axis,title in (('columns','Colonnes conditionnelles ou répétées'),):
            selected=conditional_axes(grid,axis)
            if axis=='rows':selected=[x for x in selected if x.get('property_profile')!='OBS-row-extended-fields-v1']
            if not selected:continue
            rows=[[tr('Ligne') if axis=='rows' else tr('Colonne'),tr('Règle'),tr('Répétition')]]
            for item in selected:
                rep=next((r for r in reps if r['id']==item.get('repeat')),None)
                rows.append([str(item['index']+1),rlabel.get(item.get('rule_id'),'—'),
                    rep['driver_name'] if rep else '—'])
            add(tr(title),'label');story.append(table(rows,[55,65,371]))

    first_rule_block={rid:next((pid for pid in main_ids if rid in block_rules(model,pid)),None) for rid in rids}
    def rules_recap(pid):
        ids=block_rules(model,pid)
        if not ids:return
        rows=[['Rn',tr('Nom de la règle'),tr('Algorithme')]]
        for rid in ids:
            algorithm=[]
            for kind,code in rule_algorithms(rs[rid]):
                algorithm.extend(p(line,'code' if kind in ('script','parameters') else 'small') for line in source_lines(code))
            rows.append([rlabel[rid],p(rule_name(rid),'mini'),algorithm])
        tall=any(sum(flow.wrap(303,100000)[1] for flow in row[2])>640 for row in rows[1:])
        story.append(table(rows,[35,145,311],padding=4,split_in_row=tall))
    section(tr('Rétro-documentation du courrier'))
    add(model['metadata']['source_name'],'sub')
    story.append(table([[tr('Périmètre du courrier'),tr('Éléments décodés')],[tr('Paragraphes référencés'),len(main_ids)],[tr('Unités de contenu rattachées'),len(main_units)],[tr('Règles associées'),len(rids)],[tr('Répétitions de lignes / colonnes'),str(sum(r['axis']=='row' for r in reps))+' / '+str(sum(r['axis']=='column' for r in reps))]],[320,171]))
    append_hierarchy(story,hierarchy_rows(model),c)
    from .report_data_sections import append_data_sections, append_row_automation
    append_data_sections(model,story,add,table)
    plan_start=len(story)
    add(tr('Organisation'),'sub')
    for title in plan.values():add(title)
    story[plan_start:]=[KeepTogether(story[plan_start:])]
    section(tr('1. Vue détaillée'))
    add(tr('Ce chapitre présente les paragraphes du courrier dans l’ordre retrouvé dans le package, avec leurs textes, tableaux, variables et règles d’affichage. Les variables apparaissent entre crochets ; les contenus conditionnels sont montrés sans choisir de scénario.'))
    add(tr('Les couleurs et polices reconnues sont conservées. Les repères Rn renvoient aux règles d’affichage. Les répétitions sont décrites auprès du tableau concerné ; le nombre de lignes et la pagination finale dépendent des données.'),'small')
    add(tr('Les DOCUMENT et SECTION jalonnent les contenus. Les PAGE initiales et de débordement sont présentées à l’entrée du document ; le passage effectif de l’une à l’autre dépend de la pagination.'),'mini')
    add(tr('Les repères [Rn] et [/Rn] encadrent la cible décodée. Une condition globale encadre le bloc entier, y compris ses objets non textuels. Une règle de colonne encadre chaque cellule concernée ; les cibles internes peuvent être imbriquées. Ces annotations ne font pas partie du courrier.'),'mini')
    from .document_flow import report_events
    containers={x['id']:x for key in ('documents','document_sections','page_components') for x in model.get(key,[])}
    previous_document=None
    for occurrence in report_events(model):
        pid=occurrence['source_id'];document=occurrence['source_document_id']
        if previous_document is not None and document!=previous_document:
            story.append(PageBreak())
        previous_document=document
        if occurrence['kind']!='paragraph':
            obj=containers.get(pid)
            if not obj:continue
            kind=occurrence['kind']
            label={'document':'DOCUMENT','section':'SECTION','page':'PAGE'}[kind]
            if kind=='page':
                label=tr({'initial':'PAGE initiale','overflow':'PAGE de débordement','reference':'PAGE référencée'}[occurrence['page_role']])
            story.append(CondPageBreak(105));add(label+' : '+obj['name'],'sub')
            ids=obj.get('global_rule_ids',[])
            if ids:add(tr('Règles : ')+', '.join(rlabel[rid]+' • '+rule_name(rid) for rid in ids),'label')
            continue
        grid=next((t for t in model['tables'] if t['paragraph_id']==pid),None)
        # Reserve a full tall cell pair for identity-like two-column paragraphs.
        needs_pair=grid and any(len(r['content_ids'])==2 and sum(len(us[j]['text']) for j in r['content_ids'])>1000 for r in grid['rows'])
        story.append(CondPageBreak(430 if needs_pair else 160))
        add(ps[pid]['name'],'sub')
        if ps[pid].get('global_rule_ids'):
            add(tr('Condition du paragraphe entier : ')+', '.join(rlabel[rid]+' • '+rule_name(rid) for rid in ps[pid]['global_rule_ids']),'label')
            add(' '.join('['+rlabel[rid]+']' for rid in ps[pid]['global_rule_ids']),'small')
        before=len(source_renderer.PLACED)
        overview(pid)
        from collections import Counter
        expected=Counter(u['id'] for u in ordered_units(model,pid))
        actual=Counter(source_renderer.PLACED[before:])
        if actual!=expected:
            raise ValueError('Report content coverage mismatch: '+pid+' '+str({'missing':list((expected-actual).elements()),'duplicates':list((actual-expected).elements())}))
        if ps[pid].get('global_rule_ids'):add(' '.join('[/'+rlabel[rid]+']' for rid in reversed(ps[pid]['global_rule_ids'])),'small')
        unresolved=[u for u in ordered_units(model,pid) if u.get('scope_decode_issue')]
        if any(not (u.get('richtext') or u.get('text_structure')) for u in unresolved):add(tr('Identification interne des variables non établie pour certains fragments : leurs valeurs brutes ne sont pas certifiées comme du texte fixe.'),'mini')
        if unresolved:add(tr('Certaines propriétés internes restent non interprétées : ')+', '.join(u.get('document_id',u['id']) for u in unresolved)+tr('. Aucune portée interne supposée.'),'mini')
        for repeated_grid in model['tables']:
            if repeated_grid['paragraph_id']==pid:
                append_row_automation(repeated_grid,story,add,table,rlabel,reps)
                append_repetitions(repeated_grid)
        rules_recap(pid)
    section(tr('2. Mise en forme des tableaux'))
    from .report_table_styles import append_table_styles
    shown=0
    for grid in model['tables']:
        pid=grid['paragraph_id']
        if pid not in main_ids:continue
        shown+=1;add(ps[pid]['name'],'sub')
        if grid.get('parent_table_id'):add(tr('Tableau imbriqué'),'mini')
        rendered_style=source_renderer.TABLE_STYLES.get(grid['id'],grid.get('presentation'))
        append_table_styles({**grid,'presentation':rendered_style}, story, add, table)
    if not shown:add(tr('Aucun tableau décodé dans ce courrier.'),'small')
    section(tr('3. Catalogue des règles du courrier'))
    audit=model.get('rule_catalog_audit')
    if audit:
        add(tr('Inventaire du package : ')+str(audit['definition_ids'])+tr(' identifiants de définitions ; ')+str(audit['compiled_rule_ids'])+tr(' règles compilées distinctes. Les noms identiques ne sont pas fusionnés. Le rapprochement du catalogue ne certifie pas toutes les portées.'),'small')
    add(tr('Numérotation par première rencontre dans l’ordre reconstruit ; identifiants compilés conservés pour le rapprochement. Les variantes compilées ne sont pas exécutées. Une valeur absente n’est pas assimilée arbitrairement à la branche opposée.'),'small')
    add(tr('Une portée interne CERTAINE exige : nom/condition/ID concordants, référence de ciblage, propriétaire décodé et frontières de contenu vérifiées. Le profil contrôle aussi les compteurs et le répertoire des variables. Cette certitude porte sur la conception reconnue ; le rendu final dépend des données.'),'small')
    for rid in rids:
        rule=rs[rid];story.append(CondPageBreak(110));add(rlabel[rid]+' • '+rule_name(rid),'sub')
        locations=[]
        for assoc in rule.get('associations',[]):
            if assoc['kind']=='text_paragraph' and not assoc.get('token_slices') and any(
                a['kind']=='inline_object' and a.get('anchor_content_id')==assoc.get('content_id')
                and a.get('text_paragraph_index')==assoc.get('text_paragraph_index') for a in rule.get('associations',[])):
                continue
            if assoc['kind'] in ('section_global','document_global','page_global'):
                locations.append(assoc['owner_name']+' : '+tr('condition du conteneur'));continue
            if assoc['kind']=='page_component_rule':
                locations.append(assoc['page_name']+' : '+tr('objet de page'));continue
            pid=assoc.get('paragraph_id')
            if pid not in main_ids:continue
            kind=assoc['kind']
            if kind=='paragraph_global':target=tr('paragraphe entier')
            elif kind=='grid_row':target=tr('ligne ')+str(assoc['row']+1)
            elif kind=='grid_column':target=tr('colonne ')+str(assoc['column']+1)
            elif kind=='inline_object':target=tr('objet ancré dans le paragraphe interne ')+str(assoc['text_paragraph_index']+1)
            elif assoc.get('scope_resolved'):target=us[assoc['content_id']].get('document_id',assoc['content_id'])+' / '+('fragment' if kind=='inline_run' else tr('paragraphe interne ')+str(assoc['text_paragraph_index']+1))
            else:target=tr('portée interne non résolue')
            locations.append(ps[pid]['name']+' : '+target)
        add(tr('Cibles : ')+' ; '.join(dict.fromkeys(locations)),'small')
        pid=first_rule_block.get(rid)
        if pid:add(tr('Algorithme : tableau du bloc ')+ps[pid]['name']+' (section 1).','mini')
        else:
            for kind,code in rule_algorithms(rule):
                for line in source_lines(code):add(line,'code' if kind in ('script','parameters') else 'small')
    visible={vn[name]['id'] for u in main_units for name in u['variable_names']}
    selected=[x for x in model['calculations'] if x['id'] in model.get('document_calculation_ids',[])]
    if 'valuation' in plan:
        section(plan['valuation'])
        for x in selected:add_calculation(x)
        calculations={x['id']:x for x in model['calculations']}
        displayed={x['id'] for x in selected}
        for chain in model.get('reference_chains',[]):
            for cid in chain['provider_calculation_ids']:
                if cid in displayed:continue
                displayed.add(cid);add_calculation(calculations[cid])
    if 'input_dictionary' in plan:
        section(plan['input_dictionary'])
        ids=set(model.get('document_variable_ids',visible))
        for rid in rids:
            for v in rs[rid]['variants']:ids.update(vi[i]['id'] for i in v['reads'] if i in vi)
        for x in selected:ids.update(vi[i]['id'] for i in x['reads'] if i in vi)
        maps=[m for m in model['mappings'] if m['variable_id'] in ids and m['source_classification']=='input_candidate']
        add(tr('{0} mappings rattachés au périmètre du courrier et aux calculs sélectionnés. Les exemples, namespaces et cardinalités des parents XML restent non décodés.').format(len(maps)),'small')
        rows=[[tr('Variable'),tr('Chemin XML'),tr('Type / cardinalité')]]
        for m in maps:
            v=vs[m['variable_id']];rows.append([v['name'],m['xml_path'],f"{v['type']} / {v['cardinality']}"])
        story.append(table(rows,[177,224,90],padding=5))
    if 'reconstruction' in plan:
        section(plan['reconstruction'])
        from .report_inventory import inventory_appendix
        inventory_appendix(model,story,p,table,add,rlabel)
    def header(canvas,doc):
        canvas.saveState();canvas.drawImage(str(ROOT/'assets/Logo_GroupeAlterna_825px.png'),424,789,width=119,height=29,preserveAspectRatio=True,mask='auto');canvas.setStrokeColor(c['primary']);canvas.line(52,776,543,776);canvas.setFont('Alterna',7);canvas.setFillColor(c['navy']);canvas.drawString(52,29,tr('Groupe Alterna | Analyse PUB | ')+model['engine_version']);canvas.drawRightString(543,29,str(doc.page-1));canvas.restoreState()
    doc=SimpleDocTemplate(str(path),pagesize=(595.276,841.89),leftMargin=52,rightMargin=52,topMargin=80,bottomMargin=48,title='Core Report | '+tr('Rétro-documentation - reconstitution partielle'),author='Groupe Alterna')
    build_with_cover(doc, story, model, header)
