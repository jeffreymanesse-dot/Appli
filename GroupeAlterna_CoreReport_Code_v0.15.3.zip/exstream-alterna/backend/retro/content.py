"""Empirical, bounded content decoding. Never asserts layout from byte order."""
import re,struct
from .binary import MARKER, occurrences, u32, evidence, pascal, InvalidPackage


def enrich(data, model):
    variables={v['name']:v for v in model['variables']}
    units=[]
    for p in occurrences(data, MARKER):
        if p+12>len(data): continue
        n=u32(data,p+4)
        header_ok = data[max(0,p-16):max(0,p-8)] == MARKER+struct.pack('<I',101) or data[max(0,p-20):p] in [MARKER+struct.pack('<IIII',k,101,0,0) for k in (1,2)]
        if not header_ok: continue
        if not 4<n<65536 or p+12+n>len(data): continue
        raw=data[p+8:p+8+n]
        if raw[:3]!=b'\0\0\0' or not (raw[3] in (0,1,4,7) or raw[3]>=32): continue
        if data[p+8+n:p+12+n]!=data[p+4:p+8]: continue
        if not re.search(rb'[A-Za-z]{3}',raw): continue
        parts=[]
        for m in re.finditer(rb'[\x20-\x7e\x80-\xff]+',raw):
            text=m.group().decode('cp1252',errors='replace')
            parts.append({'text':text,'offset':p+8+m.start(),'kind':'variable' if text in variables else 'text'})
        names=[x['text'] for x in parts if x['kind']=='variable']
        item={'id':f'text:{p}','offset':p,'serialized_index':len(units)+1,'document_order':None,
              'parts':parts,'text':' | '.join(x['text'] for x in parts),'variable_names':names,
              'confidence':'TRÈS PROBABLE','parent_id':None,
              'limitation':'Fragments conservés dans leur ordre sérialisé ; séparateurs, lignes, parentage et disposition non interprétés.',
              'evidence':[evidence(data,p,p+12+n,'OBS-content-redundant-length-v1')]}
        units.append(item)
        for name in names: variables[name]['usage_evidence'].append({'kind':'content','id':item['id'],'offset':p})
    # Alternate literal run: A3, kind 1, duplicated uint16 length.
    for hit in re.finditer(rb'\xa3\x00\x00\x00\x01', data):
        p=hit.end()
        if p+4>len(data): continue
        n=int.from_bytes(data[p:p+2],'little')
        if not 3<n<10000 or p+4+n>len(data) or data[p:p+2]!=data[p+2:p+4]: continue
        raw=data[p+4:p+4+n]
        if not all(x>=32 or x in (9,10,13) for x in raw): continue
        text=raw.decode('cp1252',errors='replace')
        units.append({'id':f'text:{hit.start()}', 'offset':hit.start(), 'serialized_index':None,
            'document_order':None,'parts':[{'text':text,'offset':p+4,'kind':'text'}],
            'text':text,'variable_names':[],'confidence':'HYPOTHÈSE','parent_id':None,
            'limitation':'Variante de texte littéral, longueur redondante ; parent et ordre non établis.',
            'evidence':[evidence(data,hit.start(),p+4+n,'OBS-literal-u16-v1')]})
    units.sort(key=lambda x:x['offset'])
    for i,item in enumerate(units,1):item['serialized_index']=i
    model['content_units']=units
    byid={v['internal_id']:v for v in model['variables']}
    for c in model['calculations']:
        match=re.match(r"_(?:formulas?|functions)\['([^']+)'\]",c['source_code'])
        c['id']=match.group(1) if match else f"calculation:{c['offset']}"
        c['read_names']=[byid[i]['name'] for i in c['reads'] if i in byid]
        c['write_names']=[byid[i]['name'] for i in c['writes'] if i in byid]
        fid=re.fullmatch(r'formula(\d+)',c['id'])
        c['result_variable_id']=None
        if fid and int(fid.group(1)) in byid:
            v=byid[int(fid.group(1))];c['result_variable_id']=v['id'];c['result_variable_name']=v['name']
            v['usage_evidence'].append({'kind':'formula_result_id_match','id':c['id'],'offset':c['offset']})
        for i in c['reads']+c['writes']:
            if i in byid:byid[i]['usage_evidence'].append({'kind':'calculation','id':c['id'],'offset':c['offset']})
    source_algorithms(data, model)
    model['content_variable_ids']=sorted({variables[n]['id'] for x in units for n in x['variable_names']})


def source_algorithms(data,model):
    """Length-prefixed source within the matching variable definition, before compiled code."""
    defs={'formula'+str(v['internal_id']):v for v in model['variables']}
    defs.update({'function'+str(d['internal_id']):d for d in model.get('definitions',[]) if d['class_code']==159})
    for c in model['calculations']:
        if c['id'] not in defs:continue
        v=defs[c['id']];c['definition_name']=v['name'];a=v['offset'];b=c['offset']
        if not a<b<v['end']:continue
        if v['class_code']==159:
            from .function_signature import read_signature
            declaration=read_signature(data,v,b)
            if declaration:c['design_signature']=declaration
        from .design_source import source_record
        candidate=source_record(data,a,b)
        if candidate:
            p,s=candidate;c['source_expression']=s
            c['evidence'].append(evidence(data,p,p+len(s),'OBS-formula-source-u32-v1'))


def uncomment(text):
    """Remove comments without treating comment markers inside strings as comments."""
    result=[];i=0;quote=None
    while i<len(text):
        ch=text[i]
        if quote:
            result.append(ch)
            if ch==quote:quote=None
            i+=1;continue
        if ch in ('"',"'"):
            quote=ch;result.append(ch);i+=1;continue
        if text[i:i+2]=='//':
            end=text.find('\n',i);i=len(text) if end<0 else end;continue
        if text[i:i+2]=='/*':
            end=text.find('*/',i+2)
            if end<0:return text # preserve uninterpreted input
            result.append('\n');i=end+2;continue
        result.append(ch);i+=1
    return '\n'.join(x.strip() for x in ''.join(result).splitlines() if x.strip())


def classify_sources(data,model):
    sources=[]
    for d in model['definitions']:
        if d['class_code']!=15: continue
        descriptor=source_descriptor(data,d)
        sources.append({**d,'classification':descriptor['classification'],'descriptor':descriptor})
    for m in model['mappings']:
        m['source_classification']='unknown'
        matches=[d for d in sources if d['offset']<m['offset']<d['end']]
        if len(matches)!=1:continue
        d=matches[0];m['data_source_id']=d['id'];m['data_source_name']=d['name']
        m['source_classification']=d['classification']
        m['source_classification_note']='Type du Data File extrait du record 163 borné ; la ressource externe n’est pas lue.'
        m['data_source_descriptor']=d['descriptor']
        m['evidence'].extend(d['descriptor'].get('evidence',[]))
    byid={v['id']:v for v in model['variables']}
    for v in byid.values():v['source']='unknown'
    for m in model['mappings']:
        if m['source_classification']=='input_candidate':byid[m['variable_id']]['source']='mapped_xml_flow'
        elif m['source_classification']=='reference_candidate' and byid[m['variable_id']]['source']=='unknown':byid[m['variable_id']]['source']='mapped_reference_candidate'
        elif m['source_classification']=='initialization_candidate' and byid[m['variable_id']]['source']=='unknown':byid[m['variable_id']]['source']='mapped_initialization_candidate'
        elif m['source_classification']=='report_candidate' and byid[m['variable_id']]['source']=='unknown':byid[m['variable_id']]['source']='mapped_report_candidate'
    model['input_dictionary']=[{'variable_id':m['variable_id'],'xml_path':m['xml_path'],'mapping_id':m['id']} for m in model['mappings'] if m['source_classification']=='input_candidate']
    map_by_source={}
    for m in model['mappings']:
        if m.get('data_source_id'):map_by_source.setdefault(m['data_source_id'],[]).append(m)
    model['data_files']=[{**d,'mapping_ids':[m['id'] for m in map_by_source.get(d['id'],[])],
        'mapped_variable_ids':list(dict.fromkeys(m['variable_id'] for m in map_by_source.get(d['id'],[])))} for d in sources]


def source_descriptor(data,definition):
    """Read two Pascal strings; the byte after INPUT is a length, not a space."""
    result={'classification':'unknown','profile':'OBS-source-descriptor-163-v3'}
    p=definition['name_end']+44
    try:
        if data[p:p+8]!=MARKER+struct.pack('<I',163):return result
        header=data[p+8:p+13]
        if header==b'\0'*5:strings_at=p+13
        elif data[p+8:p+14]==b'\x01;\0\0\0\0':strings_at=p+14
        else:return result
        role,_,end=pascal(data,strings_at)
        path,_,end=pascal(data,end)
        if end>definition['end'] or not role or not path or not all(c.isprintable() for c in role+path):return result
        if end+18>definition['end']:return result
        format_code=u32(data,end+10);type_code=u32(data,end+14)
        categories={0:'driver_candidate',1:'initialization_candidate',2:'reference_candidate',3:'report_candidate'}
        result.update(role=role,resource_path=path,format_code=format_code,type_code=type_code,
            data_file_type=categories.get(type_code,'unknown_type_'+str(type_code)),offset=p,
            evidence=[evidence(data,p,end+18,'OBS-source-descriptor-163-v3')])
        result['classification']=categories.get(type_code,'unknown')
        if type_code==0 and role=='INPUT':result['classification']='input_candidate'
    except (InvalidPackage,IndexError):pass
    return result
