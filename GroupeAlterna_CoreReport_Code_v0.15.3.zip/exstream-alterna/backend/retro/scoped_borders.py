"""Paint table/axis strokes independently of cells and horizontal spans."""
from reportlab.platypus import Table
from reportlab.lib import colors

def scoped_lines(style,widths,row,rows,chunk=0,chunks=1):
    lines=[];x=[0]
    for width in widths:x.append(x[-1]+width)
    def add(pen,side,left=0,right=None):
        if pen and pen.get('renderable'):
            lines.append({'pen':pen,'side':side,'x1':left,'x2':x[-1] if right is None else right})
    frame=style.get('frame',{})
    add(frame,'left',0,0);add(frame,'right',x[-1],x[-1])
    if row==0 and chunk==0:add(frame,'top')
    if row==rows-1 and chunk==chunks-1:add(frame,'bottom')
    for pen in (style.get('rows') or [{}]*rows)[row].get('borders',[]):
        if (pen['side']=='top' and chunk==0) or (pen['side']=='bottom' and chunk==chunks-1):add(pen,pen['side'])
    for i,col in enumerate(style.get('columns',[])):
        for pen in col.get('borders',[]):
            pos=x[i+(pen['side']=='right')]
            add(pen,pen['side'],pos,pos)
    return lines

class ScopedBorderTable(Table):
    def __init__(self,*args,scope_lines=(),border_scale=1,guide_sides=(),**kwargs):
        super().__init__(*args,**kwargs)
        self.scope_lines=scope_lines;self.border_scale=border_scale
        self.guide_sides=guide_sides

    def _drawLines(self):
        canvas=self.canv;canvas.saveState()
        # Display-only outline for otherwise borderless tables. It changes
        # neither the source properties nor widths, insets or row heights.
        canvas.setStrokeColor(colors.HexColor('#b9c3ce'));canvas.setLineWidth(.45)
        canvas.setDash();canvas.setLineCap(0)
        for side in self.guide_sides:
            if side in ('left','right'):
                x=0 if side=='left' else self._width
                canvas.line(x,0,x,self._height)
            else:
                y=self._height if side=='top' else 0
                canvas.line(0,y,self._width,y)
        for line in self.scope_lines:
            pen=line['pen'];side=line['side']
            canvas.setStrokeColor(colors.HexColor(pen['color']['rgb']))
            canvas.setLineWidth(pen['thickness']['pt']*self.border_scale)
            canvas.setDash();canvas.setLineCap(0)
            if side in ('left','right'):canvas.line(line['x1'],0,line['x1'],self._height)
            else:
                y=self._height if side=='top' else 0
                canvas.line(line['x1'],y,line['x2'],y)
        canvas.restoreState()
        # Local strokes are drawn afterwards; unresolved overlapping pen
        # precedence is a rendering convention, not inferred inheritance.
        super()._drawLines()
