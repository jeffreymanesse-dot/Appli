"""Preserve native script bytes alongside the readable report, without JS."""
from hashlib import sha256
from io import BytesIO
from pathlib import Path
from tempfile import NamedTemporaryFile
from zipfile import ZipFile, ZipInfo, ZIP_DEFLATED
import os
import re


def original_bytes(item):
    source=item.get('source_expression')
    if not source:return None
    raw=bytearray()
    for ch in source:
        try:raw.extend(ch.encode('cp1252'))
        except UnicodeEncodeError:
            if ord(ch) in (0x81,0x8d,0x8f,0x90,0x9d):raw.append(ord(ch))
            else:return None
    digest=sha256(raw).hexdigest()
    if not any(e.get('decoder') in ('OBS-rule-source-u32-v1','OBS-formula-source-u32-v1')
               and e.get('sha256')==digest for e in item.get('evidence',[])):return None
    return bytes(raw)


def design_archive(model):
    buffer=BytesIO()
    entries={}
    def name(text):return re.sub(r'[^\w.-]+','_',text)
    for rule in model.get('rules',[]):
        for i,variant in enumerate(rule['variants'],1):
            stem='regles/'+name(rule['document_id'])+'_v'+str(i)
            raw=original_bytes(variant)
            if raw is not None:entries[stem+'.bas']=raw
            elif variant.get('design_condition'):
                d=variant['design_condition']
                entries[stem+'_parametres.txt']=('Variable : '+d['variable_name']+'\nComparaison : =\nValeur : '+d['value']+'\n'+
                    'Type : '+str(d.get('value_type') or '')+'\n').encode('utf8')
    for calculation in model.get('calculations',[]):
        raw=original_bytes(calculation)
        if raw is not None:
            key=name(calculation['id']+'_'+(calculation.get('definition_name') or calculation.get('result_variable_name') or 'calcul'))
            entries['fonctions/'+key+'.bas']=raw
    entries['LIRE.txt']=(
        'Les fichiers .bas conservent les octets des scripts stockes dans le PUB, '
        'avec commentaires, blancs et fins de ligne. Leur encodage natif est Windows-1252; '
        'des tables de caracteres peuvent aussi contenir des octets de controle.\n'
        'Les fichiers _parametres.txt decrivent les proprietes de regles simples en UTF-8; '
        'ils ne sont pas des scripts reconstitues. Aucun code compile ne figure dans cette archive.\n'
    ).encode('ascii')
    with ZipFile(buffer,'w',ZIP_DEFLATED) as z:
        for key,raw in sorted(entries.items()):
            info=ZipInfo(key,date_time=(1980,1,1,0,0,0));info.compress_type=ZIP_DEFLATED
            z.writestr(info,raw)
    return buffer.getvalue()


def attach_design_archive(model,path):
    if model.get('kind')=='comparison':return
    from pypdf import PdfReader, PdfWriter
    path=Path(path)
    writer=PdfWriter();writer.clone_document_from_reader(PdfReader(path))
    writer.add_attachment('Sources_de_conception.zip',design_archive(model))
    temporary=None
    try:
        with NamedTemporaryFile(dir=path.parent,suffix='.pdf',delete=False) as stream:
            temporary=Path(stream.name);writer.write(stream)
        os.replace(temporary,path)
    finally:
        if temporary and temporary.exists():temporary.unlink()
