"""Core Report cover: presentation only, without guessing source identities."""
from pathlib import Path
from xml.sax.saxutils import escape

from reportlab.lib.colors import HexColor
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import PageBreak, Paragraph, Spacer

from .i18n import tr

ASSETS = Path(__file__).resolve().parents[2] / 'assets'
PRODUCT_NAME = 'Core Report'


def application_names(model):
    """Only established application objects; never derive an APP from a filename."""
    if model.get('kind') == 'comparison':
        names = [row['name'] for rows in model.get('application_structures', [])
                 for row in rows if row.get('kind') == 'Application' and row.get('object_id')]
    else:
        names = [app['name'] for app in model.get('applications', []) if app.get('name')]
    return list(dict.fromkeys(names))


def draw_cover(canvas, doc, model):
    width, height = doc.pagesize
    canvas.saveState()
    try:
        # Original CMYK JPEG: no recolouring, crop, rotation or extra transparency.
        canvas.drawImage(str(ASSETS / 'Fond_GroupeAlterna_original_CMYK.jpeg'),
                         0, 0, width=width, height=height,
                         preserveAspectRatio=True, anchor='c')
        logo_width = 42 * 72 / 25.4
        logo_height = logo_width * 416 / 825
        canvas.drawImage(str(ASSETS / 'Logo_GroupeAlterna_825px.png'),
                         (width-logo_width)/2, height-52-logo_height,
                         width=logo_width, height=logo_height, mask='auto')
        navy = HexColor('#212F44')
        title = Paragraph(PRODUCT_NAME, ParagraphStyle(
            'cover-title', fontName='AlternaBold', fontSize=32, leading=40,
            alignment=TA_CENTER, textColor=navy))
        title.wrap(width-104, 80)
        title.drawOn(canvas, 52, height/2)

        names = application_names(model)
        label = '<br/>'.join(escape(name) for name in names) if names else escape(tr('Nom d’application non décodé'))
        available_width = width-112
        # Long identifiers wrap intact as text; never elide or translate them.
        for size in (15, 14, 13, 12, 11, 10):
            name = Paragraph(label, ParagraphStyle(
                'cover-application', fontName='Alterna', fontSize=size,
                leading=size*1.45, alignment=TA_CENTER, textColor=navy,
                splitLongWords=True))
            _, label_height = name.wrap(available_width, height/2-80)
            if label_height <= height/2-80:
                break
        else:
            raise ValueError('Too many application names to fit on the report cover')
        name.drawOn(canvas, 56, height/2-22-label_height)
    finally:
        canvas.restoreState()


def build_with_cover(doc, story, model, header):
    """Prepend one page; the existing content flow starts on the next page."""
    doc.build([Spacer(1, 1), PageBreak(), *story],
              onFirstPage=lambda canvas, current: draw_cover(canvas, current, model),
              onLaterPages=header)
