import json
import os
from pathlib import Path
from tempfile import TemporaryDirectory
from .render import report
from .visual_render import VisualRenderer


def visual_stem(stem):
    return {'rapport':'visuel','analyse_A':'visuel_A','analyse_B':'visuel_B'}.get(stem,stem+'_visuel')


def check_pdf(path):
    raw=path.read_bytes() if path.exists() else b''
    if not raw.startswith(b'%PDF-') or not raw.rstrip().endswith(b'%%EOF'):
        raise ValueError('PDF incomplet ; les livrables précédents sont conservés')


def export(model,directory,stem='rapport',*,chapters=None,language='fr'):
    from .i18n import normalize_language
    language=normalize_language(language)
    from .report_options import normalize_chapters
    selected=normalize_chapters(chapters)
    if model.get('kind')!='comparison':
        from .schema import validate_model
        validate_model(model)
    directory=Path(directory);directory.mkdir(parents=True,exist_ok=True)
    data=directory/(stem+'.json');pdf=directory/(stem+'.pdf')
    # Stage and validate every deliverable before exposing any new result.
    # Jobs are only marked complete after this function returns successfully.
    outputs={stem+'.json':str(data),stem+'.pdf':str(pdf)}
    with TemporaryDirectory(prefix='retro-export-',dir=directory) as tmp:
        staged=Path(tmp);j=staged/'model.json';p=staged/'report.pdf'
        options={'language':language} if language!='fr' else {}
        if chapters is not None:options['chapters']=selected
        report(model,p,**options)
        check_pdf(p)
        payload=model
        if model.get('kind')!='comparison':
            v=staged/'visual.pdf';name=visual_stem(stem)+'.pdf'
            stats=VisualRenderer(model['visual'],language=language).render(v)
            check_pdf(v)
            payload={**model,'visual_validation':stats}
            outputs[name]=str(directory/name)
        j.write_text(json.dumps(payload,ensure_ascii=False,sort_keys=True),encoding='utf-8')
        os.replace(j,data);os.replace(p,pdf)
        if model.get('kind')!='comparison':os.replace(v,directory/name)
    return outputs
