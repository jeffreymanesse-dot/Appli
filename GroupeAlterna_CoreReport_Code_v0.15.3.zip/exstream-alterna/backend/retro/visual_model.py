"""Presentation-only model; existing retrospective documentation stays intact."""
import json
from pathlib import Path
from .visual_recovery import recover
from .visual_graphics import GraphicsDecoder

def build_visual(data,model):
    recovered=recover(data,model)
    from .table_anchors import decode_table_anchors
    decode_table_anchors(data,recovered)
    ids=set(recovered.get('document_paragraph_ids',[]))|{p['id']for p in recovered.get('visual_page_containers',[])}
    # No invented root or paragraph sequence when the document structure is absent.
    units=[u for u in recovered['content_units']if u.get('parent_id')in ids]
    tables=[t for t in recovered['tables']if t.get('paragraph_id')in ids]
    presentation={key:recovered[key]for key in ('metadata','document_paragraph_ids','paragraphs','visual_page_containers','visual_recovery')}
    presentation.update(content_units=units,tables=tables)
    presentation['document_flow']=recovered.get('document_flow',[])
    # Retain validated PAGE observations internally. Their separate component
    # section is intentionally omitted from the standalone visual PDF.
    presentation['page_analysis']=model.get('page_analysis',{})
    presentation['object_compositions']=model.get('object_compositions',[])
    graphics=GraphicsDecoder(data,presentation).decode()
    calibration=None
    path=Path(__file__).resolve().parents[2]/'assets/graphics/noa_calibration.json'
    if path.exists():
        known=json.loads(path.read_text())
        if known['source_pub_sha256']==model['metadata']['sha256']:calibration=known
    presentation.update(graphics=graphics,calibration=calibration,
        limits=['Les contenus conditionnels ne sont pas évalués ; les fragments conditionnels sont encadrés de crochets dans le visuel. Aucune branche n’est choisie.',
                'Les compositions graphiques bornées conservent les positions, contours et caractères compilés. Une image non résolue conserve son emplacement avec un cadre croisé explicite.',
                'Les noms des variables sont affichés ; les valeurs client et les exemples de conception ne les remplacent pas.',
                'Les ancrages de tableaux reconnus sont insérés dans le texte propriétaire. Position absolue, autres objets ancrés, pagination native et ressources externes restent partiels.',
                'Les familles de police indisponibles utilisent une substitution ; les styles non interprétés sont conservés.',
                'Taille, couleur, gras, italique et alignement reconnus sont restitués. Le soulignement reste non calibré ; retraits, puces, tabulations et interligne natif restent partiels. La hauteur des appels en exposant est indicative.',
                'Les largeurs de colonnes reconnues sont converties depuis 1/300 de pouce. Le visuel réduit les tables trop larges pour la page ; les mesures sources restent dans le modèle et le rapport.',
                'Les cadres de tableaux et les traits de lignes, colonnes et cellules reconnus sont dessinés selon leur portée propre. Les chevauchements de traits, profils non reconnus et couleurs conditionnelles restent partiels.',
                'Les formes Rounded, Rounded left et Rounded right sont décodées ; leur rayon ne l’est pas. Le visuel utilise un rayon indicatif de 3 points, sans valeur de mesure source.',
                'La calibration de référence NOA reste limitée au package reconnu et aux formes non décodées.' if calibration else
                'Aucune calibration graphique NOA n’est transposée à ce fichier.'])
    return presentation
