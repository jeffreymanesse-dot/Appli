"""Bounded table-object frame, separate from row/column/cell properties."""
import re, struct
from .binary import MARKER, u32, pascal, InvalidPackage, evidence

PROFILE='OBS-table-object-frame-v1'

def frame_owner(data,table):
    q=table.get('start')
    if not q or not table.get('counted_structure'):return None
    return object_frame_owner(data,q)

def object_frame_owner(data,q,object_types=(9,)):
    if data[q-44:q]!=MARKER+b'\0'*40:return None
    candidates=[]
    for hit in re.finditer(re.escape(MARKER+struct.pack('<I',1)),data[max(0,q-2048):q-44]):
        p=max(0,q-2048)+hit.start()
        if p+258>=q:continue
        try:
            if u32(data,p+88)!=300 or u32(data,p+241) not in object_types:continue
            name,_,end=pascal(data,p+257)
            if not name or end+282!=q:continue
            # Object property chains end exactly at the independently identified payload header.
            for start,stop in ((end+38,end+91),(q-97,q-44)):
                at=start
                for tag,size in ((102,4),(103,4),(104,8),(105,5)):
                    if data[at:at+8]!=struct.pack('<II',tag,size):break
                    at+=8+size
                if at!=stop:break
            else:
                if data[end+91:end+99]!=MARKER+struct.pack('<I',1):continue
                if u32(data,p+110)!=101 or data[p+122:p+126]!=MARKER:continue
                if u32(data,p+132)!=101 or data[p+144:p+148]!=MARKER:continue
                # Repeated rectangle geometry ties this to the same object.
                x,y,right,bottom=struct.unpack_from('<4i',data,p+20)
                if struct.unpack_from('<8i',data,p+36)!=(x,y,right,y,right,bottom,x,bottom):continue
                candidates.append(p)
        except (InvalidPackage,ValueError,IndexError,struct.error):continue
    return candidates[0] if len(candidates)==1 else None

def table_frame(data,table,decoder):
    p=frame_owner(data,table)
    if p is None:return {'status':'uninterpreted','scope':'table','renderable':False,'reason':'no_bounded_table_object'}
    return object_frame(data,p,table['start'],decoder,'table',PROFILE)

def object_frame(data,p,end,decoder,scope,profile):
    from .table_styles import measure,proven_colour
    enabled=struct.unpack_from('<H',data,p+100)[0]
    pattern=u32(data,p+102);width=u32(data,p+106)
    if width>1_000_000:
        return {'scope':scope,'status':'uninterpreted','renderable':False,'reason':'frame_width_outside_domain','raw_width':width,'object_offset':p}
    color=proven_colour(data,decoder,decoder.colour(p+110))
    known=enabled in (0,1) and pattern in (0,0xffffffff)
    valid=known and enabled==1 and pattern==0 and 0<width<=300 and color.get('status')=='decoded'
    return {'scope':scope,'status':'decoded' if known else 'uninterpreted','active':enabled==1,
            'renderable':bool(valid),'enabled_raw':enabled,'line_pattern_raw':pattern,
            'thickness':measure(data,p+106),'color':color,'object_offset':p,
            'line_style':'solid_calibrated' if valid else None,
            'evidence':[evidence(data,p,end+20,profile)]}
