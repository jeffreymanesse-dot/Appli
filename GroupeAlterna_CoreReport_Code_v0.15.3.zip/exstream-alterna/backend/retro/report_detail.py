from .report_structure import content_display_text
from .report_cover import build_with_cover
from .i18n import tr, note
"""Evidence-first report; no dependency on reference PDF or package-specific names."""
from xml.sax.saxutils import escape
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,PageBreak,Table,TableStyle,KeepTogether
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib import colors
from .render import setup,ROOT
from .design_source import source_available, source_lines, source_markup


def report_detail(model,path,chapters=None):
    from .report_options import chapter_plan
    from .hierarchy import hierarchy_rows, append_hierarchy
    plan=chapter_plan(chapters,fallback=True)
    c=setup(); W=491
    styles={
      'body':ParagraphStyle('b',fontName='Alterna',fontSize=9,leading=12,spaceAfter=6,textColor=c['navy']),
      'small':ParagraphStyle('s',fontName='Alterna',fontSize=7.5,leading=10,spaceAfter=4,textColor=c['navy']),
      'code':ParagraphStyle('code',fontName='AlternaMono',fontSize=7.2,leading=10,spaceAfter=0,textColor=c['navy']),
      'head':ParagraphStyle('h',fontName='AlternaBold',fontSize=15,leading=19,spaceAfter=12,keepWithNext=True,textColor=c['navy']),
      'sub':ParagraphStyle('sub',fontName='AlternaBold',fontSize=10,leading=13,spaceBefore=9,spaceAfter=6,keepWithNext=True,textColor=c['primary']),
      'white':ParagraphStyle('w',fontName='AlternaBold',fontSize=8,leading=11,textColor=colors.white),
    }
    story=[]
    def p(t,s='body'):
        value=escape(str(t)).replace('\n','<br/>')
        if s=='code':value=source_markup(t)
        return Paragraph(value,styles[s])
    def add(t,s='body'):story.append(p(t,s))
    def section(t):
        if story:story.append(PageBreak())
        add(t,'head')
    def table(rows,widths):
        t=Table([[p(v,'white' if i==0 else 'small') for v in row] for i,row in enumerate(rows)],colWidths=widths,repeatRows=1,hAlign='LEFT')
        t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),c['navy']),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,c['surface']]),('VALIGN',(0,0),(-1,-1),'TOP'),('LINEBELOW',(0,0),(-1,0),.6,c['primary']),('TOPPADDING',(0,0),(-1,-1),5),('BOTTOMPADDING',(0,0),(-1,-1),5)]));story.append(t)
    def code(text):
        # Individual source lines wrap; do not put a large algorithm into an unsplittable table row.
        for line in source_lines(text):add(line,'code')
    meta=model['metadata'];vs={v['id']:v for v in model['variables']};byid={v['internal_id']:v for v in model['variables']}
    section(tr('Rétro-documentation technique'))
    add(meta['source_name'],'sub')
    table([[tr('Éléments décodés'),tr('Nombre')],[tr('Fragments structurés de contenu'),len(model.get('content_units',[]))],[tr('Règles compilées'),len(model['rules'])],[tr('Fonctions et formules'),len(model['calculations'])],[tr('Variables / mappings'),f"{len(vs)} / {len(model['mappings'])}"]],[370,121])
    append_hierarchy(story,hierarchy_rows(model),c)
    plan_start=len(story)
    add(tr('Plan du rapport'),'sub')
    for title in plan.values():add(title)
    story[plan_start:]=[KeepTogether(story[plan_start:])]
    section(tr('1. Vue détaillée'))
    add(tr('La vue composée du courrier n’est pas encore établie : ordre des conteneurs, géométrie et relations de ciblage restent non décodés. Les fragments qui suivent sont une transcription technique, pas une simulation Exstream.'))
    add(tr('Les repères T sont des unités sérialisées. Ils ne remplacent pas les blocs Pxx du document de référence. Les règles portent leur identifiant stable ruleNNNNNN ; la numérotation du catalogue interne ne doit pas être confondue avec R1…R28 de la référence.'))
    add(tr('Le séparateur | matérialise une frontière binaire non interprétée ; il ne fait pas partie du texte métier. Une variable dynamique reste en couleur normale. Aucun fragment n’est coloré en rouge tant que sa cible de règle n’est pas prouvée.'))
    add(tr('CERTAIN : structure directement recoupée. TRÈS PROBABLE : signature empirique contrôlée. HYPOTHÈSE : relation non établie. Une présence dans le package ne prouve pas une émission dans le courrier.'))
    section(tr('2. Contenus extraits et usages directs'))
    add(tr('Inventaire intégral des zones à longueur redondante reconnues. Ordre binaire uniquement ; aucun ordre documentaire déduit. Les ressources techniques mutualisées sont également conservées.'))
    for i,u in enumerate(model.get('content_units',[]),1):
        start=len(story)
        add(f"T{i:03d}",'sub')
        story.extend([p(content_display_text(u)),p(tr('Signature : ')+u['evidence'][0]['decoder']+tr(' ; confiance ')+tr(u['confidence'])+'.','small')])
        if u['variable_names']:
            details=[]
            for name in u['variable_names']:
                v=next(v for v in vs.values() if v['name']==name)
                details.append(name+' : '+str(v['type'])+' / '+str(v['cardinality']))
            add(tr('Données : ')+' ; '.join(details),'small')
        story[start:]=[KeepTogether(story[start:])]
    section(tr('3. Répétitions et tables : preuves disponibles'))
    add(tr('Les candidats ci-dessous ne sont pas des REP confirmés. La même signature peut apparaître dans plusieurs propriétés ; elle ne permet pas de sélectionner le driver exact sans le record parent. Aucune cardinalité XML n’en est déduite.'))
    table([[tr('Axe'),tr('Driver candidat')]]+[[r['axis'],r['driver_name']] for r in model['repeat_candidates']],[70,421])
    visible=set(model.get('content_variable_ids',[]));visible_names={vs[i]['name'] for i in visible}
    selected=[x for x in model['calculations'] if x['id'] in model.get('document_calculation_ids',[]) or
              (x['id'].startswith('formula') and (x.get('result_variable_id') in visible or visible_names.intersection(x.get('write_names',[]))))]
    section(plan['rules'])
    add(tr('Catalogue complet du package, y compris les règles techniques. Cible et portée non établies. Les lectures sont résolues par ID ; aucune branche opposée n’est inventée pour une donnée absente ou nulle.'))
    from .rule_labels import rule_labels, rule_algorithms
    labels=rule_labels(model['rules'])
    for r in model['rules']:
        start=len(story)
        add(r['document_id']+' • '+labels[r['compiled_id']],'sub')
        for kind,text in rule_algorithms(r):
            if kind in ('script','parameters'):code(text)
            else:add(text,'small')
    if 'valuation' in plan:
        section(plan['valuation'])
        from .function_signature import signature_lines, code_zone
        from .formula_timing import compute_time_line
        for x in selected:
            add(x.get('definition_name') or x.get('result_variable_name') or x['id'],'sub')
            for line in signature_lines(x):add(line,'small')
            timing=compute_time_line(x)
            if timing:add(timing,'small')
            story.append(Paragraph(code_zone(x),ParagraphStyle('zone',fontName='AlternaBold',
                fontSize=8.5,leading=12,spaceBefore=4,spaceAfter=6,keepWithNext=True,textColor=c['navy'])))
            if source_available(x):code(x['source_expression'])
            else:add(tr('Ce script contient des caractères non imprimables. Son texte intégral est conservé dans les sources jointes au PDF.') if x.get('source_expression') else tr('Script non disponible dans ce PUB.'),'small')
        if not selected:add(tr('Aucune formule rattachable aux contenus reconnus.'))
        add(tr('Les appels de référentiels ne sont pas assimilés à des valeurs de référence embarquées.'))
    if 'input_dictionary' in plan:
        section(plan['input_dictionary'])
        ids=set(model.get('content_variable_ids',[]))
        for r in model['rules']:
            for v in r['variants']:ids.update(byid[i]['id'] for i in v['reads'] if i in byid)
        for x in selected:ids.update(byid[i]['id'] for i in x['reads'] if i in byid)
        rows=[[tr('Variable'),tr('Chemin XML'),tr('Type / cardinalité')]]
        for m in model['mappings']:
            if m['variable_id'] not in ids or m['source_classification']!='input_candidate':continue
            v=vs[m['variable_id']]
            rows.append([v['name'],m['xml_path'],str(v['type'])+' / '+str(v['cardinality'])])
        add(tr('{0} mappings liés aux contenus reconnus, aux règles du package ou aux calculs sélectionnés. Ce périmètre inclut des éléments mutualisés et ne correspond pas à un inventaire certifié des seuls champs émis dans ce courrier.').format(len(rows) - 1))
        table(rows,[180,211,100])
    if 'reconstruction' in plan:
        section(plan['reconstruction'])
        from .report_inventory import inventory_rows
        add(tr('Inventaire du package'),'sub')
        table(inventory_rows(model),[180,311])
    def header(canvas,doc):
        canvas.saveState();canvas.drawImage(str(ROOT/'assets/Logo_GroupeAlterna_825px.png'),450,785,width=88,height=44.37,mask='auto');canvas.setStrokeColor(c['primary']);canvas.line(52,775,543,775)
        canvas.setFont('Alterna',7);canvas.setFillColor(c['muted']);canvas.drawString(52,29,tr('Groupe Alterna | Rétro-documentation partielle | ')+model['engine_version']);canvas.drawRightString(543,29,str(doc.page-1));canvas.restoreState()
    doc=SimpleDocTemplate(str(path),pagesize=(595.276,841.89),leftMargin=52,rightMargin=52,topMargin=80,bottomMargin=48,title='Core Report | '+tr('Rétro-documentation technique - analyse partielle'),author='Groupe Alterna')
    build_with_cover(doc, story, model, header)
