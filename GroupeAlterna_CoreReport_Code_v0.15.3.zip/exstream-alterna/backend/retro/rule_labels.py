"""Source names stay verbatim; identity disambiguation is documentary only."""
from collections import Counter
import re
from .i18n import tr


def rule_labels(rules):
    names={r['compiled_id']:list(dict.fromkeys(v['name'] for v in r['variants'] if v.get('name')
        and not re.match(r'^(?:Message|Page|Table|Row|Column|Section|Document|Design Layer|Queue|Data File|Page Template) (?:Component|Rule)\b',v['name'],re.I))) for r in rules}
    counts=Counter(n for nn in names.values() for n in nn)
    return {rid:(' / '.join(nn) if nn else tr('Règle non nommée'))+
            (f' (ID {rid})' if nn and any(counts[n]>1 for n in nn) else '')
            for rid,nn in names.items()}


def rule_algorithms(rule):
    """Design scripts or stored design properties only; no compiled fallback."""
    from .design_source import source_available, condition_presentation
    result=[]
    available_codes={v.get('compiled_code') for v in rule['variants']
                     if source_available(v) or v.get('design_condition')}
    for variant in rule['variants']:
        if source_available(variant):item=('script',variant['source_expression'])
        elif variant.get('design_condition'):
            item=('parameters',condition_presentation(variant['design_condition']))
        else:
            # A duplicate occurrence of the identical compiled variant adds no
            # missing-script notice when its own design record was also found.
            if variant.get('compiled_code') in available_codes:continue
            item=('unavailable',tr('Script non restituable dans ce PUB.') if variant.get('source_expression') else tr('Script non disponible dans ce PUB.'))
        if item not in result:result.append(item)
    return result


def rule_conditions(rule):
    return list(dict.fromkeys(v['condition_readable'] for v in rule['variants'] if v.get('condition_readable')))
