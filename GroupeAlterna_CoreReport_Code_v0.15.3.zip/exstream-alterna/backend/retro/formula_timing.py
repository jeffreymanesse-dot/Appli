"""Read stored Formula Compute Time properties; never infer them from code/names."""
import struct
from .binary import MARKER, InvalidPackage, evidence, occurrences, pascal, u32

PROFILE = 'OBS-formula-compute-time-141-v1'
ENVELOPE = struct.pack('<11I', 0, 0, 2, 102, 0, 103, 4, 0, 104, 4, 0)
# Only enum values corroborated in the supplied package corpus are interpreted.
TIMES = {0: ('as_needed', 'As-needed'), 1: ('customer', 'Customer'),
         3: ('page', 'Page'), 6: ('initialization', 'Initialization'),
         8: ('named_section', 'Named section')}
EVENT_KINDS = {'customer', 'page', 'initialization', 'named_section'}
SECTION_PREFIX = struct.pack('<8I', 0, 1, 0, 5, 0, 0, 0, 2)
SECTION_SUFFIX = bytes(28) + struct.pack('<2I', 106, 0) + b'\0' + struct.pack('<6I', 104, 4, 0, 105, 4, 0)


def read_compute_time(data, variable, calculation):
    """Matching definition, type/source header and duplicated variable name.

    The field is a design property, distinct from reset time and from the
    effective timing induced by other variables. Unknown enums stay unknown.
    """
    try:
        a = variable['name_end']; p = a + 44; stop = calculation['offset']
        if variable['class_code'] != 35 or calculation.get('result_variable_id') != variable['id']:
            return None
        if calculation['id'] != 'formula' + str(variable['internal_id']):return None
        if not variable['offset'] < a < p + 41 <= stop < variable['end'] <= len(data):return None
        if data[a:p] != ENVELOPE or data[p:p+4] != MARKER or u32(data,p+4) not in (141,142):return None
        if variable.get('type_offset') != p+8 or u32(data,p+8) != variable.get('type_code'):return None
        if u32(data,p+12) != 1:return None  # Source = Formula
        if any(u32(data,p+i) for i in (20,24,32,36)) or u32(data,p+28) != 1:return None
        name,_,end = pascal(data,p+40)
        if name != variable['name'] or end+8 > stop or data[end:end+4] != bytes(4):return None
        if variable.get('cardinality_offset') != end+4 or u32(data,end+4) not in (0,1):return None
        code = u32(data,p+16); kind,label = TIMES.get(code,(None,None))
        result = {'profile':PROFILE,'status':'decoded' if kind else 'unknown_value',
                  'code':code,'kind':kind,'label':label,'section_name':None,
                  'evidence':[evidence(data,p,end+8,PROFILE)]}
        if kind == 'named_section':
            # A separate property envelope follows the stored source, not a
            # string occurrence in its comments or executable expression.
            source_ends = [e['offset_end'] for e in calculation.get('evidence',[])
                           if e.get('decoder') == 'OBS-formula-source-u32-v1']
            candidates=[]
            for rel in occurrences(data[max(source_ends,default=end+8):stop],SECTION_PREFIX):
                q=max(source_ends,default=end+8)+rel+len(SECTION_PREFIX)
                section,_,tail=pascal(data,q)
                if not section or not all(c.isprintable() for c in section):continue
                if tail+len(SECTION_SUFFIX)>stop or data[tail:tail+len(SECTION_SUFFIX)]!=SECTION_SUFFIX:continue
                candidates.append((section,q,tail+len(SECTION_SUFFIX)))
            if len(candidates)==1:
                section,q,tail=candidates[0];result['section_name']=section
                result['evidence'].append(evidence(data,q-len(SECTION_PREFIX),tail,PROFILE+'-section'))
        return result
    except (InvalidPackage,KeyError,IndexError,struct.error):return None


def enrich_compute_times(data,model):
    variables={v['id']:v for v in model['variables']}
    for calculation in model['calculations']:
        variable=variables.get(calculation.get('result_variable_id'))
        if variable is None:continue
        timing=read_compute_time(data,variable,calculation)
        if timing:
            calculation['compute_time']=timing
            variable['compute_time']=timing


def event_formula_ids(model):
    """Scheduled formulas are entry points, even without a printed result."""
    return {c['id'] for c in model['calculations'] if c.get('result_variable_id')
            and c.get('compute_time',{}).get('status')=='decoded'
            and c['compute_time']['kind'] in EVENT_KINDS}


def compute_time_line(calculation):
    from .i18n import tr
    if not calculation.get('result_variable_id'):return None
    timing=calculation.get('compute_time') or {}
    label=timing.get('label') or tr('Non déterminé dans ce PUB')
    if timing.get('section_name'):label+=' — '+timing['section_name']
    return 'Compute Time : '+label
