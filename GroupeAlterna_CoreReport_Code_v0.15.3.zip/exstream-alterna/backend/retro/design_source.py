"""Read stored design text and simple-rule properties, never decompile code."""
import re
import struct
from .binary import MARKER, InvalidPackage, evidence, pascal, u32


def decode_source(raw):
    # Preserve every byte, including undefined Windows-1252 positions. Such
    # control characters are retained internally and rejected by the PDF view.
    return ''.join(bytes([b]).decode('cp1252') if b not in (0x81,0x8d,0x8f,0x90,0x9d)
                   else chr(b) for b in raw)


def source_record(data, start, stop):
    """Unique complete uint32-sized text field inside its own design record.

    A source field is followed by a zero word. Inspect the full printable run,
    including leading whitespace, instead of requiring its first token to be IF.
    Identifiers, resource names and scalar values alone are not script fields.
    """
    candidates=[]
    for hit in re.finditer(rb'[\x09\x0a\x0d\x20-\xff]{2,}',data[start:stop]):
        p=start+hit.start();end=start+hit.end()
        # At most three printable low bytes of the size may precede the text.
        for skip in range(4):
            q=p+skip;n=end-q
            if q<start+4 or not 2<=n<=500000 or end+4>stop:continue
            if u32(data,q-4)!=n or data[end:end+4]!=bytes(4):continue
            raw=data[q:end]
            if not re.search(rb'[=()\r\n]|\b(?:INCLUDE|EXCLUDE)\b',raw,re.I):continue
            if not re.match(rb'\s*(?:[A-Za-z_]|//|/\*)',raw):continue
            candidates.append((q,decode_source(raw)))
    if not candidates:return None
    size=max(len(text) for _,text in candidates)
    longest=[item for item in candidates if len(item[1])==size]
    return longest[0] if len(longest)==1 else None


def simple_rule(data, header, stop, variables):
    """Bounded native equality-rule profile observed across 538 corpus records."""
    try:
        if data[header:header+12]!=MARKER+struct.pack('<II',108,30):return None
        if u32(data,header+20)!=0 or u32(data,header+24)!=1:return None
        var=variables.get(u32(data,header+28))
        if not var:return None
        literal,_,end=pascal(data,header+32)
        if end+8>=stop or data[end:end+8]!=bytes(8):return None
        name,_,name_end=pascal(data,end+8)
        if not name or name_end+44>stop:return None
        # Common property envelope; the saved/inline flag may be 0 or 1.
        if data[name_end:name_end+12]!=bytes(8)+struct.pack('<I',2):return None
        if u32(data,name_end+12) not in (0,1):return None
        if data[name_end+16:name_end+28]!=struct.pack('<III',0xffffffff,0,0):return None
        if data[name_end+28:name_end+44]!=struct.pack('<IIII',106,0,107,0):return None
        return {'kind':'parameter_equality','variable_id':var['id'],
                'variable_name':var['name'],'operator':'=','value':literal,
                'value_type':var['type'],
                'evidence':[evidence(data,header+20,end+8,'OBS-design-equality-properties-v1')]}
    except (InvalidPackage,IndexError,struct.error):return None


def source_available(item):
    text=item.get('source_expression')
    return bool(text) and all(c.isprintable() or c in '\t\r\n\u00a0\u202f' for c in text)


def condition_presentation(condition):
    """Readable native parameters, explicitly distinguished from a saved script.

    The declared data type matters: the string "true" is not Boolean true.
    Keep literal spelling and whitespace; never derive actions from compiled JS.
    Unsupported literal/type combinations retain the field-by-field view.
    """
    from .i18n import tr
    value=condition['value'];dtype=condition.get('value_type')
    literal=None
    if dtype=='String':literal='"'+value.replace('"','""')+'"'
    elif dtype=='Boolean' and value in ('true','false'):literal=value
    elif dtype in ('Integer','Floating','Currency') and re.fullmatch(r'[-+]?\d+(?:\.\d+)?',value):literal=value
    if condition.get('operator')=='=' and literal is not None:
        return tr('Condition paramétrée')+' ('+dtype+')\n'+condition['variable_name']+' = '+literal
    return (tr('Variable : ')+condition['variable_name']+'\n'+
            (tr('Type : ')+dtype+'\n' if dtype else '')+
            tr('Comparaison : ')+condition['operator']+'\n'+tr('Valeur : ')+value)


def source_lines(text):
    """Retain indentation, blank lines and comments; only normalize line endings."""
    return text.replace('\r\n','\n').replace('\r','\n').split('\n')


def source_markup(text):
    """Keep code whitespace while allowing visual wraps at ordinary spaces."""
    from xml.sax.saxutils import escape
    value=escape(str(text).expandtabs(4))
    value=re.sub(r'^ +',lambda m:'&#160;'*len(m.group()),value)
    return value.replace('  ','&#160; ').replace('\n','<br/>') or '&#160;'
