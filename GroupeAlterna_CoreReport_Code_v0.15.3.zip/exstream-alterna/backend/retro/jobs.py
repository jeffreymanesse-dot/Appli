import json,os,shutil,time,secrets,logging,hashlib
from pathlib import Path
from .db import Session,Job,transaction
from .config import settings
from .parser import analyze
from .export import export
from .compare import compare
from . import __version__
from .report_options import normalize_chapters, public_outputs
from .storage import stored_bytes,reconcile_retained
TERMINAL={'termine','echec','annule','expire'}
class Cancelled(Exception):pass

def stage(jid,state):
    with transaction() as db:
        j=db.get(Job,jid)
        if not j or j.cancelled or j.state in ('annule','expire'):raise Cancelled()
        j.state=state;j.updated=time.time();j.history=[*j.history,{'state':state,'at':j.updated}]

def mark_failure(jid,code='PROCESSING_FAILED'):
    with transaction() as db:
        j=db.get(Job,jid)
        if j and j.state not in TERMINAL:
            j.state='annule' if j.cancelled else 'echec';j.error=None if j.cancelled else code;j.outputs=[];j.updated=time.time();j.history=[*j.history,{'state':j.state,'at':j.updated}]

def settle_storage(jid):
    """Call only once this executor has finished all writes and cleanup."""
    with transaction() as db:
        j=db.get(Job,jid)
        if j and j.state in ('termine','echec','annule'):
            try:j.reserved_bytes=stored_bytes(settings.storage/jid)
            except OSError:logging.warning(json.dumps({'event':'storage_recount_failed','job_id':jid}))

def run_job(jid):
    directory=settings.storage/jid
    try:
        with Session() as db:
            j=db.get(Job,jid)
            if not j:return
            inputs=j.inputs;mode=j.mode;chapters=normalize_chapters(j.summary.get('report_chapters'))
            language=j.summary.get('report_language','fr')
        stage(jid,'controle');models=[]
        for item in inputs:
            m=analyze(directory/item['stored'],item['name'],lambda phase:stage(jid,phase));models.append(m)
        stage(jid,'livrables');outputs={}
        if mode=='compare':
            outputs.update(export(models[0],directory,'analyse_A',chapters=chapters,language=language));stage(jid,'livrables')
            outputs.update(export(models[1],directory,'analyse_B',chapters=chapters,language=language));stage(jid,'livrables')
            diff=compare(*models);outputs.update(export(diff,directory,'comparaison',language=language))
            summary={'counts':diff['counts'],'partial':True,'xsd_available':False,'sources':[m['metadata'] for m in models]}
        else:
            outputs.update(export(models[0],directory,chapters=chapters,language=language));m=models[0]
            summary={'variables':len(m['variables']),'mappings':len(m['mappings']),'rules':len(m['rules']),'partial':True,'xsd_available':False,'sources':[m['metadata']]}
        if sum(Path(p).stat().st_size for p in outputs.values())>settings.max_output_bytes:raise ValueError('Output quota')
        for p in outputs.values():Path(p).chmod(0o600)
        summary['report_chapters']=list(chapters)
        summary['report_language']=language
        with transaction() as db:
            j=db.get(Job,jid)
            if not j or j.cancelled or j.state in TERMINAL:raise Cancelled()
            j.outputs=public_outputs(outputs);j.summary=summary;j.state='termine';j.updated=time.time();j.history=[*j.history,{'state':'termine','at':j.updated}]
            j.reserved_bytes=stored_bytes(directory)
    except Cancelled:
        mark_failure(jid)
        for p in directory.glob('*'):
            if p.suffix in ('.json','.pdf','.xsd'):p.unlink(missing_ok=True)
        settle_storage(jid)
    except Exception:
        mark_failure(jid)
        logging.error(json.dumps({'event':'job_failed','job_id':jid}))
        for p in directory.glob('*'):
            if p.suffix in ('.json','.pdf','.xsd'):p.unlink(missing_ok=True)
        settle_storage(jid)

def rq_failure(job,connection,type,value,traceback):
    mark_failure(job.id,'WORKER_FAILED')

def rq_stopped(job,connection):
    mark_failure(job.id)

def purge(now=None):
    now=now or time.time();removed=0
    with transaction() as db:
        # Also repair reservations of 0.9.0 successes, without expiring them.
        reconcile_retained(db,settings.storage)
        for j in db.query(Job).filter(Job.state.notin_(list(TERMINAL)),Job.updated < now-settings.max_job_seconds-60).all():
            j.state='echec';j.error='WORKER_TIMEOUT';j.updated=now;j.history=[*j.history,{'state':'echec','at':now}]
        for j in db.query(Job).filter(Job.expires<=now,Job.state.in_(list(TERMINAL))).all():
            directory=settings.storage/j.id
            if directory.is_dir():shutil.rmtree(directory);removed+=1
            j.state='expire';j.outputs=[];j.inputs=[];j.summary={};j.reserved_bytes=0
        # Tombstones expire after 7 additional days; no business data retained.
        db.query(Job).filter(Job.state=='expire',Job.expires<now-7*86400).delete(synchronize_session=False)
    return removed
