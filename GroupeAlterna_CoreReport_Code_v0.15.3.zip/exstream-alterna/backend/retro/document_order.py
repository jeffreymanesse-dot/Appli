"""Propagate proven APP document references to the shared reporting sequence.

Definition offsets locate objects; they do not establish application order.
No name sorting or package-specific selection is used. Unresolved or conflicting
application roots retain their diagnostic sequence without claiming it is proven.
"""


def apply_application_document_order(model):
    documents=model.get('documents',[])
    apps=model.get('applications',[])
    byid={d['id']:d for d in documents}
    definition_ids=[d['id'] for d in model.get('definitions',[])
                    if d['class_code']==10 and d['id'] in byid]
    definition_ids+= [d['id'] for d in documents if d['id'] not in definition_ids]
    audit={'status':'unresolved','application_id':None,'referenced_document_ids':[],
           'ordered_document_ids':[],'definition_document_ids':definition_ids,
           'unreferenced_document_ids':definition_ids[:],'unresolved_document_ids':[],
           'changed':False,'evidence':[]}
    model['document_order']=audit
    if len(apps)!=1:
        audit['reason']='No unique application root; inter-application order is not established.'
        return
    app=apps[0];refs=app.get('document_ids',[])
    known={d['id'] for d in model.get('definitions',[]) if d['class_code']==10}
    if (app.get('relation_status')!='counted_references' or not refs
            or len(refs)!=len(set(refs)) or not set(refs).issubset(known)
            or not app.get('evidence')):
        audit['reason']='Application document references are not completely validated.'
        return
    resolved=[ident for ident in refs if ident in byid]
    unreferenced=[ident for ident in definition_ids if ident not in refs]
    unresolved=[ident for ident in refs if ident not in byid]
    audit.update(application_id=app['id'],referenced_document_ids=list(refs),
                 ordered_document_ids=resolved,unreferenced_document_ids=unreferenced,
                 unresolved_document_ids=unresolved,evidence=list(app['evidence']))
    if not documents:
        audit.update(status='no_decoded_document_flow',reason='Document references exist; no document flow was decoded.')
        return
    # Keep unreferenced content in its previous diagnostic tail. Its position is
    # explicitly outside the proven APP list, never a newly invented APP member.
    final_ids=resolved+unreferenced
    audit.update(status='partial_application_references' if unreferenced or unresolved else 'application_references',
                 changed=final_ids!=definition_ids)
    model['documents']=[byid[ident] for ident in final_ids]
    known_paragraphs={p['id'] for p in model.get('paragraphs',[])}
    order=[pid for d in model['documents'] for pid in d.get('paragraph_ids',[])]
    # Preserve the existing shared-paragraph deduplication policy: first visit.
    model['document_paragraph_ids']=list(dict.fromkeys(p for p in order if p in known_paragraphs))
    model['unresolved_document_paragraph_ids']=[p for p in order if p not in known_paragraphs]


def validate_application_document_order(model):
    """Reject a divergence before a report/visual is exported, without guessing."""
    audit=model.get('document_order',{})
    if audit.get('status') not in ('application_references','partial_application_references'):
        return
    documents=model.get('documents',[])
    refs=audit['referenced_document_ids'];byid={d['id']:d for d in documents}
    apps=model.get('applications',[])
    if (len(apps)!=1 or apps[0]['id']!=audit['application_id']
            or apps[0].get('relation_status')!='counted_references'
            or apps[0].get('document_ids')!=refs):
        raise ValueError('Document order is not justified by application references')
    expected=[i for i in refs if i in byid]+audit['unreferenced_document_ids']
    if [d['id'] for d in documents]!=expected:
        raise ValueError('Document flow differs from validated application order')
    known={p['id'] for p in model.get('paragraphs',[])}
    expected_paragraphs=list(dict.fromkeys(p for ident in expected
                                          for p in byid[ident].get('paragraph_ids',[]) if p in known))
    if model.get('document_paragraph_ids')!=expected_paragraphs:
        raise ValueError('Paragraph flow differs from validated application order')
    if 'visual' in model and model['visual'].get('document_paragraph_ids')!=expected_paragraphs:
        raise ValueError('Visual flow differs from validated application order')
