import argparse,json
from pathlib import Path
from .parser import analyze
from .compare import compare
from .export import export

def main():
    p=argparse.ArgumentParser(description='Analyse locale Exstream (expérimentale)')
    p.add_argument('input',type=Path);p.add_argument('--other',type=Path);p.add_argument('--output',type=Path,required=True)
    p.add_argument('--language',choices=('fr','en'),default='fr',help='Language of report headings and commentary; PUB content stays unchanged')
    a=p.parse_args();m=analyze(a.input);export(m,a.output,'analyse_A' if a.other else 'rapport',language=a.language)
    if a.other:
        n=analyze(a.other);export(n,a.output,'analyse_B',language=a.language);export(compare(m,n),a.output,'comparaison',language=a.language)
    print(json.dumps({'status':'partial_not_validated','output':str(a.output)},ensure_ascii=False))
if __name__=='__main__':main()
