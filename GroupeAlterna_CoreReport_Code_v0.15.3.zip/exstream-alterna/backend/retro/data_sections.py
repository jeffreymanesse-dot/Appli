"""Data-section declarations and explicit selectors, with bounded evidence.

Declarations are not uses. Names shared by several sources remain ambiguous.
No row binding, XML cardinality or execution order is inferred from a name.
"""
import re
from collections import defaultdict
from .binary import MARKER, occurrences, u32, pascal, evidence, InvalidPackage
from .layout import sig

XML_NAME=re.compile(r'[A-Za-z_][A-Za-z0-9_.-]*\Z')
XML_PARENT=re.compile(r'[A-Za-z_][A-Za-z0-9_.-]*(?: [A-Za-z_][A-Za-z0-9_.-]*)*\Z')


def declarations(data, definitions):
    result=[];sources=[d for d in definitions if d['class_code']==15]
    for source in sources:
        offsets=[source['offset']+i for i in occurrences(data[source['offset']:source['end']],sig(115))]
        for i,off in enumerate(offsets):
            end=offsets[i+1] if i+1<len(offsets) else source['end']
            try:
                n=u32(data,off+12)
                if not 1<=n<=240 or off+16+n+13>end:continue
                element=data[off+16:off+16+n].decode('ascii');q=off+16+n
                if not XML_NAME.fullmatch(element) or data[q:q+8]!=b'\0'*8 or u32(data,q+8)!=1:continue
                name,_,name_end=pascal(data,q+12)
                if not name or len(name)>240 or any(not c.isprintable() for c in name):continue
                if name_end+25>end or data[name_end:name_end+16]!=b'\0'*16:continue
                depth=u32(data,name_end+16)
                if depth!=u32(data,name_end+20) or not 0<depth<=128:continue
                parent,_,parent_end=pascal(data,name_end+24)
                if parent_end>end or not XML_PARENT.fullmatch(parent):continue
                duplicate=bytes([len(element)])+element.encode()+bytes([len(parent)])+parent.encode()
                corroboration=data.find(duplicate,parent_end,end)
                if corroboration<0:continue
                ident=f"data-section:{source['id']}:{u32(data,off+8)}"
                result.append({'id':ident,'name':name,'source_id':source['id'],'source_name':source['name'],
                    'element_id':u32(data,off+8),'element':element,'parent_path':parent,
                    'xml_path':'/'+parent.replace(' ','/')+'/'+element,'depth_code':depth,
                    'offset':off,'status':'declared','confidence':'CERTAIN','bindings':[],
                    'evidence':[evidence(data,off,corroboration+len(duplicate),'OBS-data-section-115-v1')]})
            except (InvalidPackage,UnicodeError,ValueError,IndexError):continue
    return result


def section_selector(data, section, definition):
    if not section.get('members'):return None
    p=section['members'][-1]['offset']+12;end=definition['end']
    try:
        if p+29>end or data[p:p+20]!=sig(1)+b'\0'*12:return None
        count=u32(data,p+20)
        if count not in (0,1):return None
        name,_,stop=pascal(data,p+24)
        if stop+12>end or bool(name)!=bool(count) or any(not c.isprintable() for c in name):return None
        if data[stop:stop+12]!=b'\0'*4+sig(106,36)[4:]:return None
        if not name:return None
        return name,p+24,[evidence(data,p,stop+12,'OBS-section-data-selector-v1')]
    except (InvalidPackage,IndexError):return None


def enrich_data_sections(data,model):
    sections=declarations(data,model['definitions']);byname=defaultdict(list);bindings=[]
    defs={d['id']:d for d in model['definitions']};rules={r['compiled_id']:r for r in model['rules']}
    for item in sections:byname[item['name']].append(item)

    def bind(name,kind,obj,offset,ev):
        candidates=byname.get(name,[])
        binding={'id':f"data-binding:{kind}:{obj['id']}:{offset}",'owner_kind':kind,
                 'owner_id':obj['id'],'owner_name':obj['name'],'data_section_name':name,
                 'data_section_id':candidates[0]['id'] if len(candidates)==1 else None,
                 'candidate_ids':[x['id'] for x in candidates],'offset':offset,
                 'status':'resolved' if len(candidates)==1 else 'ambiguous' if candidates else 'declaration_unresolved',
                 'confidence':'CERTAIN' if len(candidates)==1 else 'HYPOTHÈSE','evidence':ev}
        bindings.append(binding);obj['data_section_binding_ids']=[binding['id']]
        if binding['status']=='resolved':candidates[0]['bindings'].append(binding['id'])

    def parent_rule(obj,kind,rid,ev):
        if rid not in rules:return
        obj['global_rule_ids']=[rid]
        rules[rid].setdefault('associations',[]).append({'kind':kind+'_global','owner_id':obj['id'],
            'owner_name':obj['name'],'affected_paragraph_ids':obj.get('paragraph_ids',[]),
            'confidence':'TRÈS PROBABLE','evidence':ev})

    for section in model.get('document_sections',[]):
        d=defs[section['id']];selector=section_selector(data,section,d)
        if selector:bind(selector[0],'section',section,selector[1],selector[2])
        a=d['name_end']
        if a+64<=d['end'] and data[a+44:a+52]==sig(111):
            parent_rule(section,'section',u32(data,a+60),[evidence(data,a+44,a+68,'OBS-section-rule-v1'),*section['evidence']])
    for document in model.get('documents',[]):
        if document.get('data_section_name'):
            bind(document['data_section_name'],'document',document,document['data_section_reference_offset'],document['evidence'])
        parent_rule(document,'document',document.get('rule_id_raw'),document['evidence'])

    referenced=[s for s in sections if s['bindings']]
    for item in sections:
        item['usage_status']=('explicit_selector' if item['bindings'] else
            'within_referenced_xml_subtree' if any(item['source_id']==s['source_id'] and item['xml_path'].startswith(s['xml_path']+'/') for s in referenced)
            else 'shared_source_no_binding_decoded')
    model['data_sections']=sections;model['data_section_bindings']=bindings
    model['data_section_coverage']={'declarations':len(sections),'distinct_names':len(byname),
        'explicit_bindings':len(bindings),'resolved_bindings':sum(b['status']=='resolved' for b in bindings),
        'row_bindings_confirmed':0,'row_binding_status':'unresolved_not_absent',
        'exhaustive':False,'limits':['Les déclarations de la source partagée ne prouvent pas leur utilisation par le courrier.',
            'Rattachement des data sections aux lignes et ordre des événements non décodés ; aucune absence ni héritage supposé.']}
    model['unknowns'].append({'code':'DATA_SECTIONS','detail':'Déclarations XML et sélecteurs explicites document/section décodés. Les data sections des lignes, les variantes Header/Footer et les héritages restent à vérifier.'})


def audit_rule_catalog(data,model):
    headers=[]
    for off in occurrences(data,sig(108,30)):
        try:headers.append({'compiled_id':u32(data,off+12),'offset':off})
        except InvalidPackage:continue
    header_ids={h['compiled_id'] for h in headers};compiled_ids={r['compiled_id'] for r in model['rules']}
    model['rule_catalog_audit']={'definition_records':len(headers),'definition_ids':len(header_ids),
        'compiled_rule_ids':len(compiled_ids),'compiled_occurrences':sum(len(r['variants']) for r in model['rules']),
        'header_ids_without_compiled_rule':sorted(header_ids-compiled_ids),
        'compiled_ids_without_header':sorted(compiled_ids-header_ids),
        'inventory_reconciled':header_ids==compiled_ids,'targeting_exhaustive':False,
        'identity_key':'compiled_id','definition_offsets':headers}
