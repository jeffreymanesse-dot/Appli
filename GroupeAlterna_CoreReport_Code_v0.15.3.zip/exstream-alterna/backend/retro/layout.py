"""Bounded empirical PUB structure reader. No package names or reference-PDF data."""
import struct
from .binary import MARKER, occurrences, u32, evidence, pascal, InvalidPackage

ROW_TYPE_LABELS={1:'Automated row — repeating on defined criteria (R)',
                 2:'Header (H)',3:'Footer (F)',4:'Repeating header (H+)',5:'Repeating footer (F+)',
                 7:'Repeating footer - Except last Page (F-)'}

def row_type_label(code):
    return ROW_TYPE_LABELS.get(code)


def sig(*values):
    return MARKER + struct.pack('<'+'I'*len(values), *(x & 0xffffffff for x in values))


def grid_axis(data, start, end, tag):
    result=[]
    for rel in occurrences(data[start:end], sig(tag)):
        p=start+rel
        # Two colour envelopes; the fields at +12/+16 are NOT universal
        # sentinels. Explicitly styled rows can have zero in both fields.
        if p+117>end or u32(data,p+20)!=101 or data[p+32:p+40]!=sig(101):continue
        q=p+48
        if data[q:q+4]!=MARKER:continue
        default_axis=0xffffffff in (u32(data,p+12),u32(data,p+16))
        styled_end=(styled_row_extent(data,p,end)
                    if tag==-109 and u32(data,p+12)==u32(data,p+16)==0 else None)
        if not default_axis and styled_end is None:continue
        result.append({'index':len(result),'offset':p,'raw_dimension':u32(data,p+8),'properties_offset':q,
                       'evidence':[evidence(data,p,styled_end if styled_end is not None else q+56,
                                            'OBS-styled-row-axis-v2' if styled_end is not None else 'OBS-grid-axis-v1')]})
    return result


def styled_row_extent(data,p,end):
    """Recognise the complete observed row property stream, not bare zeroes.

    Packed prefix followed by eight bounded TLVs. The final marker belongs
    to the following record. Unknown versions/truncation are not promoted.
    """
    if p+887>end or u32(data,p+52)!=2 or u32(data,p+56)!=2:return None
    if u32(data,p+138)!=101 or data[p+150:p+154]!=MARKER:return None
    cursor=p+162
    for tag,size in ((-102,4),(-103,4),(-104,4),(-105,12),(-106,4),(-107,4),(-108,4),(-109,621)):
        if cursor+8+size>end or data[cursor:cursor+8]!=struct.pack('<iI',tag,size):return None
        cursor+=8+size
    return cursor if data[cursor:cursor+4]==MARKER else None


def styled_row_candidate(data,p,end):
    """Recognise this profile's prefix even if its later TLV stream is damaged."""
    return (p+60<=end and data[p:p+8]==sig(-109)
            and u32(data,p+12)==u32(data,p+16)==0 and u32(data,p+20)==101
            and data[p+32:p+40]==sig(101) and data[p+48:p+60]==sig(2,2))


def extended_row_profile(data,p,end):
    """Additional 24-byte row field group, validated by its full TLV tail.

    The extra words and string are retained without assigning data-section or
    Header/Footer semantics. Their presence shifts the rule reference.
    """
    try:
        q=p+48
        if p+907>end or data[q:q+12] not in (sig(1,1),sig(0,0)):return None
        name,_,name_end=pascal(data,q+84)
        if len(name)>240 or any(not c.isprintable() for c in name):return None
        shift=name_end-(q+85)
        # Optional 16-byte group, guarded by its discriminator and full tail.
        extension=data[name_end+12:name_end+28]
        if extension==struct.pack('<IIII',1,0,0,1):shift+=16
        elif u32(data,name_end+12)!=0:
            # Some rows carry a duplicated, non-executable source ID and a
            # bounded mode word here. Preserve it without treating it as a
            # rule association or shifting the separately guarded TLV tail.
            first=u32(data,name_end);second=u32(data,name_end+4)
            mode=u32(data,name_end+12)
            if not (first==second and u32(data,name_end+8)==0 and mode==2):return None
        cursor=p+186+shift
        if data[p+174+shift:p+178+shift]!=MARKER:return None
        for tag,size in ((-102,4),(-103,4),(-104,4),(-105,12),(-106,4),(-107,4),(-108,4),(-109,621)):
            if cursor+8+size>end or data[cursor:cursor+8]!=struct.pack('<iI',tag,size):return None
            cursor+=8+size
        if data[cursor:cursor+4]!=MARKER:return None
        return {'end':cursor,'rule_offset':name_end,'opaque_name':name,
                'group_previous_raw':u32(data,name_end+8),
                'section_start_extension':extension==struct.pack('<IIII',1,0,0,1),
                'extra_words':[u32(data,q+60+4*i) for i in range(6)],
                'prefix_code':u32(data,q+4),
                'row_reference_candidate':u32(data,name_end) if u32(data,name_end)==u32(data,name_end+4) and u32(data,name_end)>0 else None,
                'evidence':[evidence(data,q,cursor,'OBS-row-extended-fields-v1')]}
    except (InvalidPackage,IndexError):return None


def counted_table_openings(data,a,b):
    openings=[]
    for rel in occurrences(data[a:b],struct.pack('<i',-108)):
        q=a+rel
        if q-44<a or q+20>b or data[q-44:q]!=sig(0)+b'\0'*36:continue
        nc,nr=u32(data,q+4),u32(data,q+8)
        if 0<nc<=256 and 0<nr<=10000 and u32(data,q+12)==0:
            openings.append({'start':q,'ncols':nc,'nrows':nr})
    return openings


def section_members(data, definition, known):
    """Counted sequence: first 101/205/ID, then marker/101/205/ID."""
    out=[]
    start=definition['name_end'];end=definition['end']
    for rel in occurrences(data[start:end],struct.pack('<II',101,205)):
        a=start+rel
        if a<4:continue
        n=u32(data,a-4)
        if not 1<=n<=1000:continue
        p=a;ids=[]
        for i in range(n):
            if i:
                if data[p:p+4]!=MARKER:break
                p+=4
            if p+12>end or data[p:p+8]!=struct.pack('<II',101,205):break
            vid=u32(data,p+8)
            if vid not in known:break
            ids.append(known[vid]['id']);p+=12
        if len(ids)==n and len(set(ids))==n:
            out.append({'paragraph_ids':ids,'evidence':[evidence(data,a-4,p,'OBS-section-counted-members-v1')]})
    return out[0] if len(out)==1 else None


def decode_layout(data,model):
    byrule={r['compiled_id']:r for r in model['rules']};byvar={v['internal_id']:v for v in model['variables']}
    paragraphs=[];units=model.get('content_units',[])
    for d in model['definitions']:
        if d['class_code']!=21:continue
        # Paired records: opening 111/class/ID and closing 104/class/same ID.
        openings=list(occurrences(data[:d['offset']],sig(111,21,d['internal_id'])))
        if len(openings)!=1:continue
        a=openings[0];b=d['offset']
        if b-a>2_000_000 or any(a<x['offset']<b for x in model['definitions']):continue
        members=[x for x in units if a<x['offset']<b]
        block={'id':d['id'],'name':d['name'],'offset':a,'end':b,'confidence':'TRÈS PROBABLE',
               'content_ids':[x['id'] for x in members], 'evidence':[evidence(data,a,a+16,'OBS-paragraph-open-111-v1'),*d['evidence']]}
        if not decode_counted_tables(data,model,block,members,a,b):
            rows,cols=grid_axis(data,a,b,-109),grid_axis(data,a,b,-103)
            declared=counted_table_openings(data,a,b)
            # A rejected row must not compact the remaining coordinates and
            # silently turn an incomplete grid into a smaller valid table.
            has_styled_rows=any(styled_row_candidate(data,a+rel,b) for rel in occurrences(data[a:b],sig(-109)))
            mismatch=has_styled_rows and len(declared)==1 and (declared[0]['nrows'],declared[0]['ncols'])!=(len(rows),len(cols))
            count_proven=has_styled_rows and len(declared)==1 and not mismatch
            decode_grid(data,model,block,members,[] if mismatch else rows,[] if mismatch else cols,a,b,counted=count_proven)
            if count_proven and block.get('table_id'):
                # Empty trailing rows are valid when their axes and the
                # independent table count agree. No invented text is needed.
                table=next(t for t in model['tables'] if t['id']==block['table_id'])
                table['axis_count_status']='declared_count_matches_axes'
                table['axis_count_evidence']=[evidence(data,declared[0]['start']-44,
                    declared[0]['start']+20,'OBS-styled-grid-count-v2')]
            if mismatch:
                model.setdefault('structure_issues',[]).append({'object_id':block['id'],
                    'reason':'Le nombre d’axes reconnus ne correspond pas au compteur de table ; grille non attribuée.',
                    'declared_rows':declared[0]['nrows'],'recognized_rows':len(rows),
                    'declared_columns':declared[0]['ncols'],'recognized_columns':len(cols),
                    'evidence':[evidence(data,declared[0]['start'],declared[0]['start']+16,'OBS-counted-grid-mismatch-v1')]})
        paragraphs.append(block)
    model['paragraphs']=paragraphs;known={int(x['id'].split(':')[1]):x for x in paragraphs};sections=[]
    for d in model['definitions']:
        if d['class_code']!=206:continue
        members=section_members(data,d,known)
        if members:sections.append({'id':d['id'],'name':d['name'],**members,'confidence':'TRÈS PROBABLE'})
    model['document_sections']=sections
    ordered=[p for s in sections for p in s['paragraph_ids']];model['document_paragraph_ids']=list(dict.fromkeys(ordered))
    main=set(ordered);model['document_content_ids']=[u['id'] for u in units if u['parent_id'] in main]
    model['document_rule_ids']=sorted(r['compiled_id'] for r in model['rules'] if any(x.get('paragraph_id') in main for x in r.get('associations',[])))
    model['blocks']=paragraphs
    for unknown in model['unknowns']:
        if unknown['code']=='ORDER':unknown['detail']='Ordre des paragraphes de sections et coordonnées de cellules décodés lorsque leurs structures sont validées ; pagination et frontières Pxx éditoriales non établies.'
        if unknown['code']=='TABLES':unknown['detail']='Grilles, répétitions et étendues horizontales de cellules décodées uniquement pour les profils bornés reconnus ; autres fusions, débordements et politiques sur tableaux de longueurs différentes non interprétés.'
        if unknown['code']=='SCOPE':unknown['detail']='Règles de ligne rattachées par le record de ligne ; listes de règles internes rattachées aux textes, mais plages de caractères non décodées.'


def decode_grid(data,model,block,members,rows,cols,a,b,grid_id=None,counted=False,child_cells=None):
    byrule={r['compiled_id']:r for r in model['rules']};byvar={v['internal_id']:v for v in model['variables']}
    cells=list(child_cells or [])
    for i,item in enumerate(members):
        item['parent_id']=block['id'];item['parent_evidence']=block['evidence'];item['parent_offset']=a
        stop=members[i+1]['offset'] if i+1<len(members) else b
        item['decode_end']=stop
        # Unique coordinate trailer before next decoded content. Multiple trailers -> no assertion.
        candidates=[]
        for rel in occurrences(data[item['evidence'][0]['offset_end']:stop],sig(-105)):
            p=item['evidence'][0]['offset_end']+rel
            if p+16>stop:continue
            col,row=u32(data,p+8),u32(data,p+12)
            if col<len(cols) and row<len(rows):candidates.append((p,col,row))
        if not candidates:continue
        # Later blank cells may occur before next text: accept first only if text's immediate
        # style record closes at that trailer (100 record in same bounded suffix).
        p,col,row=candidates[0]
        styles=[item['evidence'][0]['offset_end']+x for x in occurrences(data[item['evidence'][0]['offset_end']:p],MARKER)]
        styles=[x for x in styles if x+24<=p and 0<(u32(data,x+4)&0xffff)<4096 and u32(data,x+12)==0x80000000]
        if not styles:continue
        cell={'content_id':item['id'],'column':col,'row':row,'offset':p,
              'evidence':[evidence(data,p,p+16,'OBS-cell-coordinate-trailer-v1')]}
        cells.append(cell);item['grid_position']={'row':row,'column':col};item['document_order']=[row,col]
        item['grid_id']=grid_id or 'grid:'+block['id']
        # Counted, redundant inline rule list inside the text style. Does not establish spans.
        style=styles[-1]
        item['style_offset']=style
        item['cell_trailer_offset']=p
        item['inline_rule_ids']=[]
        for at in range(style+16,p-28):
            n=u32(data,at)
            if not 1<=n<=128 or at+8+4*n+24>p or u32(data,at+4)!=n:continue
            ids=[u32(data,at+8+4*j) for j in range(n)]
            if not all(x in byrule for x in ids) or data[at-12:at]!=struct.pack('<III',1,1,0) or data[at+8+4*n:at+8+4*n+24]!=b'\0'*20+struct.pack('<I',5):continue
            item['inline_rule_ids']=ids;item['inline_rule_evidence']=[evidence(data,at,at+8+4*n,'OBS-inline-counted-rule-list-v1')]
            for cid in set(ids):
                byrule[cid].setdefault('associations',[]).append({'kind':'text_inline_span_unknown','content_id':item['id'],'paragraph_id':block['id'],'evidence':item['inline_rule_evidence']})
            break
    # Axis count must agree with populated cell coordinates, not merely the ordinal of a hit.
    if cells and (counted or len(rows)==max(c['row'] for c in cells)+1) and len(cols)>=max(c['column'] for c in cells)+1:
        block['table_id']=grid_id or 'grid:'+block['id']
        for row in rows:
            q=row['properties_offset'];idx=row['index']
            row['content_ids']=[uid for c in cells if c['row']==idx for uid in cell_content_ids(c)]
            row['rule_id']=None;row['repeat']=None
            extended=extended_row_profile(data,row['offset'],b)
            rule_at=extended['rule_offset'] if extended else q+61
            rid=u32(data,rule_at)
            if extended:
                row.update(property_profile='OBS-row-extended-fields-v1',
                           row_type_code=u32(data,q+24),
                           row_type_label=row_type_label(u32(data,q+24)),
                           row_type_status='user_confirmed_code' if u32(data,q+24) in ROW_TYPE_LABELS else 'raw_code_semantics_unvalidated',
                           data_section_status='unresolved',opaque_extended_fields=extended['extra_words'],
                           opaque_section_name=extended['opaque_name'],
                           automation_driver_internal_id=u32(data,q+48) or None,
                           automation_driver_name=byvar.get(u32(data,q+48),{}).get('name'))
                if extended.get('row_reference_candidate'):
                    row['source_rule_reference_candidate']=extended['row_reference_candidate']
                    if extended['row_reference_candidate'] not in byrule:
                        row['rule_reference_status']='no_compiled_rule_function'
                row['evidence'].extend(extended['evidence'])
                # Corroborated automation combinations inside a fully bounded
                # row record. Do not infer a driver from the preceding row.
                automation=[u32(data,q+k) for k in (28,32,36)]
                if row['row_type_code']==1 and extended['group_previous_raw']==1:
                    row['group_with_previous_row']=True
                    row['automation_evidence']=[evidence(data,rule_at+8,rule_at+12,'OBS-row-group-previous-v1')]
                if row['row_type_code']==2 and extended['section_start_extension']:
                    row['first_row_of_table_section']=True
                    row['section_start_evidence']=[evidence(data,rule_at+12,rule_at+28,'OBS-first-row-table-section-v1')]
                if (row['row_type_code'] in (1,2) and automation==[1,1,1]
                    and u32(data,q+40) in (1,4) and u32(data,q+48) in byvar):
                    row.update(break_method='when_variable_value_changes',
                        break_variable_id=byvar[u32(data,q+48)]['id'],
                        break_variable_name=byvar[u32(data,q+48)]['name'],
                        automation_evidence=[evidence(data,q+24,q+52,'OBS-row-section-value-break-v1')])
            if rid in byrule and u32(data,rule_at+4)==rid:
                row['rule_id']=rid;row['rule_evidence']=[evidence(data,rule_at-1,rule_at+8,'OBS-row-rule-duplicate-v2' if extended else 'OBS-row-rule-duplicate-v1')]
                byrule[rid].setdefault('associations',[]).append({'kind':'grid_row','paragraph_id':block['id'],'table_id':block['table_id'],'row':idx,'content_ids':row['content_ids'],'evidence':row['rule_evidence']})
                for u in model['content_units']:
                    if u['id'] in row['content_ids']:
                        u['row_rule_id']=rid
                        if rid not in u.setdefault('row_rule_ids',[]):u['row_rule_ids'].append(rid)
            flags=[u32(data,q+4+j*4) for j in range(12)]
            vid=flags[11]
            repeat_flags=(flags[5:11]==[1,1,1,0,1,99999999] or
                          extended and flags[5:11]==[1,1,1,0,4,99999999])
            if repeat_flags and vid in byvar and byvar[vid]['cardinality']=='Array':
                rep={'id':f"repeat:{block['id']}:{idx}",'axis':'row','table_id':block['table_id'],'row':idx,
                     'driver_internal_id':vid,'driver_name':byvar[vid]['name'],'content_ids':row['content_ids'],
                     'confidence':'TRÈS PROBABLE','confirmed_repeat':True,'offset':q+48,
                     'limitation':'Profil de répétition de ligne corroboré par grille et variable Array ; politiques de longueur/null et débordement non interprétées.',
                     'evidence':[evidence(data,q+24,q+52,'OBS-grid-row-repeat-v2' if extended else 'OBS-grid-row-repeat-v1'),*row['evidence']]}
                row['repeat']=rep['id'];model.setdefault('repetitions',[]).append(rep)
            if extended and row['row_type_code']==1 and not row['repeat']:
                row['repeat_status']='driver_not_resolved_no_inheritance_assumed'
        model['tables'].append({'id':block['table_id'],'paragraph_id':block['id'],'rows':rows,'columns':cols,'cells':cells,'confidence':'TRÈS PROBABLE','evidence':block['evidence']})
    else:
        # Revoke coordinates when the enclosing grid cannot be validated.
        for u in members:
            u.pop('grid_position',None);u.pop('grid_id',None);u.pop('style_offset',None);u.pop('cell_trailer_offset',None);u['document_order']=None


def cell_content_ids(cell):
    return [cell['content_id']] if cell.get('content_id') else cell.get('content_ids',[])


def inspect_cell_spans(data,model):
    for table in model['tables']:
        for cell in table['cells']:
            q=cell['offset'];nc=len(table['columns']);c=cell['column'];r=cell['row']
            # Packed cell property: mode 0, explicit horizontal extent. It is
            # not inferred from neighbouring empty cells or a long caption.
            if q+37>len(data) or data[q+16]!=0 or u32(data,q+17)!=0 or u32(data,q+25)!=0 or u32(data,q+33)!=0:continue
            span=u32(data,q+21)
            if not 1<=span<=nc-c:continue
            if any(x is not cell and x['row']==r and c<x['column']<c+span for x in table['cells']):continue
            cell.update(column_span=span,span_confidence='TRÈS PROBABLE',
                        span_evidence=[evidence(data,q,q+37,'OBS-cell-horizontal-extent-v1')])


def counted_table_containers(data,a,b):
    """Pair counted -108 table headers with independently bounded axis clusters.

    The innermost still-open header is consumed first. Footer and child-cell
    coordinates distinguish nesting from unrelated consecutive tables.
    """
    openings=counted_table_openings(data,a,b)
    if not openings:return []
    axes=sorted([(x['offset'],'row',x) for x in grid_axis(data,a,b,-109)]+[(x['offset'],'column',x) for x in grid_axis(data,a,b,-103)])
    groups=[];current=[]
    for axis in axes:
        if axis[1]=='column' and current and current[-1][1]=='row':groups.append(current);current=[]
        current.append(axis)
    if current:groups.append(current)
    used=set();nodes=[]
    for group in groups:
        cols=[dict(x[2],index=i) for i,x in enumerate(x for x in group if x[1]=='column')]
        rows=[dict(x[2],index=i) for i,x in enumerate(x for x in group if x[1]=='row')]
        if not cols or not rows:continue
        first=cols[0]['offset'];last=rows[-1]['offset']
        extended=extended_row_profile(data,last,b)
        footer=extended['end'] if extended else last+883
        if footer+176>b or data[footer-4:footer]!=MARKER:continue
        # This observed footer value is 29 or 30; it is not a table marker.
        # Keep it opaque, and require all other guards plus matching counts.
        footer_value=u32(data,footer+24)
        if footer_value not in (29,30) or data[footer:footer+48]!=sig(0,1,0,0,60,footer_value,45,0,101,0,0):continue
        # The 30 variant is calibrated here with the complete styled-row
        # profile only; do not widen unrelated legacy container profiles.
        if footer_value==30 and not extended and not any(styled_row_candidate(data,r['offset'],b) for r in rows):continue
        # +60/+64 are layout switches, not invariant container markers.
        # Both combinations occur in bounded FIP/Versement tables. Validate
        # the complete following TLV chain instead of requiring both true.
        if data[footer+48:footer+60]!=sig(0,1):continue
        if u32(data,footer+60) not in ((0,1,2) if extended else (0,1)) or any(u32(data,footer+k) not in (0,1) for k in (64,68,72)):continue
        if data[footer+92:footer+168]!=struct.pack('<19i',-102,4,0,-103,8,0,0,-104,4,0,-105,4,0,-106,0,-107,0,-108,0):continue
        end=footer+168
        if data[end:end+8] not in (sig(-105),sig(0)):continue
        available=[o for o in openings if o['start']<first and o['start'] not in used]
        if not available:continue
        op=available[-1]
        if (op['ncols'],op['nrows'])!=(len(cols),len(rows)):continue
        if any(op['start']<n['start']<first<n['end'] for n in nodes):continue
        used.add(op['start'])
        profile='OBS-counted-table-108-v4' if extended else 'OBS-counted-table-108-v3'
        nodes.append({**op,'end':end,'rows':rows,'columns':cols,'id':f'grid-at:{op["start"]}',
                      'evidence':[evidence(data,op['start']-44,op['start']+20,profile),
                                  evidence(data,first,end,profile)]})
    # Partial pairing is not a safe tree: retain the previous conservative path.
    if len(nodes)!=len(openings):return []
    for node in nodes:
        parents=[n for n in nodes if n['start']<node['start'] and node['end']<n['end']]
        parent=min(parents,key=lambda n:n['end']-n['start']) if parents else None
        node['parent_table_id']=parent['id'] if parent else None
        if parent:
            q=node['end']
            if data[q:q+8]!=sig(-105):return []
            col,row=u32(data,q+8),u32(data,q+12)
            if col>=parent['ncols'] or row>=parent['nrows']:return []
            node['parent_cell']={'row':row,'column':col,'offset':q,
                                 'evidence':[evidence(data,q,q+16,'OBS-nested-table-cell-v1')]}
    return nodes


def decode_counted_tables(data,model,block,members,a,b):
    nodes=counted_table_containers(data,a,b)
    if not nodes:return False
    roots=[n for n in nodes if not n['parent_table_id']]
    rename={n['id']:('grid:'+block['id'] if len(roots)==1 and n is roots[0] else 'grid:'+block['id']+':'+str(n['start'])) for n in nodes}
    for n in nodes:
        n['id']=rename[n['id']]
        if n['parent_table_id']:n['parent_table_id']=rename[n['parent_table_id']]
    owners={u['id']:min((n for n in nodes if n['start']<u['offset']<n['end']),key=lambda n:n['end']-n['start'],default=None) for u in members}
    for i,u in enumerate(members):
        u.update(parent_id=block['id'],parent_evidence=block['evidence'],parent_offset=a,
                 decode_end=members[i+1]['offset'] if i+1<len(members) else b)
    for n in sorted(nodes,key=lambda n:n['end']-n['start']):
        children=[x for x in nodes if x['parent_table_id']==n['id']]
        cc=[]
        for child in children:
            ids=[u['id'] for u in members if child['start']<u['offset']<child['end']]
            cc.append({**child['parent_cell'],'nested_table_id':child['id'],'content_ids':ids})
        direct=[u for u in members if owners[u['id']] is n]
        decode_grid(data,model,block,direct,n['rows'],n['columns'],n['start'],n['end'],n['id'],True,cc)
        t=next((t for t in model['tables'] if t['id']==n['id']),None)
        if t:
            t.update(start=n['start'],end=n['end'],parent_table_id=n['parent_table_id'],
                     parent_cell=n.get('parent_cell'),counted_structure=True)
            t['evidence'].extend(n['evidence'])
    block['table_ids']=[n['id'] for n in roots]
    if len(roots)==1:block['table_id']=roots[0]['id']
    else:block.pop('table_id',None)
    def position(u):
        node=owners[u['id']]
        if node is None:return [u['offset']]
        if not u.get('grid_position'):return [node['start'],999999,u['offset']]
        order=[u['grid_position']['row'],u['grid_position']['column']]
        while node['parent_table_id']:
            order=[node['parent_cell']['row'],node['parent_cell']['column']]+order
            node=next(x for x in nodes if x['id']==node['parent_table_id'])
        return [node['start']]+order
    for u in members:u['document_order']=position(u)
    return True


def inspect_columns(data,model):
    """Inspect every column property envelope, regardless of Repeat presence."""
    byvar={v['internal_id']:v for v in model['variables']}
    for table in model['tables']:
        for col in table['columns']:
            q=col['properties_offset'];raw=[u32(data,q+4*i) for i in range(1,18)]
            col.update(property_inspection='inspected',raw_properties=raw,repeat=None,rule_id=None,
                       targeting_status='non_interpreted',merge_status='non_interpreted',
                       content_ids=[uid for c in table['cells'] if c['column']==col['index'] for uid in cell_content_ids(c)])
            col['evidence'].append(evidence(data,q,q+72,'OBS-column-properties-v1','Champs conservés ; pas de symétrie supposée avec la ligne.'))
            rid=u32(data,q+16)
            # Column-specific bounded property block, not the row rule layout.
            guarded=(u32(data,q+4)==1 and u32(data,q+12)==0 and u32(data,q+20) in (0,1)
                     and u32(data,q+68)==0xffffff9a and u32(data,q+72)==4)
            rule=next((r for r in model['rules'] if r['compiled_id']==rid),None)
            if guarded and rule:
                ev=[evidence(data,q,q+76,'OBS-column-targeting-v2','ID de règle au champ +16 ; option +20 bornée à 0/1.'),*col['evidence']]
                col.update(rule_id=rid,targeting_status='decoded_on_empirical_profile',rule_evidence=ev)
                assoc={'kind':'grid_column','paragraph_id':table['paragraph_id'],'table_id':table['id'],
                       'column':col['index'],'content_ids':col['content_ids'],'evidence':ev,
                       'rule_reference_offset':q+16,'confidence':'TRÈS PROBABLE'}
                rule.setdefault('associations',[]).append(assoc)
                for u in model['content_units']:
                    if u['id'] in col['content_ids']:u['column_rule_id']=rid
            elif guarded and rid==0:col['targeting_status']='no_rule_on_recognized_property'
            vid=u32(data,q+44)
            if (data[q:q+4]==sig() and u32(data,q+36)==2 and u32(data,q+40)==1 and u32(data,q+48)==0 and u32(data,q+52)==1
                    and vid in byvar and byvar[vid]['cardinality']=='Array'):
                r={'id':f"repeat:{table['id']}:column:{col['index']}",'axis':'column','table_id':table['id'],
                   'column':col['index'],'driver_internal_id':vid,'driver_name':byvar[vid]['name'],
                   'content_ids':col['content_ids'],'confidence':'TRÈS PROBABLE','confirmed_repeat':True,'offset':q+44,
                   'evidence':[evidence(data,q+36,q+56,'OBS-column-repeat-v1'),*col['evidence']],
                   'limitation':'Driver sérialisé dans la propriété de colonne. Fusions et comportement des arrays de longueurs différentes non interprétés.'}
                col['repeat']=r['id'];model.setdefault('repetitions',[]).append(r)
            col['repeat_status']='decoded' if col['repeat'] else 'no_repeat_decoded_on_profile'
        table['uninterpreted_properties']=['merges','borders','units','pagination']+(['conditional_column_targeting'] if any(c['targeting_status']=='non_interpreted' for c in table['columns']) else [])


def decode_page_regions(data,model):
    """Direct page ownership for packages without PAR definitions.

    Each column-then-row axis cluster establishes one grid region. Coordinates
    establish order *within* it; region/page order stays explicitly unresolved.
    """
    if any(d['class_code']==21 for d in model['definitions']):return
    regions=[];pages=[];units=model['content_units']
    for d in model['definitions']:
        if d['class_code']!=24:continue
        openings=list(occurrences(data[:d['offset']],sig(111,24,d['internal_id'])))
        if len(openings)!=1:continue
        a=openings[0];b=d['offset']
        if any(a<x['offset']<b for x in model['definitions']):continue
        page={'id':d['id'],'name':d['name'],'offset':a,'end':b,'region_ids':[],
              'evidence':[evidence(data,a,a+16,'OBS-page-open-111-v1'),*d['evidence']]}
        axes=sorted([(x['offset'],'row',x) for x in grid_axis(data,a,b,-109)]+[(x['offset'],'column',x) for x in grid_axis(data,a,b,-103)])
        clusters=[];current={'rows':[],'columns':[]}
        for off,kind,axis in axes:
            if kind=='column' and current['rows']:
                clusters.append(current);current={'rows':[],'columns':[]}
            key='rows' if kind=='row' else 'columns';axis['index']=len(current[key]);current[key].append(axis)
        if current['rows'] and current['columns']:clusters.append(current)
        bound=a
        for cluster in clusters:
            cols=cluster['columns'];rows=cluster['rows'];stop=rows[-1]['offset']+117
            members=[u for u in units if bound<u['offset']<cols[0]['offset']]
            if not members:bound=stop;continue
            rid=f"region:{d['id']}:{cols[0]['offset']}"
            block={'id':rid,'name':d['name']+' / région de grille à '+str(cols[0]['offset']),
                   'offset':bound,'end':stop,'content_ids':[u['id'] for u in members],'page_id':d['id'],
                   'order_status':'grid_coordinates_only_region_order_unknown','confidence':'TRÈS PROBABLE',
                   'evidence':page['evidence']}
            decode_grid(data,model,block,members,rows,cols,bound,stop,'grid:'+rid)
            if block.get('table_id'):
                regions.append(block);page['region_ids'].append(rid)
            else:
                for u in members:
                    u['parent_id']=None;u.pop('decode_end',None)
            bound=stop
        # Preserve page text that has no validated table coordinates.
        free=[u for u in units if a<u['offset']<b and not u.get('parent_id')]
        if free:
            rid='page-unplaced:'+d['id'];block={'id':rid,'name':d['name']+' / objets sans ordre résolu','offset':a,'end':b,
                    'content_ids':[u['id'] for u in free],'page_id':d['id'],'order_status':'unknown','confidence':'HYPOTHÈSE','evidence':page['evidence']}
            for i,u in enumerate(free):u.update(parent_id=rid,parent_evidence=page['evidence'],parent_offset=a,decode_end=free[i+1]['offset'] if i+1<len(free) else b)
            regions.append(block);page['region_ids'].append(rid)
        pages.append(page)
    model['pages']=pages;model['paragraphs'].extend(regions)
    model['document_paragraph_ids']=[r['id'] for r in regions];model['document_content_ids']=[u['id'] for u in units if u.get('parent_id')]
    model['document_rule_ids']=sorted(r['compiled_id'] for r in model['rules'] if r.get('associations'))
    model['structure_issues'].append({'reason':'Ordre entre régions/pages et objets hors pages non décodé. Seul l’ordre de grille à l’intérieur de chaque région est établi.'})
