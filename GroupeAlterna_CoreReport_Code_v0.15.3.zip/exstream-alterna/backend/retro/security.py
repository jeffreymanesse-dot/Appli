import hashlib,hmac,secrets,time
from fastapi import HTTPException,Request
from .config import settings

def signature(text,key=None):return hmac.new((key or settings.signing_key).encode(),text.encode(),hashlib.sha256).hexdigest()
def owner(request:Request):
    if settings.auth_mode=='proxy':
        user=request.headers.get('x-alterna-user','');stamp=request.headers.get('x-alterna-time','');sig=request.headers.get('x-alterna-signature','')
        try:valid_time=abs(time.time()-int(stamp))<60
        except ValueError:valid_time=False
        if not user or len(user)>256 or not valid_time or not hmac.compare_digest(sig,signature(user+'|'+stamp,settings.proxy_key)):
            raise HTTPException(401,'Authentification requise')
        return hashlib.sha256(user.encode()).hexdigest()
    token=request.cookies.get('alterna_dev','')
    try:ident,stamp,sig=token.split('.')
    except ValueError:raise HTTPException(401,'Ouvrez une session de développement')
    if len(ident)!=48 or not stamp.isdigit() or time.time()-int(stamp)>7*86400 or not hmac.compare_digest(sig,signature(ident+'.'+stamp)):
        raise HTTPException(401,'Session expirée')
    return ident

def session_cookie():
    base=secrets.token_hex(24)+'.'+str(int(time.time()))
    return base+'.'+signature(base)

def csrf(request:Request):
    origin=request.headers.get('origin')
    if origin and origin not in settings.allowed_origins:raise HTTPException(403,'Origine non autorisée')
    if request.headers.get('x-alterna-request')!='1':raise HTTPException(403,'En-tête de protection absent')

def download_token(jobid,filename,user,expires):return signature('|'.join((jobid,filename,user,str(expires))))
