"""Cross-output guards on decoded facts, not a claim to decode unknown PUBs."""


def audit_content(model):
    units={u['id']:u for u in model.get('content_units',[])}
    variables={v['internal_id']:v for v in model['variables']}
    main=set(model.get('document_paragraph_ids',[]))
    audit={'profile':'OBS-content-integrity-v1','paragraphs_without_decoded_text':[],
           'unverified_richtext_units':[],'design_sample_tokens':[],
           'presentation_only_content_ids':[],'divergent_content_ids':[]}
    for p in model.get('paragraphs',[]):
        if any(i not in units for i in p['content_ids']):raise ValueError('Missing paragraph content: '+p['id'])
        if p['id'] in main and not any(any(t['text'].strip() for t in units[i]['parts']) for i in p['content_ids']):
            audit['paragraphs_without_decoded_text'].append({'id':p['id'],'name':p['name']})
    for u in units.values():
        rt=u.get('richtext') or u.get('text_structure')
        if u.get('evidence',[{}])[0].get('decoder')=='OBS-content-redundant-length-v1' and not rt:audit['unverified_richtext_units'].append(u['id'])
        for event in (rt or {}).get('variable_events',[]):
            token=u['parts'][event['token_index']];v=variables[event['internal_id']]
            if token['kind']!='variable' or token.get('variable_internal_id')!=v['internal_id'] or token.get('variable_name')!=v['name']:
                raise ValueError('Variable directory / token mismatch: '+u['id'])
            if 'design_value' in token:
                audit['design_sample_tokens'].append({'content_id':u['id'],'token_index':event['token_index'],
                    'variable_internal_id':v['internal_id'],'variable_name':v['name'],
                    'design_value':token['design_value'],'directory_offset':event['directory_offset']})
    for u in model.get('visual',{}).get('content_units',[]):
        if u['id'] not in units:audit['presentation_only_content_ids'].append(u['id'])
        elif u['parts']!=units[u['id']]['parts']:audit['divergent_content_ids'].append(u['id'])
    return audit


def validate_content(model):
    audit=audit_content(model)
    if audit['presentation_only_content_ids'] or audit['divergent_content_ids']:
        raise ValueError('Report / visual content mismatch: '+str(audit['presentation_only_content_ids']+audit['divergent_content_ids']))
    return audit
