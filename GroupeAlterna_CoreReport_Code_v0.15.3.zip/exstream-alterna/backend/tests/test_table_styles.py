"""Controlled PUB edits plus malformed/unknown profiles, with source-independent reads."""
import copy, json, os, struct
from pathlib import Path
import pytest
from retro.binary import MARKER, InvalidPackage
from retro.table_styles import decode_table_styles, measure, shape
from retro.visual_graphics import GraphicsDecoder


def test_source_measurement_is_quantised_and_bounded():
    assert measure(struct.pack('<I',945),0)['cm']==pytest.approx(8.001)
    assert measure(struct.pack('<I',6),0)['pt']==1.44
    with pytest.raises(InvalidPackage):measure(b'\0'*3,0)
    with pytest.raises(InvalidPackage):measure(b'\0'*8,-1)
    with pytest.raises(InvalidPackage):measure(struct.pack('<I',945),0,944)


def test_unknown_shape_and_bad_tail_are_not_rounded():
    raw=bytearray(120);struct.pack_into('<4I',raw,64,99,1,1,0)
    item={'richtext':{'style_offset':30,'rule_list_offset':80},'cell_trailer_offset':100}
    result=shape(raw,item)
    assert result['status']=='uninterpreted' and result['kind'] is None
    struct.pack_into('<I',raw,64,5);assert shape(raw,item)['kind']=='rounded'
    raw[76]=1;assert shape(raw,item)['status']=='uninterpreted'


def test_constraint_width_is_not_given_a_physical_unit():
    data=bytearray(100);data[:8]=MARKER+struct.pack('<i',-103)
    struct.pack_into('<III',data,8,30,0xffffffff,0xffffffff)
    struct.pack_into('<I',data,20,101);data[32:40]=MARKER+struct.pack('<I',101)
    model={'content_units':[],'tables':[{'id':'g','columns':[{'index':0,'offset':0,'raw_dimension':30}],'cells':[]}]}
    assert decode_table_styles(data,model)['tables']['g']['columns'][0]['status']=='decoded'
    struct.pack_into('<I',data,68,3)
    c=decode_table_styles(data,model)['tables']['g']['columns'][0]
    assert c['status']=='uninterpreted' and 'width' not in c


@pytest.fixture(scope='module',params=['Reference','Round','Width','Color','Black','BorderPink'])
def controlled(request):
    from retro.parser import analyze
    root=os.environ.get('PUB_TABLE_CORPUS')
    if not root:pytest.skip('Set PUB_TABLE_CORPUS to the client-owned calibration directory')
    stem='AFR_EPI_NOE_BULLETIN_ADHESION'+('' if request.param=='Reference' else '_'+request.param)+'.pub'
    paths=[p for p in Path(root).rglob(stem) if p.parent.name in ('pub_variants','pub_variants2')]
    assert len(paths)==1,f'Missing or ambiguous controlled fixture: {stem}'
    path=paths[0];model=analyze(path)
    grid=next(t for t in model['tables'] if t['id']=='grid:21:41696')
    yield request.param,path,model,grid


def test_controlled_source_properties(controlled):
    name,path,model,grid=controlled
    style=grid['presentation'];cells=sorted((c for c in style['cells'] if c['row']==0),key=lambda c:c['column'])
    expected=[945,517,591] if name=='Width' else [966,517,690]
    assert [c['width']['raw'] for c in style['columns']]==expected
    assert [c['shape']['kind'] for c in cells]==(['rounded_left','rounded','rounded_right'] if name=='Round' else ['rectangle']*3)
    assert cells[0]['background']['rgb']==('#000000' if name=='Black' else '#00008f')
    assert all(c['shape']['radius_cm'] is None for c in cells)
    pens=[p for c in cells for p in c['borders'] if p['renderable']]
    pink=[p for p in pens if p['color']['rgb']=='#ffb4ce']
    assert pens and all(p['side'] in ('top','right','bottom','left') for p in pens)
    if name=='BorderPink':
        assert len(pink)==1 and pink[0]['side']=='top'
        assert pink[0]['thickness']['cm']==pytest.approx(.0508)
    else:assert not pink


def test_controlled_pdf_emits_the_source_style(controlled,tmp_path):
    import fitz
    from reportlab.platypus import SimpleDocTemplate
    from retro.visual_render import VisualRenderer
    name,path,model,grid=controlled
    renderer=VisualRenderer(model['visual'])
    flows=renderer.visual_table(grid['id'],600,documentary_guides=False)
    file=tmp_path/'isolated_table.pdf'
    SimpleDocTemplate(str(file),pagesize=(700,900)).build(flows)
    doc=fitz.open(file);drawings=doc[0].get_drawings()
    fills=[d for d in drawings if d.get('fill') and d['type'] in ('f','fs')]
    assert len(fills)>=3
    expected=('#000000' if name=='Black' else '#00008f')
    rgb=tuple(int(expected[i:i+2],16)/255 for i in (1,3,5))
    assert any(d['fill']==pytest.approx(rgb) for d in fills)
    left=next(d for d in fills if d['fill']==pytest.approx(rgb))
    assert left['rect'].width==pytest.approx((945 if name=='Width' else 966)*.24,abs=.01)
    pink=[d for d in drawings if d.get('color')==pytest.approx((1,180/255,206/255))]
    if name=='BorderPink':
        assert len(pink)==1 and pink[0]['width']==pytest.approx(1.44)
        assert pink[0]['rect'].y0==pytest.approx(left['rect'].y0,abs=.01)
    else:assert not pink
    if name=='Round':
        assert len(renderer.ESTIMATED_ROUNDS)==3
        assert all(any(i[0]=='c' for i in d['items']) for d in fills[:3])
    else:assert not renderer.ESTIMATED_ROUNDS
    doc.close()


def test_palette_and_guards_follow_bytes_not_fixture_identity(controlled):
    name,path,model,grid=controlled
    if name!='BorderPink':return
    data=bytearray(path.read_bytes());cell=next(c for c in grid['cells'] if c['row']==c['column']==0)
    style=next(c for c in grid['presentation']['cells'] if c['offset']==cell['offset'])
    off=style['background']['palette_offset']+28;data[off:off+3]=bytes((17,34,51))
    modified=copy.deepcopy(model);modified['metadata']['source_name']='renamed.pub';modified['metadata']['sha256']='0'*64
    result=decode_table_styles(data,modified)['tables'][grid['id']]
    first=next(c for c in result['cells'] if c['offset']==cell['offset'])
    assert first['background']['rgb']=='#112233'
    decoder=GraphicsDecoder(data,modified);cg=decoder.cell_graphics(cell)
    assert len(cg['edge_groups'])==4
    data[cg['edge_groups'][0]['offset']+96]=0
    assert GraphicsDecoder(data,modified).cell_graphics(cell)['status']=='uninterpreted'
    truncated=data[:cg['property_offset']+100]
    assert GraphicsDecoder(truncated,{'content_units':[]}).cell_graphics(cell)['status']=='uninterpreted'
