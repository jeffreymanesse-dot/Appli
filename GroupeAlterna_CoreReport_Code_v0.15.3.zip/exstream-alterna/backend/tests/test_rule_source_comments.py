from retro.rules import complete_source, remove_comments, summarize


def test_trailing_block_comment_does_not_hide_balanced_rule_source():
    source='''// Header note
IF outer <> "" THEN
  IF Contains(values, key) = 0 THEN
    EXCLUDE
  ELSE
    INCLUDE
  ENDIF
ELSE
  IF Contains(otherValues, otherKey) = 0 THEN
    EXCLUDE
  ELSE
    INCLUDE
  ENDIF
ENDIF
/*** old implementation is commented out
IF obsolete() THEN INCLUDE ENDIF
***/'''
    assert complete_source(source)
    active=remove_comments(source)
    assert 'obsolete' not in active
    assert summarize(active)['incomplete'] is False


def test_comment_tokens_inside_quoted_strings_are_preserved():
    source='IF message = "https://example/ENDIF" THEN INCLUDE ENDIF /* note */'
    assert complete_source(source)
    assert remove_comments(source).strip().endswith('ENDIF')


def test_unbalanced_active_rule_is_not_promoted():
    assert not complete_source('IF active THEN /* comment */ INCLUDE')
    assert not complete_source('/* IF inactive THEN INCLUDE ENDIF */')
