"""Separated component visits survive projection; DOC boundaries start new pages."""
import copy
from collections import Counter
import pytest
from pypdf import PdfReader
from reportlab.platypus import Flowable
from retro.document_flow import build_document_flow,paragraph_occurrences,validate_document_flow
from retro.visual_render import VisualRenderer
from test_application_order import weblure


def tree_model(members,extra_sections=None,second_document=False):
    sections=[{'id':'206:1','members':[{'target_id':x} for x in members]}]+(extra_sections or [])
    docs=[{'id':'10:1','root_section_ids':['206:1']}]
    if second_document:docs.append({'id':'10:2','root_section_ids':['206:1']})
    m={'documents':docs,'document_sections':sections,'paragraphs':[{'id':p,'name':p} for p in ('21:1','21:2','21:3')],
       'document_paragraph_ids':['21:1','21:2','21:3']}
    m['document_flow']=build_document_flow(m)
    return m


def renderer(m):
    # Isolate projection from graphics decoding; A and C represent JPG/SEG variants.
    r=object.__new__(VisualRenderer);r.MODEL=m;r.PS={p['id']:p for p in m['paragraphs']}
    r.entries_for=lambda pid:[('text',pid)]
    r.unit_fingerprint=lambda pid:'same' if pid in ('21:1','21:3') else 'different'
    return r


@pytest.mark.parametrize('members,expected',[
    (['21:1','21:2','21:1'],['21:1','21:2','21:1']),
    (['21:1','21:2','21:3'],['21:1','21:2','21:3']),
    (['21:1','21:3','21:3'],['21:1']),
    (['21:1','21:999','21:3'],['21:1','21:3']),
])
def test_only_consecutive_equivalent_paragraphs_are_grouped(members,expected):
    m=tree_model(members);before=copy.deepcopy(m)
    actual,removed=renderer(m).projection()
    assert actual==expected and m==before
    assert len({p['occurrence_id'] for p in paragraph_occurrences(m)})==len([p for p in members if p!='21:999'])
    if removed:assert all(x['representative_occurrence_id']==removed[0]['representative_occurrence_id'] for x in removed)


@pytest.mark.parametrize('separator,expected',[(False,['21:1','21:2']),(True,['21:1','21:2','21:3','21:1','21:2'])])
def test_repeated_nested_section_is_preserved_when_separated(separator,expected):
    section={'id':'206:2','members':[{'target_id':'21:1'},{'target_id':'21:2'}]}
    members=['206:2']+(['21:3'] if separator else [])+['206:2']
    m=tree_model(members,[section])
    assert renderer(m).projection()[0]==expected
    assert len(paragraph_occurrences(m))==4+int(separator)


def test_document_boundary_prevents_cross_document_grouping():
    m=tree_model(['21:1'],second_document=True)
    occurrences,_=renderer(m).occurrence_projection()
    assert [p['source_id'] for p in occurrences]==['21:1','21:1']
    assert [p['source_document_id'] for p in occurrences]==['10:1','10:2']


def test_consecutive_empty_variants_keep_existing_grouping():
    m=tree_model(['21:1','21:3','21:2','21:1']);r=renderer(m)
    r.entries_for=lambda pid:[] if pid in ('21:1','21:3') else [('text',pid)]
    assert r.projection()[0]==['21:1','21:2','21:1']


def test_cycle_is_bounded_and_keeps_separator_between_repeated_paragraphs():
    m=tree_model(['21:1','206:1','21:3'])
    assert renderer(m).projection()[0]==['21:1','21:3']


@pytest.mark.parametrize('target',['model','visual'])
def test_occurrence_guard_rejects_missing_repeated_reference(target):
    m=tree_model(['21:1','21:2','21:1']);m['visual']={'document_flow':copy.deepcopy(m['document_flow'])}
    validate_document_flow(m)
    obj=m if target=='model' else m['visual']
    obj['document_flow'][0]['children'][0]['children'].pop()
    with pytest.raises(ValueError):validate_document_flow(m)


def test_weblure_second_table_has_its_own_path_after_beneficiary(weblure):
    occ=paragraph_occurrences(weblure)
    assert len(occ)==54 and len(set(p['source_id'] for p in occ))==53
    pids=[p['source_id'] for p in occ]
    assert pids.count('21:27644')==2
    assert pids[pids.index('21:27813')+1]=='21:27644'
    visits,_=VisualRenderer(weblure['visual']).occurrence_projection()
    assert Counter(p['source_id'] for p in visits)['21:27644']==2
    assert len({p['occurrence_id'] for p in visits})==len(visits)
    assert weblure['document_flow']==weblure['visual']['document_flow']


def test_weblure_pdf_occurrences_and_document_page_boundaries(weblure,tmp_path,monkeypatch):
    from retro.export import export
    events=[]
    class Marker(Flowable):
        def __init__(self,pid,side):
            super().__init__();self.pid=pid;self.side=side;self.width=0;self.height=0
            self.keepWithNext=side=='start'
        def draw(self):events.append((self.pid,self.side,self.canv.getPageNumber()))
    original=VisualRenderer.clean_section
    def trace(self,pid):return [Marker(pid,'start'),*original(self,pid),Marker(pid,'end')]
    monkeypatch.setattr(VisualRenderer,'clean_section',trace)
    paths=export(weblure,tmp_path,chapters=[])
    projection,_=VisualRenderer(weblure['visual']).occurrence_projection()
    starts=[e for e in events if e[1]=='start'];ends=[e for e in events if e[1]=='end']
    assert [e[0] for e in starts]==[p['source_id'] for p in projection]
    for i in range(1,len(projection)):
        if projection[i]['source_document_id']!=projection[i-1]['source_document_id']:
            assert starts[i][2]>ends[i-1][2]
    pages=[''.join(p.extract_text().split()) for p in PdfReader(paths['rapport.pdf']).pages]
    text=''.join(pages);chapter='1.Vuedétaillée'
    body=text.split(chapter,2)[2].split('2.Miseenformedestableaux',1)[0]
    table='PAR_AFR_EPI_WEBLURE_TABLE';benef='PAR_WEBLURE_Simul_Rente_Benef_Nom'
    assert body.count(table)==2
    assert body.index(table)<body.index(benef)<body.index(table,body.index(benef))
    names={p['id']:''.join(p['name'].split()) for p in weblure['paragraphs']}
    body_start=next(i for i,p in enumerate(pages) if chapter in p and names['21:27751'] in p)
    for previous,doc in zip(weblure['documents'],weblure['documents'][1:]):
        last=next(pid for pid in reversed(previous['paragraph_ids']) if pid in names)
        first=next(pid for pid in doc['paragraph_ids'] if pid in names)
        last_page=next(i for i,p in enumerate(pages[body_start:],body_start) if names[last] in p)
        first_page=next(i for i,p in enumerate(pages[body_start:],body_start) if names[first] in p)
        assert first_page>last_page
