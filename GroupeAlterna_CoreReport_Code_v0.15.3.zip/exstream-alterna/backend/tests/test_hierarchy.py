import struct

import pytest
from retro.hierarchy import application_graph, hierarchy_rows
from retro.layout import sig


def application_bytes(ids=(7, 3), selectors=(16, 17), data_file_ids=()):
    name = b'APP_TEST'
    data = bytearray(struct.pack('<III', 104, 1, 42)+bytes([len(name)])+name)
    end = len(data)
    data.extend(struct.pack('<11I', 0, 0, 2, 102, 0, 103, 4, 0, 104, 4, 0))
    data.extend(sig(135))
    data.extend(bytes(162-(len(data)-end)))
    data.extend(struct.pack('<I', len(selectors))+struct.pack('<'+'I'*len(selectors), *selectors))
    data.extend(struct.pack('<I', len(ids))+struct.pack('<'+'I'*len(ids), *ids))
    data.extend(struct.pack('<I',0))  # counted output queue list
    data.extend(struct.pack('<I',len(data_file_ids)))
    if data_file_ids:data.extend(struct.pack('<'+'I'*len(data_file_ids),*data_file_ids))
    return bytes(data)


def definitions():
    return [{'id': f'10:{i}', 'internal_id': i, 'class_code': 10, 'name': f'DOC_{i}'} for i in (3, 7)]


@pytest.mark.parametrize('selectors', [(), (16, 17)])
def test_counted_document_order_not_definition_order(selectors):
    model = {'definitions': definitions()}
    application_graph(application_bytes(selectors=selectors), model)
    assert model['applications'][0]['document_ids'] == ['10:7', '10:3']
    assert [r['name'] for r in hierarchy_rows(model) if r['kind'] == 'Document'] == ['DOC_7', 'DOC_3']
    assert len(model['applications'][0]['evidence']) == 2


@pytest.mark.parametrize('ids', [(7, 999), (7, 7)])
def test_unknown_or_duplicate_document_refs_are_not_invented(ids):
    model = {'definitions': definitions()}
    application_graph(application_bytes(ids=ids), model)
    assert model['applications'][0]['document_ids'] == []
    assert model['applications'][0]['relation_status'] == 'unresolved'


def test_application_data_file_list_is_decoded_after_output_queues():
    model={'definitions':definitions()+[
        {'id':'15:20','internal_id':20,'class_code':15,'name':'DF_INIT'},
        {'id':'2:30','internal_id':30,'class_code':2,'name':'DF_OUQ'}]}
    application_graph(application_bytes(data_file_ids=(20,)),model)
    app=model['applications'][0]
    assert app['document_ids']==['10:7','10:3']
    assert app['data_file_ids']==['15:20']
    assert app['data_file_reference_status']=='counted_references'


def test_repeated_section_instances_cycles_and_unplaced_pages():
    model = {'definitions': definitions()+[
        {'id': '21:1', 'class_code': 21, 'name': 'PAR_1'},
        {'id': '24:9', 'class_code': 24, 'name': 'PAG_INITIAL'}],
        'documents': [{'id': '10:7', 'name': 'DOC_7', 'first_page_id': '24:9', 'root_section_ids': ['206:1', '206:1']}],
        'document_sections': [{'id': '206:1', 'name': 'SEC_TEST', 'members': [
            {'target_id': '21:1', 'ordinal': 0}, {'target_id': '206:1', 'ordinal': 1}]}],
        'page_components': [{'id': '24:10', 'name': 'PAG_UNPLACED'}]}
    rows = hierarchy_rows(model)
    assert [r['name'] for r in rows if r['kind']=='Paragraphe'] == ['PAR_1', 'PAR_1']
    assert sum('Cycle détecté' in r['note'] for r in rows) == 2
    page = next(r for r in rows if r['name']=='PAG_UNPLACED')
    assert page['depth'] == 1 and page['note'] == ''
    section = next(r for r in rows if r['kind']=='Section')
    assert section['depth'] == 1  # Directly under the document, beside its page.
