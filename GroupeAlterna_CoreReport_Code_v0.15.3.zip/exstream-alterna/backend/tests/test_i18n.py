import copy
import io
import json
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import pytest
from pypdf import PdfReader
from retro import jobs
from retro.db import Job,transaction
from retro.i18n import tr,note,use_language,LANGUAGE
from retro.parser import analyze
from retro.render import report
from retro.report_structure import content_markup

def text(raw):return '\n'.join(p.extract_text() for p in PdfReader(io.BytesIO(raw)).pages)

@pytest.mark.parametrize('language',['fr','en'])
@pytest.mark.parametrize('mode',['analyze','compare'])
def test_report_language_survives_worker_refresh_and_download(client,package,language,mode):
    files={'file_a':('Source_française.pub',package)}
    if mode=='compare':files['file_b']=('Deuxième.pub',package)
    r=client.post('/api/jobs',data={'mode':mode,'report_language':language},files=files)
    assert r.status_code==202
    jid=r.json()['id']
    assert client.get('/api/jobs/'+jid).json()['summary']['report_language']==language
    jobs.run_job(jid)
    # Interface language can change while the job keeps its selected PDF language.
    status=client.get('/api/jobs/'+jid,headers={'Accept-Language':'fr' if language=='en' else 'en'}).json()
    assert status['state']=='termine' and status['report_language']==language
    assert status['summary']['report_language']==language
    links=client.post('/api/jobs/'+jid+'/links').json()['links']
    assert len(links)==(5 if mode=='compare' else 2)
    for link in links:
        response=client.get(link['url'],headers={'Accept-Language':'fr' if language=='en' else 'en'})
        assert response.headers['content-language']==language
        rendered=text(response.content)
        if link['name'].startswith('visuel'):
            assert 'Reading this visualisation' not in rendered
            assert 'Lecture de cette visualisation' not in rendered
            assert ('Design view - engine ' if language=='en' else 'Visuel de conception - moteur ') in rendered
        elif link['name']=='comparaison.pdf':
            assert ('Package comparison' if language=='en' else 'Comparaison de packages') in rendered
        else:
            assert ('Technical reverse documentation' if language=='en' else 'Rétro-documentation technique') in rendered
            assert ('Variables and functions' if language=='en' else 'Variables et fonctions') in rendered
            assert 'DF_FIC_TEST_amount' in rendered

def test_legacy_language_and_invalid_language(client,package):
    files={'file_a':('legacy.pub',package)}
    bad=client.post('/api/jobs',data={'mode':'analyze','report_language':'de'},files=files)
    assert bad.status_code==422
    jid=client.post('/api/jobs',data={'mode':'analyze'},files=files).json()['id']
    with transaction()as db:db.get(Job,jid).summary={}
    jobs.run_job(jid)
    assert client.get('/api/jobs/'+jid).json()['report_language']=='fr'

def test_error_language_is_per_request(client):
    url='/api/jobs/'+'f'*48
    assert client.get(url,headers={'Accept-Language':'en'}).json()['detail']=='Job not found'
    assert client.get(url,headers={'Accept-Language':'fr'}).json()['detail']=='Tâche introuvable'

def test_source_text_names_paths_algorithms_and_model_are_never_translated(package,tmp_path):
    source=tmp_path/'Original.pub';source.write_bytes(package);model=analyze(source)
    # Deliberately collide with translation keys: source-origin text must win.
    literal='Nom de la règle | Écritures : | Annuaire des données du flux'
    unit={'id':'source-text','parent_id':'21:1','text':literal,'offset':0,
          'parts':[{'kind':'literal','text':literal,'offset':0}],
          'variable_names':[],'inline_rule_ids':[],'rule_targets':[]}
    model['content_units']=[unit];model['document_content_ids']=['source-text']
    model['paragraphs']=[{'id':'21:1','name':'PAR_Origine_française'}]
    model['document_paragraph_ids']=['21:1'];model['document_rule_ids']=[]
    model['document_calculation_ids']=[];model['document_variable_ids']=[]
    before=copy.deepcopy(model)
    with use_language('en'):assert literal.replace('&','&amp;') in content_markup(unit)
    path=tmp_path/'en.pdf';report(model,path,language='en',chapters=[])
    rendered=text(path.read_bytes())
    assert 'Document reverse documentation' in rendered and 'Detailed view' in rendered
    assert literal in rendered and 'PAR_Origine_française' in rendered
    assert model==before

def test_language_scope_is_parallel_and_resets_after_error():
    from threading import Barrier
    barrier=Barrier(2)
    def run(language):
        with use_language(language):
            barrier.wait()
            return tr('Structure de l’application')
    with ThreadPoolExecutor(max_workers=2)as pool:
        values=list(pool.map(run,['fr','en']))
    assert values==['Structure de l’application','Application structure']
    with pytest.raises(RuntimeError):
        with use_language('en'):raise RuntimeError('controlled')
    assert LANGUAGE.get()=='fr'

@pytest.mark.parametrize('selected',[[],['valuation'],['input_dictionary'],['reconstruction']])
def test_optional_chapter_titles_in_english(package,tmp_path,selected):
    source=tmp_path/'source.pub';source.write_bytes(package);model=analyze(source)
    path=tmp_path/'en.pdf';report(model,path,language='en',chapters=selected)
    rendered=text(path.read_bytes())
    for key,title in [('valuation','Variables and functions'),('input_dictionary','Input data directory'),('reconstruction','Inventory and reconstruction limitations')]:
        assert (title in rendered)==(key in selected)
    assert 'Exstream source' not in rendered
    assert 'IF DF_FIC_TEST_amount > 0 THEN INCLUDE ENDIF' in rendered

def test_catalog_templates_keep_placeholders():
    from string import Formatter
    from retro.i18n import MESSAGES
    def fields(s):return sorted((field,fmt,conversion)for _,field,fmt,conversion in Formatter().parse(s)if field is not None)
    for source,target in MESSAGES.items():assert fields(source)==fields(target),source

def test_diagnostic_offsets_are_preserved():
    with use_language('en'):
        assert note('Opcode de composition non interprété : 37 à 1234')=='Uninterpreted composition opcode: 37 at 1234'
