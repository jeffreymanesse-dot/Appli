import copy
from io import BytesIO
from pathlib import Path
import struct
from zipfile import ZipFile
import pytest

from test_latest_bulletin_package import latest_bulletin
from retro.design_source import source_record, source_available, source_lines, simple_rule
from retro.rule_labels import rule_algorithms
from retro.source_archive import design_archive, original_bytes
from retro.visual_graphics import source_rgb
from retro.object_composition import colour


@pytest.mark.parametrize('source',[
    'Integer count\r\n\r\n// comment\r\nVALUE = count\r\n',
    'String text\nVALUE = "// literal /* intact */"\n',
    '\r\n\t// leading lines\r\nIF A THEN\r\n  INCLUDE\r\nENDIF\n',
    'Resize(array, 0)\r\n// preserve\r\nVALUE = 0\n',
    'VALUE = 0',
])
def test_native_text_fields_accept_any_design_start_and_keep_every_character(source):
    raw=source.encode('cp1252');data=b'\0'*8+struct.pack('<I',len(raw))+raw+b'\0'*8
    assert source_record(data,0,len(data))==(12,source)
    assert source_lines(source)==source.replace('\r\n','\n').split('\n')


@pytest.mark.parametrize('damage',['length','terminator','boundary','identifier'])
def test_source_field_is_bounded_and_not_a_name_or_unframed_script(damage):
    raw=b'VALUE = 1\r\n';data=b'\0'*8+struct.pack('<I',len(raw))+raw+b'\0'*8;end=len(data)
    if damage=='length':data=data[:8]+struct.pack('<I',len(raw)+1)+data[12:]
    elif damage=='terminator':data=data[:-8]+b'\x01'+data[-7:]
    elif damage=='boundary':end=15
    else:
        raw=b'NAMED_FUNCTION';data=b'\0'*8+struct.pack('<I',len(raw))+raw+b'\0'*8;end=len(data)
    assert source_record(data,0,end) is None


def test_no_script_never_means_display_or_translate_compiled_code():
    rule={'variants':[{'compiled_code':'SENTINEL_COMPILED','decoded_expression':'INVENTED_SOURCE'}]}
    assert rule_algorithms(rule)==[('unavailable','Script non disponible dans ce PUB.')]


def test_identical_compiled_occurrence_uses_its_available_native_design_only():
    source='IF X THEN\r\n // intact\r\n INCLUDE\r\nENDIF\r\n'
    rule={'variants':[{'compiled_code':'same'},{'compiled_code':'same','source_expression':source}]}
    assert rule_algorithms(rule)==[('script',source)]


@pytest.mark.parametrize('number,literal',[('R3','true'),('R6','false')])
def test_r3_r6_are_native_parameters_not_fabricated_if_scripts(latest_bulletin,number,literal):
    rule=next(r for r in latest_bulletin['rules'] if r['document_id']==number)
    d=rule['variants'][0]['design_condition']
    assert d['variable_name']=='DF_FIC_SD_NOE_gest_infoClient_citoyenAmericain'
    assert d['operator']=='=' and d['value']==literal
    kind,text=rule_algorithms(rule)[0]
    assert kind=='parameters' and text=='Condition paramétrée (String)\n'+d['variable_name']+' = "'+literal+'"'
    assert not any(word in text for word in ('IF','ELSE','INCLUDE','EXCLUDE','UserLogic'))


@pytest.mark.parametrize('delta,value',[(20,99),(24,0),(28,999999),(41,99)])
def test_unknown_design_comparison_properties_are_not_guessed(latest_bulletin,delta,value):
    rule=next(r for r in latest_bulletin['rules'] if r['document_id']=='R3')['variants'][0]
    h=next(e['offset_start'] for e in rule['evidence'] if e['decoder']=='OBS-rule-header-108-v1')
    data=bytearray((Path(__file__).resolve().parents[4]/'upload/AFR_EPI_NOE_BULLETIN_VERSEMENT.pub').read_bytes())
    struct.pack_into('<I',data,h+delta,value)
    assert simple_rule(bytes(data),h,rule['offset'],{v['internal_id']:v for v in latest_bulletin['variables']}) is None


def test_newly_recovered_functions_keep_native_bytes_and_comments(latest_bulletin):
    for name in ('DF_FCT_pageAttribute_get','DF_FCT_COPY_init','DF_FCT_title_build','DF_FCT_removeAllBlanks'):
        c=next(c for c in latest_bulletin['calculations'] if c.get('definition_name')==name)
        assert source_available(c) and original_bytes(c) is not None
    c=next(c for c in latest_bulletin['calculations'] if c.get('definition_name')=='DF_FCT_title_build')
    assert c['source_expression'].startswith('\r\n// Récupération')


def test_unprintable_character_table_is_preserved_in_the_source_archive(latest_bulletin):
    m=copy.deepcopy(latest_bulletin)
    c=next(c for c in m['calculations'] if c['id']=='function910')
    assert not source_available(c) and b'\x81' in original_bytes(c)
    with ZipFile(BytesIO(design_archive(m))) as z:
        name=next(n for n in z.namelist() if 'function910_' in n)
        assert z.read(name)==original_bytes(c)
        assert all(not z.read(n).startswith((b'_rules[',b'_functions[',b'_formulas[')) for n in z.namelist())
    assert m==latest_bulletin


def test_real_title_and_adviser_use_the_same_blue_as_contract_text(latest_bulletin):
    m=latest_bulletin;graphics=m['visual']['graphics']
    title=next(c for c in m['object_compositions'] if c['paragraph_id']=='21:43432')
    assert next(c for c in title['objects'][0]['commands'] if c['kind']=='text')['color']=='#00008f'
    for uid in ('text:4377124','text:4392715'):
        assert '#00008f' in [c.get('rgb') for c in graphics['units'][uid]['colors']]
    assert all(c['background']['status']=='none' for c in graphics['table_styles']['grid:21:43433']['cells'])
    assert any(c['background'].get('rgb')=='#00008f' for c in graphics['table_styles']['grid:21:43434']['cells'])


def test_graphical_and_rich_text_colour_resolvers_agree_and_reject_unknowns():
    for palette in ({7:{'rgb':'#102030'}},{'7':{'rgb':'#102030'}}):
        for kind,value in ((0,0x8f0000),(50,7),(50,8),(99,7),(0,0x1000000)):
            assert colour(kind,value,palette)==source_rgb(kind,value,palette)
    assert source_rgb(99,7,{}) is None
