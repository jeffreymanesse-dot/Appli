"""Real corpus and corruptions: variables, bounded colour owner and text boxes."""
import copy,os,struct
from pathlib import Path
import pytest
from retro.parser import analyze
from retro.scopes import read_richtext
from retro.binary import InvalidPackage
from retro.text_boxes import text_box_frame
from retro.visual_graphics import GraphicsDecoder
from retro.visual_render import VisualRenderer

@pytest.fixture(scope='module')
def plaisance():
    path=Path(os.environ.get('PUB_PLAISANCE_CP','/nonexistent'))
    if not path.exists():pytest.skip('Client Plaisance CP corpus unavailable')
    return path.read_bytes(),analyze(path)

@pytest.mark.parametrize('uid,width',[('text:5205945',521.52),('text:5379032',368.4)])
def test_dates_conditions_and_frame_are_recovered(plaisance,uid,width):
    data,m=plaisance;u=next(x for x in m['content_units'] if x['id']==uid)
    assert not u.get('scope_decode_issue')
    assert [t['rule_id'] for t in u['rule_targets']]==[700080,700080,700081]
    assert [t['text_paragraph_index'] for t in u['rule_targets']]==[0,1,2]
    assert [p.get('variable_internal_id') for p in u['parts'] if p['kind']=='variable']==[101222,101224,101222,101223]
    assert all(not p['text'].endswith(' d') for p in u['parts'])
    g=m['visual']['graphics'];obj=g['text_boxes'][uid]
    assert obj['kind']=='text_box' and obj['frame']['scope']=='text_box'
    assert obj['width_pt']==pytest.approx(width)
    assert obj['frame']['color']['rgb']=='#00008f'
    assert obj['frame']['thickness']['pt']==pytest.approx(.24)
    assert g['backgrounds'][uid]['fill']['rgb']=='#b2b2dd'
    assert g['units'][uid]['status']=='decoded'
    assert g['units'][uid]['fonts'][0]['bold'] is True
    assert g['units'][uid]['fonts'][0]['size']==10
    r=VisualRenderer(m['visual']);flows=r.decorated_text(uid,508)
    assert flows[0].__class__.__name__=='Table'
    text=''.join(getattr(p,'text','') for p in r.text_flow(uid,500))
    assert 'dateDebutContrat_Gras_ddmmmyyyy' in text and '______' not in text
    assert text.count('[</font>')==3

@pytest.mark.parametrize('field', ['directory','colour','slot','frame_role','frame_geometry'])
def test_malformed_structure_is_not_silently_accepted(plaisance,field):
    data,m=plaisance;u=next(x for x in m['content_units'] if x['id']=='text:5379032');b=bytearray(data)
    vs={v['internal_id']:v for v in m['variables']};rs={r['compiled_id']:r for r in m['rules']}
    rt=u['richtext'];obj=m['visual']['graphics']['text_boxes'][u['id']]
    if field.startswith('frame'):
        off=obj['object_offset']+(241 if field=='frame_role' else 36)
        struct.pack_into('<I',b,off,999)
        assert text_box_frame(bytes(b),u,GraphicsDecoder(bytes(b),m)) is None
    else:
        off={'directory':rt['variable_events'][0]['directory_offset'], 'colour':rt['outer_offset']+56,
             'slot':rt['paragraphs'][0]['properties_offset']+56}[field]
        struct.pack_into('<I',b,off,999999)
        with pytest.raises(InvalidPackage):read_richtext(bytes(b),u,vs,rs)

def test_name_independence_and_plaintext_d_preservation(plaisance):
    data,m=plaisance;u=copy.deepcopy(next(x for x in m['content_units'] if x['id']=='text:5379032'))
    vs={v['internal_id']:{**v,'name':'Other_'+str(v['internal_id'])} for v in m['variables']}
    rs={r['compiled_id']:r for r in m['rules']}
    # Serialized source parts carry placeholders, so names are supplied by the directory.
    rich=read_richtext(data,u,vs,rs)
    assert [p['variable_name'] for p in rich['decoded_parts'] if p['kind']=='variable']==['Other_101222','Other_101224','Other_101222','Other_101223']
    assert 'date d’échéance' in ''.join(p['text'] for p in rich['decoded_parts'])
