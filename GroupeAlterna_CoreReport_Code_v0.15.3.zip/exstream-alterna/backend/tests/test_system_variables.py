from copy import deepcopy
import struct

import pytest
from retro.parser import analyze
from retro.system_variables import CATALOG, SOURCE, enrich_system_variables
from retro.report_system_variables import system_variable_lines, append_system_catalog
from retro.i18n import use_language


def model_for(*names):
    return {'variables': [{'id': f'35:{i}', 'internal_id': i, 'name': n,
            'source': 'unknown', 'origin_class': 'system' if n.startswith('SYS_') else 'unresolved',
            'sample_value': None, 'valuation_sites': []} for i, n in enumerate(names)],
            'document_variable_ids': ['35:0']}


def test_catalog_rows_are_not_all_words_mentioned_in_pdf():
    assert len(CATALOG) == 34
    assert sum(len(e['source_occurrences']) for e in CATALOG.values()) == 64
    assert 'SYS_PageTotalPrintedInDocument' not in CATALOG
    assert CATALOG['SYS_PageTotalPrinted']['families'] == ['communication_design', 'counting_numbering']
    assert 'counting_numbering' in CATALOG['SYS_PageInQueue']['families']
    assert 'counting_numbering' in CATALOG['SYS_SheetInQueue']['families']
    assert SOURCE['sha256'] == '7ec138d7ce81b5157aa48f7a05bacbba636aed0c89fcac64e22a12fc33190d18'


@pytest.mark.parametrize('name', sorted(CATALOG))
def test_every_entry_has_exact_match_families_and_page_provenance(name):
    m = model_for(name)
    enrich_system_variables(m)
    detail = m['variables'][0]['system_variable_details']
    assert detail['status'] == 'documented'
    assert detail['runtime_value_status'] == 'not_evaluated'
    assert detail['description_fr'] and detail['description_en']
    assert {x['family'] for x in detail['source_occurrences']} == set(detail['families'])
    assert all(1 <= x['pdf_page'] <= 5 and x['printed_page'] == f"3-{19+x['pdf_page']}" for x in detail['source_occurrences'])


@pytest.mark.parametrize('name,status', [
    ('SYS_PageTotalPrintedInDocument', 'mention_only'),
    ('SYS_UnknownToThisGuide', 'not_listed'),
    ('SYS_pagePrintedValue', 'not_listed'),
    ('sys_PagePrintedValue', None), ('DF_SYS_PagePrintedValue', None),
])
def test_prefix_convention_is_not_catalog_confirmation(name, status):
    m = model_for(name)
    enrich_system_variables(m)
    detail = m['variables'][0].get('system_variable_details')
    assert (detail['status'] if detail else None) == status
    assert not m['system_variable_catalog']['present_in_package_names']


def test_does_not_create_variables_or_rewrite_samples_mappings_or_assignments():
    m = model_for('SYS_DateCurrent', 'SYS_TableRow', 'DF_FIC_TEST_amount')
    m['variables'][0].update(source='mapped_reference_candidate', sample_value='03/08/2008',
        valuation_sites=[{'owner': 'existing_function', 'expression': 'existing_expression'}])
    original = deepcopy(m)
    enrich_system_variables(m)
    assert len(m['variables']) == len(original['variables'])
    for before, after in zip(original['variables'], m['variables']):
        assert all(after[key] == value for key, value in before.items())
    assert m['system_variable_catalog']['present_in_document_names'] == ['SYS_DateCurrent']
    assert m['variables'][0]['system_variable_details']['runtime_value_status'] == 'not_evaluated'
    assert 'non composées' in m['variables'][1]['system_variable_details']['description_fr']
    copy = deepcopy(m)
    enrich_system_variables(m)
    assert m == copy


def test_duplicate_names_preserve_ids_and_counts_and_do_not_share_mutable_catalog():
    m = model_for('SYS_TableRow', 'SYS_TableRow')
    enrich_system_variables(m)
    assert len(m['system_variable_catalog']['present_in_package_names']) == 1
    assert len(m['system_variable_catalog']['present_in_package_variable_ids']) == 2
    m['variables'][0]['system_variable_details']['families'].clear()
    assert m['variables'][1]['system_variable_details']['families'] == CATALOG['SYS_TableRow']['families']


def test_pdf_language_and_uncertainty_are_presentation_only():
    m = model_for('SYS_LanguageDefault', 'SYS_Unknown', 'SYS_PageTotalPrintedInDocument')
    enrich_system_variables(m)
    original = deepcopy(m)
    for lang, expected in [('fr', 'locale'), ('en', 'locale')]:
        with use_language(lang):
            assert expected in ' '.join(system_variable_lines(m['variables'][0]))
            rows = []
            append_system_catalog(m, lambda *args: rows.append(args))
            output = ' '.join(row[0] for row in rows)
            assert '34' in output and '64' in output
            assert ('non confirmé' if lang == 'fr' else 'unconfirmed') in output
            assert 'SYS_Unknown' in output
    assert m == original


def test_reference_is_integrated_in_real_parser_pipeline(package, tmp_path):
    old = b'DF_FIC_TEST_amount'; new = b'SYS_PagePrintedValue'
    raw = bytearray(package.replace(bytes([len(old)]) + old, bytes([len(new)]) + new))
    struct.pack_into('<I', raw, 24, len(raw) - 12)
    path = tmp_path / 'system.pub'; path.write_bytes(raw)
    m = analyze(path)
    v = next(v for v in m['variables'] if v['name'] == new.decode())
    assert v['origin_class'] == 'system'
    assert v['system_variable_details']['status'] == 'documented'
    assert v['sample_value'] is None
    assert m['system_variable_catalog']['present_in_package_names'] == [new.decode()]
