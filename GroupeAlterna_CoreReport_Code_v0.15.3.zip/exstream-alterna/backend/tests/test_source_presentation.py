"""Source geometry and typography regression with byte mutations and PDF checks."""
import copy,struct
from pathlib import Path
import pytest
from test_fip_table_rows import fip
from test_versement_regression import versement
from retro.table_styles import decode_table_styles,axis_borders
from retro.table_anchors import decode_table_anchors
from retro.visual_graphics import GraphicsDecoder
from retro.visual_render import VisualRenderer
from retro.text_styles import paragraph_styles
from retro.layout import counted_table_containers


def formula(model):
    return next(t for t in model['tables'] if t['paragraph_id']=='21:42707')


@pytest.mark.parametrize('pid,index,position', [('21:42707',2,311),('21:42706',4,610)])
def test_fip_table_anchor_is_inside_the_text_owner(fip,pid,index,position):
    data,model,_=fip
    for current in (model,model['visual']):
        t=next(t for t in current['tables'] if t['paragraph_id']==pid)
        a=t['inline_anchor'];owner=next(u for u in current['content_units'] if u['id']==a['content_id'])
        assert a['paragraph_index']==index and a['design_position']==position
        para=owner['richtext']['paragraphs'][index]
        assert para['start']==para['end']==position
        assert data[para['offset']:para['offset']+24]==struct.pack('<6i',-244,index,-251,0,-106,0)
        assert not owner.get('grid_id')


def test_bad_anchor_opcode_does_not_move_a_table(fip):
    data,model,_=fip;m=copy.deepcopy(model);t=formula(m);a=t.pop('inline_anchor')
    u=next(u for u in m['content_units'] if u['id']==a['content_id']);p=u['richtext']['paragraphs'][a['paragraph_index']]['offset']
    damaged=bytearray(data);struct.pack_into('<i',damaged,p+8,-250)
    decode_table_anchors(damaged,m)
    assert 'inline_anchor' not in t


@pytest.mark.parametrize('delta,value',[(60,2),(96,5),(108,7),(164,1)])
def test_footer_layout_switches_keep_full_structural_guards(fip,delta,value):
    data,model,_=fip;t=formula(model);p=next(p for p in model['paragraphs']if p['id']==t['paragraph_id'])
    assert t['counted_structure']
    assert len(counted_table_containers(data,p['offset'],p['end']))==1
    footer=t['end']-168;damaged=bytearray(data);struct.pack_into('<I',damaged,footer+delta,value)
    assert not counted_table_containers(damaged,p['offset'],p['end'])


def test_axis_pens_and_cell_pens_have_independent_sources(fip):
    data,model,_=fip;t=formula(model);style=t['presentation']
    row=style['rows'][1]['borders']
    assert {p['side']for p in row if p['renderable']}=={'top','bottom'}
    assert all(p['color']['rgb']=='#00008f' and p['thickness']['pt']==pytest.approx(.48) for p in row)
    cell=next(c for c in style['cells']if c['row']==1 and c['column']==1)
    assert {p['scope']for p in cell['effective_borders'] if p['renderable']}=={'cell'}
    assert next(p for p in cell['effective_borders']if p['side']=='left')['color']['rgb']=='#00008f'
    # An unknown pattern cannot silently be rendered as solid.
    damaged=bytearray(data);struct.pack_into('<I',damaged,t['rows'][1]['offset']+12,99)
    pens=axis_borders(damaged,GraphicsDecoder(damaged,model),t['rows'][1],'row',t['end'])
    assert not pens[0]['renderable'] and pens[0]['effective_status']=='uninterpreted'


def test_versement_has_four_sided_cell_pens_and_column_separator(versement):
    model=versement;ps={p['id']:p['name']for p in model['paragraphs']}
    detail=next(t for t in model['tables']if ps[t['paragraph_id']].endswith('_DETAIL_VERSEMENT'))
    assert detail['counted_structure']
    cell=next(c for c in detail['presentation']['cells']if c['row']==4 and c['column']==1)
    assert {p['side']for p in cell['effective_borders']if p['renderable']}=={'top','bottom','left','right'}
    situation=next(t for t in model['tables']if ps[t['paragraph_id']].endswith('_VOTRE_SITUATION'))
    pen=next(p for p in situation['presentation']['columns'][0]['borders']if p['side']=='right')
    assert pen['renderable'] and pen['color']['rgb']=='#00008f'
    width=situation['presentation']['columns'][0]
    assert width['status']=='decoded'
    assert width['width']['pt']==pytest.approx(situation['columns'][0]['raw_dimension']*.24)


def test_empty_cells_keep_their_borders_without_invented_text(versement):
    visual=versement['visual'];grid=next(t for t in visual['tables']if len(t['columns'])==6)
    cell=next(c for c in grid['cells']if c['row']==4 and c['column']==2)
    unit=next(u for u in visual['content_units']if u['id']==cell['content_id'])
    assert not unit['parts'] and unit['richtext']['design_length']==0
    styles=visual['graphics']['table_styles'][grid['id']]
    decoded=next(c for c in styles['cells']if c['offset']==cell['offset'])
    assert any(p['renderable'] for p in decoded['effective_borders'])
    renderer=VisualRenderer(visual)
    flows=renderer.text_flow(unit['id'],100)
    assert all(not getattr(f,'text',None) for f in flows)


def test_font_resources_keep_bold_italic_and_unknown_decoration():
    name=b'Example Italic';raw=struct.pack('<III',134,123,0)+bytes([len(name)])+name+struct.pack('<9I',100,300,1252,2,1,1,7,0,0)
    font=GraphicsDecoder(raw,{}) .fonts['123']
    assert font['bold'] and font['italic']
    assert font['decoration_raw']==[7,0,0] and font['decoration_status']=='not_calibrated'
    assert 'underline' not in font


def test_visual_deduplication_includes_anchored_table_and_inline_formatting(fip):
    _,model,_=fip;v=copy.deepcopy(model['visual']);renderer=VisualRenderer(v)
    t=formula(v);uid=t['inline_anchor']['content_id'];original=renderer.unit_fingerprint(uid)
    cell=next(c for c in t['cells'] if c.get('content_id'))
    renderer.UNITS[cell['content_id']]['parts'][0]['text']='Changed guarantee'
    assert renderer.unit_fingerprint(uid)!=original
    before=renderer.unit_fingerprint(uid)
    renderer.G['units'][uid]['inline_breaks'].append({'design_position':1})
    assert renderer.unit_fingerprint(uid)!=before
    before=renderer.unit_fingerprint(uid)
    renderer.G['units'][uid]['superscript_spans'].append({'start':2,'end':3})
    assert renderer.unit_fingerprint(uid)!=before


def test_empty_narrow_gutter_keeps_source_width_without_negative_padding(versement):
    v=copy.deepcopy(versement['visual']);renderer=VisualRenderer(v)
    grid=next(t for t in v['tables'] if len(t['columns'])==6)
    renderer.TABLE_STYLES[grid['id']]['columns'][0]['width']['pt']=1
    renderer.TABLE_STYLES[grid['id']]['columns'][0]['status']='decoded'
    flows=renderer.visual_table(grid['id'],491,documentary_guides=False)
    assert renderer.height_of(flows,491)>0
    assert renderer.TABLE_LAYOUTS[-1]['display_widths_pt'][0]<=1


@pytest.mark.parametrize('text,alignment', [('Garantie','center'),('Votre choix','right'),('Capital Obsèques','left')])
def test_actual_paragraph_alignment_and_typography(fip,text,alignment):
    _,model,_=fip;v=model['visual'];u=next(u for u in v['content_units']if u['parent_id']=='21:42707' and u['text'].startswith(text))
    gx=v['graphics']['units'][u['id']]
    assert gx['paragraphs'][0]['alignment']==alignment
    renderer=VisualRenderer(v);flow=renderer.text_flow(u['id'],140)[0]
    assert flow.style.alignment=={'left':0,'center':1,'right':2}[alignment]
    assert any(r['render_font']=='SSPBold' and r['size']==10 and r['text'].strip() for r in renderer.RUNS)


def test_alignment_mutation_is_bounded_and_justification_is_present(fip):
    data,model,_=fip;v=model['visual'];u=next(u for u in v['content_units']if u['text'].startswith('Votre choix') and u['parent_id']=='21:42707')
    style=paragraph_styles(data,u)[0];raw=bytearray(data)
    struct.pack_into('<I',raw,style['prefix_offset']+52,99)
    assert paragraph_styles(raw,u)[0]['alignment'] is None
    assert any(p.get('alignment')=='justify' for gx in v['graphics']['units'].values()for p in gx.get('paragraphs',[]))


@pytest.mark.parametrize('kind',['report','visual'])
def test_pdfs_place_table_between_introduction_and_following_text(fip,tmp_path,kind):
    import fitz
    _,model,_=fip;path=tmp_path/(kind+'.pdf')
    if kind=='report':
        from retro.render import report
        report(model,path,chapters=[])
    else:VisualRenderer(model['visual']).render(path)
    with fitz.open(path) as pdf:
        text='\n'.join(p.get_text()for p in pdf)
        assert text.index('Pour répondre à vos besoins')<text.index('Garantie')<text.index('Vous avez choisi')
        page=next(p for p in pdf if 'Garantie' in p.get_text() and 'Durée de cotisation' in p.get_text())
        assert 'Pour répondre à vos besoins' in page.get_text()
        strokes=[d for d in page.get_drawings()if d.get('color') and abs(d['color'][2]-143/255)<.002]
        assert any(abs(d['rect'].width)<.01 and d['rect'].height>10 for d in strokes)
        assert any(d['rect'].width>80 and abs(d['rect'].height)<.01 for d in strokes)
        spans=[s for b in page.get_text('dict')['blocks']if 'lines'in b for l in b['lines']for s in l['spans']]
        assert any('Garantie' in s['text'] and s['color']==0xfefefe and 'Bold' in s['font'] for s in spans)
