import copy,struct
import pytest
from test_plaisance_blocks import plaisance
from retro.visual_render import VisualRenderer
from retro.visual_graphics import GraphicsDecoder
from retro.text_styles import paragraph_styles

UID='text:4736352'

def test_intro_bullets_indents_and_leading(plaisance):
    _,m=plaisance;g=m['visual']['graphics']['units'][UID]
    assert [p['bullet']['status'] for p in g['paragraphs']]==['none','decoded','decoded','none','none']
    assert all(p.get('leading_pt')==pytest.approx(12.48) for p in g['paragraphs'])
    r=VisualRenderer(m['visual']);ps=r.text_flow(UID,360)
    assert [p.bulletText for p in ps]==[None,'▪','▪',None,None]
    assert ps[1].style.leftIndent==pytest.approx(10.08)
    assert all(p.style.fontSize==10 for p in ps)
    assert all(x['font']=='Source Sans Pro Regular' and x['size']==10 for x in r.RUNS)
    assert 'DF_FIC_CD_PRD_cgId' in ps[1].text

@pytest.mark.parametrize('delta,value',[(80,99),(96,168),(88,2)])
def test_unknown_bullet_is_not_guessed(plaisance,delta,value):
    data,m=plaisance;u=next(u for u in m['content_units'] if u['id']==UID);g=m['visual']['graphics']['units'][UID]
    b=bytearray(data);p=g['paragraphs'][1]['prefix_offset']
    if delta==96:b[p+96]=value
    else:struct.pack_into('<I',b,p+delta,value)
    result=paragraph_styles(bytes(b),u,g['fonts'])
    assert result[1].get('bullet',{}).get('status')!='decoded'

def test_source_widths_and_minimum_heights(plaisance):
    _,m=plaisance;r=VisualRenderer(m['visual']);tid=next(t['id'] for t in m['tables'] if t['paragraph_id']=='21:37293')
    flows=r.visual_table(tid,508,documentary_guides=False)
    assert r.TABLE_LAYOUTS[-1]['display_widths_pt']==[360]
    for flow,minimum in zip(flows,[191,411,284]):
        w,h=flow.wrap(508,10000)
        assert w==pytest.approx(360) and h>=minimum*.24
    box=r.decorated_text('text:5379032',508)[0]
    w,h=box.wrap(508,10000)
    assert w==pytest.approx(368.4) and h>=154.08


def test_corrupt_native_line_bounds_do_not_set_leading(plaisance):
    data,m=plaisance;u=next(u for u in m['content_units'] if u['id']==UID);g=m['visual']['graphics']['units'][UID]
    b=bytearray(data);struct.pack_into('<I',b,u['richtext']['line_table_offset']+4,0xffffffff)
    result=paragraph_styles(bytes(b),u,g['fonts'])
    assert all('leading_pt' not in p for p in result)
    assert result[1]['bullet']['glyph']=='▪'


def test_anchored_child_height_is_not_reserved_twice(plaisance):
    _,m=plaisance;r=VisualRenderer(m['visual'])
    uid='text:5375881'
    assert any(c['opcode']==-251 for c in r.UNITS[uid]['richtext']['opaque_controls'])
    flows=r.decorated_text(uid,508)
    assert r.height_of(flows,508)<50
