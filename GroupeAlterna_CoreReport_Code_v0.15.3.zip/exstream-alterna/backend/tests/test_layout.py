import struct
from retro.layout import decode_layout,grid_axis,section_members,sig


def axis(tag,rule=0,driver=0):
    b=bytearray(sig(tag,120,-1,-1,101,0,0)+sig(101,0,0))
    props=bytearray(sig(1,1,1,0,0,1 if driver else 0,1 if driver else 0,1,0,1,99999999 if driver else 0,driver))
    props.extend(b'\0'*(69-len(props)))
    struct.pack_into('<II',props,61,rule,rule)
    return bytes(b+props)


def test_axis_rejects_bare_tag_and_truncation():
    b=axis(-109)
    assert len(grid_axis(b,0,len(b),-109))==1
    assert grid_axis(b,0,60,-109)==[]
    assert grid_axis(sig(-109)+b'x'*120,0,124,-109)==[]


def test_section_uses_counted_references_not_names():
    b=struct.pack('<IIII',2,101,205,4)+sig(101,205,7)
    d={'name_end':0,'end':len(b)};known={4:{'id':'21:4'},7:{'id':'21:7'}}
    assert section_members(b,d,known)['paragraph_ids']==['21:4','21:7']
    assert section_members(b[:-2],{'name_end':0,'end':len(b)-2},known) is None
    assert section_members(b,d,{4:known[4]}) is None


def test_pairing_grid_rule_and_repeat_survive_binary_order():
    # Cell serialized at column 1 before column 0. Coordinates determine order, not bytes.
    b=bytearray(sig(111,21,42));units=[]
    for col in (1,0):
        start=len(b);b.extend(b'TEXT')
        units.append({'id':str(col),'offset':start,'parent_id':None,'evidence':[{'offset_end':len(b)}]})
        b.extend(sig(100,0,0x80000000)+b'\0'*24+sig(-105,col,0)+b'\0'*4)
    b.extend(axis(-103)+axis(-103)+axis(-109,rule=99,driver=123))
    end=len(b);b.extend(sig(104,21,42)+b'\x03PAR')
    model={'rules':[{'compiled_id':99}],'variables':[{'internal_id':123,'name':'TEST_ARRAY','cardinality':'Array'}],
           'definitions':[{'id':'21:42','internal_id':42,'class_code':21,'name':'PAR','offset':end,'evidence':[{'offset_start':end,'offset_end':len(b)}]}],
           'content_units':units,'tables':[],'unknowns':[]}
    decode_layout(bytes(b),model)
    assert units[0]['document_order']==[0,1] and units[1]['document_order']==[0,0]
    assert all(x['parent_id']=='21:42' and x['row_rule_id']==99 for x in units)
    assert model['repetitions'][0]['driver_internal_id']==123
    assert model['rules'][0]['associations'][0]['kind']=='grid_row'
    # Mismatched closing identity must not inherit the preceding paragraph's content.
    model['definitions'][0]['internal_id']=43
    decode_layout(bytes(b),model)
    assert model['paragraphs']==[]


def test_packed_style_does_not_drop_cell():
    b=bytearray(sig(111,21,42));start=len(b);b.extend(b'TEXT');endtext=len(b)
    b.extend(sig(0x260064,0x3000b,0x80000000)+b'\0'*24+sig(-105,0,0)+b'\0'*4)
    b.extend(axis(-103)+axis(-109));end=len(b);b.extend(sig(104,21,42))
    model={'rules':[],'variables':[],'definitions':[{'id':'21:42','internal_id':42,'class_code':21,'name':'PAR','offset':end,'evidence':[]}],
           'content_units':[{'id':'x','offset':start,'evidence':[{'offset_end':endtext}]}],'tables':[],'unknowns':[]}
    decode_layout(bytes(b),model)
    assert model['content_units'][0]['grid_position']=={'row':0,'column':0}


def test_reference_trigger_and_calls_are_lexical_not_execution():
    from retro.provenance import enrich_provenance
    code="if (x) UserLogic.callSubfunction('function9'); UserLogic.callBuiltin('TRIGGER', \"REF\", 0);"
    model={'calculations':[{'id':'function1','source_code':code,'offset':0}],
           'variables':[{'id':'35:1','name':'OUT'}],'mappings':[{'id':'map:1','source_classification':'reference_candidate','variable_id':'35:1','data_source_name':'REF'}],
           'content_units':[{'id':'x','variable_names':['OUT']}],'document_content_ids':['x']}
    enrich_provenance(code.encode(),model)
    assert model['calculations'][0]['calls'][0]['callee_id']=='function9'
    assert model['reference_chains'][0]['provider_calculation_ids']==['function1']


def test_axis_accepts_each_observed_sentinel_without_zero_font_assumption():
    import struct
    for index in (12,16):
        b=bytearray(axis(-103));struct.pack_into('<I',b,index,0)
        struct.pack_into('<II',b,24,50,51)
        assert len(grid_axis(bytes(b),0,len(b),-103))==1
    struct.pack_into('<II',b,12,0,0)
    assert grid_axis(bytes(b),0,len(b),-103)==[]
