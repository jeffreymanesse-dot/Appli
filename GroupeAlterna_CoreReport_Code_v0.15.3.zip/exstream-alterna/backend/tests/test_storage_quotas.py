"""Capacity depends on retained bytes, not lifetime worst-case reservations."""
import hashlib
import time
from dataclasses import replace
from pathlib import Path
import pytest
from retro import api, jobs
from retro.db import Job, Session, transaction

MIB=1024**2

@pytest.fixture
def quota(client,monkeypatch,tmp_path):
    cfg=replace(api.settings,storage=tmp_path/'private',max_file_bytes=MIB,
                max_output_bytes=2*MIB,disk_quota_bytes=2*1024**3)
    cfg.storage.mkdir()
    monkeypatch.setattr(api,'settings',cfg);monkeypatch.setattr(jobs,'settings',cfg)
    with transaction()as db:db.query(Job).delete()
    yield cfg
    with transaction()as db:db.query(Job).delete()

def submit(client,package,mode='analyze'):
    files={'file_a':('test.pub',package)}
    if mode=='compare':files['file_b']=('other.pub',package)
    return client.post('/api/jobs',data={'mode':mode},files=files)

def retained(cfg,jid):
    return sum(p.stat().st_size for p in (cfg.storage/jid).rglob('*')if p.is_file())

def seed(cfg,index,state='termine',reserved=320*MIB,size=4096):
    jid=f'{index:048x}';directory=cfg.storage/jid;directory.mkdir()
    (directory/'rapport.pdf').write_bytes(b'a'*size)
    now=time.time()
    with transaction()as db:
        db.add(Job(id=jid,owner='old-user',mode='analyze',state=state,created=now-120,updated=now,
                   expires=now+3600,inputs=[],outputs=['rapport.pdf'],history=[],summary={},
                   engine_version='0.9.0',reserved_bytes=reserved))
    return jid

def test_six_legacy_successes_no_longer_block_without_deleting_files(client,package,quota):
    ids=[seed(quota,i)for i in range(6)]
    before={j:hashlib.sha256((quota.storage/j/'rapport.pdf').read_bytes()).hexdigest()for j in ids}
    # Reproduce exact defaults of 0.9.0: 6 * 320 Mio + another 320 > 2 Gio.
    cfg=replace(quota,max_file_bytes=32*MIB,max_output_bytes=256*MIB)
    api.settings=cfg;jobs.settings=cfg
    response=submit(client,package)
    assert response.status_code==202,response.text
    with Session()as db:
        for jid in ids:
            j=db.get(Job,jid)
            assert j.state=='termine' and j.reserved_bytes==4096 and j.expires>time.time()
            assert hashlib.sha256((quota.storage/jid/'rapport.pdf').read_bytes()).hexdigest()==before[jid]

@pytest.mark.parametrize('mode,count',[('analyze',1),('compare',2)])
def test_queue_keeps_output_budget_then_success_counts_every_file(client,package,quota,mode,count,monkeypatch):
    # Comparisons contain three original CMYK cover assets (~1 MiB each).
    # Keep the separate admission/overbooking tests on their deliberate 2 MiB limit.
    quota=replace(quota,max_output_bytes=5*MIB)
    monkeypatch.setattr(api,'settings',quota);monkeypatch.setattr(jobs,'settings',quota)
    response=submit(client,package,mode);assert response.status_code==202
    jid=response.json()['id']
    with Session()as db:assert db.get(Job,jid).reserved_bytes==count*len(package)+quota.max_output_bytes
    jobs.run_job(jid)
    with Session()as db:
        j=db.get(Job,jid)
        assert j.state=='termine' and j.reserved_bytes==retained(quota,jid)
        assert len(j.outputs)==(2 if mode=='analyze'else 5)
    assert any(p.suffix=='.json'for p in (quota.storage/jid).iterdir())

@pytest.mark.parametrize('state',['attente','analyse','echec'])
def test_unconfirmed_jobs_keep_their_reserved_budget(client,package,quota,state,monkeypatch):
    jid=seed(quota,99,state=state,reserved=2*MIB,size=10)
    cfg=replace(quota,disk_quota_bytes=4*MIB)
    monkeypatch.setattr(api,'settings',cfg);monkeypatch.setattr(jobs,'settings',cfg)
    response=submit(client,package)
    assert response.status_code==507
    with Session()as db:assert db.get(Job,jid).reserved_bytes==2*MIB
    assert (quota.storage/jid/'rapport.pdf').read_bytes()==b'a'*10

def test_real_occupied_quota_is_still_enforced(client,package,quota,monkeypatch):
    jid=seed(quota,99,size=2*MIB)
    cfg=replace(quota,disk_quota_bytes=4*MIB)
    monkeypatch.setattr(api,'settings',cfg);monkeypatch.setattr(jobs,'settings',cfg)
    assert submit(client,package).status_code==507
    assert retained(quota,jid)==2*MIB

def test_failed_render_releases_only_unused_capacity_after_cleanup(client,package,quota,monkeypatch):
    jid=submit(client,package).json()['id']
    def fail(model,directory,*a,**kw):
        (Path(directory)/'rapport.pdf').write_bytes(b'partial')
        raise ValueError('controlled failure')
    monkeypatch.setattr(jobs,'export',fail);jobs.run_job(jid)
    with Session()as db:
        j=db.get(Job,jid);assert j.state=='echec' and j.reserved_bytes==len(package)
    assert retained(quota,jid)==len(package)

def test_cancelled_queue_counts_retained_input(client,package,quota):
    jid=submit(client,package).json()['id']
    assert client.post('/api/jobs/'+jid+'/cancel').status_code==200
    jobs.run_job(jid)
    with Session()as db:
        j=db.get(Job,jid);assert j.state=='annule' and j.reserved_bytes==len(package)

def test_unreadable_success_keeps_previous_reservation(quota,monkeypatch):
    from retro import storage
    jid=seed(quota,99)
    def denied(path):raise PermissionError('not readable')
    monkeypatch.setattr(storage,'stored_bytes',denied)
    jobs.purge()
    with Session()as db:assert db.get(Job,jid).reserved_bytes==320*MIB

def test_stopped_services_repair_counts_failed_and_cancelled_without_deleting(quota):
    from retro.storage import reconcile_retained
    ids=[seed(quota,i,state=state)for i,state in enumerate(('termine','echec','annule','analyse'))]
    with transaction()as db:
        result=reconcile_retained(db,quota.storage,('termine','echec','annule'))
    assert result=={'jobs':3,'before_bytes':960*MIB,'after_bytes':3*4096,'unreadable':0}
    with Session()as db:
        assert all(db.get(Job,jid).reserved_bytes==4096 for jid in ids[:3])
        assert db.get(Job,ids[3]).reserved_bytes==320*MIB
    assert all(retained(quota,jid)==4096 for jid in ids)

def test_parallel_admissions_cannot_overbook_output_budget(client,package,quota,monkeypatch):
    from concurrent.futures import ThreadPoolExecutor
    cfg=replace(quota,disk_quota_bytes=4*MIB)
    monkeypatch.setattr(api,'settings',cfg);monkeypatch.setattr(jobs,'settings',cfg)
    with ThreadPoolExecutor(max_workers=2)as pool:
        results=list(pool.map(lambda _:submit(client,package).status_code,range(2)))
    assert sorted(results)==[202,507]
    with Session()as db:
        assert sum(j.reserved_bytes for j in db.query(Job).all())<=cfg.disk_quota_bytes

def test_nested_internal_files_count_but_links_are_not_followed(tmp_path):
    from retro.storage import stored_bytes
    job=tmp_path/'job';job.mkdir();inner=job/'internal';inner.mkdir()
    (inner/'model.json').write_bytes(b'a'*400)
    outside=tmp_path/'outside';outside.mkdir();(outside/'large').write_bytes(b'b'*10000)
    link=job/'link';link.symlink_to(outside,target_is_directory=True)
    assert stored_bytes(job)==400+link.lstat().st_size
