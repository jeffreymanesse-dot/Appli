from pathlib import Path
import pytest
from retro.parser import analyze


def test_page_components_capture_both_empirical_rule_tags():
    source = Path(__file__).resolve().parents[4] / 'upload/AFR_EPI_WEBLURE_COURRIER_SIMUL.txt'
    if not source.exists():
        pytest.skip('Weblure regression package is not present')
    model = analyze(source)
    pages = model['page_analysis']['rule_uses']
    assert any(x['compiled_id'] == 510262 and x['page_name'] == 'DF_PAG_MAIN_withoutCtcGutAdr_BR' for x in pages)
    assert any(x['compiled_id'] == 512304 and x['page_name'] == 'DF_PAG_MAIN_withoutCtcGutAdr_BR' for x in pages)
    by_id = {r['compiled_id']: r for r in model['rules']}
    assert any(v.get('name') == 'DF_RUL_HEAD_h0857v0030' for v in by_id[510262]['variants'])
    assert any(v.get('name') == 'DF_RUL_LEGN' for v in by_id[512304]['variants'])
    first = next(p for p in model['page_components'] if p['name'] == 'DF_PAG_MAIN_withoutCtcGutAdr_BR')
    overflow = next(p for p in model['page_components'] if p['name'] == 'DF_PAG_FLOW_standard_BR')
    simulation = next(d for d in model['documents'] if d['name'] == 'DOC_AFR_EPI_WEBLURE_SIMULATION')
    request = next(d for d in model['documents'] if d['name'] == 'DOC_AFR_EPI_WEBLURE_DEM_MISE_EN_SERVICE')
    fake = next(p for p in model['page_components'] if p['name'] == 'WEBLURE_PAG_MAIN_fakePageWithCalculus')
    assert first['overflow_page_id'] == overflow['id']
    assert simulation['page_ids'] == [overflow['id']]
    assert request['page_ids'] == [fake['id'], first['id'], overflow['id']]
    visual_rules = {x['compiled_id'] for x in model['visual']['page_analysis']['rule_uses']}
    assert {510262, 512304} <= visual_rules
