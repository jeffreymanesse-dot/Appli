"""Second-PDF regression and failure boundaries, without customer fixtures."""
import copy
import importlib
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import struct
import pytest
from pypdf import PdfReader
from retro.parser import analyze
from retro.visual_graphics import GraphicsDecoder
from retro.visual_model import build_visual
from retro.visual_render import VisualRenderer
from retro.export import export


@pytest.mark.parametrize('tag',[133,134])
def test_font_resource_requires_valid_envelope(tag):
    name=b'Source Sans Pro Bold'
    data=struct.pack('<III',tag,123,0)+bytes([len(name)])+name+struct.pack('<9I',140,300,1252,2,1,0,0,0,0)
    decoder=GraphicsDecoder(data,{'content_units':[]})
    assert decoder.fonts['123']['name']=='Source Sans Pro Bold'
    assert decoder.fonts['123']['resource_tag']==tag
    damaged=bytearray(data);struct.pack_into('<I',damaged,13+len(name)+4,0)
    assert not GraphicsDecoder(bytes(damaged),{'content_units':[]}).fonts


def test_visual_failure_keeps_all_previous_outputs(package,tmp_path,monkeypatch):
    source=tmp_path/'source.pub';source.write_bytes(package);model=analyze(source)
    previous={'rapport.pdf':b'old report','visuel.pdf':b'old visual','rapport.json':b'old model'}
    for name,raw in previous.items():(tmp_path/name).write_bytes(raw)
    def fail(self,path):
        path.write_bytes(b'%PDF-incomplete');raise ValueError('visual failed')
    monkeypatch.setattr(VisualRenderer,'render',fail)
    with pytest.raises(ValueError,match='visual failed'):export(model,tmp_path)
    assert all((tmp_path/n).read_bytes()==raw for n,raw in previous.items())
    assert not list(tmp_path.glob('retro-export-*'))


def test_graphical_enrichment_is_isolated_and_calibration_is_hash_bound(package,tmp_path):
    source=tmp_path/'source.pub';source.write_bytes(package);model=analyze(source)
    before=copy.deepcopy(model);visual=build_visual(package,model)
    assert model==before
    assert visual['calibration'] is None
    assert visual['graphics']['source_sha256']==model['metadata']['sha256']


def test_parallel_visuals_keep_their_own_source(package,tmp_path):
    source=tmp_path/'source.pub';source.write_bytes(package);v=analyze(source)['visual']
    def render(name):
        own=copy.deepcopy(v);own['metadata']['source_name']=name
        path=tmp_path/(name+'.pdf');stats=VisualRenderer(own).render(path)
        return '\n'.join(p.extract_text() for p in PdfReader(path).pages),stats
    with ThreadPoolExecutor(max_workers=2) as pool:
        a,b=pool.map(render,['ALPHA','BETA'])
    assert 'ALPHA' in a[0] and 'BETA' not in a[0]
    assert 'BETA' in b[0] and 'ALPHA' not in b[0]
    assert a[1]['missing']==b[1]['missing']==[]


def test_unresolved_structure_produces_explicit_visual_limit(package,tmp_path):
    p=tmp_path/'source.pub';p.write_bytes(package)
    outputs=export(analyze(p),tmp_path/'out',chapters=[])
    assert set(outputs)=={'rapport.json','rapport.pdf','visuel.pdf'}
    text='\n'.join(p.extract_text() for p in PdfReader(outputs['visuel.pdf']).pages)
    assert 'Aucun contenu visuel rattaché' in text
    assert 'JSON' not in text.upper()


@pytest.mark.parametrize('source,fonts,styles,calibrated',[
    ('AFR_EPI_NOE_BULLETIN_ADHESION',31,100,False),
    ('AFR_EPI_NOE_BULLETIN_VERSEMENT',25,85,False),
    ('AFR_GENERIC_FIP_DEVIS_ESSENCIEL',34,94,False),
    ('AFR_IARD_DEVIS_AUTO',20,143,False),
    ('AFR_GENERIC_PROJET_OBSEQUES_ESSENCIEL',28,103,False),
    ('AFR_GENERIC_IARD_VEHIC_NOA_DEVIS',37,378,True),
])
def test_real_graphical_profiles_and_full_placement(source,fonts,styles,calibrated,tmp_path):
    root=Path(__file__).resolve().parents[3]/'project_sources'
    candidates=list(root.glob('*'+source+'.pub'))
    if not candidates:pytest.skip('Client corpus unavailable')
    m=analyze(candidates[0]);v=m['visual'];g=v['graphics']
    if not any(d['class_code']==21 for d in m['definitions']):
        # Page-only packages must retain text when recovery establishes a
        # new region that was previously part of the unplaced page contents.
        assert set(m['document_content_ids']) <= {u['id'] for u in v['content_units']}
    assert len(g['fonts'])==fonts
    # All previously decoded text is retained; newly recovered empty cells
    # have a complete style envelope but no character styles.
    assert sum(x['status']=='decoded' and bool(x['styles']) for x in g['units'].values())==styles
    recovered={'AFR_EPI_NOE_BULLETIN_ADHESION':['text:5023442'],
               'AFR_GENERIC_FIP_DEVIS_ESSENCIEL':['text:4702030','text:4920764','text:4943885','text:4958948'],
               'AFR_GENERIC_PROJET_OBSEQUES_ESSENCIEL':['text:4704658'],
               'AFR_GENERIC_IARD_VEHIC_NOA_DEVIS':['text:6611819']}
    for uid in recovered.get(source,[]):
        assert g['units'][uid]['status']=='decoded' and g['units'][uid]['styles']
        assert next(u for u in v['content_units'] if u['id']==uid).get('text_structure')
    empty=[uid for uid,x in g['units'].items() if x['status']=='decoded' and not x['styles']]
    units={u['id']:u for u in v['content_units']}
    assert empty and all(not units[uid]['parts'] and units[uid]['richtext']['design_length']==0 for uid in empty)
    assert bool(v['calibration'])==calibrated
    before=copy.deepcopy(v)
    stats=VisualRenderer(v).render(tmp_path/'visuel.pdf')
    assert v==before
    assert not stats['missing'] and not stats['duplicate_placements']
    assert not stats['long_paragraphs'] and not stats['split_rows']
    assert stats['units_source']==stats['units_rendered']+len(stats['intentionally_removed_units'])
