"""Independent screenshots, corruptions and actual PDF stroke extents."""
import copy,struct
from pathlib import Path
import pytest
from test_versement_regression import versement
from retro.table_frames import table_frame
from retro.visual_graphics import GraphicsDecoder
from retro.scoped_borders import scoped_lines,ScopedBorderTable
from retro.layout import counted_table_openings,grid_axis

@pytest.fixture(scope='module')
def source():
    return (Path(__file__).resolve().parents[3]/'project_sources/04-AFR_EPI_NOE_BULLETIN_VERSEMENT.pub').read_bytes()

@pytest.mark.parametrize('pid',['21:43433','21:43434','21:43435'])
def test_table_frames_match_three_screenshots(versement,pid):
    t=next(t for t in versement['tables'] if t['paragraph_id']==pid)
    f=t['presentation']['frame']
    assert f['renderable'] and f['scope']=='table'
    assert f['color']['rgb']=='#00008f' and f['thickness']['raw']==2
    assert f"{f['thickness']['cm']:.2f}"=='0.02'

def test_column_screenshots_are_independent_of_frame_and_cells(versement):
    t=next(t for t in versement['tables'] if t['paragraph_id']=='21:43435');s=t['presentation']
    assert [f"{c['width']['cm']:.2f}" for c in s['columns']]==['9.48','8.92']
    assert [[p['side'] for p in c['borders']if p['renderable']]for c in s['columns']]==[['right'],[]]
    assert all(p['scope']=='cell' for c in s['cells']for p in c['effective_borders'])

@pytest.mark.parametrize('delta',[88,110,122,241,301])
def test_frame_requires_full_bounded_object(source,versement,delta):
    t=next(t for t in versement['tables']if t['paragraph_id']=='21:43435')
    raw=bytearray(source);p=t['presentation']['frame']['object_offset'];raw[p+delta]^=1
    f=table_frame(raw,t,GraphicsDecoder(raw,versement))
    assert not f['renderable'] and f['status']=='uninterpreted'

def test_unknown_line_pattern_is_not_drawn_as_solid(source,versement):
    t=next(t for t in versement['tables']if t['paragraph_id']=='21:43435');raw=bytearray(source)
    struct.pack_into('<I',raw,t['presentation']['frame']['object_offset']+102,99)
    f=table_frame(raw,t,GraphicsDecoder(raw,versement))
    assert not f['renderable'] and f['line_pattern_raw']==99

def test_explicit_frame_none_keeps_raw_color_without_drawing(source,versement):
    t=next(t for t in versement['tables']if t['paragraph_id']=='21:43435');raw=bytearray(source)
    p=t['presentation']['frame']['object_offset'];struct.pack_into('<HI',raw,p+100,0,0xffffffff)
    f=table_frame(raw,t,GraphicsDecoder(raw,versement))
    assert f['status']=='decoded' and not f['renderable'] and not f['active']

def test_invalid_frame_width_does_not_abort_analysis(source,versement):
    t=next(t for t in versement['tables']if t['paragraph_id']=='21:43435');raw=bytearray(source)
    struct.pack_into('<I',raw,t['presentation']['frame']['object_offset']+106,0xffffffff)
    f=table_frame(raw,t,GraphicsDecoder(raw,versement))
    assert f['status']=='uninterpreted' and not f['renderable']

def pen(scope,side,rgb):
    return {'scope':scope,'side':side,'renderable':True,'color':{'rgb':rgb},'thickness':{'pt':.48}}

def style():
    return {'frame':pen('table',None,'#00ff00'),'rows':[{'borders':[pen('row','bottom','#0000ff')]}]*3,
            'columns':[{'borders':[pen('column','right','#ff0000')]},{'borders':[]}]}

def test_scope_extents_do_not_depend_on_cells_or_spans():
    lines=scoped_lines(style(),[40,60],1,3)
    assert {p['side'] for p in lines if p['pen']['scope']=='table'}=={'left','right'}
    assert [(p['x1'],p['x2'])for p in lines if p['pen']['scope']=='row']==[(0,100)]
    assert [(p['x1'],p['x2'])for p in lines if p['pen']['scope']=='column']==[(40,40)]
    assert len(scoped_lines(style(),[40,60],0,3))==5
    assert len(scoped_lines(style(),[40,60],2,3))==5

def test_split_row_only_emits_axis_horizontal_at_true_boundaries():
    middle=scoped_lines(style(),[40,60],1,3,1,3)
    assert not any(p['pen']['scope']=='row' for p in middle)
    assert any(p['pen']['scope']=='column' for p in middle)

def test_actual_pdf_strokes_cross_merged_cell_and_empty_row(tmp_path):
    from reportlab.pdfgen.canvas import Canvas
    from reportlab.platypus import TableStyle
    import fitz
    path=tmp_path/'scopes.pdf';c=Canvas(str(path),pagesize=(200,200))
    t=ScopedBorderTable([['','']],colWidths=[40,60],rowHeights=[20],scope_lines=scoped_lines(style(),[40,60],1,3))
    t.setStyle(TableStyle([('SPAN',(0,0),(1,0)),('BACKGROUND',(0,0),(-1,-1),'white')]))
    t.wrapOn(c,100,100);t.drawOn(c,20,50);c.save()
    with fitz.open(path) as pdf:
        lines=pdf[0].get_drawings()
        assert any(d['color']==(1,0,0) and d['rect'].height==20 and d['rect'].width==0 for d in lines)
        assert any(d['color']==(0,0,1) and d['rect'].width==100 for d in lines)

def test_title_capture_has_no_matching_row_in_available_pub(source,versement):
    p=next(p for p in versement['paragraphs']if p['id']=='21:43432')
    assert not counted_table_openings(source,p['offset'],p['end'])
    assert not grid_axis(source,p['offset'],p['end'],-109)
