import importlib
import pytest


def test_empty_pdf_is_not_published_over_previous_report(tmp_path,monkeypatch):
    module=importlib.import_module('retro.export')
    (tmp_path/'rapport.pdf').write_bytes(b'previous report')
    (tmp_path/'rapport.json').write_text('previous model')
    monkeypatch.setattr(module,'report',lambda model,path:path.write_bytes(b''))
    with pytest.raises(ValueError,match='PDF incomplet'):
        module.export({'kind':'comparison'},tmp_path)
    assert (tmp_path/'rapport.pdf').read_bytes()==b'previous report'
    assert (tmp_path/'rapport.json').read_text()=='previous model'
