"""Independent synthetic structures and optional client corpus; no PUB bundled."""
import copy
import hashlib
import os
import struct
from pathlib import Path

import pytest
from retro.binary import u32
from retro.data_sections import declarations, section_selector, enrich_data_sections, audit_rule_catalog
from retro.layout import sig, extended_row_profile
from retro.structure import document_record
from retro.compare import scope_semantics, compare


def pstr(s):
    b=s.encode('ascii');return bytes([len(b)])+b


def source_bytes():
    b=sig(115,42,4)+b'item'+bytes(8)+struct.pack('<I',1)+pstr('DS_ITEMS')
    b+=bytes(16)+struct.pack('<II',3,3)+pstr('flow record')+bytes(9)+pstr('item')+pstr('flow record')
    return b,{'id':'15:1','class_code':15,'offset':0,'end':len(b),'name':'SOURCE'}


def test_declaration_needs_duplicate_xml_and_matching_depth():
    b,d=source_bytes();s=declarations(b,[d]);assert len(s)==1
    assert s[0]['xml_path']=='/flow/record/item' and s[0]['name']=='DS_ITEMS'
    assert declarations(b[:-1],[{**d,'end':len(b)-1}])==[]
    bad=bytearray(b);bad[49]=4
    assert declarations(bytes(bad),[d])==[]
    assert declarations(b.replace(b'item\x0bflow',b'fake\x0bflow'),[d])==[]


def test_selector_and_duplicate_names_do_not_invent_binding():
    b,d=source_bytes();prefix=len(b);tail=bytes(12)+sig(1)+bytes(12)+struct.pack('<I',1)+pstr('DS_ITEMS')+bytes(4)+sig(106,36)[4:]
    b+=tail
    section={'id':'206:2','name':'SEC','members':[{'offset':prefix}], 'paragraph_ids':[], 'evidence':[]}
    sd={'id':'206:2','class_code':206,'name_end':len(b),'end':len(b)}
    assert section_selector(b,section,sd)[0]=='DS_ITEMS'
    assert section_selector(b[:-1],section,{**sd,'end':len(b)-1}) is None
    model={'definitions':[d,{**d,'id':'15:3'},sd],'document_sections':[section],'documents':[],'rules':[],'unknowns':[]}
    enrich_data_sections(b,model)
    binding=model['data_section_bindings'][0]
    assert binding['status']=='ambiguous' and binding['data_section_id'] is None
    assert len(binding['candidate_ids'])==2
    assert all(s['bindings']==[] for s in model['data_sections'])


def doc_bytes(selector='',pages=(8,),mode=0):
    b=bytearray(44);b+=sig(120)+bytes(12)+struct.pack('<II',mode,bool(selector))+pstr(selector)+bytes(4)+struct.pack('<I',len(pages))
    for page in pages:b+=struct.pack('<I',page)+sig(-102,0,0,0)[4:]+sig()
    b+=struct.pack('<I',99)+bytes(65)+struct.pack('<II',1,3)+struct.pack('<III',0,1,0)+sig(116)[4:]+struct.pack('<I',4)
    return bytes(b),{'id':'10:1','name':'DOC','name_end':0,'end':len(b)},{'24:8':{},'24:9':{},'206:3':{}}


@pytest.mark.parametrize('selector,pages,mode',[('',(8,),0),('',(8,),1),('DS_ITEMS',(8,9),1)])
def test_document_counted_pages_and_selector(selector,pages,mode):
    b,d,defs=doc_bytes(selector,pages,mode);doc=document_record(b,d,defs)
    assert doc['page_ids']==['24:'+str(p) for p in pages]
    assert doc['data_section_name']==(selector or None) and doc['rule_id_raw']==99
    assert document_record(b,d,{}) is None
    assert document_record(b[:-1],{**d,'end':len(b)-1},defs) is None
    bad=bytearray(b);struct.pack_into('<I',bad,68,2)
    assert document_record(bytes(bad),d,defs) is None


def row_bytes(optional=False,zero_prefix=False):
    b=bytearray(186+(16 if optional else 0));b[48:60]=sig(1,1)
    if zero_prefix:b[48:60]=sig(0,0)
    struct.pack_into('<II',b,133,99,99)
    if zero_prefix:struct.pack_into('<II',b,145,0,2)
    if optional:struct.pack_into('<IIII',b,145,1,0,0,1)
    b[-12:-8]=sig()
    for tag,size in ((-102,4),(-103,4),(-104,4),(-105,12),(-106,4),(-107,4),(-108,4),(-109,621)):
        b+=struct.pack('<iI',tag,size)+bytes(size)
    b+=sig();return bytes(b)


@pytest.mark.parametrize('optional',[False,True])
def test_extended_rows_require_full_tail(optional):
    b=row_bytes(optional);profile=extended_row_profile(b,0,len(b))
    assert profile['rule_offset']==133 and u32(b,profile['rule_offset'])==99
    assert profile['end']==len(b)-4
    assert extended_row_profile(b[:-1],0,len(b)-1) is None
    bad=bytearray(b);bad[194+(16 if optional else 0)]=99
    # Mutate next TLV tag, not an opaque property value.
    bad[198+(16 if optional else 0)]=99
    assert extended_row_profile(bytes(bad),0,len(bad)) is None
    if optional:
        bad=bytearray(b);bad[157]=2
        assert extended_row_profile(bytes(bad),0,len(bad)) is None


def test_zero_prefix_row_profile_needs_duplicate_reference_and_full_tail():
    b=row_bytes(zero_prefix=True);profile=extended_row_profile(b,0,len(b))
    assert profile['prefix_code']==0 and profile['row_reference_candidate']==99
    assert profile['end']==len(b)-4
    assert extended_row_profile(b[:-2],0,len(b)-2) is None


def test_row_code_mapping_is_explicit_and_preserves_unknowns():
    from retro.layout import row_type_label
    assert row_type_label(4)=='Repeating header (H+)'
    assert row_type_label(1)=='Automated row — repeating on defined criteria (R)'
    assert row_type_label(3)=='Footer (F)' and row_type_label(5)=='Repeating footer (F+)'
    assert row_type_label(2)=='Header (H)'
    assert row_type_label(7)=='Repeating footer - Except last Page (F-)'
    assert row_type_label(99) is None


def test_rule_audit_uses_ids_and_keeps_unmatched_headers():
    m={'rules':[{'compiled_id':1,'variants':[{},{}]},{'compiled_id':2,'variants':[{}]}]}
    audit_rule_catalog(sig(108,30,1)+sig(108,30,2)+sig(108,30,3),m)
    a=m['rule_catalog_audit'];assert a['compiled_occurrences']==3
    assert a['header_ids_without_compiled_rule']==[3] and not a['inventory_reconciled']
    assert not a['targeting_exhaustive']


def test_scope_comparison_includes_column_and_parent_identity():
    r={'targets':[{'kind':'grid_column','paragraph_id':'21:1','column':2,'table_id':'g'}]}
    original=scope_semantics(r,{})
    r['targets'][0]['column']=3;assert original!=scope_semantics(r,{})
    r={'targets':[{'kind':'section_global','owner_id':'206:1'}]};original=scope_semantics(r,{})
    r['targets'][0]['owner_id']='206:2';assert original!=scope_semantics(r,{})


def test_data_section_comparison_ignores_binary_shift_and_detects_selector_change():
    a={'engine_version':'test','metadata':{},'variables':[],'mappings':[],'rules':[],
       'data_section_bindings':[{'id':'binding:20','owner_kind':'section','owner_id':'206:1',
          'data_section_name':'DS_A','data_section_id':'data-section:15:1:1','status':'resolved','offset':20}]}
    b=copy.deepcopy(a);b['data_section_bindings'][0].update(id='binding:40',offset=40)
    assert compare(a,b)['changes'][0]['status']=='inchangé'
    b['data_section_bindings'][0]['data_section_name']='DS_B'
    assert compare(a,b)['changes'][0]['status']=='modifié'


def test_hierarchy_lists_all_decoded_pages_without_assigning_sections():
    from retro.hierarchy import hierarchy_rows
    m={'definitions':[{'id':'10:1','class_code':10,'name':'DOC'}],
       'documents':[{'id':'10:1','name':'DOC','first_page_id':'24:8','page_ids':['24:8','24:9']}],
       'page_components':[{'id':'24:8','name':'P1'},{'id':'24:9','name':'P2'}]}
    rows=hierarchy_rows(m)
    pages=[r for r in rows if r['kind'] in ('Page initiale','Page référencée','Page de débordement')]
    assert len(pages)==2 and pages[1]['note']==''


def test_txt_is_only_an_extension_alias(client,package):
    response=client.post('/api/jobs',data={'mode':'analyze'},files={'file_a':('renamed.TXT',package)})
    assert response.status_code==202
    assert client.post('/api/jobs',data={'mode':'analyze'},files={'file_a':('ordinary.txt',b'ordinary text '*100)}).status_code==422


@pytest.fixture(scope='module')
def weblure():
    path=Path(os.environ.get('PUB_WEBLURE','__client_corpus_not_available__'))
    if not path.is_file():pytest.skip('Set PUB_WEBLURE to the client PUB (or renamed .txt)')
    assert hashlib.sha256(path.read_bytes()).hexdigest()=='45ff5ce41fefac5b7fd02c63a956fc180eba2d3fea6c06d3d252335b3b4e2621'
    from retro.parser import analyze
    return analyze(path)


def test_weblure_sections_and_rule_inventory(weblure):
    from retro.schema import validate_model
    validate_model(weblure)
    assert len(weblure['data_sections'])==31
    selected=[s for s in weblure['data_sections'] if s['usage_status']!='shared_source_no_binding_decoded']
    assert {s['name'] for s in selected}=={'WEBLURE_'+s for s in ['SIMULATION','RENTE','RENTE_FISCALITY','BENEF','BENEF_FISCALITY','RENTE_END','SIMULATION_END','SIMULATIONS_END']}
    assert len(weblure['data_section_bindings'])==11
    assert sum(b['owner_kind']=='section' for b in weblure['data_section_bindings'])==10
    assert all(b['status']=='resolved' for b in weblure['data_section_bindings'])
    a=weblure['rule_catalog_audit'];assert a['definition_ids']==a['compiled_rule_ids']==274
    assert a['compiled_occurrences']==327 and a['inventory_reconciled']
    assert not weblure['data_section_coverage']['exhaustive']


def test_weblure_main_table_targets_and_unresolved_automation(weblure):
    t=next(t for t in weblure['tables'] if t['paragraph_id']=='21:27644')
    assert len(t['rows'])==10 and len(t['columns'])==19
    assert [r['rule_id'] for r in t['rows']]==[None,None,571164,571166,571166,571166,571165,571163,571162,571161]
    assert [c.get('rule_id') for c in t['columns']]==[None,None,*range(571145,571161),None]
    assert [r['row_type_code'] for r in t['rows']]==[7,3,2,2,2,2,2,1,1,1]
    assert t['rows'][2]['automation_driver_internal_id']==92567 and t['rows'][2]['repeat'] is None
    assert t['rows'][7]['automation_driver_internal_id']==92123 and t['rows'][7]['repeat']
    assert all(t['rows'][i]['repeat'] is None for i in [8,9])
    assert all(r['data_section_status']=='unresolved' for r in t['rows'])
    assert len(weblure['documents'])==4 and len(weblure['document_paragraph_ids'])==53
