"""Generic record guards plus observed client regressions; no fixture in runtime."""
import copy,struct,os
from pathlib import Path
import pytest
from retro.binary import InvalidPackage,evidence
from retro.layout import sig
from retro.scopes import read_richtext
from retro.content_recovery import recover_content
from retro.content_integrity import validate_content
from retro.rule_labels import rule_labels
from retro.report_structure import content_display_text
from test_application_order import weblure


def literal_fixture(text=b'Example title',copies=1):
    b=bytearray(sig(111,21,17))
    for _ in range(copies):b.extend(b'\xa0\0\0\0\x01'+struct.pack('<HH',len(text),len(text))+text)
    end=len(b);b.extend(sig(104,21,17))
    m={'definitions':[dict(id='21:17',class_code=21,internal_id=17,offset=end,evidence=[evidence(b,end,end+16,'fixture')])],
       'content_units':[],'variables':[],'rules':[]}
    return b,m


def test_identical_literals_in_distinct_records_are_preserved():
    b,m=literal_fixture(copies=2);recover_content(b,m)
    assert len(m['content_units'])==2
    assert len({u['offset']for u in m['content_units']})==2
    prior=copy.deepcopy(m['content_units']);recover_content(b,m)
    assert m['content_units']==prior


@pytest.mark.parametrize('damage',['length','owner','bound'])
def test_literal_requires_redundant_lengths_and_owner(damage):
    b,m=literal_fixture()
    if damage=='length':b[23]=99
    elif damage=='owner':b[12]=99
    else:m['definitions'][0]['offset']-=4
    recover_content(b,m);assert not m['content_units']


def title_input(weblure):
    b=bytearray(Path(os.environ['PUB_WEBLURE']).read_bytes())
    u=next(u for u in weblure['content_units'] if u['offset']==4900146)
    vv={v['internal_id']:v for v in weblure['variables']};rr={r['compiled_id']:r for r in weblure['rules']}
    return b,u,vv,rr


def test_closed_empty_run_does_not_hide_variable_and_does_not_target_text(weblure):
    b,u,vv,rr=title_input(weblure)
    rt=read_richtext(b,u,vv,rr)
    assert any(r['start']==r['end'] for r in rt['inlines'])
    part=next(p for p in rt['decoded_parts'] if p.get('design_value'))
    assert part['variable_internal_id']==92874
    assert part['variable_name']=='DF_FIC_SD_SIMURENTE_SIMBYPRODUCT_annuityEffectiveDate'
    assert part['design_value']=='03/08/2008'
    assert '03/08/2008' not in content_display_text(u)
    assert not any(t['kind']=='inline_run' and not t['token_slices']for t in u.get('rule_targets',[]))


def test_variable_identity_has_no_business_name_or_internal_id_special_case(weblure):
    b,u,vv,rr=title_input(weblure);vv=copy.deepcopy(vv)
    event=u['richtext']['variable_events'][0];newid=max(vv)+100
    vv[newid]={**vv.pop(event['internal_id']),'internal_id':newid,'name':'ANY_VARIABLE_NAME'}
    struct.pack_into('<I',b,event['offset']+4,newid)
    struct.pack_into('<I',b,event['directory_offset'],newid)
    result=read_richtext(b,u,vv,rr)
    assert next(p for p in result['decoded_parts'] if p['kind']=='variable')['variable_name']=='ANY_VARIABLE_NAME'


@pytest.mark.parametrize('damage',['id','directory','extent','slot','opcode'])
def test_invalid_empty_run_or_variable_directory_is_not_guessed(weblure,damage):
    b,u,vv,rr=title_input(weblure);event=u['richtext']['variable_events'][0]
    offset,value={'id':(event['offset']+4,1),'directory':(event['directory_offset'],1),
        'extent':(event['directory_offset']+8,1),'slot':(4900240,999),'opcode':(4900244,0xfffffc19)}[damage]
    struct.pack_into('<I',b,offset,value)
    with pytest.raises(InvalidPackage):read_richtext(b,u,vv,rr)


def test_every_recovered_title_is_shared_with_the_report(weblure):
    core={u['id']:u for u in weblure['content_units']};visual={u['id']:u for u in weblure['visual']['content_units']}
    for pid in ['21:27815','21:27817','21:27819','21:27821','21:28998','21:28999','21:29000','21:36748','21:28116','21:27835','21:27836','21:27838','21:27837']:
        p=next(p for p in weblure['paragraphs'] if p['id']==pid)
        assert any(core[i]['text'].strip()for i in p['content_ids'])
        assert all(core[i]['parts']==visual[i]['parts'] for i in p['content_ids'])


@pytest.mark.parametrize('damage',['missing','sample','identity'])
def test_shared_content_guard_detects_regression(weblure,damage):
    m=copy.deepcopy(weblure);u=next(u for u in m['visual']['content_units']if u['offset']==4900146)
    if damage=='missing':m['content_units']=[x for x in m['content_units']if x['id']!=u['id']]
    elif damage=='sample':u['parts'][-1]['kind']='text'
    else:next(x for x in m['content_units']if x['id']==u['id'])['parts'][-1]['variable_name']='WRONG'
    with pytest.raises(ValueError):validate_content(m)


def test_rule_names_are_not_fabricated_or_merged():
    rules=[{'compiled_id':i,'variants':[{'name':'Message Component SHARED'}]}for i in (10,20)]
    labels=rule_labels(rules)
    assert labels[10]==labels[20]=='Règle non nommée'
    assert len(labels)==2  # Separate rule identities; only the public label changes.
    assert all(r['variants'][0]['name']=='Message Component SHARED' for r in rules)
    assert rule_labels([{'compiled_id':30,'variants':[{'name':None}]}])[30]=='Règle non nommée'


def test_unplaced_text_can_still_identify_its_sample_without_inventing_owner():
    from retro.parser import analyze
    path=Path(__file__).resolve().parents[3]/'project_sources/07-AFR_IARD_DEVIS_AUTO.pub'
    if not path.exists():pytest.skip('Client Auto not supplied')
    m=analyze(path)
    u=next(u for u in m['content_units'] if u['id']=='text:969837')
    assert not u.get('parent_id')
    token=next(p for p in u['parts'] if p['kind']=='variable')
    assert token['variable_name']=='WRK_AFR_OriasNumber_STR'
    assert token['design_value']=='12345'
    assert '12345' not in content_display_text(u)
    assert m['content_integrity']['unverified_richtext_units']==['text:1252466']


def test_trailing_spacers_cannot_create_a_blank_page_before_forced_break(tmp_path):
    import fitz
    from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer
    from reportlab.lib.styles import getSampleStyleSheet
    from retro.visual_render import VisualRenderer
    style=getSampleStyleSheet()['BodyText']
    story=[Paragraph('First content',style),Spacer(1,690),Spacer(1,90)]
    VisualRenderer.page_break(story);story.append(Paragraph('Second content',style))
    target=tmp_path/'break.pdf';SimpleDocTemplate(str(target)).build(story)
    doc=fitz.open(target)
    assert len(doc)==2 and all(p.get_text().strip()for p in doc)
