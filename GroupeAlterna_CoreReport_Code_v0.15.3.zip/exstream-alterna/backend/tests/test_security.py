import time
from dataclasses import replace
from starlette.requests import Request
from fastapi import HTTPException
import pytest
from retro.config import settings
from retro import security

def req(headers):return Request({'type':'http','headers':[(k.encode(),v.encode()) for k,v in headers.items()]})
def test_proxy_signature(monkeypatch):
    config=replace(settings,auth_mode='proxy',proxy_key='p'*40)
    monkeypatch.setattr(security,'settings',config);stamp=str(int(time.time()));user='synthetic-user'
    sign=security.signature(user+'|'+stamp,config.proxy_key)
    headers={'x-alterna-user':user,'x-alterna-time':stamp,'x-alterna-signature':sign}
    assert len(security.owner(req(headers)))==64
    headers['x-alterna-user']='other'
    with pytest.raises(HTTPException):security.owner(req(headers))

def test_production_fails_closed():
    with pytest.raises(RuntimeError):replace(settings,production=True).validate()
    with pytest.raises(RuntimeError):replace(settings,signing_key='short').validate()
    with pytest.raises(RuntimeError):replace(settings,signing_key='REPLACE_WITH_AT_LEAST_32_RANDOM_CHARACTERS').validate()

def test_schema_rejects_orphan(tmp_path,package):
    from retro.parser import analyze
    from retro.schema import validate_model
    p=tmp_path/'a.pub';p.write_bytes(package);model=analyze(p);validate_model(model)
    model['mappings'][0]['variable_id']='invalid'
    with pytest.raises(ValueError):validate_model(model)
