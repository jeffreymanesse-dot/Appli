"""Regression: three FIP data rows, followed by the merged explanatory note."""
import copy, struct
from pathlib import Path
import pytest
from retro.binary import MARKER
from retro.layout import grid_axis, sig, decode_layout, counted_table_containers


def explicit_row():
    raw=bytearray(887)
    raw[:48]=sig(-109,186,0,0,101,50,51)+sig(101,50,51)
    raw[48:60]=sig(2,2)
    struct.pack_into('<I',raw,138,101);raw[150:154]=MARKER
    cursor=162
    for tag,size in ((-102,4),(-103,4),(-104,4),(-105,12),(-106,4),(-107,4),(-108,4),(-109,621)):
        struct.pack_into('<iI',raw,cursor,tag,size);cursor+=8+size
    raw[cursor:cursor+4]=MARKER
    return bytes(raw)


def test_styled_rows_do_not_require_a_default_sentinel():
    row=explicit_row();axes=grid_axis(row+row,0,2*len(row),-109)
    assert [a['index'] for a in axes]==[0,1]
    assert [a['raw_dimension'] for a in axes]==[186,186]
    assert axes[0]['evidence'][0]['offset_end']==883
    # The new row profile must not loosen the independent column grammar.
    column=bytearray(row);struct.pack_into('<i',column,4,-103)
    assert not grid_axis(column,0,len(column),-103)


@pytest.mark.parametrize('offset,value',[(52,9),(138,99),(166,5),(258,999),(883,0)])
def test_incomplete_or_unknown_styled_rows_fail_closed(offset,value):
    raw=bytearray(explicit_row());struct.pack_into('<I',raw,offset,value)
    assert not grid_axis(raw,0,len(raw),-109)
    assert not grid_axis(explicit_row(),0,883,-109)


@pytest.fixture(scope='module')
def fip():
    from retro.parser import analyze
    root=Path(__file__).resolve().parents[3]/'project_sources'
    matches=list(root.glob('*AFR_GENERIC_FIP_DEVIS_ESSENCIEL.pub'))
    if not matches:pytest.skip('Client FIP corpus unavailable')
    source=matches[0];model=analyze(source)
    pid=next(p['id'] for p in model['paragraphs'] if p['name']=='PAR_AFR_EPI_NSE_FDC_DEVOIR_DE_CONSEIL_ESSENCIEL_BR_notreEntretien')
    return source.read_bytes(),model,pid


def test_fip_main_rows_and_prices_keep_their_source_coordinates(fip):
    data,model,pid=fip
    for current in (model,model['visual']):
        grid=next(t for t in current['tables'] if t['paragraph_id']==pid)
        units={u['id']:u for u in current['content_units']}
        assert grid['counted_structure'] and len(grid['columns'])==4
        # The binary table also serialises the explanatory note as a fourth
        # merged row. Keep it; do not delete it to manufacture a count of 3.
        assert len(grid['rows'])==4
        positions={(c['row'],c['column']):c for c in grid['cells']}
        for col,label in enumerate(('Simple','Standard','Supérieure'),1):
            assert units[positions[0,col]['content_id']]['text']==label
        for row,label,stem in ((1,'Inhumation','inhumation'),(2,'Crémation','cremation')):
            assert units[positions[row,0]['content_id']]['text']==label
            for col,level in enumerate(('Simple','Standard','Superieure'),1):
                expected='DF_FIC_SD_sousPrev_coutObseques_'+stem+level
                assert expected in units[positions[row,col]['content_id']]['variable_names']
        note=units[positions[3,0]['content_id']]
        assert note['text']=="Hors concessions, monuments et frais d'inhumation à l'étranger"
        assert struct.unpack_from('<I',data,positions[3,0]['offset']+21)[0]==4
        intro=next(u for u in units.values() if u['parent_id']==pid and u['text'].startswith('Notre entretien'))
        assert not intro.get('grid_id') and intro['document_order'][0]<grid['start']
        if current is model:
            assert positions[3,0]['column_span']==4
            assert {c['offset'] for c in grid['presentation']['cells']}=={c['offset'] for c in grid['cells']}


@pytest.mark.parametrize('damaged_rows',[(1,),(1,2)])
def test_corrupt_row_cannot_renumber_a_partial_table(fip,damaged_rows):
    data,model,pid=fip
    paragraph=next(p for p in model['paragraphs'] if p['id']==pid)
    grid=next(t for t in model['tables'] if t['paragraph_id']==pid)
    damaged=bytearray(data)
    for row in damaged_rows:struct.pack_into('<I',damaged,grid['rows'][row]['offset']+166,5)
    assert not counted_table_containers(damaged,paragraph['offset'],paragraph['end'])
    subset={'definitions':[copy.deepcopy(d) for d in model['definitions'] if d['id']==pid],
            'content_units':[{k:copy.deepcopy(u[k]) for k in ('id','offset','evidence')}
                             for u in model['content_units'] if u['parent_id']==pid],
            'variables':[],'rules':[],'tables':[],'unknowns':[]}
    decode_layout(damaged,subset)
    assert not subset['tables'] and all('grid_position' not in u for u in subset['content_units'])
    assert subset['structure_issues'][0]['declared_rows']==4
    assert subset['structure_issues'][0]['recognized_rows']==4-len(damaged_rows)


def test_visual_pdf_places_both_body_rows_and_merged_note(fip,tmp_path):
    import fitz
    from reportlab.platypus import SimpleDocTemplate
    from retro.visual_render import VisualRenderer
    _,model,pid=fip;visual=model['visual'];renderer=VisualRenderer(visual)
    grid=next(t for t in visual['tables'] if t['paragraph_id']==pid)
    flows=renderer.visual_table(grid['id'],540,documentary_guides=False)
    assert len(flows)==4
    # Last row is one note spanning the four columns, not four empty labels.
    assert ('SPAN',(0,0),(3,0)) in flows[-1]._spanCmds
    path=tmp_path/'fip_table.pdf';SimpleDocTemplate(str(path),pagesize=(650,600),leftMargin=40,rightMargin=40).build(flows)
    with fitz.open(path) as pdf:
        assert len(pdf)==1
        page=pdf[0];ys=[]
        for text in ('Simple','Inhumation','Crémation','Hors concessions'):
            hits=page.search_for(text);assert hits;ys.append(hits[0].y0)
        assert ys==sorted(ys) and len(set(ys))==4
        assert page.search_for('Inhumation')[0].x0==pytest.approx(page.search_for('Crémation')[0].x0)
        assert not renderer.SPLITS


def test_shared_component_keeps_its_declared_empty_last_row(fip):
    data,model,_=fip
    pid=next(p['id'] for p in model['paragraphs'] if p['name']=='DF_MSG_GUT_ref_BR')
    grid=next(t for t in model['tables'] if t['paragraph_id']==pid)
    assert len(grid['rows'])==5 and len(grid['columns'])==1
    assert grid['axis_count_status']=='declared_count_matches_axes'
    assert {c['row'] for c in grid['cells']}=={0,1,2,3,4}
    units={u['id']:u for u in model['content_units']}
    assert grid['rows'][4]['content_ids']==['text:5299604']
    assert all(not t['text'].strip() for i in grid['rows'][4]['content_ids'] for t in units[i]['parts'])
    p=grid['axis_count_evidence'][0]['offset_start']+44
    assert struct.unpack_from('<II',data,p+4)==(1,5)


@pytest.mark.parametrize('language',['fr','en'])
def test_report_keeps_the_short_table_and_note_together(fip,tmp_path,language):
    import fitz
    from retro.render import report
    _,model,_=fip;path=tmp_path/'report.pdf'
    report(model,path,chapters=[],language=language)
    with fitz.open(path) as pdf:
        matches=[p for p in pdf if 'Inhumation' in p.get_text() and 'Crémation' in p.get_text()]
        assert len(matches)==1
        assert 'Hors concessions' in matches[0].get_text()
        assert all(x in matches[0].get_text() for x in ('Simple','Standard','Supérieure'))
