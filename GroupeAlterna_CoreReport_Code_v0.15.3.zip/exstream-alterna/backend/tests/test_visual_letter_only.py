"""PAGE appendix material is excluded without hiding missing letter content."""
import copy
import pytest
from pypdf import PdfReader
from retro.visual_render import VisualRenderer
from test_latest_bulletin_package import latest_bulletin


@pytest.mark.parametrize('language', ['fr', 'en'])
def test_visual_omits_page_section_and_keeps_letter(latest_bulletin, tmp_path, language):
    visual=latest_bulletin['visual'];before=copy.deepcopy(visual)
    renderer=VisualRenderer(visual,language=language)
    kept=renderer.projection()[0]
    page_ids={p['id'] for p in visual['visual_page_containers']}-set(kept)
    excluded={u['id'] for u in visual['content_units'] if u['parent_id'] in page_ids}
    path=tmp_path/'visual.pdf';stats=renderer.render(path)
    text='\n'.join(p.extract_text() for p in PdfReader(path).pages)
    # The graphical title stores separately positioned glyphs in the PDF.
    assert 'DEMANDEDEVERSEMENTCOMPLÉMENTAIRE' in ''.join(text.split())
    assert 'Pages, composants et débordements' not in text
    assert all(p['name'] not in text for p in visual['visual_page_containers'])
    assert stats['pages']==3
    assert 'Lecture de cette visualisation' not in text
    assert 'Reading this visualisation' not in text
    assert excluded and set(stats['excluded_page_units'])==excluded
    assert excluded.isdisjoint(renderer.PLACED)
    assert not stats['missing'] and not stats['duplicate_placements'] and not stats['occurrence_errors']
    assert stats['units_source']==stats['units_rendered']+len(stats['intentionally_removed_units'])
    assert visual==before


def test_page_exclusion_does_not_mask_missing_letter(latest_bulletin,tmp_path,monkeypatch):
    renderer=VisualRenderer(latest_bulletin['visual'])
    pid=renderer.projection()[0][0];original=renderer.clean_section
    monkeypatch.setattr(renderer,'clean_section',lambda source:[] if source==pid else original(source))
    with pytest.raises(ValueError,match='Visual coverage mismatch'):
        renderer.render(tmp_path/'missing.pdf')


def test_page_only_visual_keeps_explicit_no_letter_message(latest_bulletin,tmp_path):
    visual=copy.deepcopy(latest_bulletin['visual'])
    page_ids={p['id'] for p in visual['visual_page_containers']}
    visual['paragraphs']=[];visual['document_paragraph_ids']=[];visual['document_flow']=[]
    visual['content_units']=[u for u in visual['content_units'] if u['parent_id'] in page_ids]
    visual['tables']=[t for t in visual['tables'] if t['paragraph_id'] in page_ids]
    visual['object_compositions']=[c for c in visual['object_compositions'] if c['paragraph_id'] in page_ids]
    path=tmp_path/'page_only.pdf';stats=VisualRenderer(visual).render(path)
    text='\n'.join(p.extract_text() for p in PdfReader(path).pages)
    assert 'Aucun contenu visuel rattaché' in text
    assert all(p['name'] not in text for p in visual['visual_page_containers'])
    assert stats['units_rendered']==0 and stats['units_source']==len(stats['excluded_page_units'])
    assert stats['pages']==1 and not stats['missing']
