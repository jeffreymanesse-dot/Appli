import os,tempfile
from pathlib import Path
TEST_ROOT=Path(tempfile.mkdtemp(prefix='alterna-tests-'))
os.environ['APP_SIGNING_KEY']='test-only-not-production-'+('a'*40)
os.environ['DATABASE_URL']='sqlite:///'+str(TEST_ROOT/'jobs.db')
os.environ['STORAGE_DIR']=str(TEST_ROOT/'private')
os.environ['MAX_FILE_BYTES']='16384'
os.environ['MAX_TOTAL_JOBS']='30'
os.environ['MAX_USER_JOBS']='10'
os.environ['DISK_QUOTA_BYTES']=str(20*1024**3)
os.environ['QUEUE_BACKEND']='local'
os.environ['AUTH_MODE']='dev'
os.environ['APP_ENV']='development'
import struct
import pytest
from retro.binary import MARKER

def sample_package():
    # Synthetic fixture, no client content. Header mirrors supported empirical envelope.
    b=bytearray(256);b[:4]=bytes.fromhex('21941e00');b[4:12]=bytes.fromhex('4f61bc00b17f3905');b[49:68]=b'ExstreamPackageFile'
    name=b'DF_FIC_TEST_amount';vid=12345
    b.extend(MARKER+struct.pack('<III',104,35,vid)+bytes([len(name)])+name)
    b.extend(b'\0'*16);b.extend(MARKER+struct.pack('<II',141,5)+b'\0'*28+bytes([len(name)])+name+b'\0'*4+struct.pack('<I',0))
    leaf=b'amount';parent=b'flow record test'
    b.extend(MARKER+struct.pack('<III',115,1,len(leaf))+leaf+b'\0'*37+bytes([len(parent)])+parent)
    b.extend(bytes.fromhex('0800000000010000007000000000000000')+struct.pack('<II',1,vid))
    b.extend(b'\0'*30+bytes([len(leaf)])+leaf+bytes([len(parent)])+parent+b'\0'*12)
    rid=99001;source=b'IF DF_FIC_TEST_amount > 0 THEN INCLUDE ENDIF';rn=b'RUL_TEST_amount'
    b.extend(MARKER+struct.pack('<III',108,30,rid)+b'\0'*20+bytes([len(rn)])+rn+b'\0'*12+struct.pack('<I',len(source))+source+b'\0'*12)
    b.extend(b"_rules['rule99001'] = function() { var numIncludes = 0; if (UserLogic.getValue(12345) > 0) {numIncludes = 1;} UserLogic.setInclude('rule99001', numIncludes); };"+b'\0'*24)
    struct.pack_into('<I',b,24,len(b)-12)
    return bytes(b)

@pytest.fixture
def package():return sample_package()
@pytest.fixture
def client():
    from fastapi.testclient import TestClient
    from retro.api import app
    with TestClient(app) as client:
        client.headers['X-Alterna-Request']='1';client.post('/api/session');yield client
