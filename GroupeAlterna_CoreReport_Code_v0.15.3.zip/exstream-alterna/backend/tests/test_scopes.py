from pathlib import Path
import struct
import pytest
from retro.binary import InvalidPackage
from retro.scopes import read_richtext
from retro.report_structure import content_markup
from test_versement_regression import versement


def unit(model, offset):
    return next(u for u in model['content_units'] if u['offset']==offset)


def test_inline_exactness_and_dynamic_positions(versement):
    t=unit(versement,4614983)
    target=next(x for x in t['rule_targets'] if x['rule_id']==781266)
    assert target['kind']=='inline_run'
    assert target['target_fragment_text']=='tte'
    assert (target['target_token_start'],target['target_token_end'])==(9,10)
    assert target['token_slices'][0]['offset_start']==0x466ee5
    assert target['composed_character_start'] is None
    value=content_markup(t)
    assert 'de ce<font color="#B42318">tte</font> [WRK_AFR_EPI_NOE_BV_typeCourrier]' in value
    assert '<font color="#B42318">WRK_AFR_EPI_NOE_BV_typeCourrier' not in value


def test_reused_rule_slot_and_nested_levels(versement):
    t=unit(versement,4420501)
    actual=[(x['rule_id'],x['kind'],x['target_fragment_text']) for x in t['rule_targets']]
    assert (781270,'inline_run','Oui') in actual
    assert (787027,'inline_run','Non') in actual
    assert (781268,'inline_run','Oui') in actual
    assert (781269,'inline_run','Non') in actual
    # Same compiled rule used by a paragraph AND by a different inline owner.
    para=next(x for x in t['rule_targets'] if x['rule_id']==781268 and x['kind']=='text_paragraph')
    assert para['target_fragment_text'].startswith('Vous possédez un identifiant fiscal américain')
    assert para['target_fragment_text'].endswith('DF_FIC_SD_NOE_gest_infoClient_numeroFiscal')
    assert len({x['owner_object_id'] for x in t['rule_targets']})==5


def test_paragraph_not_visual_line_or_whole_cell(versement):
    t=unit(versement,4409463);a=t['rule_targets'][0]
    assert a['target_fragment_text']=='Nom de naissance : DF_FIC_CD_HOLD_maidenName'
    assert a['text_paragraph_index']==3
    assert len(t['richtext']['paragraphs'])==13
    assert len(t['parts'])==26
    t=unit(versement,4499178)
    scopes={x['rule_id']:x for x in t['rule_targets']}
    assert scopes[781331]['target_fragment_text']=='nuls'
    assert scopes[781332]['target_fragment_text']=='de DF_FIC_SD_NOE_gest_cotisations_txFraisDeroge %'
    assert len(scopes[781332]['token_slices'])==3


@pytest.mark.parametrize('offset,value',[
    (4620101,99),        # Valid inline open, invalid local rule slot.
    (4620117,-62),       # Missing close must not extend to surrounding text.
    (4620097,-999),      # Unknown grammar is preserved, never skipped.
    (4619077,107735),    # Variable ID conflicts with its independent payload.
    (4613337+56,99),     # Out-of-range paragraph targeting index.
    (4624656,1),         # Conflicting rule-list length.
    (4618445,99),        # Broken paragraph sequence / parentage.
])
def test_corrupted_structure_never_guesses_scope(versement,offset,value):
    path=Path(__file__).resolve().parents[3]/'project_sources/04-AFR_EPI_NOE_BULLETIN_VERSEMENT.pub'
    data=bytearray(path.read_bytes());struct.pack_into('<I',data,offset,value & 0xffffffff)
    with pytest.raises(InvalidPackage):
        read_richtext(bytes(data),unit(versement,4614983),
                      {v['internal_id']:v for v in versement['variables']},
                      {r['compiled_id']:r for r in versement['rules']})


def test_occurrence_classification_retains_unknowns(versement):
    r=next(r for r in versement['rules'] if r['compiled_id']==781266)
    kinds={x['classification'] for x in r['target_candidates']}
    assert kinds=={'definition','targeting_reference','unresolved_numeric_occurrence'}
    assert all(a['evidence'] and a['confidence_reason'] for a in r['targets'])


def test_parameterized_rule_header_and_quoted_condition(versement):
    r=next(r for r in versement['rules'] if r['compiled_id']==781268)
    v=r['variants'][0]
    assert v['name']=='RUL_AFR_EPI_NOE_BV_citoyenAmericain_true'
    assert v['condition_readable']=='DF_FIC_SD_NOE_gest_infoClient_citoyenAmericain = "true"'
    assert v['effect_false']=='EXCLUDE' and v['false_effect_origin']=='explicit_compiled_else'
    assert all(t['confidence']=='CERTAIN' for t in r['targets'])


def test_compact_cell_envelope_keeps_dynamic_token(versement):
    t=unit(versement,4534853)
    assert 'richtext' in t
    assert len(t['richtext']['variable_events'])==1
    assert '#B42318' not in content_markup(t)


def test_scope_diff_ignores_byte_relocation_but_detects_target_change(versement):
    from copy import deepcopy
    from retro.compare import compare
    old=deepcopy(versement);new=deepcopy(versement)
    rule=next(r for r in new['rules'] if r['compiled_id']==781266)
    rule['targets'][0]['owner_object_id']='relocated:9999'
    rule['targets'][0]['evidence'][0]['offset_start']+=10
    changed=lambda m:next(c for c in compare(old,m)['changes'] if c['kind']=='rule' and c['id']=='rule:781266')['status']
    assert changed(new)=='inchangé'
    rule['targets'][0]['token_slices'][0]['text']='t'
    rule['targets'][0]['token_slices'][0]['end_in_token']=1
    assert changed(new)=='modifié'


def test_invalid_scope_model_is_rejected(versement):
    from copy import deepcopy
    from retro.schema import validate_model
    m=deepcopy(versement);unit(m,4614983)['rule_targets'][-1]['token_slices'][0]['end_in_token']=100
    with pytest.raises(ValueError,match='boundaries'):validate_model(m)


def test_compiled_condition_does_not_invent_a_missing_else():
    from retro.rules import summarize_compiled
    code="_rules['rule1'] = function() { if (UserLogic.getValue('X') == \"true\") { UserLogic.setInclude('rule1', 1); } }"
    assert summarize_compiled(code,1)=={}
