import copy,json
from pathlib import Path
import pytest
from retro.binary import validate,InvalidPackage,strings,pascal
from retro.parser import analyze
from retro.rules import if_blocks,summarize,function_end
from retro.compare import compare
from retro.export import export

def test_non_pub_and_truncated(package):
    for blob in (b'',b'not a pub'*50,package[:90],b'PK\x03\x04'+package[4:]):
        with pytest.raises(InvalidPackage):validate(blob)

def test_strings_encodings_and_offsets():
    data=b'\0Bonjour\0'+('Été'.encode('utf-16-le')+b' \0')
    ss=strings(data);assert any(s['offset']==1 and s['text']=='Bonjour' for s in ss)
    assert any(s['encoding']=='utf-16-le' for s in ss)

def test_nested_if_and_quotes():
    source='IF X THEN IF Y THEN INCLUDE ENDIF ELSE EXCLUDE ENDIF'
    nodes,incomplete=if_blocks(source);assert len(nodes)==1 and len(nodes[0]['children'])==1 and not incomplete
    assert if_blocks('IF X THEN')[1]
    assert not if_blocks('"IF" // IF\n')[0]
    assert summarize(source)['condition_readable'] is None

def test_braces_inside_literal():
    blob=b'function(){ var x="}"; /* } */ if(1){x=2;} } trailing'
    assert blob[function_end(blob,0)-1:][:1]==b'}'

def test_model_proof_and_determinism(tmp_path,package):
    f=tmp_path/'synthetic.pub';f.write_bytes(package);a=analyze(f);b=analyze(f)
    assert a==b
    v=a['variables'][0];assert v['type']=='Currency' and v['cardinality']=='Scalar'
    assert a['mappings'][0]['xml_path']=='/flow/record/test/amount'
    assert a['rules'][0]['variants'][0]['source_expression']=='IF DF_FIC_TEST_amount > 0 THEN INCLUDE ENDIF'
    assert a['rules'][0]['target'] is None and a['xsd']['available'] is False
    assert not a['blocks'] and not a['tables']
    for ev in v['evidence']:assert 0<=ev['offset_start']<ev['offset_end']<=len(package)

def test_diff_semantics_separate_from_offsets(tmp_path,package):
    f=tmp_path/'fixture.pub';f.write_bytes(package);a=analyze(f);b=copy.deepcopy(a)
    b['variables'][0]['offset']+=17;d=compare(a,b)
    v=next(c for c in d['changes'] if c['kind']=='variable');assert v['status']=='inchangé' and v['representation_changed']
    b['variables'][0]['type']='String';assert compare(a,b)['counts']['modifié']==1
    b['variables'][0]['name']='DF_FIC_RENAMED';assert compare(a,b)['counts']['incertain']==1

def test_pdf_json_exports(tmp_path,package):
    f=tmp_path/'synthetic.pub';f.write_bytes(package);m=analyze(f);out=export(m,tmp_path/'out')
    assert Path(out['rapport.pdf']).read_bytes().startswith(b'%PDF')
    stored=json.loads(Path(out['rapport.json']).read_text())
    stats=stored.pop('visual_validation')
    assert stored==m
    assert stats['missing']==[]
    assert Path(out['visuel.pdf']).read_bytes().startswith(b'%PDF')
    assert not list((tmp_path/'out').glob('*.xsd'))

def test_ambiguous_type_not_guessed(tmp_path,package):
    from retro.binary import MARKER
    import struct
    data=package.replace(MARKER+struct.pack('<II',141,5),MARKER+struct.pack('<II',141,99))
    f=tmp_path/'unknown.pub';f.write_bytes(data);m=analyze(f)
    assert m['variables'][0]['type']=='UNKNOWN_99'
