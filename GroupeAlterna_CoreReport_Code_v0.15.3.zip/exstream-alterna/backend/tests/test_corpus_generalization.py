"""Client-owned corpus: regression cases from independently inspected records.
No input packages are redistributed in the application archive.
"""
from pathlib import Path
import struct
import pytest
from retro.parser import analyze
from retro.binary import InvalidPackage
from retro.scopes import read_richtext
from retro.report_structure import content_markup
from retro.schema import validate_model

ROOT=Path(__file__).resolve().parents[3]/'project_sources'

@pytest.fixture(scope='module',params=['03','04','05','07'])
def corpus(request):
    files=list(ROOT.glob(request.param+'-*.pub'))
    if not files:pytest.skip('Client corpus unavailable')
    return request.param,files[0],analyze(files[0])


def test_auditable_models_and_no_unproved_xml(corpus):
    prefix,path,m=corpus;validate_model(m)
    assert m['document_content_ids']
    data=path.read_bytes()
    for mapping in m['mappings']:
        assert struct.unpack_from('<I',data,mapping['id_offset'])[0]==mapping['internal_id']
    selected={x['mapping_id'] for x in m['input_dictionary']}
    assert selected=={x['id'] for x in m['mappings'] if x['source_classification']=='input_candidate'}
    assert selected, 'Every supplied package has an independently observed INPUT descriptor'
    assert all(x['data_source_descriptor']['role']=='INPUT' for x in m['mappings'] if x['id'] in selected)
    assert all(v['sample_value'] is None for v in m['variables'])


def test_every_column_is_inspected_even_without_repeat(corpus):
    _,_,m=corpus
    assert m['tables']
    for table in m['tables']:
        for c in table['columns']:
            assert c['property_inspection']=='inspected' and len(c['raw_properties'])==17
            if c['targeting_status']=='decoded_on_empirical_profile':
                assert c['raw_properties'][3]==c['rule_id']
                rule=next(r for r in m['rules'] if r['compiled_id']==c['rule_id'])
                assert any(a['kind']=='grid_column' and a['table_id']==table['id'] and a['column']==c['index'] for a in rule['associations'])
            elif c['targeting_status']=='no_rule_on_recognized_property':assert c['raw_properties'][3]==0
            else:assert c['targeting_status']=='non_interpreted'
    assert len({r['document_id'] for r in m.get('repetitions',[])})==len(m.get('repetitions',[]))
    assert len({r['document_id'] for r in m['rules']})==len(m['rules'])


def test_source_specific_relationships_not_string_order(corpus):
    prefix,path,m=corpus
    if prefix=='03':
        order=m['document_paragraph_ids']
        assert order.index('21:41514')<order.index('21:41513')
        assert order.index('21:41753')<order.index('21:41699')
        repeat=[r for r in m['repetitions'] if r['axis']=='column']
        assert {(r['table_id'],r['column'],r['driver_internal_id']) for r in repeat}=={('grid:21:41698',1,105522),('grid:21:41753',1,105522)}
        sample=next(u for u in m['content_units'] if u['offset']==5047803)
        part=next(p for p in sample['parts'] if p.get('design_value'))
        assert part['variable_name']=='DF_PAR_title' and part['design_value']=='Mesdames, Messieurs'
        assert '[DF_PAR_title]' in content_markup(sample)
    elif prefix=='04':
        assert len(m['document_rule_ids'])>=29
        assert {x['compiled_id'] for x in m['page_analysis']['rule_uses']} <= set(m['document_rule_ids'])
        assert 777282 in m['document_rule_ids']  # Explicit document condition, newly decoded.
        # Shared decoding now includes the 15 independently bounded empty cells.
        assert m['coverage']['document_richtext_decoded']==76
        target=next(t for u in m['content_units'] for t in u.get('rule_targets',[]) if t['rule_id']==781266)
        assert target['target_fragment_text']=='tte'
    elif prefix=='05':
        assert '21:42708' in m['document_paragraph_ids']
        assert next(d for d in m['definitions'] if d['id']=='21:42708')['name'].endswith('solutionProposée')
        free=next(u for u in m['content_units'] if u['offset']==4722313)
        assert 'grid_position' not in free
        assert not any(c.get('content_id')==free['id'] for t in m['tables'] for c in t['cells'])
    else:
        source=next(v for v in m['variables'] if v['name']=='FIC_AFR_IAR_IARD_VEHIC_VEH_MARQUE')
        assert source['origin_class']=='input'
        mapping=next(x for x in m['mappings'] if x['variable_id']==source['id'])
        assert mapping['xml_path']=='/PFEL/HPDATA/AGRT-VEH_make'
        assert len(m['pages'])==3 and len(m['document_content_ids'])>=140
        u=next(u for u in m['content_units'] if u['offset']==1162248)
        targets={t['rule_id']:t['target_fragment_text'] for t in u['rule_targets']}
        assert targets[746157]=='an' and targets[746158]=='mois'
        assert '€ TTC au titre' in targets[746161]
        assert m['metadata']['ordering']=='partial_page_ownership_only'
        assert m['coverage']['unplaced_content_ids']


def test_corrupt_rule_slot_fails_closed_on_each_profile(corpus):
    _,path,m=corpus
    item=next(u for u in m['content_units'] if u.get('richtext',{}).get('rule_ids') and u.get('rule_targets'))
    target=item['rule_targets'][0];raw=bytearray(path.read_bytes())
    off=(target['owner_record_offset']+56) if target['kind']=='text_paragraph' else target['scope_open_offset']+4
    struct.pack_into('<I',raw,off,0x7fffffff)
    with pytest.raises(InvalidPackage):read_richtext(bytes(raw),item,{v['internal_id']:v for v in m['variables']},{r['compiled_id']:r for r in m['rules']})
