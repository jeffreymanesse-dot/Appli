"""User-facing changes with independent package evidence and corruption guards."""
import copy
from pathlib import Path
import struct
import pytest
from test_latest_bulletin_package import latest_bulletin
from retro.binary import MARKER
from retro.campaigns import campaign_graph
from retro.hierarchy import hierarchy_rows
from retro.object_composition import decode_compositions, command, Unresolved
from retro.rule_labels import rule_labels, rule_algorithms
from retro.i18n import use_language
from retro.report_table_styles import append_table_styles


@pytest.fixture(scope='module')
def bulletin_bytes():
    return (Path(__file__).resolve().parents[4]/'upload/AFR_EPI_NOE_BULLETIN_VERSEMENT.pub').read_bytes()


def test_campaign_members_match_the_supplied_designer_tree(latest_bulletin):
    m=latest_bulletin
    assert m['applications'][0]['campaign_ids']==['6:16','6:17']
    assert [c['message_ids'] for c in m['campaigns']]==[
        ['21:28747','21:25239','21:28004','21:28844','21:27176','21:25240','21:26138'],
        ['21:25542','21:27178','21:30899','21:44341','21:44342','21:44343','21:44344',
         '21:44345','21:25243','21:38265','21:25244','21:29789','21:25242']]
    rows=hierarchy_rows(m)
    assert len([r for r in rows if r['kind']=='Message'])==20
    assert not any(r['kind']=='Règle de composant' or r['name']=='Sections dans l’ordre sérialisé' for r in rows)
    current=None
    for row in rows:
        if row['kind']=='Campagne':current=row
        if row['kind']=='Message':assert row['depth']==current['depth']+1


@pytest.mark.parametrize('damage',['unknown_member','count','envelope','terminator'])
def test_campaign_damaged_record_is_not_guessed(latest_bulletin,bulletin_bytes,damage):
    m=copy.deepcopy(latest_bulletin);b=bytearray(bulletin_bytes)
    a=next(d['name_end'] for d in m['definitions'] if d['id']=='6:16')
    delta,value={'unknown_member':(160,999999),'count':(156,999999),'envelope':(48,999),
                 'terminator':(188,1)}[damage]
    struct.pack_into('<I',b,a+delta,value)
    for app in m['applications']:
        app.pop('campaign_ids',None);app.pop('campaign_reference_status',None)
    campaign_graph(bytes(b),m)
    assert '6:16' not in {c['id'] for c in m['campaigns']}
    assert 'campaign_ids' not in m['applications'][0]


def test_title_uses_source_font_colour_line_and_geometry(latest_bulletin):
    comp=next(c for c in latest_bulletin['object_compositions'] if c['paragraph_id']=='21:43432')
    cmds=comp['objects'][0]['commands'];text=next(c for c in cmds if c['kind']=='text')
    assert text['text']=='DEMANDE DE VERSEMENT COMPLÉMENTAIRE'
    assert (text['font']['name'],text['font']['size'],text['font']['bold'],text['color'])==('Source Sans Pro Bold',19,True,'#00008f')
    line=next(c for c in cmds if c['kind']=='line')
    assert line['points']==[[308,160],[2481,160]] and line['width_raw']==2
    assert comp['bounds_raw']==[308,30,2481,160]


@pytest.mark.parametrize('offset,value',[(4370809,9),(4370963,164),(4371462,999999),
    (4371589,161),(4371660,1),(4369594,0xffffffff)])
def test_damaged_title_command_font_line_or_owner_is_not_rendered(latest_bulletin,bulletin_bytes,offset,value):
    b=bytearray(bulletin_bytes);struct.pack_into('<I',b,offset,value)
    probe={'paragraphs':[p for p in latest_bulletin['paragraphs'] if p['id']=='21:43432'],
        'variables':latest_bulletin['variables'],'rules':latest_bulletin['rules']}
    decode_compositions(bytes(b),probe)
    assert probe['object_compositions']==[]


def test_title_decoding_is_independent_of_name_and_file_position(latest_bulletin,bulletin_bytes):
    par=copy.deepcopy(next(p for p in latest_bulletin['paragraphs'] if p['id']=='21:43432'))
    par.update(id='21:9999',name='ARBITRARY_NAME',offset=par['offset']+71,end=par['end']+71)
    probe={'paragraphs':[par],'variables':latest_bulletin['variables'],'rules':latest_bulletin['rules']}
    decode_compositions(b'X'*71+bulletin_bytes,probe)
    assert len(probe['object_compositions'])==1
    assert probe['object_compositions'][0]['paragraph_id']=='21:9999'


@pytest.mark.parametrize('rid',[781331,790440,790441,789194])
def test_parameter_rules_never_fall_back_to_compiled_code(latest_bulletin,bulletin_bytes,rid):
    rule=next(r for r in latest_bulletin['rules'] if r['compiled_id']==rid)
    before=copy.deepcopy(rule)
    result=rule_algorithms(rule)
    assert len(result)==1 and result[0][0]=='parameters'
    design=rule['variants'][0]['design_condition']
    assert design['variable_name'] in result[0][1] and result[0][1].endswith(design['value'])
    assert 'UserLogic' not in result[0][1] and 'ELSE' not in result[0][1]
    assert rule==before


def test_source_script_comments_and_branches_are_not_rewritten():
    source='// untouched\r\nIF A THEN\r\n EXCLUDE\r\nELSE\r\n INCLUDE\r\nENDIF'
    rule={'variants':[{'source_expression':source,'compiled_code':'compiled','decoded_expression':'wrong'}]}
    assert rule_algorithms(rule)[0][1]==source


def test_generic_rule_names_keep_identity_and_named_duplicates():
    rules=[{'compiled_id':1,'variants':[{'name':'Message Component OWNER'}]},
           {'compiled_id':2,'variants':[{'name':None}]},
           {'compiled_id':3,'variants':[{'name':'RUL_same'}]},
           {'compiled_id':4,'variants':[{'name':'RUL_same'}]},
           {'compiled_id':5,'variants':[{'name':'Document Rule DOC_OWNER'}]},
           {'compiled_id':6,'variants':[{'name':'DF_CMP_COPY_notice'}]},
           {'compiled_id':7,'variants':[{'name':'Message Rule DF_MSG_OWNER'}]}]
    labels=rule_labels(rules)
    assert labels[1]==labels[2]=='Règle non nommée'
    assert labels[5]==labels[7]=='Règle non nommée'
    assert labels[6]=='DF_CMP_COPY_notice'
    for name in ('Design Layer Rule LAY_DRAFT', 'Queue Rule QUE_OWNER',
                 'Data File Rule DF_OWNER', 'Page Template Component PAG_OWNER'):
        assert rule_labels([{'compiled_id':8,'variants':[{'name':name}]}])[8]=='Règle non nommée'
    assert labels[3]!=labels[4] and all('RUL_same' in labels[i] for i in (3,4))
    with use_language('en'):assert rule_labels(rules)[1]=='Unnamed rule'


def test_table_style_summary_omits_empty_pens_and_empty_cells():
    pen={'side':'top','status':'decoded','active':False,'renderable':False}
    cell={'row':0,'column':0,'background':{'status':'none'},'shape':{'kind':'rounded'},'borders':[pen]}
    grid={'presentation':{'columns':[{'index':0,'width':{'cm':5,'pt':141.73,'raw':591,'offset':123}}],
        'frame':pen,'rows':[{'index':0,'borders':[pen]}],'cells':[cell]}}
    before=copy.deepcopy(grid);tables=[];lines=[]
    def table(rows,*args,**kwargs):tables.append(rows);return rows
    append_table_styles(grid,[],lambda text,*args:lines.append(text),table)
    assert len(tables)==1 and len(tables[0][0])==2
    assert 'Offset' not in str(tables) and 'Arrondi' not in str(tables)
    assert grid==before


def test_no_fill_with_border_retains_border_without_shape():
    pen={'side':'top','renderable':True,'color':{'rgb':'#112233'},'thickness':{'cm':.01,'pt':.28}}
    cell={'row':0,'column':0,'background':{'status':'none'},'shape':{'kind':'rectangle'},'borders':[pen]}
    grid={'presentation':{'columns':[],'frame':{'status':'decoded','active':False},'cells':[cell]}}
    tables=[]
    def table(rows,*args,**kwargs):tables.append(rows);return rows
    append_table_styles(grid,[],lambda *args:None,table)
    assert '#112233' in str(tables) and 'Rectangle' not in str(tables)

