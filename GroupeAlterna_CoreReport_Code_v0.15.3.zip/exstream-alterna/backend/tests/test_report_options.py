import io
import itertools
import re
import time

import pytest
from pypdf import PdfReader
from retro.db import Job, Session, transaction
from retro.jobs import run_job
from retro.parser import analyze
from retro.render import report
from retro.report_options import DEFAULT_CHAPTERS, OPTIONAL_CHAPTERS, normalize_chapters
from retro.security import download_token

COMBINATIONS = list(itertools.product((False, True), repeat=4))


def pdf_text(raw):
    return '\n'.join(p.extract_text() for p in PdfReader(io.BytesIO(raw)).pages)


def check_chapters(text, enabled, mandatory=4):
    assert 'Structure de l’application' in text
    assert 'JSON' not in text.upper()
    number = mandatory + 1
    for (key, title), included in zip(OPTIONAL_CHAPTERS, enabled):
        # Compare extracted text, allowing ordinary PDF line wrapping.
        found = re.search(re.escape(title).replace(r'\ ', r'\s+'), text)
        assert bool(found) == included, title
        if included:
            if key=='template_pages':
                assert 'Annexe - Template et Page' in text
                continue
            assert re.search(str(number) + r'\.\s+' + re.escape(title).replace(r'\ ', r'\s+'), text)
            number += 1


@pytest.mark.parametrize('enabled', COMBINATIONS)
def test_choices_survive_queue_refresh_and_download(client, package, enabled):
    fields = {'mode': 'analyze', **{'include_'+key: str(on).lower() for key, on in zip(DEFAULT_CHAPTERS, enabled)}}
    response = client.post('/api/jobs', data=fields, files={'file_a': ('options.pub', package)})
    assert response.status_code == 202
    jid = response.json()['id']
    chosen = [k for k, on in zip(DEFAULT_CHAPTERS, enabled) if on]
    assert client.get('/api/jobs/'+jid).json()['summary']['report_chapters'] == chosen
    run_job(jid)
    status = client.get('/api/jobs/'+jid).json()
    assert status['state'] == 'termine'
    assert status['summary']['report_chapters'] == chosen
    assert status['outputs'] == ['rapport.pdf', 'visuel.pdf']
    links = client.post(f'/api/jobs/{jid}/links').json()['links']
    assert [x['name'] for x in links] == ['rapport.pdf', 'visuel.pdf']
    check_chapters(pdf_text(client.get(links[0]['url']).content), enabled)
    visual_text = pdf_text(client.get(links[1]['url']).content)
    assert 'Lecture de cette visualisation' not in visual_text
    assert 'JSON' not in visual_text.upper()
    assert all(title not in visual_text for _, title in OPTIONAL_CHAPTERS)


@pytest.mark.parametrize('enabled', COMBINATIONS)
def test_structured_renderer_independent_choices(package, tmp_path, enabled):
    source = tmp_path/'synthetic.pub'; source.write_bytes(package)
    model = analyze(source)
    # Minimal, controlled structural relation; actual binaries are covered separately.
    model['paragraphs'] = [{'id': '21:1', 'name': 'PAR_TEST'}]
    model['document_paragraph_ids'] = ['21:1']
    model['document_rule_ids'] = []
    model['document_variable_ids'] = [v['id'] for v in model['variables']]
    model['document_calculation_ids'] = []
    model['mappings'][0]['source_classification'] = 'input_candidate'
    output = tmp_path/'report.pdf'
    report(model, output, chapters=[k for k, on in zip(DEFAULT_CHAPTERS, enabled) if on])
    text = pdf_text(output.read_bytes())
    check_chapters(text, enabled, mandatory=3)
    if enabled[1]:
        assert 'DF_FIC_TEST_amount' in text
    assert 'PAR_TEST' in text


def test_legacy_job_defaults_and_old_technical_link_denied(client, package):
    jid = client.post('/api/jobs', data={'mode': 'analyze'}, files={'file_a': ('old.pub', package)}).json()['id']
    with transaction() as db:
        db.get(Job, jid).summary = {}  # A queued task created before report options existed.
    run_job(jid)
    assert client.get('/api/jobs/'+jid).json()['summary']['report_chapters'] == list(DEFAULT_CHAPTERS)
    with transaction() as db:
        db.get(Job, jid).outputs = ['rapport.pdf', 'rapport.json']
    status = client.get('/api/jobs/'+jid).json()
    assert status['outputs'] == ['rapport.pdf']
    assert [x['name'] for x in client.post(f'/api/jobs/{jid}/links').json()['links']] == ['rapport.pdf']
    with Session() as db:
        owner = db.get(Job, jid).owner
    expiry = int(time.time())+30
    signature = download_token(jid, 'rapport.json', owner, expiry)
    assert client.get(f'/api/jobs/{jid}/download/rapport.json?expires={expiry}&signature={signature}').status_code == 404


def test_invalid_options_rejected(client, package):
    assert client.post('/api/jobs', data={'mode': 'analyze', 'include_template_pages': 'maybe'},
                       files={'file_a': ('bad.pub', package)}).status_code == 422
    assert client.post('/api/jobs', data={'mode': 'analyze', 'include_valuation': 'maybe'},
                       files={'file_a': ('bad.pub', package)}).status_code == 422
    for value in ('valuation', ['unknown']):
        with pytest.raises(ValueError): normalize_chapters(value)
    assert normalize_chapters([]) == ()
