"""Client regression plus damaged and renamed records; no client bytes shipped."""
import copy
import os
import struct
from pathlib import Path
import pytest
from retro.parser import analyze
from retro.inline_objects import decode_inline_objects
from retro.content_recovery import recover_content
from retro.layout import sig, counted_table_containers, decode_grid, extended_row_profile
from retro.document_flow import report_events, paragraph_occurrences
from retro.visual_render import VisualRenderer, ReservedGraphic
from retro.report_data_sections import append_data_sections, append_row_automation


@pytest.fixture(scope='module')
def package_model():
    path=Path(os.environ.get('PUB_WEBLURE','__unavailable__'))
    if not path.exists():pytest.skip('Set PUB_WEBLURE to the client package')
    return path.read_bytes(),analyze(path)


def plain(flows):
    out=[]
    for flow in flows:
        if isinstance(flow,(str,int)):out.append(str(flow))
        elif isinstance(flow,(list,tuple)):out.append(plain(flow))
        else:
            out.append(getattr(flow,'text',''))
            out.append(plain(getattr(flow,'_content',[])))
            out.append(plain(getattr(flow,'_cellvalues',[])))
            if hasattr(flow,'flow'):out.append(plain([flow.flow]))
    return '\n'.join(out)


def test_row_types_breaks_and_groups(package_model):
    _,m=package_model
    table=next(t for t in m['tables'] if t['paragraph_id']=='21:27644')
    assert [r['row_type_code'] for r in table['rows']]==[7,3,2,2,2,2,2,1,1,1]
    assert all(r['row_type_label'] for r in table['rows'])
    first=table['rows'][2]
    assert first['first_row_of_table_section'] is True
    assert first['break_method']=='when_variable_value_changes'
    assert first['break_variable_name']=='WRK_AFR_EPI_WEBLURE_RENTE_LineTitle'
    assert not first['repeat']
    for row in table['rows'][8:]:
        assert row['group_with_previous_row'] is True
        assert row['automation_driver_name'] is None and row['repeat'] is None
    assert not any(r.get('group_with_previous_row') for r in table['rows'][:8])


def test_complete_signature_cells_and_palette_styles(package_model):
    _,m=package_model
    for pid,suffix in [('21:27731','jpg'),('21:27732','seg')]:
        table=next(t for t in m['tables'] if t['paragraph_id']==pid)
        assert {(c['row'],c['column']) for c in table['cells']}=={(r,c) for r in range(3) for c in range(2)}
        units=[u for u in m['content_units'] if u['parent_id']==pid]
        assert len(units)==6
        assert {n for u in units for n in u['variable_names']}=={'DF_PAR_SIGN2_label1','DF_PAR_SIGN_label1','DF_PAR_SIGN_label2','DF_PAR_SIGN_'+suffix+'Ph'}
        for u in units:
            assert u.get('richtext') and not u.get('scope_decode_issue')
            assert m['visual']['graphics']['units'][u['id']]['status']=='decoded'


@pytest.mark.parametrize('group',[0,1,99])
def test_grouping_reads_its_own_property_after_relocation(package_model,group):
    data,m=package_model
    source=next(t for t in m['tables'] if t['paragraph_id']=='21:27644')['rows'][8]
    p=source['offset'];extent=extended_row_profile(data,p,len(data))['end']
    raw=bytearray(b'X'*64+data[p:extent+4]);rule_at=64+extent-p
    profile=extended_row_profile(raw,64,len(raw));assert profile
    struct.pack_into('<I',raw,profile['rule_offset']+8,group)
    row={'index':0,'offset':64,'properties_offset':112,'evidence':[]}
    probe={'rules':[{'compiled_id':r['compiled_id']} for r in m['rules']],
        'variables':m['variables'],'content_units':[],'tables':[]}
    decode_grid(raw,probe,{'id':'21:123','name':'UNRELATED','evidence':[]},[],[row],[{'index':0}],
        0,len(raw),counted=True,child_cells=[{'row':0,'column':0,'content_ids':[]}])
    assert bool(row.get('group_with_previous_row'))==(group==1)


@pytest.mark.parametrize('damage',[None,'length','colour','directory'])
def test_coloured_payload_recovery_after_relocation_and_rename(package_model,damage):
    data,m=package_model
    p=next(p for p in m['paragraphs'] if p['id']=='21:27731')
    prefix=113;raw=bytearray(b'X'*prefix+data[p['offset']:p['end']]+sig(104,21,123))
    struct.pack_into('<I',raw,prefix+12,123)
    item=next(u for u in m['content_units'] if u['id']=='text:4910555')
    off=prefix+item['offset']-p['offset'];n=struct.unpack_from('<I',raw,off+4)[0]
    if damage=='length':struct.pack_into('<I',raw,off+8+n,n+1)
    if damage=='colour':struct.pack_into('<I',raw,off-8,77)
    if damage=='directory':
        at=prefix+item['richtext']['variable_events'][0]['directory_offset']-p['offset']
        struct.pack_into('<I',raw,at,0)
    variables=copy.deepcopy(m['variables'])
    for v in variables:v['name']='GENERIC_FIELD_'+str(v['internal_id'])
    end=len(raw)-16
    model={'definitions':[{'id':'21:123','internal_id':123,'class_code':21,'name':'UNRELATED','offset':end,'evidence':[]}],
        'content_units':[],'variables':variables,'rules':m['rules']}
    recover_content(raw,model)
    found=[u for u in model['content_units'] if u['offset']==off]
    assert bool(found)==(damage is None)
    if found:assert found[0]['variable_names']==['GENERIC_FIELD_89025']


@pytest.mark.parametrize('damage',[None,'count','dimensions','opcode'])
def test_inline_image_link_needs_directory_frame_and_anchor(package_model,damage):
    data,m=package_model;raw=bytearray(data)
    units=copy.deepcopy([u for u in m['content_units'] if u['parent_id']=='21:27002'])
    for i,u in enumerate(units):
        u['parent_id']='21:123';u['id']='generic-unit-'+str(i)
        u.pop('inline_object_anchor',None);u.pop('inline_object_rule_ids',None)
    owner,child=units;rt=owner['richtext'];end=rt['rule_list_offset']+8+4*len(rt['rule_ids'])
    if damage=='count':struct.pack_into('<I',raw,end+36,2)
    if damage=='dimensions':struct.pack_into('<I',raw,end+60,123)
    if damage=='opcode':struct.pack_into('<i',raw,rt['paragraphs'][3]['offset']+8,-250)
    probe={'content_units':units,'rules':[{'compiled_id':r['compiled_id']} for r in m['rules']]}
    decode_inline_objects(raw,probe)
    assert bool(child.get('inline_object_anchor'))==(damage is None)
    if damage is None:
        assert child['inline_object_anchor']['content_id']=='generic-unit-0'
        assert child['inline_object_rule_ids']==[571546]


def test_image_rules_are_visible_around_graphics(package_model):
    _,m=package_model;labels={r['compiled_id']:r['document_id'] for r in m['rules']}
    renderer=VisualRenderer(m['visual'],rule_labels=labels)
    for pid,rid in [('21:27002',571546),('21:27003',626199)]:
        owner=next(u for u in m['content_units'] if u['parent_id']==pid and not u.get('inline_object_anchor'))
        text=plain(renderer.text_flow(owner['id'],491))
        assert '['+labels[rid]+']' in text and '[/'+labels[rid]+']' in text
        assert 'Image :' in text
    for uid,rid in [('text:4913963',571573),('text:4931728',699675)]:
        flows=renderer.text_flow(uid,220);text=plain(flows)
        assert any(isinstance(f,ReservedGraphic) for f in flows)
        assert '['+labels[rid]+']' in text and '[/'+labels[rid]+']' in text


def test_table_is_inside_text_between_birth_date_and_rate(package_model):
    data,m=package_model
    table=next(t for t in m['tables'] if t['paragraph_id']=='21:27809')
    anchor=table['inline_anchor'];assert anchor['paragraph_index']==11
    owner=next(u for u in m['content_units'] if u['id']==anchor['content_id'])
    text=''.join(p.get('variable_name',p['text']) for p in owner['parts'])
    assert 'dateNaissance' in text and 'Taux technique' in text
    rendered=plain(VisualRenderer(m['visual']).text_flow(owner['id'],491))
    assert rendered.index('dateNaissance')<rendered.index('WRK_AFR_EPI_WEBLURE_BENEF_ProductList_CivNameDtNaiss')<rendered.index('Taux technique')
    p=next(p for p in m['paragraphs'] if p['id']==table['paragraph_id'])
    bad=bytearray(data);struct.pack_into('<I',bad,table['end']-168+60,99)
    assert not counted_table_containers(bad,p['offset'],p['end'])


def test_container_events_preserve_occurrences_and_page_rules(package_model):
    _,m=package_model;events=list(report_events(m))
    assert [e for e in events if e['kind']=='paragraph']==paragraph_occurrences(m)
    assert len([e for e in events if e['kind']=='document'])==4
    assert len([e for e in events if e['kind']=='section'])>=len(m['document_sections'])
    for page in m['page_components']:
        for rid in page.get('global_rule_ids',[]):
            assert rid in m['document_rule_ids']
            rule=next(r for r in m['rules'] if r['compiled_id']==rid)
            assert any(a['kind']=='page_global' and a['page_id']==page['id'] for a in rule['associations'])


def test_simplified_data_sections_and_single_row_table(package_model):
    _,m=package_model;story=[];titles=[]
    append_data_sections(m,story,lambda t,s:titles.append(t),lambda rows,widths:rows)
    text=plain(story)
    assert '/ statut' not in text and 'Sélecteur explicite résolu' not in text
    grid=next(t for t in m['tables'] if t['paragraph_id']=='21:27809');story=[];titles=[]
    append_row_automation(grid,story,lambda t,s:titles.append(t),lambda rows,widths:rows,
        {r['compiled_id']:r['document_id'] for r in m['rules']},m['repetitions'])
    assert len(story)==1 and len(story[0])==4
    assert 'Aucun driver' not in plain(story)
    assert all(str(i) in plain(story) for i in (1,2,3))
