from pathlib import Path
import copy,hashlib,struct
import pytest
from retro.parser import analyze
from retro.layout import inspect_columns
from retro.report_structure import content_markup
from retro.valuation import assignment_sites

SOURCE=Path(__file__).resolve().parents[3]/'project_sources/06-AFR_GENERIC_PROJET_OBSEQUES_ESSENCIEL.pub'
@pytest.fixture(scope='module')
def corpus():
    if not SOURCE.exists():pytest.skip('PUB client absent')
    data=SOURCE.read_bytes()
    assert hashlib.sha256(data).hexdigest()=='78b79d2cf896722b8cc4a057a222b2df595af34a44fdb7bd1f1c402bdf7b2337'
    return data,analyze(SOURCE)

def test_column_rules_and_assignment_origins(corpus):
    data,m=corpus;grid=next(t for t in m['tables'] if t['paragraph_id']=='21:42545')
    assert [c['rule_id'] for c in grid['columns']]==[None,767773,767782,767783]
    assert {767773,767782,767783}<=set(m['document_rule_ids'])
    expected={106457:(767773,106396),106460:(767773,106395),106464:(767782,106396),106463:(767782,106395),106467:(767783,106396),106466:(767783,106395)}
    for vid,(rid,input_id) in expected.items():
        v=next(v for v in m['variables'] if v['internal_id']==vid)
        assert v['origin_class']=='calculated'
        sites=[s for s in v['valuation_sites'] if s.get('rule_id')==rid]
        assert len(sites)==1 and sites[0]['branch_conditions']==['_n > 0']
        assert sites[0]['read_variable_ids']==['35:'+str(input_id)]
        assert sites[0]['rule_in_document']
    for rid in (767773,767782,767783):
        r=next(r for r in m['rules'] if r['compiled_id']==rid);v=r['variants'][0]
        assert v['source_expression'].startswith('Dim n as Integer')
        assert len(v['assignments'])==3 and v['effect_false']=='EXCLUDE'
        assert 'Contains(' in v['source_expression']

def test_column_guard_fails_closed(corpus):
    data,m=corpus
    for delta,value in [(16,123456789),(68,0)]:
        bad=bytearray(data);q=4575518;struct.pack_into('<I',bad,q+delta,value)
        model={'variables':m['variables'],'content_units':[],'tables':[copy.deepcopy(next(t for t in m['tables'] if t['paragraph_id']=='21:42545'))],'rules':copy.deepcopy(m['rules'])}
        inspect_columns(bytes(bad),model)
        assert model['tables'][0]['columns'][1]['rule_id'] is None

def test_names_pages_and_precise_paragraph_annotations(corpus):
    _,m=corpus
    assert {p['name'] for p in m['page_components']}=={'DF_PAG_MAIN_ficheInfos_BR','DF_PAG_BLANK','DF_PAG_FLOW_ficheInfos_BR'}
    assert next(c for c in m['calculations'] if c['id']=='function895')['definition_name']=='DF_FCT_IMG_getImage'
    assert next(r for r in m['rules'] if r['compiled_id']==767788)['variants'][0]['name'].endswith('Viagère_True')
    unit=next(u for u in m['content_units'] if u['id']=='text:4497508')
    assert {t['rule_id'] for t in unit['rule_targets']}=={767726,767727}
    labels={r['compiled_id']:r['document_id'] for r in m['rules']};text=content_markup(unit,labels)
    for rid in (767727,767726):
        assert '['+labels[rid]+']' in text and '[/'+labels[rid]+']' in text
    label=labels[767727]
    assert text.index('['+label+']')<text.index('Pour vous aider')<text.index('[/'+label+']')<text.index('Hors concessions')
    label=labels[767726]
    assert text.index('['+label+']')<text.index('En France métropolitaine')<text.index('[/'+label+']')<text.index('Source : OGF')

def test_annotation_closes_at_mid_token():
    u={'parts':[{'text':'abcdef','kind':'text','offset':10}],'rule_targets':[{'kind':'inline_run','rule_id':7,'token_slices':[{'token_index':0,'start_in_token':1,'end_in_token':3}]}]}
    txt=content_markup(u,{7:'R7'})
    assert txt.index('[R7]')<txt.index('bc')<txt.index('[/R7]')<txt.index('def')

def test_named_assignment_balanced_and_comments_ignored():
    code='var x="UserLogic.setValue(1, 0)"; // UserLogic.setValue(1, 0)\nif (flag) { UserLogic.setValue("CALC", UserLogic.getValueAt(2, fn(1, 2))); }'
    vs=[{'id':'35:1','internal_id':1,'name':'CALC'},{'id':'35:2','internal_id':2,'name':'INPUT'}]
    sites=assignment_sites(code.encode(),code,0,vs)
    assert len(sites)==1 and sites[0]['read_variable_ids']==['35:2']
    assert sites[0]['branch_conditions']==['flag']
    assert sites[0]['expression_readable']=='INPUT(fn(1, 2))'
