"""Native properties, scheduled entry points and presentation regressions."""
import copy
import struct
from pathlib import Path
import pytest
from retro.binary import MARKER
from retro.formula_timing import (ENVELOPE, SECTION_PREFIX, SECTION_SUFFIX,
    read_compute_time, compute_time_line, event_formula_ids)
from retro.visual_render import VisualRenderer
from test_weblure_properties import package_model


def record(code=3, name='GENERIC_VARIABLE', prefix=91, section=None):
    raw=bytearray(bytes(prefix)+b'X'*20+ENVELOPE)
    p=len(raw)
    raw+=MARKER+struct.pack('<9I',141,0,1,code,0,0,1,0,0)
    raw+=bytes([len(name)])+name.encode()+bytes(4)
    cardinality=len(raw);raw+=bytes(4)
    if section is not None:
        raw+=SECTION_PREFIX+bytes([len(section)])+section.encode()+SECTION_SUFFIX
    stop=len(raw);raw+=b'_formula[\'formula123\'] = function(){};'
    v={'id':'35:123','internal_id':123,'class_code':35,'offset':prefix,'end':len(raw),
       'name_end':prefix+20,'name':name,'type_offset':p+8,'type_code':0,
       'cardinality_offset':cardinality}
    c={'id':'formula123','offset':stop,'result_variable_id':v['id']}
    return raw,v,c


@pytest.mark.parametrize('code,label',[(0,'As-needed'),(1,'Customer'),(3,'Page'),(6,'Initialization'),(8,'Named section')])
def test_timing_is_read_from_renamed_relocated_design_property(code,label):
    raw,v,c=record(code,section='SECTION_OTHER' if code==8 else None)
    timing=read_compute_time(raw,v,c)
    assert timing['label']==label
    assert timing['section_name']==('SECTION_OTHER' if code==8 else None)
    c['compute_time']=timing
    assert compute_time_line(c).startswith('Compute Time : '+label)
    assert bool(event_formula_ids({'calculations':[c]}))==(code!=0)


@pytest.mark.parametrize('damage',['envelope','tag','source','name','owner','truncated','cardinality'])
def test_timing_rejects_corrupt_or_mismatching_property(damage):
    raw,v,c=record();p=v['type_offset']-8
    if damage=='envelope':raw[v['name_end']]=1
    elif damage=='tag':struct.pack_into('<I',raw,p+4,999)
    elif damage=='source':struct.pack_into('<I',raw,p+12,0)
    elif damage=='name':v['name']='UNRELATED'
    elif damage=='owner':c['result_variable_id']='35:999'
    elif damage=='truncated':raw=raw[:c['offset']-2]
    elif damage=='cardinality':struct.pack_into('<I',raw,v['cardinality_offset'],3)
    assert read_compute_time(raw,v,c) is None


def test_unknown_enum_is_not_given_a_guessed_label_or_scheduled():
    raw,v,c=record(99);timing=read_compute_time(raw,v,c)
    assert timing['status']=='unknown_value' and timing['label'] is None
    c['compute_time']=timing
    assert not event_formula_ids({'calculations':[c]})
    assert 'Non déterminé' in compute_time_line(c)
    assert compute_time_line({'id':'function1'}) is None


def test_named_section_must_have_the_complete_unique_envelope():
    raw,v,c=record(8,section='NAMED_DATA')
    at=raw.index(SECTION_SUFFIX)
    raw[at]=1
    assert read_compute_time(raw,v,c)['section_name'] is None
    raw,v,c=record(8,section='NAMED_DATA')
    extra=SECTION_PREFIX+b'\x05OTHER'+SECTION_SUFFIX
    raw[c['offset']:c['offset']]=extra;v['end']+=len(extra);c['offset']+=len(extra)
    assert read_compute_time(raw,v,c)['section_name'] is None


def test_weblure_scheduled_formulas_and_named_sections(package_model):
    _,m=package_model
    c=next(c for c in m['calculations'] if c.get('definition_name')=='WRK_AFR_EPI_WEBLURE_COURRIER_SIMUL_initPage')
    assert c['compute_time']['label']=='Page'
    assert c['id'] in m['document_calculation_ids'] and c['id'] in m['event_calculation_ids']
    assert c['result_variable_id'] in m['document_variable_ids']
    assert all(call['callee_id'] in m['document_calculation_ids'] for call in c['calls'])
    assert '//   OBLIGATOIRE pour forcer le compute time à page' in c['source_expression']
    expected={'formula102905':'WEBLURE_SIMULATIONS_END','formula102803':'WEBLURE_SIMULATION',
              'formula92882':'WEBLURE_SIMULATION','formula92117':'WEBLURE_RENTE','formula92116':'WEBLURE_BENEF'}
    formulas=[x for x in m['calculations'] if x.get('result_variable_id')]
    assert len(formulas)==29 and all(x['compute_time']['status']=='decoded' for x in formulas)
    for x in formulas:
        if x['id'] in expected:assert x['compute_time']['section_name']==expected[x['id']]


def test_borderless_inline_table_has_a_complete_light_outline_without_mutation(package_model):
    _,m=package_model
    pid=next(p['id'] for p in m['paragraphs'] if p['name']=='PAR_WEBLURE_Simul_Liste-data')
    table=next(t for t in m['tables'] if t['paragraph_id']==pid and t.get('inline_anchor'))
    visual=copy.deepcopy(m['visual']);before=copy.deepcopy(visual)
    renderer=VisualRenderer(visual)
    flows=renderer.visual_table(table['id'],491,documentary_guides=False)
    assert [f.guide_sides for f in flows]==[('left','right','top'),('left','right'),('left','right','bottom')]
    assert visual==before
    # A real frame retains its source strokes and receives no guide overlay.
    renderer.TABLE_STYLES[table['id']]['frame']={'renderable':True,
        'thickness':{'pt':.8},'color':{'rgb':'#00008f'}}
    flows=renderer.visual_table(table['id'],491,documentary_guides=False)
    assert not any(f.guide_sides for f in flows)
    assert any(line['pen']['color']['rgb']=='#00008f' for f in flows for line in f.scope_lines)
