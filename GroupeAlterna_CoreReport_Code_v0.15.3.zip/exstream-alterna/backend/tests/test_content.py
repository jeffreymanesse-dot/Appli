import struct
from retro.binary import MARKER
from retro.content import enrich,uncomment
from retro.parser import analyze


def test_content_requires_redundant_length_and_structural_header():
    raw=b'\0\0\0\1Montant : \0\0DF_FIC_TEST_amount\0\0 \x80\0'
    prefix=MARKER+struct.pack('<III',101,50,51)
    payload=MARKER+struct.pack('<I',len(raw))+raw+struct.pack('<I',len(raw))
    def model():return {'variables':[{'name':'DF_FIC_TEST_amount','id':'35:1','internal_id':1,'usage_evidence':[]}],'calculations':[]}
    m=model();enrich(prefix+payload,m)
    assert len(m['content_units'])==1
    assert '€' in m['content_units'][0]['text']
    assert m['content_units'][0]['document_order'] is None
    assert m['content_units'][0]['variable_names']==['DF_FIC_TEST_amount']
    for data in (payload,prefix+payload[:-1],prefix+payload[:-4]+b'xxxx'):
        m=model();enrich(data,m);assert m['content_units']==[]


def test_formula_singular_and_plural(tmp_path,package):
    for token in [b'_formula',b'_formulas']:
        f=tmp_path/'sample.pub';f.write_bytes(package+b"\0"+token+b"['formula91'] = function(){ return 1; }\0")
        m=analyze(f);assert any(x['id']=='formula91' for x in m['calculations'])


def test_comment_removal_keeps_literals_and_conditions():
    s='// hidden\nIF X THEN\nvalue = "https://test/*ok*/" /* comment */\nELSE\nvalue="null"\nENDIF'
    cleaned=uncomment(s)
    assert 'https://test/*ok*/' in cleaned and 'hidden' not in cleaned
    assert 'ELSE' in cleaned and '"null"' in cleaned
    assert uncomment('value=1 /* unfinished')=='value=1 /* unfinished'


def test_named_rule_dependencies(tmp_path,package):
    f=tmp_path/'sample.pub'
    f.write_bytes(package+b"\0_rules['rule91'] = function(){if(UserLogic.getValue('DF_FIC_TEST_amount') == 1){UserLogic.setInclude('rule91',1);}}\0")
    m=analyze(f);r=next(r for r in m['rules'] if r['compiled_id']==91)
    assert r['variants'][0]['reads']==[m['variables'][0]['internal_id']]


def test_reference_flow_is_not_input():
    from retro.content import classify_sources
    # Source ownership and Pascal descriptors, including a reference rooted at /flow.
    data=bytearray(600)
    inp=bytes.fromhex('5707f042a30000000000000000')+b'\x05INPUT\x09input.xml'+b'\0'*10+(0).to_bytes(4,'little')+(0).to_bytes(4,'little')
    data[54:54+len(inp)]=inp
    ref=bytes.fromhex('5707f042a3000000013b00000000')+b'\x03REF\x13M:\\refFiles\\ref.xml'+b'\0'*10+(0).to_bytes(4,'little')+(2).to_bytes(4,'little')
    data[354:354+len(ref)]=ref
    model={'definitions':[{'id':'15:1','class_code':15,'name':'input','offset':0,'name_end':10,'end':300},{'id':'15:2','class_code':15,'name':'ref','offset':300,'name_end':310,'end':len(data)}], 'variables':[{'id':'35:1'},{'id':'35:2'}], 'mappings':[{'id':'a','offset':150,'variable_id':'35:1','xml_path':'/flow/record/x','evidence':[]},{'id':'b','offset':450,'variable_id':'35:2','xml_path':'/flow/record/x','evidence':[]}]}
    classify_sources(data,model)
    assert len(model['input_dictionary'])==1
    assert model['mappings'][1]['source_classification']=='reference_candidate'


def test_compiled_rule_only_interprets_explicit_branches():
    from retro.rules import summarize_compiled
    source="_rules['rule91'] = function(){if(UserLogic.getValue('FLAG') == true){UserLogic.setInclude('rule91',1);}else{UserLogic.setInclude('rule91',0);}}"
    r=summarize_compiled(source,91)
    assert r['condition_readable']=='FLAG = true' and r['effect_false']=='EXCLUDE'
    assert r['false_effect_origin']=='explicit_compiled_else'
    assert summarize_compiled(source.replace("else{UserLogic.setInclude('rule91',0);}",''),91)=={}
    assert summarize_compiled(source,92)=={}
    assert summarize_compiled(source.replace('true','null'),91)=={}
    assert summarize_compiled(source.replace(' == true',' && other'),91)=={}
