import struct
import pytest
from retro.binary import MARKER
from retro.content import source_descriptor


def fixture(role,path,reference=False):
    header=b'\x01;\0\0\0\0' if reference else b'\0'*5
    raw=b'\0'*44+MARKER+struct.pack('<I',163)+header+bytes([len(role)])+role+bytes([len(path)])+path
    raw+=bytes(10)+struct.pack('<II',10,2 if reference else 0)
    return raw,{'name_end':0,'end':len(raw)}


@pytest.mark.parametrize('path',[b'M:\\flow.xml',b'M:\\'+b'a'*55+b'.xml'])
def test_input_role_is_length_delimited(path):
    raw,d=fixture(b'INPUT',path)
    result=source_descriptor(raw,d)
    assert result['classification']=='input_candidate' and result['resource_path']==path.decode()


def test_input_word_in_resource_does_not_classify_source():
    raw,d=fixture(b'OUTPUT',b'M:\\INPUT file.xml')
    assert source_descriptor(raw,d)['classification']=='driver_candidate'
    raw,d=fixture(b'REFERENCE',b'M:\\refFiles\\INPUT file.xml',True)
    assert source_descriptor(raw,d)['classification']=='reference_candidate'


def test_descriptor_cannot_cross_source_boundary():
    raw,d=fixture(b'INPUT',b'M:\\file.xml');d['end']-=1
    assert source_descriptor(raw,d)['classification']=='unknown'
    assert source_descriptor(raw[:55],{'name_end':0,'end':55})['classification']=='unknown'


def test_data_file_type_wins_over_path_and_role():
    raw,d=fixture(b'anything',b'M:\\refFiles\\not_a_reference.xml',False)
    result=source_descriptor(raw,d)
    assert result['classification']=='driver_candidate' and result['type_code']==0


def test_flow_root_without_source_owner_is_not_input():
    from retro.content import classify_sources
    m={'definitions':[],'variables':[{'id':'35:1'}],
       'mappings':[{'id':'map:1','variable_id':'35:1','offset':10,'xml_path':'/flow/record/x','source_classification':'input_candidate'}]}
    classify_sources(b'INPUT flow',m)
    assert m['input_dictionary']==[] and m['variables'][0]['source']=='unknown'


def test_zero_length_header_requires_second_package_signature_profile():
    from retro.binary import validate,InvalidPackage
    raw=bytearray(300);raw[:4]=bytes.fromhex('35202300');raw[36:44]=b'opaque!!';raw[48]=19
    raw[49:68]=b'ExstreamPackageFile';raw[100:104]=MARKER
    validate(bytes(raw))
    raw[48]=18
    with pytest.raises(InvalidPackage):validate(bytes(raw))
