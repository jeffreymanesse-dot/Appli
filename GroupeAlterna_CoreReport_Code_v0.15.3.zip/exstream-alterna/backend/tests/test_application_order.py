"""Application order must reach the content report and the rendered visual."""
import copy,hashlib,os
from pathlib import Path
import pytest
from pypdf import PdfReader
from retro.document_order import apply_application_document_order,validate_application_document_order
from retro.hierarchy import application_graph
from test_hierarchy import application_bytes


def fixture():
    model={'definitions':[{'id':'10:3','internal_id':3,'class_code':10,'name':'AAA'},
                          {'id':'10:7','internal_id':7,'class_code':10,'name':'ZZZ'},
                          {'id':'21:10','class_code':21,'name':'PAR_EARLY_BYTES'},
                          {'id':'21:20','class_code':21,'name':'PAR_FIRST_APPLICATION'},
                          {'id':'21:30','class_code':21,'name':'PAR_SHARED'}],
           'documents':[{'id':'10:3','name':'AAA','paragraph_ids':['21:10','21:30']},
                        {'id':'10:7','name':'ZZZ','paragraph_ids':['21:20','21:30']}],
           'paragraphs':[{'id':'21:10'},{'id':'21:20'},{'id':'21:30'}],
           'document_paragraph_ids':['21:10','21:30','21:20'],
           'content_units':[{'id':'literal','text':'unchanged'}],
           'tables':[{'id':'table','rows':[{'rule_id':42}]}]}
    application_graph(application_bytes(),model)
    return model


def test_reference_order_overrides_bytes_and_names_without_changing_content():
    m=fixture();before=copy.deepcopy(m)
    apply_application_document_order(m)
    assert [d['id'] for d in m['documents']]==['10:7','10:3']
    assert m['document_paragraph_ids']==['21:20','21:30','21:10']
    assert m['document_order']['definition_document_ids']==['10:3','10:7']
    assert m['document_order']['changed'] and m['document_order']['evidence']
    for key in ('definitions','paragraphs','content_units','tables','applications'):assert m[key]==before[key]
    after=copy.deepcopy(m);apply_application_document_order(m);assert m==after
    validate_application_document_order(m)


@pytest.mark.parametrize('case',['absent','unresolved','multiple','duplicate','unknown','no_evidence'])
def test_unproved_application_order_preserves_the_diagnostic_sequence(case):
    m=fixture()
    if case=='absent':m['applications']=[]
    elif case=='unresolved':m['applications'][0]['relation_status']='unresolved'
    elif case=='multiple':m['applications'].append({**m['applications'][0],'id':'1:99','document_ids':['10:3','10:7']})
    elif case=='duplicate':m['applications'][0]['document_ids']=['10:7','10:7']
    elif case=='unknown':m['applications'][0]['document_ids']=['10:7','10:999']
    else:m['applications'][0]['evidence']=[]
    docs=copy.deepcopy(m['documents']);order=m['document_paragraph_ids'][:]
    apply_application_document_order(m)
    assert m['documents']==docs and m['document_paragraph_ids']==order
    assert m['document_order']['status']=='unresolved' and not m['document_order']['changed']


def test_unreferenced_document_is_preserved_but_not_promoted_to_application_member():
    m=fixture();m['definitions'].append({'id':'10:9','class_code':10})
    m['documents'].insert(0,{'id':'10:9','paragraph_ids':['21:40']});m['paragraphs'].append({'id':'21:40'})
    apply_application_document_order(m)
    assert [d['id'] for d in m['documents']]==['10:7','10:3','10:9']
    assert m['document_order']['unreferenced_document_ids']==['10:9']
    assert m['document_order']['status']=='partial_application_references'
    assert m['document_paragraph_ids']==['21:20','21:30','21:10','21:40']
    validate_application_document_order(m)


def test_missing_document_decoder_is_explicit_and_does_not_hide_known_content():
    m=fixture();m['documents']=m['documents'][:1]
    apply_application_document_order(m)
    assert m['document_order']['unresolved_document_ids']==['10:7']
    assert m['document_order']['status']=='partial_application_references'
    assert m['document_paragraph_ids']==['21:10','21:30']
    validate_application_document_order(m)


@pytest.mark.parametrize('target',['documents','paragraphs','visual','audit'])
def test_export_guard_rejects_order_drift(target):
    m=fixture();apply_application_document_order(m)
    m['visual']={'document_paragraph_ids':m['document_paragraph_ids'][:]}
    if target=='documents':m['documents'].reverse()
    elif target=='paragraphs':m['document_paragraph_ids'].reverse()
    elif target=='visual':m['visual']['document_paragraph_ids'].reverse()
    else:m['document_order']['referenced_document_ids'].reverse()
    with pytest.raises(ValueError):validate_application_document_order(m)


def test_single_document_keeps_its_sections_and_paragraphs_in_place():
    m=fixture();m['documents']=m['documents'][:1]
    m['applications'][0]['document_ids']=['10:3'];m['document_paragraph_ids']=['21:10','21:30']
    before=copy.deepcopy(m);apply_application_document_order(m)
    assert not m['document_order']['changed']
    assert m['documents']==before['documents'] and m['document_paragraph_ids']==before['document_paragraph_ids']


@pytest.fixture(scope='module')
def weblure():
    path=Path(os.environ.get('PUB_WEBLURE','__not_available__'))
    if not path.is_file():pytest.skip('Client WEBLURE not supplied')
    assert hashlib.sha256(path.read_bytes()).hexdigest()=='45ff5ce41fefac5b7fd02c63a956fc180eba2d3fea6c06d3d252335b3b4e2621'
    from retro.parser import analyze
    return analyze(path)


def test_weblure_order_is_propagated_to_the_visual_model(weblure):
    expected=['10:4001','10:3999','10:4052','10:4051']
    assert weblure['applications'][0]['document_ids']==expected
    assert [d['id'] for d in weblure['documents']]==expected
    known={p['id'] for p in weblure['paragraphs']}
    paragraphs=list(dict.fromkeys(p for d in weblure['documents'] for p in d['paragraph_ids'] if p in known))
    assert weblure['document_paragraph_ids']==paragraphs
    assert weblure['visual']['document_paragraph_ids']==paragraphs
    assert len(paragraphs)==53 and len(weblure['rules'])==274
    assert weblure['unresolved_document_paragraph_ids']==['21:38941']  # Existing undecoded reference retained.
    validate_application_document_order(weblure)


def test_weblure_pdf_body_and_visual_renderer_follow_application_order(weblure,tmp_path,monkeypatch):
    from retro.export import export
    from retro.visual_render import VisualRenderer
    paragraphs={p['id']:p for p in weblure['paragraphs']}
    markers=[paragraphs[d['paragraph_ids'][0]]['name'] for d in weblure['documents']]
    actual=[];original=VisualRenderer.clean_section
    def trace(self,pid):
        actual.append(pid);return original(self,pid)
    monkeypatch.setattr(VisualRenderer,'clean_section',trace)
    paths=export(weblure,tmp_path,chapters=[])
    text=''.join(''.join(p.extract_text().split()) for p in PdfReader(paths['rapport.pdf']).pages)
    chapter='1.Vuedétaillée'
    # The first occurrence is in the contents list; the second starts the body.
    body=text.split(chapter,2)[2].split('2.Miseenformedestableaux',1)[0]
    positions=[body.index(''.join(name.split())) for name in markers]
    assert positions==sorted(positions)
    assert actual==VisualRenderer(weblure['visual']).projection()[0]
    assert actual[0]==weblure['documents'][0]['paragraph_ids'][0]
