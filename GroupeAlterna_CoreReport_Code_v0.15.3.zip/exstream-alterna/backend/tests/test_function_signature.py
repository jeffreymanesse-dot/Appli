import copy
from pathlib import Path
import struct
import pytest
from pypdf import PdfReader
from retro.binary import MARKER
from retro.function_signature import ENVELOPE,read_signature,signature_lines,code_zone
from retro.render import report
from test_latest_bulletin_package import latest_bulletin


def declaration(kind=0,return_type=0,args=()):
    prefix=b'\0'*20;header=MARKER+struct.pack('<7I',103,100,kind,return_type,0,0,len(args))
    payload=b''
    for name,dtype,array,optional in args:
        raw=name.encode('ascii')
        payload+=struct.pack('<I',101)+bytes([len(raw)])+raw+struct.pack('<4I',1,dtype,array,optional)+b'\0'+MARKER
    data=prefix+ENVELOPE+header+payload+struct.pack('<I',1)+b'\0'*16
    d={'offset':0,'name_end':20,'class_code':159,'end':len(data)}
    return data,d


@pytest.mark.parametrize('kind,return_type,expected',[(0,0,'String'),(0,1,'Integer'),(0,2,'Boolean'),(1,1,None)])
def test_native_kind_and_return_type_not_an_inferred_value(kind,return_type,expected):
    data,d=declaration(kind,return_type);s=read_signature(data,d,len(data))
    assert s['return_type']==expected
    assert s['kind']==('Function' if kind==0 else 'Subroutine')
    lines=signature_lines({'design_signature':s})
    assert not any('Arguments' in x for x in lines)
    assert lines==(['Type de retour : '+expected] if expected else [])


def test_counted_arguments_keep_order_names_types_arrays_and_optionality():
    data,d=declaration(args=[('values',0,1,0),('count',1,0,0),('when',4,0,1),('enabled',2,0,1)])
    s=read_signature(data,d,len(data));lines=signature_lines({'design_signature':s})
    assert lines==['Arguments en entrée :','values : String[]','count : Integer','when : Date (facultatif)',
                  'enabled : Boolean (facultatif)','Type de retour : String']


@pytest.mark.parametrize('damage',['envelope','kind','return_type','return_array','count','name','arg_type','optional','terminator','boundary'])
def test_unknown_or_truncated_properties_never_publish_a_signature(damage):
    data,d=declaration(args=[('input',0,0,0)]);data=bytearray(data);p=64;q=p+32;end=q+10;stop=len(data)
    if damage=='envelope':data[20]=1
    elif damage=='kind':struct.pack_into('<I',data,p+12,2)
    elif damage=='return_type':struct.pack_into('<I',data,p+16,77)
    elif damage=='return_array':struct.pack_into('<I',data,p+24,77)
    elif damage=='count':struct.pack_into('<I',data,p+28,2)
    elif damage=='name':data[q+5]=ord('!')
    elif damage=='arg_type':struct.pack_into('<I',data,end+4,77)
    elif damage=='optional':struct.pack_into('<I',data,end+12,77)
    elif damage=='terminator':data[end+17]=0
    else:stop=end+2
    assert read_signature(bytes(data),d,stop) is None


def test_missing_signature_never_falls_back_to_compiled_reads_or_writes():
    c={'source_code':'COMPILED','read_names':['FAKE_INPUT'],'write_names':['FAKE_OUTPUT']}
    assert signature_lines(c)==[] and code_zone(c)=='Logic'
    assert code_zone({'result_variable_id':'35:1'})=='Formula'


def test_latest_native_declarations_cover_functions_and_subroutines(latest_bulletin):
    c={c['definition_name']:c for c in latest_bulletin['calculations']}
    assert c['DF_FCT_APPLI_get']['design_signature']['kind']=='Subroutine'
    assert signature_lines(c['DF_FCT_APPLI_get'])==['Arguments en entrée :','argMd_key : String']
    assert signature_lines(c['DF_FCT_COPY_init'])==[]
    assert signature_lines(c['DF_FCT_COPY_counterOnGoingDependingOnRecipient'])==[
        'Arguments en entrée :','argMd_recipientNumber : Integer','Type de retour : Integer']
    assert signature_lines(c['DF_FCT_title_build'])==['Arguments en entrée :',
        'argOp_typeOfTitle : String (facultatif)','argOp_forcedKey : String (facultatif)']
    assert all('design_signature' in x for x in c.values() if x['id'].startswith('function'))
    assert all('design_signature' not in x for x in c.values() if x.get('result_variable_id'))


@pytest.mark.parametrize('fallback',[False,True])
def test_report_chapter_prints_logic_formula_without_dependency_lists(latest_bulletin,tmp_path,fallback):
    m=copy.deepcopy(latest_bulletin)
    names={'DF_FCT_APPLI_get','DF_FCT_distributeurOrias_ML_build','DF_FCT_COPY_counterOnGoingDependingOnRecipient'}
    formula=next(c for c in m['calculations'] if c.get('result_variable_id'))
    m['calculations']=[c for c in m['calculations'] if c.get('definition_name') in names or c['id']==formula['id']]
    m['document_calculation_ids']=[c['id'] for c in m['calculations']];m['reference_chains']=[]
    if fallback:
        m['document_paragraph_ids']=[];m['content_variable_ids']=[formula['result_variable_id']]
        m['rules']=[];m['content_units']=[];m['repeat_candidates']=[]
    target=tmp_path/'report.pdf';report(m,target,chapters=['valuation'])
    text='\n'.join(p.extract_text() for p in PdfReader(target).pages)
    assert 'Lectures :' not in text and 'Écritures :' not in text
    assert 'Formula' in text and '_functions[' not in text and 'UserLogic.' not in text
    if not fallback:
        assert 'Logic' in text and 'Type de retour : Integer' in text
        assert 'argMd_key : String' in text
