"""Cover identity, escaping and pagination must not alter evidence or content."""
import copy

import pytest
from pypdf import PdfReader

from retro.compare import compare
from retro.parser import analyze
from retro.render import report


def model_from_package(package, tmp_path):
    source = tmp_path / 'UNRELATED_FILENAME.pub'
    source.write_bytes(package)
    return analyze(source)


@pytest.mark.parametrize('language', ['fr', 'en'])
def test_cover_uses_decoded_name_and_body_still_starts_at_one(package, tmp_path, language):
    model = model_from_package(package, tmp_path)
    name = 'APP_Origine_Épargne_&_Contrat<2026>'
    model['applications'] = [{'id': '1:1', 'name': name, 'document_ids': []}]
    before = copy.deepcopy(model)
    path = tmp_path / 'report.pdf'
    report(model, path, language=language, chapters=[])
    pdf = PdfReader(path)
    assert [line.strip() for line in pdf.pages[0].extract_text().splitlines()] == ['Core Report', name]
    assert 'UNRELATED_FILENAME' not in pdf.pages[0].extract_text()
    assert 'Core Report' in pdf.metadata.title
    assert len(pdf.pages[0].images) == 2  # Original background and complete logo.
    body = pdf.pages[1].extract_text()
    assert ('Technical reverse documentation' if language == 'en' else 'Rétro-documentation technique') in body
    assert body.splitlines()[1] == '1'  # Page number is emitted with the header.
    assert model == before


def test_unknown_application_is_not_invented_from_filename(package, tmp_path):
    model = model_from_package(package, tmp_path)
    path = tmp_path / 'report.pdf'
    report(model, path, language='en', chapters=[])
    cover = PdfReader(path).pages[0].extract_text()
    assert 'Application name not decoded' in cover
    assert 'UNRELATED_FILENAME' not in cover


def test_long_names_and_comparison_keep_all_source_identities(package, tmp_path):
    a = model_from_package(package, tmp_path)
    b = copy.deepcopy(a)
    names = ['APP_' + 'ORIGINE_EXACTE_' * 13, 'APP_Deuxième_Application']
    a['applications'] = [{'id': '1:1', 'name': names[0], 'document_ids': []}]
    b['applications'] = [{'id': '1:2', 'name': names[1], 'document_ids': []}]
    path = tmp_path / 'comparison.pdf'
    report(compare(a, b), path, language='en')
    pdf = PdfReader(path)
    cover = ''.join(pdf.pages[0].extract_text().split())
    assert all(name in cover for name in names)
    assert cover.index(names[0]) < cover.index(names[1])
    assert 'Package comparison' in pdf.pages[1].extract_text()
