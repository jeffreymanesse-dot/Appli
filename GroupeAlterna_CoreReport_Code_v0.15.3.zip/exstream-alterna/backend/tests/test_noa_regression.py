from pathlib import Path
from copy import deepcopy
import struct
import pytest
from retro.parser import analyze
from retro.component_properties import paragraph_global_rules
from retro.layout import counted_table_containers, inspect_cell_spans
from retro.scopes import decode_scopes
from retro.report_structure import content_markup, block_rules, conditional_axes

@pytest.fixture(scope="module")
def noa():
    path=Path(__file__).resolve().parents[3]/"project_sources/AFR_GENERIC_IARD_VEHIC_NOA_DEVIS.pub"
    if not path.exists():pytest.skip("Client NOA corpus unavailable")
    return path.read_bytes(),analyze(path)

def test_global_paragraph_rule_is_structural_not_nearest_number(noa):
    data,m=noa
    p=next(p for p in m["paragraphs"] if p["id"]=="21:25233")
    assert p["global_rule_ids"]==[524781]
    assert p["global_rule_property"]["offset"]==4556914
    r=next(r for r in m["rules"] if r["compiled_id"]==524781)
    assert r["variants"][0]["name"]=="DF_RUL_pdf"
    assert any(a["kind"]=="paragraph_global" and a["paragraph_id"]==p["id"] for a in r["associations"])
    assert not next(p for p in m["paragraphs"] if p["id"]=="21:29078").get("global_rule_ids")
    raw=bytearray(data);struct.pack_into("<I",raw,4556866+200,119)
    clean=deepcopy(m)
    for p in clean["paragraphs"]:p.pop("global_rule_ids",None)
    paragraph_global_rules(bytes(raw),clean)
    assert not next(p for p in clean["paragraphs"] if p["id"]=="21:25233").get("global_rule_ids")

def test_bullets_and_design_values_are_decoded_with_variable_directory(noa):
    _,m=noa;u=next(u for u in m["content_units"] if u["id"]=="text:4743194")
    assert "richtext" in u and len(u["richtext"]["paragraphs"])==16
    assert len(u["rule_targets"])==25
    assert len(u["variable_names"])==4
    markup=content_markup(u,{r["compiled_id"]:r["document_id"] for r in m["rules"]})
    assert "[DF_FIC_BD_pAC_driverPartner_driverPartner_givenName]" in markup
    assert "[WRK_AFR_IAR_IARD_VEHIC_NOA_AFFICHE_CONDUCTEURS_OCCASIONNELS]" in markup
    assert "Céline MAISSENER" not in markup and "givenName1" not in markup and "surName1" not in markup
    assert markup.count("<br/>")>=12

def test_unknown_scope_keeps_independently_proven_variable_name(noa):
    data,m=noa;u=deepcopy(next(u for u in m["content_units"] if u["id"]=="text:4743194"))
    raw=bytearray(data);struct.pack_into("<I",raw,u["richtext"]["paragraphs"][1]["targeting_field_offset"],999)
    u["parts"]=u.pop("serialized_parts");u.pop("richtext");u.pop("rule_targets");u.pop("global_rule_ids",None)
    subset={"rules":[],"variables":m["variables"],"content_units":[u],"metadata":{},"unknowns":[]}
    # Preserve rule identities but avoid unrelated rule occurrences during this unit check.
    subset["rules"]=[dict(r,target_candidates=[],associations=[]) for r in m["rules"]]
    decode_scopes(bytes(raw),subset)
    assert u.get("scope_decode_issue") and u.get("text_structure") and not u.get("rule_targets")
    assert "Céline MAISSENER" not in content_markup(u) and "#B42318" not in content_markup(u)

def test_nested_table_counts_and_cell_ownership_are_independent(noa):
    data,m=noa;p=next(p for p in m["paragraphs"] if p["id"]=="21:40824")
    grids=[t for t in m["tables"] if t["paragraph_id"]==p["id"]]
    root=next(t for t in grids if not t.get("parent_table_id"))
    assert (len(root["columns"]),len(root["rows"]))==(7,19)
    assert len(grids)==7
    child=next(t for t in grids if t.get("start")==5012737)
    assert child["parent_table_id"]==root["id"] and child["parent_cell"]["row"]==9 and child["parent_cell"]["column"]==0
    title=next(c for c in root["cells"] if c.get("content_id")=="text:4920707")
    assert title["column_span"]==5
    raw=bytearray(data);struct.pack_into("<I",raw,5012737+4,4)
    assert counted_table_containers(bytes(raw),p["offset"],p["end"])==[]
    raw=bytearray(data);struct.pack_into("<I",raw,title["offset"]+21,100)
    clean=deepcopy(root)
    for c in clean["cells"]:c.pop("column_span",None)
    inspect_cell_spans(bytes(raw),{"tables":[clean]})
    assert not next(c for c in clean["cells"] if c.get("content_id")=="text:4920707").get("column_span")

def test_block_recap_is_unique_and_plain_axes_are_omitted(noa):
    _,m=noa;ids=block_rules(m,"21:40201")
    assert len(ids)==len(set(ids)) and 781439 in ids
    assert 781443 in ids
    for t in m["tables"]:
        for axis in ("rows","columns"):
            assert all(x.get("rule_id") or x.get("repeat") for x in conditional_axes(t,axis))

def test_line_break_inside_literal_token_is_preserved():
    u={"parts":[{"text":"PremièreSeconde","kind":"text","offset":0}],
       "text_structure":{"paragraphs":[{"start":0},{"start":8}],"design_length":15}}
    assert content_markup(u)=="Première<br/>Seconde"
