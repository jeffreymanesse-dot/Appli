import time
from fastapi.testclient import TestClient
from retro.api import app
from retro.jobs import run_job,purge
from retro.db import Session,Job,transaction

def submit(c,package,mode='analyze'):
    files={'file_a':('synthetic.pub',package,'application/octet-stream')}
    if mode=='compare':files['file_b']=('new.pub',package,'application/octet-stream')
    return c.post('/api/jobs',data={'mode':mode},files=files)

def test_analysis_refresh_and_download(client,package):
    r=submit(client,package);assert r.status_code==202;jid=r.json()['id']
    run_job(jid)
    status=client.get('/api/jobs/'+jid).json();assert status['state']=='termine' and status['summary']['partial']
    # Refresh fetches the same task; no second POST/upload needed.
    assert client.get('/api/jobs/'+jid).json()['inputs'][0]['name']=='synthetic.pub'
    links=client.post(f'/api/jobs/{jid}/links').json()['links'];assert {l['name'] for l in links}=={'rapport.pdf','visuel.pdf'}
    for link in links:
        assert client.get(link['url']).content.startswith(b'%PDF')
        assert client.get(link['url'].replace('signature=','signature=bad')).status_code==403
    pdf=links[-1]
    with TestClient(app) as other:
        other.headers['X-Alterna-Request']='1';other.post('/api/session')
        assert other.get('/api/jobs/'+jid).status_code==404
        assert other.get(pdf['url']).status_code==404

def test_comparison(client,package):
    r=submit(client,package,'compare');assert r.status_code==202;jid=r.json()['id'];run_job(jid)
    j=client.get('/api/jobs/'+jid).json();assert j['state']=='termine' and len(j['outputs'])==5
    assert j['summary']['counts']['modifié']==0

def test_invalid_and_size_and_filename(client,package):
    assert submit(client,b'not a pub').status_code==422
    assert submit(client,package+b'0'*17000).status_code==413
    assert client.post('/api/jobs',data={'mode':'analyze'},files={'file_a':('../bad.pub',package)}).status_code==422
    assert client.post('/api/jobs',data={'mode':'compare'},files={'file_a':('ok.pub',package)}).status_code==422

def test_cancel_queued_job(client,package):
    jid=submit(client,package).json()['id']
    assert client.post(f'/api/jobs/{jid}/cancel').status_code==200
    run_job(jid);j=client.get('/api/jobs/'+jid).json();assert j['state']=='annule' and not j['outputs']

def test_failure_redacted(client,package,monkeypatch):
    import retro.jobs as jobs
    jid=submit(client,package).json()['id']
    def fail(*a,**k):raise ValueError('/server/private/customer-sensitive-data')
    monkeypatch.setattr(jobs,'analyze',fail);run_job(jid)
    r=client.get('/api/jobs/'+jid);assert r.json()['state']=='echec' and 'customer-sensitive-data' not in r.text

def test_expired_links_and_purge(client,package):
    jid=submit(client,package).json()['id'];run_job(jid)
    link=client.post(f'/api/jobs/{jid}/links').json()['links'][0]['url']
    with transaction() as db:db.get(Job,jid).expires=time.time()-1
    assert client.get(link).status_code==410
    assert client.get('/api/jobs/'+jid).json()['state']=='expire'
    assert purge()>=1
    with Session() as db:assert db.get(Job,jid).inputs==[]

def test_csrf_and_unauthenticated(package):
    with TestClient(app) as c:
        assert c.post('/api/session').status_code==403
        c.headers['X-Alterna-Request']='1';c.headers['Origin']='https://evil.invalid'
        assert c.post('/api/session').status_code==403
        assert c.get('/api/jobs/'+'a'*48).status_code==401

def test_body_limit(client):
    assert client.post('/api/jobs',headers={'Content-Length':str(100*1024*1024)}).status_code==413
