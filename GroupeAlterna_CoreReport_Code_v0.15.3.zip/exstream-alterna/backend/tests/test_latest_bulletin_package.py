from pathlib import Path
import hashlib
import pytest
from retro.parser import analyze


@pytest.fixture(scope='module')
def latest_bulletin():
    source = Path(__file__).resolve().parents[4] / 'upload/AFR_EPI_NOE_BULLETIN_VERSEMENT.pub'
    if not source.exists():
        pytest.skip('Latest user-provided Bulletin package is not present')
    if hashlib.sha256(source.read_bytes()).hexdigest() != '99bc04e0aa443034dadfab2a5598ac73bdde3411e5e3ce1ab7806bd6ccb45520':
        pytest.skip('Different Bulletin package version')
    return analyze(source)


def test_header_repeating_footer_and_automated_rows(latest_bulletin):
    table = next(t for t in latest_bulletin['tables'] if t['id'] == 'grid:21:43718')
    rows = table['rows']
    assert [(r['index'] + 1, r['row_type_code'], r['row_type_label']) for r in rows[3:10]] == [
        (4, 4, 'Repeating header (H+)'),
        (5, 1, 'Automated row — repeating on defined criteria (R)'),
        (6, 1, 'Automated row — repeating on defined criteria (R)'),
        (7, 1, 'Automated row — repeating on defined criteria (R)'),
        (8, 1, 'Automated row — repeating on defined criteria (R)'),
        (9, 3, 'Footer (F)'), (10, 5, 'Repeating footer (F+)')]
    assert [r['automation_driver_name'] for r in rows[4:8]] == [
        'DF_FIC_SD_NOE_gest_supEuro_supEuroNom',
        'DF_FIC_SD_NOE_gest_fdCrois_fdCroisNom',
        'DF_FIC_SD_NOE_gest_suppUC_suppUCMontant',
        'DF_FIC_SD_NOE_gest_supSpe_supSpeMnt']
    assert rows[3]['rule_id'] == 792469 and rows[8]['rule_id'] == 792470
    assert rows[7]['rule_id'] is None and rows[7]['source_rule_reference_candidate'] == 790289
    assert rows[9].get('rule_id') is None


def test_shared_input_sections_and_system_variables(latest_bulletin):
    assert len(latest_bulletin['data_sections']) == 39
    assert latest_bulletin['used_data_sections'] == []
    assert all(v['origin_class'] == 'system' for v in latest_bulletin['variables']
               if v['name'].startswith('SYS_'))
