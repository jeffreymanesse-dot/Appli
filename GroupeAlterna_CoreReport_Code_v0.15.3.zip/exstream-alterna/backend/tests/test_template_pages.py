"""Native Page regression, corruption guards and optional PDF assembly."""
import copy
import json
from pathlib import Path
import re
import struct

import fitz
import pytest
from pypdf import PdfReader
from retro.i18n import use_language
from retro.page_layout import decode_page_layouts, selected_pages, object_frame, jpeg_resources
from retro.report_pages import appendix_rule_ids, existing_rule_ids, build_page_appendix, PT
from retro.report_options import normalize_chapters
from retro.render import report
from retro.rule_labels import rule_algorithms
from test_latest_bulletin_package import latest_bulletin


@pytest.fixture(scope='module')
def native_bytes():
    p=Path(__file__).resolve().parents[4]/'upload/AFR_EPI_NOE_BULLETIN_VERSEMENT.pub'
    if not p.exists():pytest.skip('Latest user package unavailable')
    return p.read_bytes()


def test_counted_geometry_images_rotation_and_overlaps(latest_bulletin):
    pages=selected_pages(latest_bulletin)
    assert [p['name'] for p in pages]==['DF_PAG_MAIN_withoutCtcGutAdr_BR','DF_PAG_FLOW_standard_BR']
    assert [len(p['objects']) for p in pages]==[22,5]
    assert all(p['status']=='decoded' and p['size_raw']==[2480,3508] for p in pages)
    assert all(o['status']=='decoded' for p in pages for o in p['objects'])
    main,flow=pages
    assert main['objects'][7]['rect_raw']==[2398,2717,2476,3166]
    assert main['objects'][7]['rotation']==main['objects'][16]['rotation']==-90
    assert main['objects'][17]['rect_raw']==main['objects'][18]['rect_raw']==[2339,3047,2457,3331]
    assert main['objects'][17]['name']!=main['objects'][18]['name']
    assert flow['objects'][0]['rect_raw'][:2]==flow['objects'][2]['rect_raw'][:2]==[154,3236]
    assert main['objects'][10]['images'][0]['rect_raw']==[2207,3071,2326,3189]
    assert main['objects'][11]['name']=='DF_CMP_BOT_APRS'
    assert main['objects'][11]['rotation'] is None
    resources=latest_bulletin['page_layouts']['resources']
    assert {r['name']:r['pixels'] for r in resources.values()}=={'S1FLECBR':[119,118],'S1LOAPRS':[368,216]}
    assert all(p['template_status']=='unresolved' for p in pages)


def test_decoder_leaves_previous_model_and_numbering_unchanged(latest_bulletin,native_bytes):
    model=copy.deepcopy(latest_bulletin);expected=model.pop('page_layouts')
    before=copy.deepcopy(model)
    assert decode_page_layouts(native_bytes,model)==expected
    assert model.pop('page_layouts')==expected and model==before
    model['metadata']['source_name']='arbitrary-name.pub'
    assert decode_page_layouts(native_bytes,model)==expected


@pytest.mark.parametrize('field,delta',[(80,1),(44,1),(28,1)])
def test_incoherent_page_counter_size_or_unit_is_rejected(latest_bulletin,native_bytes,field,delta):
    model=copy.deepcopy(latest_bulletin)
    p=next(p for p in model['page_components'] if p['name']=='DF_PAG_MAIN_withoutCtcGutAdr_BR')
    data=bytearray(native_bytes);at=p['owner_offset']+field
    struct.pack_into('<I',data,at,struct.unpack_from('<I',data,at)[0]+delta)
    decode_page_layouts(bytes(data),model)
    damaged=next(p for p in selected_pages(model) if p['name']=='DF_PAG_MAIN_withoutCtcGutAdr_BR')
    assert damaged['status']=='uninterpreted' and damaged['objects']==[]
    assert selected_pages(model)[1]['status']=='decoded'


@pytest.mark.parametrize('relative,value',[(120,0),(152,90),(172,600),(104,99999)])
def test_frame_requires_matching_polygon_rotation_and_units(latest_bulletin,native_bytes,relative,value):
    o=selected_pages(latest_bulletin)[0]['objects'][0]
    data=bytearray(native_bytes);struct.pack_into('<i',data,o['record_offset']+relative,value)
    assert object_frame(bytes(data),o['record_offset'],o['record_end'],o['type_code']) is None


def test_corrupt_jpeg_is_not_replaced_with_external_artwork(latest_bulletin,native_bytes):
    r=latest_bulletin['page_layouts']['resources']['5']
    data=bytearray(native_bytes);data[r['evidence'][0]['offset_start']+20]=0
    assert 5 not in jpeg_resources(bytes(data))
    model=copy.deepcopy(latest_bulletin);decode_page_layouts(bytes(data),model)
    image=selected_pages(model)[0]['objects'][11]['images'][0]
    assert image['status']=='resource_unresolved' and image['resource_id'] is None
    assert image['rect_raw']==[1012,3000,1380,3216]


@pytest.fixture(scope='module')
def appendix_pdf(latest_bulletin,tmp_path_factory):
    path=tmp_path_factory.mktemp('pages')/'appendix.pdf'
    build_page_appendix(latest_bulletin,path)
    return path


def test_plans_are_native_scale_with_all_frames_and_images(appendix_pdf,latest_bulletin):
    doc=fitz.open(appendix_pdf)
    assert len(doc)==8
    plans=[p for p in doc if 'Plan à l’échelle 1:1' in p.get_text()]
    assert len(plans)==2
    for pdf,page in zip(plans,selected_pages(latest_bulletin)):
        rectangles=[item[1] for d in pdf.get_drawings() for item in d['items'] if item[0]=='re']
        assert any(abs(r.width-2480*PT)<.01 and abs(r.height-3508*PT)<.01 for r in rectangles)
        # Every record, including the exactly coincident Triman pair, is drawn.
        available=list(rectangles)
        for o in page['objects']:
            x,y,r,b=o['rect_raw']
            found=next((i for i,v in enumerate(available) if abs(v.width-(r-x)*PT)<.01 and abs(v.height-(b-y)*PT)<.01),None)
            assert found is not None,o['name']
            available.pop(found)
    image_rects=[r for info in plans[0].get_images(full=True) for r in plans[0].get_image_rects(info[0])]
    for w,h in [(119,118),(368,216)]:
        assert any(abs(r.width-w*PT)<.01 and abs(r.height-h*PT)<.01 for r in image_rects)


def test_appendix_deduplicates_rules_and_content_and_keeps_native_code(appendix_pdf,latest_bulletin):
    pages=selected_pages(latest_bulletin);ids=set(appendix_rule_ids(pages));existing=existing_rule_ids(latest_bulletin)
    assert len(ids&existing)==12 and len(ids-existing)==6
    text='\n'.join(p.get_text() for p in fitz.open(appendix_pdf))
    compact=lambda s:re.sub(r'\s','',s)
    for r in latest_bulletin['rules']:
        if r['compiled_id'] in ids-existing:
            for _,code in rule_algorithms(r):assert compact(code) in compact(text)
    assert 'Contenu et style : voir P1.09' in text and 'Contenu et style : voir P1.07' in text
    for forbidden in ('UserLogic.',"_rules['",'SHA-256','offset','Source de conception'):
        assert forbidden not in text


def test_opt_out_removes_annex_and_keeps_original_attachment(latest_bulletin,tmp_path):
    on=tmp_path/'on.pdf';off=tmp_path/'off.pdf'
    report(latest_bulletin,on);report(latest_bulletin,off,chapters=['valuation','input_dictionary','reconstruction'])
    a=PdfReader(on);b=PdfReader(off)
    assert len(a.pages)==len(b.pages)+8
    assert a.attachments['Sources_de_conception.zip']==b.attachments['Sources_de_conception.zip']
    assert not any('Template et Page' in p.extract_text() for p in b.pages)
    assert 'Annexe - Template et Page' in a.pages[len(b.pages)].extract_text()
    assert a.outline[-1]['/Title']=='Annexe - Template et Page'
    assert normalize_chapters(['valuation','input_dictionary','reconstruction'])==('valuation','input_dictionary','reconstruction')


def test_english_appendix_preserves_model_and_native_names(latest_bulletin,tmp_path):
    before=json.dumps(latest_bulletin,sort_keys=True)
    path=tmp_path/'en.pdf'
    with use_language('en'):build_page_appendix(latest_bulletin,path)
    text='\n'.join(p.get_text() for p in fitz.open(path))
    assert 'Appendix - Template and Page' in text and 'Plan at 1:1 scale' in text
    assert 'DF_PAG_MAIN_withoutCtcGutAdr_BR' in text
    assert 'Objets de page' not in text and 'Superpositions conservées' not in text
    assert json.dumps(latest_bulletin,sort_keys=True)==before
