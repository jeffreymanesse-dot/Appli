"""Optional corpus checks against independently recorded binary observations.
The fixture is client-owned and is not distributed with application code.
"""
from pathlib import Path
import hashlib
import pytest
from retro.parser import analyze

@pytest.fixture(scope='module')
def versement():
    source=Path(__file__).resolve().parents[3]/'project_sources/04-AFR_EPI_NOE_BULLETIN_VERSEMENT.pub'
    if not source.exists():pytest.skip('Client PUB not available')
    if hashlib.sha256(source.read_bytes()).hexdigest()!='f23ca63a540159156cc72f63277b238bf656751f1035791fae294b65b21f0877':pytest.skip('Different corpus version')
    return analyze(source)


def test_section_identity_and_grid_order(versement):
    m=versement
    assert m['document_paragraph_ids']==['21:43432','21:43433','21:43434','21:43435','21:43709','21:43712','21:43718','21:44200']
    situation=next(t for t in m['tables'] if t['id']=='grid:21:43435')
    assert len(situation['columns'])==2 and len(situation['rows'])==2
    byoff={u['offset']:u for u in m['content_units']}
    assert byoff[4443394]['document_order'][-2:]==[15,0] # Table path precedes cell coordinates.
    assert byoff[4446952]['document_order'][-2:]==[2,0]
    assert byoff[4394191]['document_order'][-2:]==[1,1] # Contract ID beside name, before dispositions.
    assert byoff[4583621]['grid_position']=={'row':6,'column':2} # Packed style header.


def test_row_rules_and_repeat_drivers(versement):
    m=versement;main=set(m['document_paragraph_ids'])
    reps=[x for x in m['repetitions'] if x['table_id']=='grid:21:43718']
    assert [(r['row'],r['driver_internal_id']) for r in reps]==[(4,107948),(5,107953),(6,108184),(7,107600)]
    assert len(m['document_rule_ids'])>=29
    assert {x['compiled_id'] for x in m['page_analysis']['rule_uses']} <= set(m['document_rule_ids'])
    assert 777282 in m['document_rule_ids']  # Explicit document condition, newly decoded.
    rule=next(r for r in m['rules'] if r['compiled_id']==781329)
    assoc=next(a for a in rule['associations'] if a['paragraph_id'] in main)
    assert assoc['kind']=='grid_row' and assoc['row']==2
    inline=next(r for r in m['rules'] if r['compiled_id']==790284)
    assert inline['associations'][0]['content_id']=='text:4377580'
    assert inline['associations'][0]['kind']=='text_paragraph'
    assert inline['associations'][0]['target_fragment_text']=='N° Orias : DF_FIC_CD_DIST_oriasList'


def test_reference_provenance_keeps_unexecuted_lookup(versement):
    chain=next(x for x in versement['reference_chains'] if x['variable_id']=='35:88342')
    assert chain['reference_source']=='DF_REF_DIST' and chain['provider_calculation_ids']==['function918']
    function=next(c for c in versement['calculations'] if c['id']=='function918')
    assert function['source_expression'] and function['definition_name']=='DF_FCT_DIST_get'
    assert [x['source_name'] for x in function['triggers']]==['DF_REF_DIST_keys','DF_REF_DIST']


def test_valuation_algorithm_with_indirect_formula_result_is_not_lost(versement):
    m=versement
    assert 'formula107407' in m['document_calculation_ids']
    v=next(v for v in m['variables'] if v['name']=='WRK_AFR_EPI_NOE_BV_typeCourrier')
    assert any(x['calculation_id']=='formula107407' for x in v['valuation_sites'])
