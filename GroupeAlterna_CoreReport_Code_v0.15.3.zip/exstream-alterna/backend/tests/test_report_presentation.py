import copy
import hashlib
from io import BytesIO
import json
import re
from zipfile import ZipFile

import fitz
import pytest
from pypdf import PdfReader

from retro.design_source import condition_presentation
from retro.i18n import use_language
from retro.render import report
from retro.report_inventory import inventory_rows
from retro.rule_labels import rule_algorithms
from retro.visual_render import VisualRenderer
from test_latest_bulletin_package import latest_bulletin


@pytest.mark.parametrize('dtype,value,literal',[
    ('String','true','"true"'),('String','false','"false"'),
    ('Boolean','true','true'),('Boolean','false','false'),
    ('String',' A "B" ','" A ""B"" "'),('String','','""'),
    ('Integer','007','007'),('Floating','-1.50','-1.50'),
])
def test_parameter_condition_keeps_native_type_and_literal(dtype,value,literal):
    d={'variable_name':'Native_name','operator':'=','value':value,'value_type':dtype}
    assert condition_presentation(d)==f'Condition paramétrée ({dtype})\nNative_name = {literal}'
    r={'variants':[{'design_condition':d,'compiled_code':'DO_NOT_DISPLAY',
                    'decoded_expression':'DO_NOT_INVENT_IF','effect_false':'DO_NOT_INVENT_ELSE'}]}
    assert rule_algorithms(r)==[('parameters',condition_presentation(d))]


@pytest.mark.parametrize('dtype,value',[(None,'raw'),('Date','01/02/2026'),('Boolean','1'),('Integer','1,2')])
def test_unverified_literal_formats_retain_fields_without_coercion(dtype,value):
    d={'variable_name':'Native_name','operator':'=','value':value,'value_type':dtype}
    text=condition_presentation(d)
    assert text.endswith('Valeur : '+value) and 'Condition paramétrée' not in text


def test_parameter_caption_translates_but_identifiers_and_values_do_not():
    d={'variable_name':'DF_name','operator':'=','value':'true','value_type':'String'}
    with use_language('en'):
        assert condition_presentation(d)=='Parameter condition (String)\nDF_name = "true"'


def test_latest_r3_r6_r7_have_distinct_native_value_types(latest_bulletin):
    for number,dtype,literal in [('R3','String','"true"'),('R6','String','"false"'),('R7','Boolean','true')]:
        r=next(r for r in latest_bulletin['rules'] if r['document_id']==number)
        v=r['variants'][0];d=v['design_condition']
        assert not v['source_expression']
        assert rule_algorithms(r)==[('parameters',f'Condition paramétrée ({dtype})\n'+d['variable_name']+' = '+literal)]


@pytest.fixture(scope='module')
def rendered(latest_bulletin,tmp_path_factory):
    out=tmp_path_factory.mktemp('presentation');m=copy.deepcopy(latest_bulletin)
    for v in m['variables']:v['usage_evidence']=[{'kind':'HIDDEN_USAGE_SENTINEL'}]
    fingerprint=lambda:hashlib.sha256(json.dumps(m,sort_keys=True).encode()).hexdigest()
    before=fingerprint();report(m,out/'report.pdf')
    VisualRenderer(m['visual']).render(out/'visual.pdf')
    assert fingerprint()==before
    return m,out


def test_report_removes_requested_sections_and_usage_and_keeps_only_inventory_table(rendered):
    m,out=rendered;doc=fitz.open(out/'report.pdf')
    text='\n'.join(p.get_text() for p in doc)
    for forbidden in ('Origine des variables de référence','Fiches des variables hors flux',
        'Contenus non rattachés','Règles sans rattachement au périmètre reconstruit',
        'Calculs et fonctions — inventaire complet','Variable / usages','Variable / usage',
        'HIDDEN_USAGE_SENTINEL','Lectures :','Écritures :','UserLogic.',"_rules['"):
        assert forbidden not in text
    last=next(p.get_text(clip=fitz.Rect(40,79,555,775)) for p in doc
              if p.get_text(clip=fitz.Rect(40,79,555,775)).startswith('6. Inventaire et limites de reconstruction'))
    expected='6. Inventaire et limites de reconstruction\nInventaire du package\n'
    expected+='\n'.join(value for row in inventory_rows(m) for value in row)
    compact=lambda value:re.sub(r'\s','',value)
    assert compact(last)==compact(expected)
    displayed=set(m['document_calculation_ids'])
    displayed.update(cid for chain in m['reference_chains'] for cid in chain['provider_calculation_ids'])
    assert len(displayed)==31 and len(m['rules'])==148


@pytest.mark.parametrize('filename',['report.pdf','visual.pdf'])
def test_actual_pdf_blue_matches_for_title_adviser_contract_and_fill(rendered,filename):
    _,out=rendered;doc=fitz.open(out/filename)
    spans=[s for page in doc for b in page.get_text('dict')['blocks'] for line in b.get('lines',[]) for s in line['spans']]
    for text in ('DEMANDE DE VERSEMENT COMPLÉMENTAIRE','[DF_REF_DIST_distributorFunction]',
                 'Prénom et Nom :','Nom du contrat :'):
        found=[s for s in spans if text in s['text']]
        assert found and all(s['color']==0x00008f for s in found),text
    fills=[d['fill'] for page in doc for d in page.get_drawings() if d.get('fill')]
    assert any(all(abs(a-b)<0.00001 for a,b in zip(rgb,(0,0,143/255))) for rgb in fills)


def test_attached_parameter_files_include_type_and_native_scripts_stay_exact(rendered,latest_bulletin):
    _,out=rendered
    with ZipFile(BytesIO(PdfReader(out/'report.pdf').attachments['Sources_de_conception.zip'][0])) as z:
        assert 'Type : String\n' in z.read('regles/R3_v1_parametres.txt').decode()
        assert 'Type : String\n' in z.read('regles/R6_v1_parametres.txt').decode()
        assert 'Type : Boolean\n' in z.read('regles/R7_v1_parametres.txt').decode()
        from retro.source_archive import original_bytes
        for r in latest_bulletin['rules']:
            for i,v in enumerate(r['variants'],1):
                if v.get('source_expression'):
                    assert z.read(f'regles/{r["document_id"]}_v{i}.bas')==original_bytes(v)
