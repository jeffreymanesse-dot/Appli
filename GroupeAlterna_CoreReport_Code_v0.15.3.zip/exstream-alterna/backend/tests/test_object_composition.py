import copy,struct
import pytest
from test_noa_regression import noa
from retro.object_composition import command,display_object,decode_compositions,Unresolved
from retro.visual_graphics import GraphicsDecoder
from retro.table_anchors import decode_table_anchors
from retro.visual_render import VisualRenderer
from retro.object_render import ObjectComposition

def test_three_inline_objects_and_source_glyphs(noa):
    data,m=noa;c=next(c for c in m['object_compositions'] if c['paragraph_id']=='21:29172')
    assert [o['kind'] for o in c['objects']]==['compiled_table','compiled_object','compiled_table']
    commands=[x for o in c['objects'] for x in o['commands']]
    texts=[x for x in commands if x['kind']=='text']
    assert [x['text'].strip() for x in texts]==['Vos avantages','(1)']
    assert [(x['font']['size'],x['font']['bold'],x['color']) for x in texts]==[(10,True,'#00008f'),(6,True,'#00008f')]
    assert len([x for x in commands if x['kind']=='polygon'])==2
    assert [x['rect'] for x in commands if x['kind']=='image']==[[700,30,765,95]]
    assert c['image_resources']=='unresolved'

@pytest.mark.parametrize('offset,value',[(6705586,8),(6705599,161),(6705747,0),(6707092,0xffffffff),(6704247,2)])
def test_corrupt_count_command_polygon_font_or_reference_is_rejected(noa,offset,value):
    data,m=noa;b=bytearray(data);struct.pack_into('<I',b,offset,value)
    probe={'paragraphs':[p for p in m['paragraphs'] if p['id']=='21:29172'],'variables':m['variables'],'rules':m['rules']}
    decode_compositions(bytes(b),probe);assert not probe['object_compositions']

def test_offset_shift_name_and_identity_do_not_select_profile(noa):
    data,m=noa;shift=317;probe={'paragraphs':[],'variables':m['variables'],'rules':m['rules']}
    p=copy.deepcopy(next(p for p in m['paragraphs'] if p['id']=='21:29172'))
    p.update(id='21:999',name='ANY_other_customer_document',offset=p['offset']+shift,end=p['end']+shift)
    probe['paragraphs']=[p];decode_compositions(b'X'*shift+data,probe)
    c=probe['object_compositions'][0];assert c['paragraph_id']=='21:999' and len(c['objects'])==3
    assert c['objects'][2]['commands'][5]['text'].strip()=='Vos avantages'

def test_synthetic_display_list_is_independent_of_client_bytes():
    from retro.binary import MARKER
    # Arbitrary text, font id, origin and package offset.
    text=b'Example';font=4321
    glyphs=b''.join(struct.pack('<ii',50+13*i,70)+bytes.fromhex('0100ff0000') for i in range(len(text)))
    cmd=struct.pack('<IBHH',160,1,len(text),len(text))+text+glyphs+struct.pack('<I',font)+b'\0'*2+struct.pack('<II',0x002211,0)+b'\0'*8
    prefix=b'unknown'*5+MARKER+struct.pack('<II',0,1);q=len(prefix)
    data=prefix+struct.pack('<4I',107,50,20,1)+b'\0'*9+cmd+b'\x10'+b'\0'*10+MARKER
    o=display_object(data,q,len(data),{str(font):{'name':'Generic','size':9}}, {})
    assert o['commands'][0]['text']=='Example' and o['commands'][0]['color']=='#112200'
    with pytest.raises(Unresolved):display_object(data[:-10],q,len(data)-10,{str(font):{}},{})

def test_font_switch_before_anchor_and_bad_switch(noa):
    data,m=noa;t=next(t for t in m['tables'] if t['paragraph_id']=='21:25366')
    assert t['inline_anchor']['paragraph_index']==0
    assert t['inline_anchor']['content_id']=='text:6607272'
    probe=copy.deepcopy(m);b=bytearray(data);struct.pack_into('<i',b,6607381,-999)
    for t in probe['tables']:t.pop('inline_anchor',None)
    decode_table_anchors(bytes(b),probe)
    assert not next(t for t in probe['tables'] if t['paragraph_id']=='21:25366').get('inline_anchor')

def test_typography_survives_unresolved_hyperlink_targeting(noa):
    _,m=noa;u=next(u for u in m['content_units'] if u['id']=='text:6611819')
    assert not u.get('richtext') and u.get('scope_decode_issue')
    gx=m['visual']['graphics']['units'][u['id']]
    assert gx['status']=='decoded' and all(f['size']==8 for f in gx['fonts'])
    assert not u.get('rule_targets')

def test_variants_are_visibly_separated_without_evaluation(noa):
    _,m=noa;r=VisualRenderer(m['visual'])
    text=''.join(getattr(x,'text','') for x in r.text_flow('text:6666233',300))
    assert '123' not in text and '[</font>' in text and '] </font>' in text
    assert all(x in text for x in ['>1<','>2<','>3<'])

def test_report_and_visual_share_composition_geometry(noa):
    _,m=noa;r=VisualRenderer(m['visual']);typ,key=r.entries_for('21:29172')[0]
    assert typ=='composition';flows=r.composition_flow(key,500)
    assert isinstance(flows[0],ObjectComposition)
    assert flows[0].width==pytest.approx(371.52) and flows[0].height==pytest.approx(15.6)
    assert 'literal:6706817' in r.PLACED
