# Groupe Alterna - Core Report 0.14.6

Cette version reprend la livraison complète 0.14.5 et traite les retours sur le dernier Bulletin de versement fourni le 8 octobre 2026.

## Installation

1. Conserver le fichier `.env` de l’installation et les volumes Docker.
2. Remplacer les fichiers du programme par le contenu du dossier `exstream-alterna` de l’archive.
3. Reconstruire avec `docker compose up -d --build` ou le lanceur Windows habituel.
4. Créer une nouvelle analyse du PUB. Les résultats antérieurs ne sont pas recalculés automatiquement.

Aucune migration destructive ni suppression de volume n’est requise.

## Changements visibles

- Structure de l’application allégée : documents, pages et sections, puis campagnes et leurs messages dans l’ordre enregistré.
- Suppression des remarques techniques demandées dans l’introduction et le sommaire. Les règles de composants n’encombrent plus l’arborescence.
- Titre du Bulletin restitué avec les caractères, la police, la taille, la couleur et le trait horizontal présents dans le package.
- Répétitions et types de lignes présentés auprès du paragraphe concerné.
- Chapitre 2 renommé « Mise en forme des tableaux », sans les deux paragraphes d’introduction, sans valeurs brutes ni positions binaires. Les lignes de bordure et de cellule sans propriété visuelle utile sont supprimées.
- Règles anonymes présentées comme « Règle non nommée ». Les règles restent distinctes par leur repère Rn et leur identité interne.

## Fidélité des algorithmes

Les scripts de conception présents sont reproduits sans réécriture. Quand seul le code compilé est disponible, le rapport affiche ce code en le désignant explicitement ; il ne le remplace plus par une reconstruction en pseudo-code.

Pour R22, R27, R28 et R29 du dernier Bulletin, le PUB fourni ne contient pas de script de conception textuel rattaché. Ses fonctions compilées contiennent bien une branche `else` avec `setInclude(..., 0)`. Elle est conservée dans cette vue compilée. Cela ne permet pas d’affirmer que le développeur avait écrit un `ELSE EXCLUDE` dans un script source.

Le détail des 22 points et des validations figure dans `docs/VALIDATION_RAPPORT_0.14.6.md`. Les preuves de décodage restent disponibles dans le modèle interne, sans afficher leurs positions dans le rapport client.
