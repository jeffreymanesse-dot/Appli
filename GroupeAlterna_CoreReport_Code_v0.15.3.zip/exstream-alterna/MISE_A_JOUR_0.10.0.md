# Mise à jour 0.10.0 — Français / English

Les drapeaux France et Royaume-Uni, en haut à droite, changent immédiatement la langue de l'interface. Le choix est conservé après actualisation.

## Langue des rapports

La langue sélectionnée **au lancement** est enregistrée avec l'analyse. Elle s'applique aux titres, rubriques, légendes et commentaires produits par le moteur, dans les deux PDF. La comparaison utilise également cette langue.

Les textes du `.pub`, les noms d'objets, variables et règles, les conditions, les algorithmes et les chemins XML restent dans leur langue d'origine. Aucune traduction automatique externe n'est utilisée.

Changer le drapeau ne réécrit pas les rapports déjà générés. Leur langue est indiquée dans les résultats ; relancez une analyse pour obtenir une autre langue. Les anciennes tâches sans langue enregistrée restent en français.

Les trois chapitres facultatifs et leur sélection sont conservés. Le style de l'interface et les ressources Groupe Alterna restent ceux de la version précédente.

## Mettre à jour une installation 0.9.0 ou 0.9.1

Utilisez **GroupeAlterna_MiseAJour_v0.10.0.zip**. Cette archive contient les fichiers à fusionner dans l'application existante, ainsi que le correctif de réservation d'espace 0.9.1. Ce n'est pas une installation autonome.

1. Attendez la fin des analyses en cours, puis sauvegardez le dossier de l'application.
2. Depuis votre dossier habituel `exstream-alterna`, arrêtez les services applicatifs :

   ```powershell
   docker compose stop api worker purge web
   ```

3. Décompressez l'archive de mise à jour. Copiez le **contenu** de son dossier `exstream-alterna` dans votre dossier `exstream-alterna` existant, en fusionnant les dossiers et remplaçant les fichiers fournis. Ne créez pas de dossier `exstream-alterna` supplémentaire à l'intérieur.
4. **Conservez votre `.env` actuel, le même dossier Compose et vos volumes.** L'archive de mise à jour ne contient aucun `.env` et ne change aucun mot de passe.
5. Dans ce même dossier, exécutez les commandes suivantes, une à une :

   ```powershell
   docker compose build api worker purge web
   docker compose up -d
   docker compose ps
   ```

6. Ouvrez `http://localhost:3000`, actualisez la page, choisissez FR ou EN, puis lancez une nouvelle analyse. Téléchargez les deux PDF et vérifiez leurs titres.

Si une commande échoue, conservez son message. Ne supprimez pas les volumes. Cette mise à jour ne demande aucune migration de schéma ni réinitialisation de base.

Si vous venez directement de 0.9.0 et rencontrez toujours « Espace réservé insuffisant », la procédure de réconciliation non destructive reste décrite dans `docs/VALIDATION_QUOTA_0.9.1.md`. Le changement de langue n'efface aucune analyse.

## Installation neuve

L'archive **GroupeAlterna_Exstream_Code_v0.10.0.zip** contient l'application complète. Son `.env` initial contient uniquement des marqueurs à initialiser, sans mot de passe partagé. Lancez `DEMARRER_WINDOWS.cmd` avec Docker Desktop démarré ; le script génère vos secrets locaux. Voir `LIRE_EN_PREMIER.md`.

Pour une installation existante, utilisez de préférence l'archive de mise à jour ci-dessus : ne remplacez pas votre `.env` par celui d'une installation neuve.

## Ligne de commande et API

```bash
PYTHONPATH=backend python -m retro.cli /chemin/fichier.pub --output /chemin/sorties --language en
```

L'option accepte `fr` ou `en` ; le défaut reste `fr`. L'API accepte le champ de formulaire `report_language`, conservé avec la tâche. Les téléchargements portent l'en-tête `Content-Language` correspondant au PDF.

## Vérification de cette livraison

- 146 tests réussis, aucun test sauté ; compilation Next.js et TypeScript réussie.
- Navigateur : FR/EN, clavier, bureau/mobile, actualisation, options conservées, analyse réelle et téléchargement des deux PDF en anglais.
- Versement, FIP Essenciel et Devis Auto NOA : rapports et visuels FR/EN ; comparaison FR/EN, soit 14 PDF et 1 128 pages.
- Toutes les pages rendues et revues en planches, avec inspection détaillée de pages représentatives ; aucun mot hors page détecté. La pagination peut différer légèrement entre langues.
- Modèles d'analyse identiques avant/après les deux rendus. Décodage binaire et ressources graphiques inchangés.

La recette locale utilise SQLite et un worker séparé. Docker Desktop, Windows et PostgreSQL/RQ n'ont pas été exécutés dans l'environnement de livraison. Les limites de reconstruction Exstream antérieures restent applicables.

Le bilan détaillé est dans `docs/VALIDATION_I18N_0.10.0.md`. Le journal de reprise est `ETAT_VALIDATION_MOTEUR.md`.
