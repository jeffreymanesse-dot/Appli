# Core Report 0.14.2 — occurrences et sauts de page

Les occurrences de paragraphes et sections séparées par un autre composant sont conservées. Dans WEBLURE, `PAR_AFR_EPI_WEBLURE_TABLE` réapparaît après `PAR_WEBLURE_Simul_Rente_Benef_Nom`. Le moteur utilise les références réellement présentes dans le PUB.

Chaque DOCUMENT suivant commence sur une nouvelle page, dans le corps du rapport et dans le visuel. L'ordre APP reste : COURRIER, SIMULATION, MIEUX_COMPRENDRE, DEM_MISE_EN_SERVICE.

Les composants sources restent uniques dans les inventaires techniques et le catalogue des règles. Le corps du rapport restitue les occurrences et leur récapitulatif de règles. Le visuel conserve le regroupement local des variantes équivalentes consécutives ; il ne supprime plus une réapparition après un autre composant. Les règles et leurs algorithmes ne sont pas modifiés.

## Installation

1. Arrêter l'application avec `ARRETER_WINDOWS.cmd` ou `docker compose stop`.
2. Sauvegarder l'installation ; conserver `.env` et les volumes Docker.
3. Remplacer les fichiers du programme par ceux du dossier `exstream-alterna` de cette archive.
4. Relancer `DEMARRER_WINDOWS.cmd` ou `docker compose up --build --detach`.
5. Créer une nouvelle analyse : les anciens résultats ne sont pas recalculés automatiquement.

## Recette WEBLURE

| Vérification | Résultat attendu |
| --- | --- |
| Tableau `PAR_AFR_EPI_WEBLURE_TABLE` | Deux occurrences ; la seconde après `PAR_WEBLURE_Simul_Rente_Benef_Nom` |
| DOCUMENT | Chaque nouveau document commence sur une nouvelle page |
| Rapport livré | 306 pages ; 53 paragraphes distincts / 54 occurrences connues |
| Visuel livré | 16 pages ; 51 occurrences après regroupement des variantes consécutives |
| Règles WEBLURE | 274 identifiants compilés distincts, inchangés |

289 tests réussis. Les 13 PUB analysables conservent exactement leurs faits sources ; seul WEBLURE gagne une occurrence affichée. Plaisance FDC reste refusé pour son en-tête. Les autres limites de décodage sont conservées ; voir le bilan et le journal. Aucun déploiement sur le poste utilisateur n'a été effectué.
