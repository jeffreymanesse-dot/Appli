@echo off
setlocal DisableDelayedExpansion
cd /d "%~dp0"
where docker >nul 2>nul
if errorlevel 1 goto docker_missing
docker info >nul 2>nul
if errorlevel 1 goto docker_stopped
docker compose version >nul 2>nul
if errorlevel 1 goto compose_missing
if not exist "scripts\init_env.py" goto wrong_folder

echo Preparation de la configuration locale avec Docker...
echo Le premier lancement peut telecharger l'image Python.
docker run --rm --network none --read-only --mount "type=bind,source=%CD%,target=/app" --workdir /app python:3.12-slim python scripts/init_env.py
if errorlevel 1 goto failed

echo Construction et lancement de l'application...
docker compose up --build --detach
if errorlevel 1 goto failed
echo.
echo Application : http://localhost:3000
echo Patientez quelques secondes si la page ne repond pas encore.
echo Pour arreter : ARRETER_WINDOWS.cmd
echo Ouverture du navigateur dans 5 secondes...
timeout /t 5 /nobreak >nul
start "" "http://localhost:3000"
pause
exit /b 0

:docker_missing
echo Docker est introuvable. Installez Docker Desktop avec WSL2.
goto failed
:docker_stopped
echo Docker Desktop ne repond pas. Demarrez-le puis relancez ce fichier.
goto failed
:compose_missing
echo Docker Compose est introuvable. Verifiez votre installation Docker Desktop.
goto failed
:wrong_folder
echo Placez ce fichier dans exstream-alterna, a cote de docker-compose.yml.
goto failed
:failed
echo.
echo Le lancement n'a pas abouti. Copiez le message precedent pour le diagnostic.
pause
exit /b 1
