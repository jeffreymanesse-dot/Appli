# Groupe Alterna — Core Report 0.14.7

Cette version complète la 0.14.6 et corrige la restitution des sources dans le rapport du Bulletin de versement.

## Installation

1. Conserver le fichier `.env` de l’installation et les volumes Docker.
2. Remplacer les fichiers du programme par le dossier `exstream-alterna` de cette archive.
3. Reconstruire les services avec `docker compose up -d --build`, ou utiliser le lanceur Windows habituel. La dépendance de production `pypdf` est maintenant nécessaire pour joindre les sources originales au PDF.
4. Lancer une nouvelle analyse du PUB. Un rapport déjà généré n’est pas recalculé automatiquement.

Aucune migration destructive n’est requise. Cette livraison ne constitue pas un déploiement sur votre installation.

## Ce qui change

- Chapitre 1 : « Vue détaillée » ; chapitre 4 : « Variables et fonctions ».
- Suppression des deux paragraphes sous le nom du PUB, de la section du référentiel système, des empreintes dans le rapport et des étiquettes « Source de conception ».
- Aucun code compilé dans les règles, variables ou fonctions du rapport. Si le script n’est pas disponible, une notice le signale ; aucun algorithme n’est inventé.
- Les scripts natifs retrouvés gardent leurs commentaires, leur indentation et leurs lignes vides. Une police à chasse fixe facilite leur lecture. Les retours visuels nécessaires à la largeur du PDF ne changent pas les fichiers sources joints.
- Les règles simples stockées sous forme paramétrée sont présentées avec leur variable, leur comparaison et leur valeur enregistrées.
- Tous les scripts natifs récupérés sont joints au PDF dans `Sources_de_conception.zip`, en conservant leurs octets d’origine. L’archive de sources est également livrée séparément.

## R3 et R6

L’ancien moteur utilisait le code JavaScript compilé lorsque son lecteur ne trouvait pas de script. Dans le dernier PUB, R3 et R6 sont enregistrées comme comparaisons paramétrées de `DF_FIC_SD_NOE_gest_infoClient_citoyenAmericain`, avec les valeurs `true` et `false`. Aucun script textuel associé n’y a été retrouvé.

Le rapport restitue maintenant ces paramètres natifs. Il ne transforme pas les branches du code compilé en un script `IF/ELSE`. Le format textuel éventuellement saisi dans le développement ne peut pas être certifié à partir de ce seul PUB.

## Couleur des premiers blocs

Le titre, les coordonnées du conseiller et le corps des blocs suivants utilisent tous le bleu `#00008f` dans la source. Le titre et le conseiller sont sur fond blanc ; les sections suivantes ont des bandeaux bleus avec du texte blanc. Cette différence de fond est enregistrée dans le PUB. Les deux chemins de lecture des couleurs partagent désormais le même résolveur ; les couleurs source ne sont pas modifiées pour uniformiser artificiellement les blocs.

## Conservation intégrale

La fonction `DF_FCT_removeAccentuatedChars` contient une table avec des caractères non imprimables. Le PDF l’indique et conserve son script intégral dans la pièce jointe, sans remplacer ses caractères par des approximations. Les fichiers `.bas` de l’archive sont les octets natifs Windows-1252 ; les fichiers `_parametres.txt` décrivent des propriétés enregistrées et ne sont pas des scripts reconstitués.

La validation détaillée et les limites figurent dans `docs/VALIDATION_SOURCES_0.14.7.md`.
