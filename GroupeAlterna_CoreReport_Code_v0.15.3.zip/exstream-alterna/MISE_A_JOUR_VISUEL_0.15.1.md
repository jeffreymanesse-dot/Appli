# Groupe Alterna — CoreReport 0.15.1

Le fichier PDF **Visuel du courrier** ne contient plus la section **Pages, composants et débordements** : titre, descriptions, listes de composants et contenus propres aux pages sont retirés de cette sortie.

Les paragraphes du courrier et la page « Lecture de cette visualisation » sont conservés. L’annexe facultative **Template et Page** du rapport principal reste disponible avec le même choix dans l’interface. Les sources natives, règles et fonctions ne sont pas modifiées.

## Installation

1. Conserver le fichier `.env` et les volumes Docker de l’installation existante.
2. Remplacer les fichiers du programme par le dossier `exstream-alterna` de cette archive.
3. Depuis ce dossier, exécuter `docker compose up -d --build` ou utiliser le lanceur Windows habituel.
4. Lancer une nouvelle analyse du PUB puis télécharger le nouveau Visuel. Les PDF déjà produits ne sont pas recalculés automatiquement.

Aucune dépendance ni migration ajoutée. Cette livraison ne déploie pas les fichiers sur une installation externe.

## Vérification

Le Visuel du dernier Bulletin de versement passe de **8 à 4 pages**. Les trois pages du courrier et la page de lecture conservées ont un rendu identique au précédent hors pied de page de version. Dix tests ciblés réussissent. Le rapport principal généré pour contrôle comporte toujours 100 pages et son annexe Template et Page.

Voir `docs/VALIDATION_VISUEL_0.15.1.md` pour le périmètre précis des contrôles.
