# Mise à jour de l’application 0.9.0

Chaque nouvelle analyse produit deux PDF : **Rétro-documentation** et **Visuel du courrier**. Les options de chapitres habituelles et la structure en introduction sont conservées. En comparaison, cinq PDF sont disponibles : deux paires A/B et le différentiel.

## Installation existante

1. Attendre la fin des analyses et sauvegarder votre installation.
2. Décompresser l’archive dans un dossier temporaire. Copier le programme `exstream-alterna` dans votre dossier d’installation existant, en conservant impérativement **votre `.env` actuel**. Mettre à jour ensemble le backend, le frontend et `assets` (polices et profil graphique).
3. Garder le même dossier Compose et les volumes. Ne pas utiliser `docker compose down -v`. Le `.env` inclus dans l’archive est uniquement un modèle pour une installation neuve : il ne doit pas remplacer le mot de passe associé à votre base existante.
4. Depuis le dossier d’installation, reconstruire les services :

```powershell
docker compose up -d --build api worker purge web
```

5. Actualiser `http://localhost:3000`, lancer une nouvelle analyse et ouvrir les deux téléchargements. Le pied de page indique le moteur 0.9.0. Les anciens résultats ne sont pas réécrits : les relancer pour obtenir le visuel.

Aucune migration de base n’est nécessaire.

## Installation neuve

L’archive comprend `.env` et `.env.example` avec des valeurs à initialiser. Lancer `DEMARRER_WINDOWS.cmd` : `scripts/init_env.py` génère les secrets manquants puis Docker construit l’application. Les prérequis et le lancement Linux/WSL sont dans `LIRE_EN_PREMIER.md`.

## Vérifications et limites

119 tests et 76 contrôles de calibration réussis ; six paires de PDF générées ; 51 pages visuelles inspectées ; compilation et parcours navigateur bureau/mobile validés. Docker/Windows/PostgreSQL/RQ n’ont pas été exécutés dans l’environnement de recette.

Le visuel utilise les propriétés décodées et conserve les noms de variables. Les ressources externes, la pagination native et certains styles restent partiels. Les arrondis calibrés sont réservés au PUB NOA reconnu. Détails : `docs/VALIDATION_MOTEUR_0.9.0.md` et `ETAT_VALIDATION_MOTEUR.md`.
