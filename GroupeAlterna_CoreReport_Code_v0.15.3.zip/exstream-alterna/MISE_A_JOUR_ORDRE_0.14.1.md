# Core Report 0.14.1 — ordre des documents de l'application

Cette version corrige un écart entre la structure APP affichée en introduction et l'ordre effectivement utilisé dans le corps du rapport et le visuel. Les deux sorties suivent désormais les références DOC validées de l'application.

## Pourquoi l'ordre était faux

Le moteur construisait d'abord le flux des documents dans l'ordre physique des définitions du PUB. L'analyse APP trouvait ensuite la bonne séquence, mais celle-ci n'était pas propagée au flux déjà construit. Le correctif intervient avant la numérotation des paragraphes et des règles, puis une vérification de cohérence est appliquée avant l'export. L'erreur ne venait pas du fichier source.

## Résultat WEBLURE

| Position | Document | Identifiant compilé |
| --- | --- | --- |
| 1 | DOC_AFR_EPI_WEBLURE_COURRIER | 10:4001 |
| 2 | DOC_AFR_EPI_WEBLURE_SIMULATION | 10:3999 |
| 3 | DOC_AFR_EPI_WEBLURE_MIEUX_COMPRENDRE | 10:4052 |
| 4 | DOC_AFR_EPI_WEBLURE_DEM_MISE_EN_SERVICE | 10:4051 |

Les 53 paragraphes connus et les 274 règles compilées distinctes sont conservés. Les repères éditoriaux P/R peuvent être renumérotés suivant la nouvelle séquence ; les identifiants compilés et les algorithmes ne changent pas. Les inventaires thématiques de propriétés conservent leur organisation existante.

## Installation

1. Arrêter l'application avec `ARRETER_WINDOWS.cmd` ou `docker compose stop`.
2. Sauvegarder l'installation actuelle et conserver son `.env` et les volumes Docker.
3. Remplacer les fichiers du programme par ceux du dossier `exstream-alterna` de cette archive.
4. Relancer `DEMARRER_WINDOWS.cmd`, ou `docker compose up --build --detach` dans le dossier du programme. Ne pas supprimer les volumes.
5. Créer une nouvelle analyse WEBLURE : les anciens résultats ne sont pas recalculés automatiquement.

Le déploiement sur votre poste et la recette Windows/Docker restent à effectuer. La correction a été vérifiée dans le moteur Python et dans les PDF générés ici.

## Vérifications et périmètre

276 tests réussis, aucun échec ni saut. Comparaison avant/après sur les 14 PUB distincts disponibles : WEBLURE corrigé, 12 autres analysables inchangés, Plaisance FDC toujours refusé pour son en-tête non pris en charge. Aucune autre erreur d'ordre corrigée n'a été observée.

Les limites existantes restent documentées : annexe FIP non décodée, ordre documentaire Auto incomplet, data sections directement portées par les lignes et correspondance des codes Header/Footer non établies. Aucun comportement n'a été ajouté pour les deviner.

Voir `docs/VALIDATION_ORDRE_0.14.1.md`, `validation/order_0.14.1` et le journal pour les preuves et le périmètre exact.
