# Mise à jour Core Report 0.14.5

Cette livraison réunit le référentiel des variables système et la base 0.14.4 qui contient les évolutions Data Files, PAGE/Page Flow et types de lignes. Elle remplace les deux archives différentes diffusées sous le numéro 0.14.4, sans supprimer les anciennes livraisons.

## Installation

1. Conserver votre fichier `.env` et les volumes Docker.
2. Remplacer les fichiers du programme par le contenu du dossier `exstream-alterna` de cette archive.
3. Reconstruire avec `docker compose up -d --build`.
4. Lancer une nouvelle analyse du PUB. Les anciens rapports ne sont pas recalculés automatiquement.

Aucune suppression de volume ni migration destructive n’est nécessaire. Ne remplacez pas votre `.env` par `.env.example`.

## Changements

- Référentiel issu de `VariableSystem.pdf`, pages imprimées 3-20 à 3-24 : 34 noms listés, 64 appartenances aux 7 familles.
- Correction du comptage précédent : `SYS_PageTotalPrintedInDocument` est seulement cité dans une description ; ce n’est pas une 35e entrée confirmée ni un alias résolu de `SYS_PageTotalPrinted`.
- Identification exacte, descriptions, familles, pages source et divergences du guide exposées dans le rapport. Les fiches système précisent que les valeurs d’exécution ne sont pas évaluées.
- La convention existante `SYS_` reste applicable. Un nom absent des tableaux n’est pas présenté comme confirmé par ce guide ; cela ne signifie pas qu’il est invalide dans d’autres versions d’Exstream.
- Les échantillons de conception, mappings et sites d’affectation restent séparés. Aucune date, pagination, valeur de compteur ou répétition n’est calculée à partir de la rétro-documentation.

Le visuel du courrier n’a pas été modifié. Le référentiel ne constitue ni une exécution Exstream ni une certification de son comportement.

Le bilan et les preuves sont dans `docs/VALIDATION_VARIABLES_SYSTEME_0.14.5.md` et `validation/systemvars_0.14.5/`.
