# Groupe Alterna - Core Report 0.15.0

Cette version intègre l’étude des pages dans une annexe facultative du rapport, intitulée **Template et Page**.

## Utilisation

Dans **Analyser un fichier**, la zone **Chapitres complémentaires** propose maintenant quatre cases indépendantes : Variables et fonctions, Annuaire des données du flux, Inventaire et limites de reconstruction, et **Template et Page**. Toutes sont cochées par défaut. Décochez Template et Page pour produire le rapport sans cette annexe. La sélection est conservée avec la tâche et rappelée dans son résultat, y compris après actualisation.

L’annexe est placée en fin de rapport et annoncée dans son organisation. Elle ne modifie pas la numérotation des chapitres précédents. Les choix des tâches déjà enregistrées sont conservés ; les PDF déjà générés ne sont pas modifiés. En mode comparaison, les deux analyses utilisent les options par défaut, comme auparavant ; le PDF de comparaison ne reçoit pas l’annexe.

## Contenu

- Plans à l’échelle 1:1, avec cotes en millimètres et repères d’objets. Les plans du Bulletin occupent des feuilles A3 pour conserver une page native A4 à sa taille réelle. Imprimer à **100 %**, sans ajustement automatique.
- Noms des objets, contenus ou variables associés, emplacements, dimensions, rotations, images intégrées retrouvées et conditions.
- Cadres superposés conservés, y compris les objets de dimensions identiques. Les contours ajoutés pour l’étude ne sont pas des bordures imprimées du courrier.
- Styles partagés décrits une seule fois ; contenus identiques renvoyés à leur première description ; règles existantes citées par leur repère Rn. Seules les conditions supplémentaires sont détaillées sous TP-R.

Pour le dernier Bulletin fourni, le rapport comprend **100 pages**, dont **8 pages d’annexe** pour la page initiale DF_PAG_MAIN_withoutCtcGutAdr_BR et la page de débordement DF_PAG_FLOW_standard_BR : 27 objets, 8 styles partagés, 12 renvois au catalogue et 6 conditions supplémentaires. Sans cette option, le rapport conserve 92 pages. Le PDF séparé « Visuel du courrier » conserve son contenu antérieur.

Les relations vers un composant Template non interprétées restent inconnues. Les valeurs dynamiques, conditions d’affichage et priorités d’impression ne sont pas exécutées. Une variante de page non reconnue est signalée sans inventer ses positions. Les sources natives et leurs commentaires sont conservés ; aucun code compilé n’est ajouté au rapport.

## Installation

1. Conserver le fichier `.env` et les volumes Docker de l’installation.
2. Remplacer les fichiers du programme par le dossier `exstream-alterna` de l’archive 0.15.0.
3. Exécuter `docker compose up -d --build` depuis ce dossier pour reconstruire l’API, le worker et l’interface, ou utiliser le lanceur Windows habituel.
4. Lancer une nouvelle analyse du PUB avec **Template et Page** coché.
5. Vérifier la version **0.15.0** dans le pied du PDF et l’annexe en fin de rapport.

Aucune dépendance ni migration ajoutée. La livraison ne déploie pas les fichiers sur une installation externe. Voir `docs/VALIDATION_TEMPLATE_PAGE_0.15.0.md` pour les vérifications et limites.
