# Mise à jour du moteur 0.7.0

Cette version corrige la lecture et la restitution NOA, puis applique les mêmes corrections aux quatre courriers historiques et à Obsèques. L'interface et son contrat API sont conservés.

## Installation existante

1. Attendre la fin des analyses en cours et conserver une copie de l'installation.
2. Copier le dossier complet `backend/retro` fourni dans le dossier `backend/retro` de votre installation. Le nouveau fichier `component_properties.py` est nécessaire ; copier uniquement le générateur PDF ne suffit pas.
3. Conserver votre `.env` et les volumes existants. Les identifiants doivent correspondre à la base déjà initialisée.
4. Reconstruire les services du moteur depuis le dossier d'application :

```powershell
docker compose up -d --build api worker purge
```

Le frontend n'a pas besoin d'être remplacé. Relancer chaque analyse pour produire les nouveaux rapports : les PDF des anciens traitements ne sont pas réécrits. Le pied de page des nouveaux rapports indique `0.7.0`.

Pour une installation neuve, lancer `DEMARRER_WINDOWS.cmd` : il crée le `.env` local depuis `.env.example`, tous deux pris en charge par les scripts fournis. Aucun secret utilisateur n'est incorporé à l'archive ; ne pas remplacer le `.env` d'une installation existante par des identifiants neufs. Voir `LIRE_EN_PREMIER.md`.

Docker Desktop, Windows et PostgreSQL n'ont pas été exécutés dans cette validation. Celle-ci couvre le moteur Python, les tests existants et les PDF générés.

## Reproduire les six analyses

Installer `backend/requirements-dev.txt` et les polices DejaVu. Depuis l'application :

```powershell
$env:PYTHONPATH="backend"
python scripts/validate_corpus.py --source-dir "C:\Documents\PUB" --output-dir "validation\nouvelle_iteration" --include-obseques --extra-pub AFR_GENERIC_IARD_VEHIC_NOA_DEVIS.pub
```

Le dossier doit contenir les six PUB nommés dans le bilan. Le script accepte les noms exacts ou préfixés, refuse les sources ambiguës et exige un dossier de sortie vide. Il génère PDF et JSON sans utiliser de PDF de référence ou de Tools Report comme entrée du moteur.

Pour reproduire tous les tests, placer vos sources dans `../project_sources` :

```text
03-AFR_EPI_NOE_BULLETIN_ADHESION.pub
04-AFR_EPI_NOE_BULLETIN_VERSEMENT.pub
05-AFR_GENERIC_FIP_DEVIS_ESSENCIEL.pub
06-AFR_GENERIC_PROJET_OBSEQUES_ESSENCIEL.pub
07-AFR_IARD_DEVIS_AUTO.pub
AFR_GENERIC_IARD_VEHIC_NOA_DEVIS.pub
```

```powershell
python -m pytest backend/tests -q
python scripts/validate_revision.py
```

Les sources client ne sont pas distribuées dans le ZIP de code. Sans elles, les tests de corpus concernés sont sautés ; un passage des seuls tests restants ne reproduit pas la validation complète.

## Livrables et limites

`docs/VALIDATION_MOTEUR_0.7.0.md` décrit les quatre itérations, les corrections, les 84 tests, les 76 contrôles de calibration et les limites résiduelles. `ETAT_VALIDATION_MOTEUR.md` permet la reprise. L'archive de validation séparée contient les six PDF/JSON finaux, les versions intermédiaires, les preuves et les rendus.

Les noms de règles sont stables lorsqu'ils sont décodés ; les repères Rn peuvent changer avec l'ordre de rencontre. L'ancienne R57 du premier titre NOA est désormais R1, toujours `DF_RUL_pdf` / ID 524781. Le moteur reste une analyse statique partielle et ne reproduit pas la pagination exacte du moteur Exstream.
