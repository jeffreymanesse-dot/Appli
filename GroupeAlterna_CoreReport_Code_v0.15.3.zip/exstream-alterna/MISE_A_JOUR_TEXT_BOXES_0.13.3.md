# Mise à jour Core Report 0.13.3

Remplacer les fichiers du programme par le contenu du ZIP en conservant le `.env` et les volumes de l'installation existante. Reconstruire les services selon le README et relancer les analyses : les anciens rapports et visuels ne sont pas régénérés automatiquement.

Corrections : variables dont l'en-tête contient un caractère imprimable ; propriétés de texte avec couleurs de palette ; zones de texte avec fond, contour, largeur et marges ; règles d'affichage des paragraphes internes. Aucune migration de données.

Consulter `docs/VALIDATION_TEXT_BOXES_0.13.3.md` pour les preuves, tests et limites. Le contrôle d'en-tête Plaisance FDC n'a pas été modifié ; ce fichier reste réservé à l'essai forcé local.
