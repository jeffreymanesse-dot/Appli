# Livraison 0.15.3

Compute Time affiché pour chaque Formula du chapitre 4, formules déclenchées par événement et leurs dépendances incluses (dont initPage). Contours gris légers pour les tableaux sans trait source ; suppression de la lecture finale du Visuel et des paragraphes « Règles des objets de la page ». Le lanceur Windows attend cinq secondes avant d’ouvrir le navigateur. Lire `MISE_A_JOUR_LECTURE_0.15.3.md` et `docs/VALIDATION_LECTURE_0.15.3.md`. Conserver `.env` et les volumes, reconstruire les services puis lancer une nouvelle analyse.

# Livraison 0.15.2

Règles des images, contenus de signature, types et propriétés de lignes, ancrages de tableaux et entrées DOCUMENT/PAGE/SECTION corrigés par des lecteurs génériques. Rapport allégé et tableaux de lignes fusionnés. Lire `MISE_A_JOUR_PROPRIETES_0.15.2.md` et `docs/VALIDATION_PROPRIETES_0.15.2.md`. Conserver `.env` et les volumes, reconstruire les services puis lancer une nouvelle analyse.

# Livraison 0.15.1

Le PDF **Visuel du courrier** ne contient plus la section « Pages, composants et débordements ». L’annexe **Template et Page** reste disponible dans le rapport principal. Lire `MISE_A_JOUR_VISUEL_0.15.1.md` et `docs/VALIDATION_VISUEL_0.15.1.md`. Conserver `.env` et les volumes, reconstruire les services puis lancer une nouvelle analyse.

# Livraison 0.15.0

Annexe facultative **Template et Page**, sélectionnable dans l’interface : plans à l’échelle, objets, cotes, rotations et superpositions ; renvois aux règles et styles partagés pour éviter les répétitions. Voir `MISE_A_JOUR_TEMPLATE_PAGE_0.15.0.md` et `docs/VALIDATION_TEMPLATE_PAGE_0.15.0.md`. Reconstruire l’API, le worker et l’interface, puis lancer une nouvelle analyse.

## Livraison 0.14.9

Conditions paramétrées typées, annuaire sans usages et chapitre 6 limité au tableau récapitulatif. Couleur du titre et du conseiller vérifiée dans les PDF. Voir `MISE_A_JOUR_PRESENTATION_0.14.9.md` et `docs/VALIDATION_PRESENTATION_0.14.9.md`. Reconstruire les services, puis lancer une nouvelle analyse pour obtenir le nouveau rapport.

## Livraison 0.14.8

Chapitre « Variables et fonctions » limité aux arguments déclarés, au retour des Function et aux sources natives sous Logic/Formula. Voir `MISE_A_JOUR_LOGIC_0.14.8.md` et `docs/VALIDATION_LOGIC_0.14.8.md`.

## Livraison 0.14.7

Sources natives uniquement dans le rapport, commentaires et indentation conservés, règles paramétrées restituées depuis leurs propriétés enregistrées. Chapitres et introduction simplifiés. Voir `MISE_A_JOUR_SOURCES_0.14.7.md` et `docs/VALIDATION_SOURCES_0.14.7.md`.

## Livraison 0.14.6

Rapport simplifié selon les 22 retours du Bulletin de versement : campagnes et messages rattachés, titre graphique restitué, algorithmes reproduits depuis leur source disponible, répétitions rapprochées des contenus. Voir `MISE_A_JOUR_RAPPORT_0.14.6.md` et `docs/VALIDATION_RAPPORT_0.14.6.md`.

## Livraison 0.14.5

Référentiel des variables système consolidé avec les évolutions 0.14.4. Lire `MISE_A_JOUR_VARIABLES_SYSTEME_0.14.5.md` et `docs/VALIDATION_VARIABLES_SYSTEME_0.14.5.md`.

## Livraison 0.14.4

Lire `MISE_A_JOUR_CONTENUS_0.14.4.md` et `docs/VALIDATION_CONTENUS_0.14.4.md`.

# Livraison 0.14.2

Occurrences séparées conservées et saut de page entre DOCUMENT. Voir `MISE_A_JOUR_FLUX_0.14.2.md` et `docs/VALIDATION_FLUX_0.14.2.md`.

# Livraison 0.14.1

Ordre des documents APP propagé au rapport et au visuel. Voir `MISE_A_JOUR_ORDRE_0.14.1.md` et `docs/VALIDATION_ORDRE_0.14.1.md`.

# Livraison 0.14.0

Voir `MISE_A_JOUR_DATA_SECTIONS_0.14.0.md` et `docs/VALIDATION_DATA_SECTIONS_0.14.0.md`.

# Livraison 0.13.4

Voir `MISE_A_JOUR_INTRO_0.13.4.md` et `docs/VALIDATION_INTRO_0.13.4.md`.

# Livraison 0.13.3

Voir `MISE_A_JOUR_TEXT_BOXES_0.13.3.md` et `docs/VALIDATION_TEXT_BOXES_0.13.3.md`.

# Livraison 0.13.2

Voir `MISE_A_JOUR_COMPOSITIONS_0.13.2.md` et `docs/VALIDATION_COMPOSITIONS_0.13.2.md`.

# Core Report — Groupe Alterna

Moteur **0.15.3**, analyse statique locale de packages Exstream. Interface Next.js/React/TypeScript, API FastAPI, rapports PDF, comparaison, suivi durable, annulation et liens temporaires associés au propriétaire.

La version 0.13.1 distingue les quatre portées des bordures et décode les cadres extérieurs de tableau. Voir `MISE_A_JOUR_BORDURES_0.13.1.md` et `docs/VALIDATION_BORDURES_0.13.1.md`.

La version 0.13.0 place les tableaux à leurs ancrages internes, restitue les bordures reconnues des cellules/lignes/colonnes et partage les styles sources entre rapport et visuel. Voir `MISE_A_JOUR_PRESENTATION_0.13.0.md` et `docs/VALIDATION_PRESENTATION_0.13.0.md`. Le soulignement et la pagination native restent partiels.

Le correctif 0.12.1 reconnaît les axes de lignes portant des propriétés explicites. Il rétablit les trois lignes principales du tableau FIP « notreEntretien » (en-tête, Inhumation, Crémation), conserve sa note fusionnée et corrige les composants du corpus présentant la même structure. Voir `MISE_A_JOUR_CORRECTIF_FIP_0.12.1.md` et `docs/VALIDATION_FIP_0.12.1.md`.

Les tableaux disposent maintenant de largeurs sources en cm/points, de fonds RGB résolus dans la palette du package, des formes Rounded/left/right et de bordures locales validées. Le visuel utilise les largeurs physiques reconnues avec réduction pour la page ; les axes à dimensionnement automatique conservent un rendu proportionnel signalé. Le rayon exact des arrondis et l'héritage complet des bordures restent inconnus. Voir `MISE_A_JOUR_TABLEAUX_0.12.0.md`.

La structure de l'application figure toujours en introduction. En mode analyse, quatre parties peuvent être incluses ou exclues indépendamment : Variables et fonctions, Annuaire des données du flux, Inventaire du package et annexe Template et Page. Les quatre sont activées par défaut ; aucune sélection est également acceptée. Les sorties techniques sont conservées par le moteur, sans être proposées dans l'interface.

Le moteur reste partiel : seules les relations décodées sont présentées comme établies. Le rattachement des sections aux pages, certaines portées, l'ordre global de valorisation et le rendu Exstream exact restent incomplets. Aucun XSD ni relation ne sont fabriqués. Voir `docs/VALIDATION_MOTEUR_0.9.0.md`, `docs/VALIDATION_I18N_0.10.0.md` et le journal courant.

Pour Windows/Docker Desktop, commencer par `LIRE_EN_PREMIER.md` et `DEMARRER_WINDOWS.cmd`.

## Démarrage local

Prérequis : Python 3.12+, Node.js 22+, npm ; police DejaVu Sans installée (`fonts-dejavu-core` sous Debian). Depuis le dossier du projet :

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -r backend/requirements-dev.txt
npm --prefix frontend ci
python scripts/init_env.py
```

Les secrets sont générés automatiquement dans `.env` sans être affichés. Puis :

```bash
./scripts/dev.sh
```

Ouvrir `http://localhost:3000`. Le script lance trois processus réels : interface, API et worker local. Les entrées sont réellement analysées. Aucun mode de simulation du traitement n'est présent. La session locale est uniquement destinée au développement ; elle est explicitement signalée à l'écran.

Windows : utiliser WSL2 ou Docker Desktop. Les scripts Bash sont prévus pour Linux/WSL ; ils n'ont pas été testés dans PowerShell natif.

La base SQLite conserve les tâches après actualisation. Le worker traite un job à la fois, dans un processus enfant avec limite de durée et annulation. Une tâche interrompue n'est pas silencieusement rejouée ; elle passe en échec après le délai de surveillance. Les états sont consultés toutes les 1,5 secondes : polling retenu pour sa simplicité de déploiement derrière un proxy ; aucun faux pourcentage.

## Docker Compose

Créer la configuration avec `python scripts/init_env.py` pour une installation neuve. Conserver impérativement le `.env` d’une installation existante. Puis :

```bash
docker compose up --build
```

Cette configuration assemble Next.js, FastAPI, **RQ/Redis**, PostgreSQL et un service de purge. Seul le port `127.0.0.1:3000` est publié. Les migrations initiales sont appliquées avec verrou. Le volume privé est partagé uniquement par l'API, le worker et la purge.

**Compose n'a pas été exécuté dans l'environnement de livraison : Docker n'y est pas installé.** Le fonctionnement local Python/SQLite/processus séparé a été testé ; ne pas confondre cela avec une recette PostgreSQL/RQ en production.

## Identité Core Report et couverture

Core Report porte l’accroche « Vos applications documentaires, en toute clarté. ». Chaque nouvelle rétro-documentation reçoit une couverture Alterna avec le nom exact de l’application décodée. Le visuel du courrier reste sans couverture documentaire. Voir `MISE_A_JOUR_CORE_REPORT_0.11.0.md` et `docs/VALIDATION_CORE_REPORT_0.11.0.md`.

## Langue de l’interface et des PDF

Les drapeaux FR/EN en haut à droite changent l’interface. La langue sélectionnée au lancement est conservée avec chaque analyse et utilisée pour les rubriques et commentaires des PDF. Le contenu extrait du `.pub` n’est jamais traduit. Les PDF existants gardent leur langue ; relancez une analyse pour la changer. Voir `MISE_A_JOUR_0.10.0.md`.

## Utilisation

1. Choisir « Analyser un fichier » ou « Comparer deux versions ».
2. Déposer un `.pub` par zone, ou utiliser le bouton de sélection ; 32 Mio maximum par fichier. Le nom, la taille et le format sont affichés.
3. En analyse, choisir les chapitres complémentaires à générer. La structure, les contenus, les tables et le catalogue des règles restent présents.
4. Lancer le traitement. Une actualisation retrouve la tâche et sa sélection de chapitres.
5. Préparer les liens puis télécharger les deux PDF : rétro-documentation et visuel du courrier. En comparaison, les deux paires A/B et le différentiel sont fournis (cinq PDF).

La numérotation et le plan s’adaptent aux chapitres retenus. Leur désactivation ne supprime aucune observation du modèle interne. Les incertitudes locales continuent d'être signalées dans les blocs concernés.

Le visuel représente les contenus décodés, les styles, les tableaux et les emplacements graphiques. Les variables gardent leur nom ; les blocs équivalents sont regroupés uniquement dans cette vue. Une dernière page précise les limites. Les arrondis calibrés sur NOA sont réservés à son empreinte exacte ; ils ne sont pas supposés pour les autres packages.

## Architecture et modules

- `backend/retro/binary.py` : signatures, lecture bornée, ASCII/Latin-1 et UTF-16LE, preuves.
- `visual_recovery.py`, `visual_graphics.py`, `visual_model.py`, `visual_render.py` : récupération et rendu graphique isolés par analyse.
- `parser.py` : définitions, variables, mappings recoupés, règles, calculs et candidats Repeat.
- `rules.py` : scanner IF imbriqués et fonctions à accolades équilibrées ; aucun `eval`.
- `schema.py`, `docs/communication.schema.json` : contrat JSON versionné et validation des références/bornes.
- `compare.py` : ajouts/suppressions/modifications/incertitudes ; distingue déplacement binaire et ordre métier inconnu.
- `hierarchy.py`, `report_options.py` : relations APP→DOC, hiérarchie ordonnée et choix indépendants de chapitres.
- `render.py`, `report_structure.py`, `report_detail.py`, `export.py` : rendu PDF configurable et modèle technique interne ; logo authentique et tokens Alterna.
- `api.py`, `security.py` : dépôt, contrôle serveur, propriétaire, CSRF, liens signés et expiration.
- `db.py`, `jobs.py`, `worker.py`, `maintenance.py` : métadonnées, orchestration, annulation, migrations et purge.
- `frontend/app/` : interface français/anglais responsive, focus, annonces de statut et mouvements réduits.

## Analyse en ligne de commande

```bash
PYTHONPATH=backend python -m retro.cli /chemin/fichier.pub --output /chemin/sorties --language en
PYTHONPATH=backend python -m retro.cli /chemin/A.pub --other /chemin/B.pub --output /chemin/comparaison
```

Aucun accès au Projet ChatGPT, à sa mémoire ou à ses fichiers n'est effectué par l'application. Aucune clé IA ni appel externe d'analyse. Les règles sont explicitement présentes dans le code.

## Calibration et preuves

La régression du moteur porte sur six PUB autorisés : Adhésion, Versement, FIP, Obsèques, Auto et NOA. La livraison 0.10.0 vérifie les rapports et visuels FR/EN de NOA, Versement et FIP, ainsi qu’une comparaison bilingue. Les sélections de chapitres sont testées séparément. La calibration historique indépendante couvre quatre de ces sources.

Quatre références indépendantes **partielles** PDF/JSON ont été produites avant le moteur, par sondes binaires ciblées et inspection hexadécimale. Elles ne constituent pas l'oracle complet requis. `references/investigation_independante.py` est séparé du moteur et n'importe aucun de ses modules.

Contrôles figés : trois variables par package (ID, type, cardinalité, offsets, chemin XML) et liste des IDs de règles. **76 contrôles ciblés conformes** ; cela ne valide pas les autres propriétés. Les grilles détaillées sont dans l’archive séparée de validation ; elles ne sont pas nécessaires au démarrage.

| Package | Variables | Mappings | Règles distinctes | Règles avec source rattachée |
|---|---:|---:|---:|---:|
| Adhésion | 5 774 | 5 057 | 183 | 130 |
| Versement | 5 796 | 5 236 | 146 | 100 |
| FIP Essen'Ciel | 5 713 | 5 154 | 184 | 121 |
| Projet Obsèques | 5 380 | 4 898 | 29 | 17 |

Ces décomptes incluent des ressources génériques embarquées ; ils ne sont pas le nombre de données réellement utilisées par le courrier. Les cardinalités sont des propriétés de variables, pas des contraintes XML ni des Repeat.

## Vérifications

```bash
PYTHONPATH=backend python -m pytest backend/tests -q
npm --prefix frontend run typecheck
NEXT_TELEMETRY_DISABLED=1 npm --prefix frontend run build
```

La suite comprend 219 tests, dont 19 nouveaux cas de présentation, les 13 cas FIP de 0.12.1 et les 21 contrôles de styles de 0.12.0. Les six PUB historiques se placent dans `../project_sources` ; les variantes contrôlées sont recherchées sous les dossiers `pub_variants` et `pub_variants2` de la racine définie par `PUB_TABLE_CORPUS`. Les tests du corpus sont sautés si les sources client sont absentes ; cela ne reproduit pas la validation complète. Le script navigateur optionnel requiert Playwright et la variable PUB_TEST_PATH ; il ne contient pas de fichier client. Revoir `ETAT_VALIDATION_MOTEUR.md` pour le dernier résultat exact.

Pour analyser chaque `.pub` de plusieurs dossiers, dédupliquer les copies identiques, produire les rapports/visuels et comparer les données métier à une version précédente :

```bash
PYTHONPATH=backend python scripts/validate_table_corpus.py --source-dir ../project_sources --source-dir ../pub_variants --source-dir ../pub_variants2 --output-dir ../validation_nouvelle --baseline-backend ../ancienne_version/backend
```

Le résumé comporte les empreintes SHA-256, tous les chemins sources, les profils reconnus/non interprétés et les contrôles de PDF. Chaque package est analysé dans un processus distinct. Le dossier de sortie doit être vide ; les PUB ne sont pas copiés dans les livrables.

Pour comparer 0.12.1 à 0.12.0, utiliser `scripts/validate_styled_rows.py` avec les mêmes arguments. Ce contrôle conserve les faits sources et autorise uniquement les corrections de lignes justifiées par le profil binaire reconnu, en vérifiant la conservation des axes et cellules précédents. Une égalité stricte de tout le modèle serait incorrecte pour ce correctif : les rattachements de cellules et les usages dérivés sont précisément ce qui change.

## Protection et exploitation

Consulter `docs/SECURITE_EXPLOITATION.md`. Production bloquée si la configuration reste en authentification de développement, SQLite ou worker local. L'adaptateur de proxy signé est fourni ; **aucun SSO/OIDC/SAML du client n'est configuré**. Il doit être intégré, audité et testé dans l'intranet avant toute mise en service.

Rétention par défaut : 24 heures. Liens : cinq minutes maximum. Purge toutes les 30 secondes via service dédié ou boucle du worker local. En l'absence de service actif, les liens restent refusés après expiration mais la suppression physique reprend au redémarrage de la purge. Tombstones sans contenus conservés sept jours supplémentaires puis supprimés.

## Reprise

Lire `ETAT_VALIDATION_MOTEUR.md`, vérifier l'inventaire et les empreintes, puis commencer par la prochaine action indiquée. Ne pas regénérer les références déjà valides. Les fichiers `.pub`, `.env`, dépendances installées et fichiers d'exécution ne sont pas inclus dans le code livré.

Pour comparer 0.13.0 à 0.12.1, utiliser `scripts/validate_presentation_corpus.py`. Le script contrôle aussi la conservation de chaque contenu visuel antérieur et exporte les audits de typographie.
