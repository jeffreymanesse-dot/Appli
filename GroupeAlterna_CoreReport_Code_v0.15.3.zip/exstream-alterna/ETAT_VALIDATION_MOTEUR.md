# État courant — CoreReport 0.15.3 — 9 octobre 2026

**Itération 58 : Compute Time des Formula, inclusion des calculs déclenchés par événement, contours de tableaux et allègement des PDF.**

Base complète 0.15.2 conservée. Le Visuel ne contient plus « Lecture de cette visualisation » ni les paragraphes qui composaient cette partie. Les paragraphes « Règles des objets de la page » sont retirés du rapport. Les règles restent analysées et rattachées à leurs objets ; les entrées DOCUMENT/PAGE/SECTION et l’annexe facultative Template et Page sont conservées.

Un contour gris léger de 0,45 point délimite les tableaux dépourvus de trait source visible, dans le rapport et le Visuel. Il suit leur largeur et leurs lignes, sans modifier les propriétés du modèle. Le tableau de PAR_WEBLURE_Simul_Liste-data reste ancré entre la date de naissance et le taux technique. Les tableaux avec traits sources et les text boxes ne reçoivent pas ce contour supplémentaire.

Compute Time : lecture du champ natif par un profil borné, avec contrôle des identités, enveloppes, types, source Formula, cardinalité et bornes. Les codes corroborés sont As-needed, Customer, Page, Initialization et Named section ; les autres restent non déterminés. Les sections nommées sont lues dans leur propre enveloppe validée. Aucun nom métier ou commentaire ne commande la reconnaissance.

WRK_AFR_EPI_WEBLURE_COURRIER_SIMUL_initPage était présente avec sa Formula complète dans le modèle 0.15.2 mais exclue par le filtre du chapitre 4. Le filtre suivait les références des contenus et règles sans inclure les formules déclenchées par événement. Celles-ci sont désormais des points d’entrée de la fermeture de dépendances existante. initPage apparaît avec Compute Time : Page, ses commentaires et sa source inchangés ; ses appels sont suivis. WEBLURE comporte 29 Formula : 20 As-needed, 1 Customer, 1 Page, 2 Initialization et 5 Named section. Le périmètre du chapitre 4 passe de 63 à 79 calculs et fonctions.

DEMARRER_WINDOWS.cmd contient `timeout /t 5 /nobreak >nul` avant l’unique ouverture du navigateur, après le démarrage réussi de Docker Compose. Fins de ligne Windows et branches d’erreur conservées. Contrôle statique uniquement ; Windows et Docker Desktop n’ont pas été exécutés ici.

Validation : **90 tests ciblés réussis, 1 test API désélectionné**. Cas renommés, déplacés, corrompus et inconnus inclus. Les assertions API affectées sont adaptées, sans revendication d’exécution des tests API ni de la suite complète. Analyse, schéma et couverture du Visuel validés sur trois autres packages : Bulletin d’adhésion, FIP Devis Essentiel et dernier Bulletin de versement. Aucune perte, duplication ni erreur d’occurrence détectée. Deux Compute Time du FIP restent non reconnus, sans valeur inventée.

Rapport WEBLURE final : **271 pages** avec annexe Template et Page ; Visuel : **14 pages**. Toutes les pages sont rasterisées et inspectées en planches, avec agrandissements ciblés du tableau inline, de initPage et de la fin du Visuel. Aucun texte hors page. Les règles, sources natives, commentaires, algorithmes, contenus et propriétés de mise en page sont comparés à 0.15.2 et inchangés ; les nouveaux champs de Compute Time et le périmètre documentaire sont les ajouts intentionnels. L’export ne modifie pas le modèle.

Livraison : code complet 0.15.3, rapport, Visuel, notice et bilan intégrés. Preuves compactes : `validation/reading_0.15.3/`. Le journal canonique version 44 est conservé intégralement ci-dessous. Conserver `.env` et les volumes, reconstruire les services puis lancer une nouvelle analyse. Aucune dépendance ni migration ajoutée. Aucun déploiement utilisateur ni validation native Exstream revendiqué.

---

# État courant — CoreReport 0.15.2 — 9 octobre 2026

**Itération 57 : corrections génériques des contenus, objets image, types de lignes et entrées de conteneurs, validées sur WEBLURE.**

Base complète 0.15.1 conservée. Les contenus à première couleur de palette sont récupérés après validation du préambule et de toute la chaîne de texte et de variables. Les deux composants de signature ont chacun leurs six cellules, avec leurs quatre variables et leurs deux cellules vides ; quatre unités supplémentaires sont retrouvées, soit 366 unités au total contre 362 auparavant.

Les règles des objets inclus sont rattachées par ancrage, répertoire, cadre et dimensions concordantes. R18 et R20 encadrent désormais leurs images ; les autres règles des images du courrier sont contrôlées. La ressource d'une image dynamique n'est pas inventée. Les tableaux étendus retrouvent leur ancrage : celui de la simulation se situe après la date de naissance et avant le taux technique.

Types Header (H), Repeating footer — Except last Page (F-) et Automated row (R), First row of table section, rupture sur changement de variable et Group with previous row reconnus depuis leurs champs propres. Les dix lignes du tableau principal correspondent aux retours : F-, Footer, cinq Header, puis trois R ; les deux dernières portent Group with previous row. Aucun driver manquant n'est fabriqué.

Rapport : entrées DOCUMENT/PAGE/SECTION, règles affichées uniquement lorsqu'elles existent, ajout de trois règles globales PAGE du périmètre WEBLURE. Les PAGE initiales/de débordement sont présentées à l'entrée du DOCUMENT, sans simuler la pagination native ni inventer le rattachement des sections. Tableaux de lignes fusionnés ; statuts Data Section, mention d'ordre local non établi et mention d'absence de driver supprimés de la présentation demandée. Les sources natives et les algorithmes sont inchangés.

Validation : **101 tests ciblés distincts réussis** (98 puis 3 complémentaires), avec cas renommés, déplacés et corrompus ; deux tests API désélectionnés dans le premier lot. Analyse, schéma et couverture du Visuel validés sur six autres packages, dont le dernier Bulletin de versement. Aucune perte, duplication ou erreur d'occurrence détectée. Suite complète historique non relancée ; aucun nouveau contrôle API, navigateur, Docker ou Windows revendiqué.

Rapport WEBLURE final : **223 pages** avec annexe Template et Page ; Visuel : **15 pages**, sans Pages, composants et débordements. Toutes les pages ont été rasterisées et inspectées, avec agrandissements ciblés ; aucun texte hors page. Les variantes de règles et les calculs sont identiques à 0.15.1 et l'export ne modifie pas le modèle.

Livraison : code complet 0.15.2, rapport, Visuel, notice et bilan intégrés. Preuves compactes : `validation/properties_0.15.2/`. Le journal canonique version 43 est conservé intégralement ci-dessous. Conserver `.env` et les volumes, reconstruire les services puis lancer une nouvelle analyse. Aucune dépendance ni migration ajoutée. Aucun déploiement utilisateur ni validation native Exstream revendiqué. Les variantes non reconnues restent inconnues.

---

# État courant — CoreReport 0.15.1 — 9 octobre 2026

**Itération 56 : suppression de la section « Pages, composants et débordements » du PDF Visuel.**

Base complète 0.15.0 conservée. La section Page du Visuel est retirée dans son intégralité. Les informations Page restent dans l’analyse et dans l’annexe facultative Template et Page du rapport principal. Aucun changement du décodeur, des sources natives, des règles, des fonctions ou du choix des chapitres dans l’interface.

Le contrôle de couverture distingue les unités Page volontairement exclues des contenus du courrier attendus. Il continue à signaler les pertes et les doublons de ces derniers. Le modèle analysé n’est pas modifié par l’export.

Dernier Bulletin : **8 à 4 pages** dans le Visuel ; 101 unités sources, 77 rendues, 24 unités Page exclues intentionnellement. Les nouvelles pages 1 à 4 correspondent aux anciennes pages 1, 2, 3 et 8. Les corps de ces pages sont identiques pixel par pixel après rasterisation, hors pied de page de version. Les quatre pages ont été inspectées visuellement ; aucun texte hors page, contenu attendu manquant, doublon ou erreur d’occurrence. Le rapport principal régénéré pour contrôle conserve ses 100 pages et son annexe Template et Page.

Validation : **10 tests ciblés réussis, 6 tests de profils graphiques désélectionnés**. Sorties française et anglaise, couverture du courrier, exclusion des Page et cas Page seul vérifiés. La suite complète n’a pas été relancée pour cette livraison ; le résultat de 471 tests plus bas concerne uniquement la version historique 0.15.0.

Livraison : code complet 0.15.1, Visuel corrigé, notice et bilan intégrés. Preuves : `validation/visual_0.15.1/`. Le journal canonique version 42 est conservé intégralement ci-dessous. Conserver `.env` et les volumes, reconstruire les services puis lancer une nouvelle analyse ; les anciens PDF ne sont pas recalculés automatiquement. Aucune dépendance ni migration ajoutée. Aucun déploiement utilisateur ni validation native Exstream revendiqué.

---

# État courant — Core Report 0.15.0 — 8 octobre 2026

**Itération 55 : annexe facultative « Template et Page », plans à l’échelle et sélection dans CoreReport.**

Base complète 0.14.9 conservée. L’étude séparée des deux pages est intégrée au rapport comme une annexe de fin, indépendamment sélectionnable dans l’interface aux côtés des chapitres 4, 5 et 6. La case est cochée par défaut. La sélection est conservée dans la tâche, après actualisation et jusqu’au téléchargement. Les choix explicites des tâches historiques restent inchangés ; les PDF existants ne sont pas recalculés.

Le nouveau profil borné OBS-page-counted-layout-v1 ajoute uniquement page_layouts au modèle. Il recoupe les propriétaires de Page, listes comptées, dimensions répétées, unités au 1/300 pouce, polygones, rotations et images JPEG référencées. Aucun nom de fichier, empreinte, nom métier ou position absolue du Bulletin ne commande le décodage. Les variantes incohérentes restent inconnues, sans remplacement par des positions supposées ni par une ressource de marque externe.

Dernier Bulletin : page initiale DF_PAG_MAIN_withoutCtcGutAdr_BR (22 objets) et débordement DF_PAG_FLOW_standard_BR (5 objets). Les 27 noms/emprises et 26 rotations de cadres correspondent à l’étude acceptée ; la rotation de l’image directe n’est pas présumée. Les deux images intégrées S1FLECBR et S1LOAPRS sont conservées. Plans 1:1 sur A3, dimensions et positions en millimètres, superpositions maintenues. Le rapport conserve 92 pages hors annexe et atteint 100 pages avec l’option ; visuel séparé de 8 pages inchangé dans son contenu.

Répétitions limitées : 8 styles partagés, renvois vers 2 contenus déjà décrits, 12 règles citées par leurs repères existants Rn ; seules 6 conditions supplémentaires (4 scripts natifs et 2 conditions paramétrées) sont détaillées sous TP-R. Les paragraphes du courrier ne sont pas reproduits dans l’annexe. Aucun code compilé, aucune pseudo-source IF/ELSE et aucune relation Template non interprétée ne sont ajoutés.

Validation ciblée : 66 contrôles des options, langues et présentation, puis 14 tests des pages, tous réussis. Les 16 combinaisons des quatre choix sont testées de l’API à la file de traitement et au téléchargement. Les plans PDF sont mesurés à leur échelle réelle ; les 100 pages du rapport et 8 pages du visuel sont contrôlées. Archive des 174 scripts natifs inchangée octet pour octet. Réanalyse du dernier Bulletin : tous les champs antérieurs identiques à 0.14.9 hors version. Corpus de 15 packages : 33 pages sélectionnées, dont 26 décodées, 2 partielles et 5 non interprétées ; génération des annexes sans texte hors page, aucune mutation des champs existants par le décodeur.

Interface : TypeScript et compilation Next.js réussis ; quatre cases indépendantes retrouvées dans le HTML compilé, libellés français et anglais présents. La persistance des choix et les téléchargements sont validés par API. Aucun navigateur Chromium disponible pour rejouer les clics dans cette session ; aucune validation interactive navigateur n’est revendiquée.

Suite complète : **471 tests réussis**, aucun échec ni saut ; un avertissement de dépréciation préexistant du client HTTP de test.

Livraison : code complet 0.15.0, rapport et visuel du dernier Bulletin, archive des sources, guide de mise à jour et bilan. Preuves : validation/template_page_0.15.0/. Le journal canonique version 41 est conservé intégralement ci-dessous. Conserver .env et les volumes, reconstruire l’API, le worker et l’interface, puis lancer une nouvelle analyse. Aucune dépendance ni migration ajoutée. Aucun déploiement utilisateur ni validation native Exstream revendiqué. Les références Template, priorités d’impression, valeurs dynamiques et variantes de pages non décodées restent inconnues.

---


# État courant — Core Report 0.14.9 — 8 octobre 2026

**Itération 54 : conditions paramétrées lisibles, vérification des couleurs et rapport allégé.**

Base complète 0.14.8 conservée. R3/R6 portent sur des chaînes de caractères, R7 sur un booléen : le rapport affiche désormais le type et la comparaison native, avec guillemets pour les chaînes. Le correctif couvre les sept conditions paramétrées du courrier, dont R22/R27/R28/R29. Aucun script IF/ELSE ni effet n'est reconstruit à partir du code compilé. Les scripts natifs existants restent inchangés, commentaires compris.

Les deux premiers paragraphes, le texte du contrat et son bandeau utilisent #00008F dans le PUB et dans les PDF. L'écart visuel observé correspond à la présence ou absence d'aplat et aux traits fins (0,48 pt avant adaptation de largeur). Les couleurs, fonds et épaisseurs ne sont pas modifiés arbitrairement ; les tests contrôlent maintenant les valeurs réellement écrites dans le rapport et le visuel, au-delà du modèle extrait.

L'annuaire conserve 342 mappings sans leurs usages. Le chapitre 6 est limité au tableau récapitulatif de l'inventaire. Les sections d'origine des variables, de fiches hors flux, de contenus non rattachés, de règles hors périmètre et d'inventaire complet des calculs sont absentes. Le modèle conserve ses 148 règles et 57 calculs ; le chapitre 4 garde ses 31 calculs et fonctions sous Logic/Formula.

Validation : 441 tests réussis, aucun échec ni saut, un avertissement de dépréciation préexistant ; 39 contrôles ciblés dont 18 nouveaux cas. Réanalyse du dernier Bulletin comparée à 0.14.8 : tous les champs identiques après normalisation JSON, hors numéro de version. Rapport de 92 pages et visuel de 8 pages vérifiés ; 66 scripts imprimables et 7 conditions du périmètre retrouvés dans le rapport ; les 174 scripts natifs joints sont inchangés octet pour octet. Les fichiers descriptifs des conditions jointes reçoivent uniquement le type déclaré.

Livraison : code complet 0.14.9, rapport et visuel du dernier Bulletin, archive des sources, guide et bilan. Preuves compactes : validation/presentation_0.14.9/. Le journal canonique version 40 est conservé intégralement ci-dessous. Les PDF historiques ne sont pas recalculés : conserver .env et les volumes, reconstruire notamment l'API et le worker, puis lancer une nouvelle analyse. Aucune dépendance ni migration ajoutée. Aucun déploiement utilisateur ni validation native Exstream revendiqué.

---


# État courant — Core Report 0.14.8 — 8 octobre 2026

**Itération 53 : déclarations natives et zones Logic / Formula au chapitre 4.**

Base complète 0.14.7 conservée. Le chapitre « Variables et fonctions » présente uniquement les arguments déclarés et leurs types, le type de retour des Function et le code natif. Les listes Lectures/Écritures et les fiches détaillées de dépendances/provenance sont retirées de cette vue. Les données correspondantes restent dans le moteur ; tous les scripts du périmètre précédent sont conservés.

Nouveau profil borné OBS-function-declaration-103-v1 : déclaration de classe 159, nature Function/Subroutine, type de retour et liste comptée d’arguments avec nom, type, indicateur de tableau et caractère facultatif. Les signatures inconnues ou corrompues ne sont pas extrapolées. Aucun type ne provient d’une déduction depuis les variables lues, les affectations ou les commentaires.

Une sous-routine sans argument affiche directement Logic ; une Function affiche son type de retour ; une variable calculée affiche Formula. Les commentaires, l’indentation et les lignes vides sont conservés. Aucun code compilé n’est affiché. Les sources originales jointes au PDF sont identiques à 0.14.7, y compris la fonction comportant des caractères non imprimables.

Dernier Bulletin : 37 déclarations natives reconnues (13 Function, 24 Subroutine). Le chapitre 4 garde 31 scripts : 7 Function, 18 Subroutine et 6 formules, soit 25 zones Logic, 6 zones Formula et 7 types de retour. Le rapport régénéré compte 118 pages, toutes parcourues en planches avec agrandissements ciblés.

Validation : 423 tests réussis, aucun échec ni saut, dont 19 nouveaux tests de signatures et de présentation ; un avertissement de dépréciation préexistant. Comparaison des 15 modèles à 0.14.7 : les champs préexistants sont identiques hors version ; seules les déclarations natives s’ajoutent. Les arguments passés par référence sont recoupés avec leurs alias compilés uniquement pour la validation, sans les exposer dans le rapport. Preuves compactes : validation/logic_0.14.8/ ; contrôle reproductible : scripts/validate_function_signatures.py.

Livraison : code complet 0.14.8, rapport du dernier Bulletin, guide et bilan. Journal canonique version 39 conservé intégralement ci-dessous. Conserver .env et les volumes, reconstruire les services, puis lancer une nouvelle analyse. Aucune nouvelle dépendance par rapport à 0.14.7. Aucun déploiement utilisateur ni validation native Exstream revendiqué ; limites antérieures de pagination native et de ressources externes conservées.

---


# État courant — Core Report 0.14.7 — 8 octobre 2026

**Itération 52 : sources natives exclusivement dans le rapport, commentaires conservés et contrôle des couleurs.**

La base complète 0.14.6 est conservée. Chapitres renommés « Vue détaillée » et « Variables et fonctions » ; section du référentiel système, empreintes, étiquettes « Source de conception » et deux paragraphes sous le nom du PUB retirés du rapport. Le référentiel reste utilisé en interne.

Le repli vers le code compilé est supprimé dans toutes les vues de règles, variables et fonctions. Le lecteur de champs source bornés accepte désormais les déclarations Integer/String, appels, affectations et lignes vides initiales. Les scripts conservent commentaires, indentation et lignes vides ; aucune correction des algorithmes métier. Les propriétés paramétrées reconnues sont décrites directement, sans inventer de script IF/ELSE.

R3 et R6 du dernier Bulletin : comparaison native de DF_FIC_SD_NOE_gest_infoClient_citoyenAmericain avec true/false, sans script textuel associé retrouvé. La forme éventuellement saisie dans l’éditeur ne peut pas être certifiée depuis ce PUB. La même règle de fidélité s’applique à R22/R27/R28/R29 ; les branches compilées ne sont plus présentées comme des branches source.

Le titre, le conseiller et le texte du contrat partagent le bleu #00008f. Les deux premiers blocs ont un fond blanc, tandis que les bandeaux des sections suivantes sont bleus. Ces propriétés sont conservées. Les deux chemins de résolution RGB/palette partagent le même résolveur ; aucune recoloration arbitraire.

Tous les scripts natifs récupérés sont conservés dans une archive jointe au PDF et livrée séparément. Les octets, commentaires, blancs et fins de ligne sont vérifiés. La fonction DF_FCT_removeAccentuatedChars contient des caractères non imprimables : notice dans le PDF et texte exact en pièce jointe, sans remplacement ni code compilé. Les paramètres de règles sont décrits dans des fichiers distincts, explicitement non assimilés à un script source.

Validation : 404 tests réussis, aucun échec ni saut, puis 56 tests ciblés réussis après les derniers ajustements ; un avertissement préexistant de dépréciation. Comparaison de 15 modèles à 0.14.6 : 4 409 algorithmes compilés inchangés, 3 544 sources natives vérifiées dont 358 supplémentaires, et 538 comparaisons paramétrées. Hors annotations de source, les champs préexistants sont identiques. La source récupérée d’une règle WEBLURE enrichit uniquement les preuves et la confiance de ses liens existants ; cette différence est vérifiée explicitement.

Livraison : code complet 0.14.7, rapport du dernier Bulletin de 128 pages, visuel de 8 pages, archive des sources, guide et bilan. Les 15 rapports passent les contrôles de contenu, d’absence de code compilé et de géométrie. Revue de toutes les pages livrées en planches et agrandissements ciblés. Preuves : validation/sources_0.14.7/ ; contrôle reproductible des modèles : scripts/validate_design_sources.py.

Journal canonique version 38 conservé intégralement ci-dessous. Aucun déploiement utilisateur ni validation native Exstream revendiqué. Conserver .env et les volumes, reconstruire pour installer pypdf, puis créer une nouvelle analyse. Les limites antérieures sur la pagination native, les ressources externes et les propriétés non reconnues restent applicables.

---


# État courant — Core Report 0.14.6 — 8 octobre 2026

**Itération 51 : corrections du rapport du dernier Bulletin de versement et fidélité des algorithmes.**

Les 22 demandes et la mention initiale sont traitées dans `docs/VALIDATION_RAPPORT_0.14.6.md`. Base complète 0.14.5 conservée. Source de recette : dernier PUB fourni, SHA-256 `99bc04e0aa443034dadfab2a5598ac73bdde3411e5e3ce1ab7806bd6ccb45520`, distinct du Bulletin historique. Les deux photos Design Manager servent au contrôle de l’arborescence.

Structure allégée : application, document, pages, section et paragraphes ; campagnes sous l’application, avec leurs 7 messages CTC et 13 messages GUT dans l’ordre enregistré. Les liens proviennent des identifiants et listes comptées du package. Le titre retrouve son format graphique A3 : Source Sans Pro Bold 19 pt, bleu #00008f, positions source et trait horizontal, avec réduction proportionnelle à la largeur de restitution. Les commandes inconnues ne sont pas extrapolées.

Le chapitre 2 devient « Mise en forme des tableaux ». Les commentaires et colonnes demandés sont supprimés ; aucune position binaire n’est affichée dans le rapport. Les lignes de bordure sans trait et les cellules sans fond ni bordure locale sont omises du résumé. Les répétitions sont présentées auprès du paragraphe concerné. Les noms automatiques sont remplacés par « Règle non nommée » sans fusionner les identités.

Règles : aucune modification des algorithmes métier. Les scripts présents sont restitués avec leurs commentaires et branches ; à défaut, le code compilé exact est affiché et désigné comme tel. Cela concerne aussi l’inventaire des règles non rattachées. Pour R22, R27, R28 et R29, le PUB ne fournit pas de script de conception textuel rattaché ; ses fonctions compilées contiennent bien une branche `else` avec exclusion. Le rapport n’en déduit plus un script source `ELSE EXCLUDE`. Une comparaison avec un autre état du développement nécessiterait ce script ou son export de propriété.

Validation : 383 tests réussis, aucun échec ni saut, un avertissement de dépréciation ; puis 21 tests ciblés réussis après les derniers ajustements de présentation. Les 15 PUB sont comparés à 0.14.5, avec 3 344 variantes compilées et tous les scripts disponibles vérifiés sur leurs octets sources. Hors version, nouveaux liens de campagnes et nouveaux objets graphiques bornés, les modèles préexistants sont identiques ; les anciennes compositions sont conservées. Règles, associations, repères Rn, données, mappings, Data Files, Page Flow et référentiel système restent inchangés.

Livraison : code complet 0.14.6, rapport du dernier Bulletin (149 pages), visuel (8 pages), bilan détaillé, guide de mise à jour et ce journal. Les 15 rapports régénérés passent les contrôles de géométrie, de mentions supprimées et de présence des algorithmes sans réécriture. Toutes les pages des deux PDF livrés sont parcourues en planches, avec agrandissements ciblés. Preuves compactes : `validation/report_0.14.6/` ; comparaison reproductible : `scripts/validate_report_revision.py`.

Journal canonique version 37 conservé intégralement ci-dessous. Aucun déploiement utilisateur ni validation native Exstream revendiqué. Conserver `.env` et les volumes, reconstruire les services, puis lancer une nouvelle analyse ; les anciens résultats ne sont pas recalculés automatiquement. Les limites antérieures de pagination native, ressources externes et propriétés non décodées restent applicables.

---

# État courant — Core Report 0.14.5 — 8 octobre 2026

**Itération 50 : référentiel système consolidé avec la base complète 0.14.4.**

Deux archives différentes portaient le numéro 0.14.4. La 0.14.5 conserve la base Data Files/PAGE/Page Flow/profils de lignes et y intègre le guide système. Les anciennes livraisons restent intactes.

Correction du précédent comptage : le PDF `VariableSystem.pdf` contient 34 noms listés, 64 appartenances aux 7 familles et une mention seulement textuelle (`SYS_PageTotalPrintedInDocument`), qui n’est pas promue en entrée ni alias confirmé. Descriptions, familles multiples, pages source et divergences documentaires sont maintenant exposées. Les noms SYS_ absents de l’extrait restent explicitement non listés, avec conservation de la convention système préexistante.

362 tests réussis, zéro échec/saut ; 44 nouveaux tests. 15 packages acceptés et comparés à la base 0.14.4 : tous les champs préexistants des modèles sont identiques hors numéro de version. Les nouvelles annotations seules s’ajoutent ; aucune valeur d’exécution, date, pagination ni répétition n’est simulée. Le support de Plaisance FDC et les évolutions de lignes/Data Files/PAGE sont conservés.

PDF de contrôle : Versement historique 152 pages de rapport / 8 de visuel ; WEBLURE 354 / 22. Vérifications automatiques et revue visuelle ciblée des nouvelles notices. Limites natives et de rendu antérieures inchangées. Voir `docs/VALIDATION_VARIABLES_SYSTEME_0.14.5.md` et les preuves compactes `validation/systemvars_0.14.5/`.

Journal canonique version 36 consulté et conservé intégralement dans l’historique, avec l’entrée 0.14.4 issue de l’archive publiée. Guide de mise à jour inclus. Pas de déploiement sur le poste utilisateur : conserver `.env`/volumes, reconstruire et lancer une nouvelle analyse.

---

# État courant — Core Report 0.14.4 — 8 octobre 2026

**Itération 49 terminée : Data Files, règles de lignes et PAGE/Page Flow ajoutés au parcours de rapport et au visuel.**

15 packages distincts analysés et 30 PDF produits. 251 tests réussis, 67 ignorés. Aucun contenu attendu n’est déclaré manquant par les contrôles de couverture; aucun PDF ne contient de page vide ou de texte hors page. Plaisance FDC est maintenant accepté par un profil d’en-tête borné. Voir `docs/VALIDATION_CONTENUS_0.14.4.md`.

Le nouveau Bulletin restitue les lignes H+, R, F et F+, les drivers de répétition et les conditions actives. Les 39 data sections du Bulletin ne sont pas présentées car aucune n’est reliée au document. Les variables `SYS_` sont identifiées comme système suivant la règle fournie. Weblure restitue les règles PAGE 510262/512304, les pages de débordement, les titres et les occurrences séparées. Les anciens IDs et algorithmes de règles et l’ordre de document conservés.

Limites : aucune documentation technique OpenText décrivant tous les types Data Files ou le format Page template n’est présente parmi les documents fournis. Le rattachement Page template demeure non décodé. Les ressources images externes/non reliées et la pagination native restent partielles et sont signalées dans les sorties.

Livraison : code 0.14.4, validation du corpus et rapports/visuels régénérés pour les 15 packages. Les anciennes livraisons et les anciens rapports sont conservés.

---

# État courant — Core Report 0.14.3 — 7 octobre 2026

**Itération 48 terminée : contenus partagés rapport/visuel, variables de conception et identification des règles homonymes. Version prête pour recette utilisateur.**

Base 0.14.2 conservée. Journal canonique version 35 consulté et historique intégral conservé ci-dessous. Correctifs génériques, sans sélection par nom métier, nom de fichier ou valeur d'exemple. Voir `docs/VALIDATION_CONTENUS_0.14.3.md`.

Causes : extraction complémentaire isolée dans le visuel ; rejet global d'un run conditionnel vide avant lecture du répertoire variable ; contenu non rattaché exclu de cette lecture ; inventaire affichant les fragments bruts. Ces causes sont corrigées séparément, sans inventer les propriétaires manquants. Les libellés source de règles restent intacts et les IDs compilés distinguent les noms identiques.

Résultats : 14 PUB distincts repris, 13 acceptés et FDC toujours refusé. 307 tests réussis sans échec ni saut. Les 53 omissions non vides observées dans l'ancien constructeur de rapport sont réintégrées : WEBLURE 13, Obsèques 32, NOA 6, Auto 2 soulignements. Les noms variables sont remontés dans le modèle commun, y compris ceux des éléments de page et des 25 unités Auto dont le propriétaire reste inconnu. Le titre de simulation utilise la variable 92874, en conservant séparément son sample.

Contrôles : preuves binaires bornées ; IDs et répertoire variable concordants ; couverture des placements par occurrence ; modèle/visuel identiques pour les tokens. Les définitions, mappings, algorithmes/noms de règles, ordre APP et flux DOCUMENT/SECTION/PAR, data sections et compositions préexistantes restent identiques. Les numéros Rn peuvent se décaler avec les nouvelles associations ; une correspondance par ID compilé est fournie.

26 PDF générés et contrôlés automatiquement ; WEBLURE livré : rapport 326 pages, visuel 17 pages, titres/variable/date vérifiés dans leurs passages, 54 occurrences et deux tableaux conservés, débuts DOCUMENT distincts. Revue visuelle de ces deux PDF. Le retrait générique des seuls espacements avant un saut de page explicite supprime une page vide observée sur Versement. Pas de validation native Exstream ni de recette sur le poste utilisateur.

Limites : Auto text:1252466/opcode -240 reste non interprété ; FDC refusé ; référence WEBLURE 21:38941, annexe FIP, data sections de lignes, Header/Footer, breakpage natif, ressources externes et pagination native restent partiels. Aucun de ces points n'est présenté comme corrigé.

Livraison : code complet 0.14.3, deux PDF WEBLURE, archive de validation avec bilan et correspondance des règles, guide de mise à jour et ce journal. Les anciennes livraisons sont conservées. Prochaine action : installer en conservant `.env`/volumes, reconstruire puis analyser de nouveau les fichiers ; les anciens résultats ne sont pas modifiés automatiquement.

---

# État courant — Core Report 0.14.2 — 6 octobre 2026

**Itération 47 terminée : occurrences séparées conservées et nouveau DOCUMENT sur une nouvelle page. Version prête pour la recette utilisateur.**

- Base : code livré 0.14.1, conservé intact ; SHA-256 de l'archive `06610820b87ba27919f8ea6f4ccf1230040ea88b1e45c13e5205544f6fe02585`. Journal canonique version 34 vérifié ; historique complet conservé ci-dessous.
- Cause : la liste documentaire dédoublonnée servait à la fois d'inventaire et de flux d'affichage ; elle supprimait les nouvelles occurrences d'une même référence. Le visuel regroupait aussi les empreintes de contenu sur tout le flux, indépendamment des composants intercalés. L'ordre APP corrigé en 0.14.1 était correct, mais ne suffisait pas à préserver les occurrences.
- Correction : nouvelle arborescence `document_flow`, avec un chemin distinct pour chaque occurrence de DOCUMENT/SECTION/PAR, dérivée des références décodées. L'inventaire unique et les objets sources restent inchangés. Le corps du rapport parcourt les occurrences. Le visuel limite son regroupement aux composants équivalents consécutifs d'une même liste ; des sections réutilisées séparées par un autre composant sont parcourues à nouveau. Les frontières DOCUMENT, les références inconnues et les cycles interrompent le regroupement. Les cycles restent bornés.
- WEBLURE : deux références réelles à `PAR_AFR_EPI_WEBLURE_TABLE` (`21:27644`) ; la seconde est sous `SEC_AFR_EPI_WEBLURE_BENEF`, immédiatement après `PAR_WEBLURE_Simul_Rente_Benef_Nom` (`21:27813`). Elles sont maintenant rendues toutes les deux. 53 paragraphes distincts / 54 occurrences connues dans le rapport ; 51 occurrences dans le visuel après regroupement local des variantes consécutives, contre 50 auparavant. Aucune occurrence n'a été ajoutée par son nom métier.
- Pagination : un saut de page est inséré entre deux DOCUMENT décodés, dans le corps du rapport et le visuel. L'ordre reste COURRIER → SIMULATION → MIEUX_COMPRENDRE → DEM_MISE_EN_SERVICE. Ce saut à la frontière DOCUMENT répond à la consigne utilisateur ; il n'est pas présenté comme une nouvelle preuve de décodage d'une propriété native `breakpage`.
- Contrôles : validation des chemins d'occurrences contre les références des sections ; contrôle d'identité du flux transmis au visuel avant export ; couverture vérifiée par occurrence pour distinguer une réutilisation prévue d'un doublon accidentel. Les métriques de composants uniques restent séparées du nombre de placements.
- Tests finaux : 289 réussis, aucun échec ni saut, un avertissement ; 13 nouveaux cas sur répétitions de paragraphes/sections, séparateurs inconnus, cycles, frontières DOCUMENT, variantes vides consécutives, altérations du flux et export WEBLURE réel. Les pages effectives de début/fin des occurrences visuelles sont vérifiées dans le test d'export. Un premier passage du corpus a mis en évidence un changement inutile du regroupement des variantes vides Obsèques : la règle d'équivalence antérieure a été rétablie, puis le corpus et la suite complète ont été revérifiés sur le code final.
- Corpus : les 14 contenus PUB distincts disponibles ont été repris. 13 analysables, comparés à la 0.14.1 ; Plaisance FDC conserve le même refus d'en-tête. Pour les 13, modèle source complet identique après retrait des seuls ajouts `document_flow` et du numéro de version : textes, règles, algorithmes, variables, mappings, data sections/rattachements, tableaux, styles et ordre APP inchangés. Treize visuels ont été régénérés avec le code final. Seul WEBLURE présente une nouvelle occurrence affichée ; les séquences des 12 autres restent identiques. Les fichiers d'entrée n'ont pas été modifiés.
- PDF WEBLURE finaux : rapport 306 pages, visuel 16 pages. Les 54 titres de paragraphes du corps sont retrouvés dans l'ordre ; le tableau apparaît deux fois, après le bon prédécesseur à sa seconde occurrence. Contrôle des changements de page aux frontières DOCUMENT. 237 unités visuelles distinctes / 347 placements prévus ; aucune occurrence manquante ou accidentellement dupliquée, ligne fractionnée ou paragraphe excessif signalé. Aucun vide ni dépassement physique détecté dans les PDF livrés. Toutes leurs pages rendues et parcourues en planches, avec agrandissements ciblés.
- Périmètre : nouveau `document_flow.py`, intégration parser/schéma/modèle visuel, parcours du corps du rapport, projection et contrôle de couverture du visuel ; métadonnées de version, tests et documentation. Décodeurs binaires, règles, data sections, propriétés graphiques, interface et scripts de démarrage inchangés.
- Limites conservées : référence WEBLURE `21:38941` non décodée, annexe FIP non décodée, flux documentaire Auto incomplet, en-tête FDC non pris en charge, propriétés natives `breakpage` non calibrées, data sections de lignes et correspondance Header/Footer partielles, ressources graphiques externes et pagination native non certifiées. Le tableau à 19 colonnes reste dense. Aucun de ces points n'est déclaré corrigé.
- Livraison : archive complète 0.14.2, deux PDF WEBLURE, guide `MISE_A_JOUR_FLUX_0.14.2.md`, bilan `docs/VALIDATION_FLUX_0.14.2.md`, preuves dans `validation/flow_0.14.2`, manifeste et journal. Aucun PUB/PDF client, secret réel, dépendance installée ou cache dans l'archive. Aucun déploiement utilisateur ni recette Windows/Docker/PostgreSQL/RQ/navigateur revendiqué.

Prochaine action : installer la 0.14.2 en conservant `.env` et les volumes, reconstruire les services puis lancer une nouvelle analyse. Vérifier la seconde occurrence du tableau après le nom du bénéficiaire et le début de chacun des quatre DOCUMENT sur une nouvelle page. Les anciens résultats enregistrés ne sont pas recalculés automatiquement.

---

# État courant — Core Report 0.14.1 — 6 octobre 2026

**Itération 46 terminée : correction de l'ordre des documents de l'application, vérifiée sur tout le corpus disponible. Version prête pour la recette utilisateur.**

- Base : archive livrée 0.14.0 préservée, SHA-256 `b8acecb7c3b24ad55ec5c512ac3b0846d0d5f11f20f1637443867bc96fcd1845`. Journal canonique version 33 lu ; historique intégral conservé ci-dessous.
- Cause reconnue : `document_graph()` constituait le flux des paragraphes dans l'ordre physique des définitions DOC. `application_graph()` décodait ensuite correctement les références APP, utilisées dans l'introduction mais non propagées au corps du rapport ni au visuel. Les contrôles précédents vérifiaient séparément la hiérarchie et la présence des contenus, sans vérifier cette concordance de bout en bout. Le moteur était en erreur ; le PUB n'est pas responsable.
- WEBLURE avant : SIMULATION (`10:3999`), COURRIER (`10:4001`), DEM_MISE_EN_SERVICE (`10:4051`), MIEUX_COMPRENDRE (`10:4052`). Ordre APP démontré et maintenant utilisé : COURRIER (`10:4001`), SIMULATION (`10:3999`), MIEUX_COMPRENDRE (`10:4052`), DEM_MISE_EN_SERVICE (`10:4051`).
- Correctif générique : module `document_order.py`, appliqué après le décodage APP et avant les portées, la numérotation éditoriale et le modèle visuel. Le moteur suit uniquement une liste APP validée ; aucun tri alphabétique, offset de stockage ou nom métier ne décide de l'ordre. Une vérification commune bloque les exports si documents, paragraphes et visuel divergent de cette liste. Les références non décodées restent explicites ; aucune relation n'est inventée.
- Changements de code : nouveau module, appel dans `parser.py`, contrôle dans `schema.py`, version backend/frontend 0.14.1, 16 tests ajoutés. Les décodeurs de contenus, tableaux, data sections et règles, les moteurs de rendu, les styles, l'interface et les scripts de démarrage ne sont pas modifiés (hors métadonnées de version).
- Corpus : 15 chemins, 14 PUB binaires distincts après dédoublonnage SHA-256. Deux analyses complètes, avec les moteurs 0.14.0 puis 0.14.1 : 13 fichiers acceptés et comparés ; Plaisance FDC refusé dans les deux versions avec la même erreur d'en-tête. Aucune exception locale d'en-tête n'a été utilisée. Les sources sont inchangées.
- Résultats : WEBLURE est le seul PUB dont l'ordre documentaire, l'ordre des paragraphes et l'ordre visuel changent. Les 12 autres PUB analysables conservent leur séquence : Adhésion et ses cinq variantes Color/Round/Width/Black/BorderPink, Versement, FIP, Obsèques, Auto, NOA et Plaisance CP. Aucune autre correction d'ordre n'est démontrée sur ce corpus.
- Non-régression : comparaison profonde du modèle complet après neutralisation des seules différences attendues de version, audit d'ordre, séquences racines et numéros éditoriaux P/R. Identité des contenus, algorithmes, identifiants compilés, variables, mappings, data sections/rattachements, tableaux, répétitions, styles et relations dans les 13 cas ; appartenance des paragraphes/règles et références non résolues préservée. Détail reproductible dans `validation/order_0.14.1`.
- Limites conservées : FIP conserve une annexe référencée non décodée ; Auto conserve ses régions de pages sans ordre documentaire complet établi ; WEBLURE conserve sa référence de paragraphe non décodée `21:38941`. Data sections de lignes, correspondances Header/Footer, pagination native et ressources d'images restent au même niveau de connaissance que la 0.14.0. Aucun de ces points n'est déclaré corrigé.
- Tests : 276 réussis, aucun échec ni saut, un avertissement ; dont 16 nouveaux cas (listes APP validées ou ambiguës, références manquantes, non-régression mono-document, contrôle avant export et génération des deux PDF WEBLURE). Le premier test WEBLURE comptait à tort la référence non décodée parmi les paragraphes connus ; l'attendu du test a été corrigé, sans étendre le décodeur.
- PDF WEBLURE régénérés : rapport 300 pages, visuel 13 pages. Les 53 paragraphes connus sont retrouvés dans l'ordre attendu dans le corps du rapport ; les débuts des quatre documents sont aux pages PDF 7, 15, 28 et 34. Parcours effectif du moteur visuel vérifié par le test d'export. 237 unités visuelles rendues, aucune unité reconnue manquante ou dupliquée, aucune ligne fractionnée ni paragraphe excessif signalé. Aucun vide ni dépassement physique détecté sur les 313 pages. Toutes les pages ont été rendues et parcourues en planches, avec agrandissements ciblés ; ceci ne constitue pas une certification de fidélité au rendu natif Exstream. Le tableau à 19 colonnes reste dense.
- Livraison : code complet `GroupeAlterna_CoreReport_Code_v0.14.1.zip`, guide `MISE_A_JOUR_ORDRE_0.14.1.md`, bilan `docs/VALIDATION_ORDRE_0.14.1.md`, preuves compactes, manifeste et journal actualisé. Aucun PUB client, PDF client, secret réel, cache ou dépendance installée dans l'archive. Les versions précédentes sont conservées. Aucun déploiement sur le poste utilisateur ni recette Windows/Docker/PostgreSQL/RQ/navigateur n'est revendiqué.

Prochaine action : installer la 0.14.1 en conservant `.env` et les volumes, reconstruire les services, puis créer une nouvelle analyse WEBLURE. Les anciens résultats enregistrés ne sont pas recalculés automatiquement. Vérifier l'ordre COURRIER → SIMULATION → MIEUX_COMPRENDRE → DEM_MISE_EN_SERVICE dans les deux PDF.

---

# État courant — Core Report 0.14.0 — 4 octobre 2026

**Itération 45 terminée : data sections, documents multipages, règles de conteneurs et propriétés étendues des tableaux WEBLURE. Version prête pour la recette utilisateur.**

- Base : archive code 0.13.4 préservée, SHA-256 `b4cc30de3ca8366a7d2c3f73b7863c12835e663d28065d19293a38f484820a52`. Travail dans `engine/exstream-alterna`. Journal canonique version 32 lu ; historique intégral conservé ci-dessous. Charte Alterna et actifs authentiques du moteur utilisés.
- Source principale : `AFR_EPI_WEBLURE_COURRIER_SIMUL.txt`, véritable PUB binaire ; SHA-256 `45ff5ce41fefac5b7fd02c63a956fc180eba2d3fea6c06d3d252335b3b4e2621`. Le contenu source n'est ni modifié ni inclus dans la livraison.
- Data sections : 31 déclarations / 30 noms dans la source partagée. Les 8 déclarations du sous-arbre WEBLURE sont identifiées ; 11 sélecteurs explicites sont résolus (10 sections, 1 document). Trois des 8 déclarations restent sans propriétaire explicite décodé. Un nom partagé par plusieurs déclarations reste ambigu. Chemins XML, identités, rattachements et preuves bornées sont conservés et exposés dans le rapport.
- Structure : 4 documents et 53 paragraphes de flux retrouvés (aucun flux documentaire reconstruit auparavant sur ce PUB), dont le document à deux références de pages. L'affectation des sections aux pages et l'ordre d'exécution ne sont pas supposés.
- Tableau principal `21:27644` : 19 colonnes, 10 lignes ; 16 règles de colonnes aux positions physiques 3 à 18 ; 8 rattachements de règles de lignes (6 IDs distincts). Référence de règle décalée reconnue, avec variante de propriété additionnelle de 16 octets. Ligne 8 : Repeat explicite sur `WRK_AFR_EPI_WEBLURE_RENTE_LineValue1`. Ligne 3 : driver `WRK_AFR_EPI_WEBLURE_RENTE_LineTitle`, sans en déduire un Repeat. Les lignes 9/10 n'héritent pas arbitrairement du driver de la ligne 8.
- Catalogue : 274 IDs de définitions concordent avec 274 règles compilées distinctes / 327 occurrences. Le moteur les extrayait déjà ; la nouveauté est le rapprochement vérifiable et les rattachements structuraux supplémentaires. Les règles portant le même nom restent distinctes. 164 règles sont reliées au périmètre documentaire reconstruit. Les conditions explicites des documents/sections sont ajoutées au catalogue et à la comparaison.
- Interface : import `.pub` ou `.txt` renommé ; le serveur exige toujours une signature/enveloppe Exstream prise en charge. Un texte ordinaire reste refusé. Libellés français/anglais mis à jour, sans changement de charte.
- Tests : suite générale 208 réussis, 50 sautés (autres fixtures client indisponibles), aucun échec résiduel ; reprise finale ciblée 39 réussis, dont deux nouveaux cas, soit 210 cas distincts validés. Les 14 cas spécifiques couvrent structures synthétiques, mutations/troncatures, ambiguïtés, alias `.txt`, comparaison et PUB WEBLURE. Compilation Next.js/TypeScript réussie.
- Régression 0.13.4 / 0.14.0 : cinq PUB historiques disponibles (Adhésion, Versement, FIP, Obsèques, Auto). 35 invariants préservés : variables, algorithmes, mappings, contenus, ordre des paragraphes, topologie des tableaux et répétitions pour chaque source. Aucune cible antérieure ni unité visuelle perdue. Ajouts documentés de cibles de document/section, trois colonnes FIP et sept lignes Auto ; les compteurs de Versement intègrent désormais la condition de document 777282 (29 règles au lieu de 28).
- Rapports WEBLURE générés : rapport 299 pages, visuel 13 pages. Contrôles automatiques sur toutes les pages : aucun vide/dépassement physique détecté ; aucun placement visuel reconnu manquant/dupliqué, aucune ligne fractionnée ni paragraphe excessif signalé. Huit noms de data sections présents dans le rapport. Revue ciblée des pages de data sections, tableau, types de lignes et catalogue (5, 10, 58, 65), puis nouvelle revue des pages finales 5/58. Pas de revue humaine exhaustive des 312 pages ; les 19 colonnes restent denses dans cette restitution statique.
- Limites conservées : data sections directement portées par les lignes non rattachées ; codes bruts 7/3/2/1 conservés sans assimilation validée à Header/Footer/Section Header ; héritages, conditions de pagination, débordements, valeurs du flux et ordre des événements non exécutés. Le rapprochement du catalogue ne certifie pas toutes les portées. Les ressources d'images et les limites historiques de rendu restent inchangées.
- Fichiers principaux : `data_sections.py`, `report_data_sections.py`, `structure.py`, `hierarchy.py`, `layout.py`, `scopes.py`, `coverage.py`, `compare.py`, `schema.py`, `report_structure.py`, `parser.py`, `api.py`, traductions et formulaire. Nouveaux tests `test_data_sections.py`. Profils génériques : aucun choix de décodage conditionné par le nom/ID métier, l'offset absolu ou le hash du PUB ; ces références ne figurent que dans les tests et le bilan.
- Livraison : `GroupeAlterna_CoreReport_Code_v0.14.0.zip`, guide `MISE_A_JOUR_DATA_SECTIONS_0.14.0.md`, bilan et preuves compactes dans `validation/weblure_0.14.0`, journal actualisé. Aucun fichier `.env` réel, PUB client, dépendance installée ni rapport contenant les données client dans le ZIP. Les versions précédentes sont conservées. Aucun déploiement ni recette Windows/Docker/PostgreSQL/RQ/navigateur.

Prochaine action : installer le code en conservant `.env` et volumes, reconstruire puis créer une nouvelle analyse du PUB (ou du `.txt` renommé). Vérifier les rattachements et types de lignes dans Exstream ; transmettre les écarts ou une variante contrôlée pour calibrer les data sections de lignes et Header/Footer sans extrapolation.

---

# État courant — Core Report 0.13.4 — 30 septembre 2026

**Itération 44 terminée : IntroCP, puces et interligne, dimensions de tableaux et zones de texte.**

- Base 0.13.3 intacte ; travail sous `work_intro_0134/release/exstream-alterna`. Journal canonique version 31 vérifié, historique complet conservé.
- IntroCP : police Source Sans Pro Regular 10 pt vérifiée, variables incluses ; deux puces Wingdings 0xA7 identifiées par préfixe compté et police indépendante, rendues par U+25AA avec substitution déclarée. Retrait 10,08 pt, interligne 12,48 pt et cinq paragraphes centraux conservés. Mapping Unicode N4115 w-1167 consulté.
- Dimensions : largeur IntroCP 12,70 cm ; hauteurs de lignes 191/411/284 unités de 1/300 pouce utilisées comme minima. Largeur et hauteur minimale des zones de texte bornées ; agrandissement pour noms longs/conditions, sans coupure de contenu. Pas de double réservation de la hauteur des enfants ancrés. Texte libre découpable entre pages à largeur source.
- Modules : scopes.py, text_styles.py, visual_graphics.py, visual_render.py ; sept nouveaux tests test_intro_layout.py. Aucun sélecteur métier/offset/hash dans les nouveaux profils.
- 246 tests finaux réussis, zéro échec/saut ; 14 chemins / 13 PUB distincts, 26 PDF / 2434 pages. Les échecs intermédiaires de double conteneur et texte long insécable ont été corrigés puis revérifiés. Faits/contenus/règles/topologies des 11 historiques préservés ; contrôles finaux sans vide/débordement physique ni contenu reconnu manquant/dupliqué, ligne fractionnée ou paragraphe excessif.
- Revue : visuel CP 14 pages sur planches et zoom 1 ; rapport CP 1/2/3/5/7/35/205 et zoom 5. Autres pages contrôlées automatiquement. CP livré : rapport 205 pages, visuel 14 pages. Pas de déploiement ni recette système. Sources originales inchangées.
- Limites : pagination valorisée non reproduite ; autres puces/retraits/styles partiels, soulignement et images non reliées inchangés. FDC testé uniquement avec exception d'en-tête locale, non intégrée au moteur.
- Prochaine action : recette utilisateur d'IntroCP (visuel page 1, rapport page 5), puis calibration d'autres styles de puce/retraits sur des variantes contrôlées si nécessaire. Le profil d'en-tête FDC et l'image NOA restent des travaux distincts.

---

# État courant — Core Report 0.13.3 — 30 septembre 2026

**Itération 43 terminée : variables, règles des paragraphes et zones de texte Plaisance.**

- Base 0.13.2 intacte ; travail : `work_plaisance_0133/release/exstream-alterna`. Journal canonique version 30 consulté et historique intégral conservé.
- Correction utilisateur : DuréeContratCP / DuréeContratAV sont des text boxes, pas des tableaux. La collection `graphics.text_boxes` et le module `text_boxes.py` les distinguent explicitement des grilles.
- Segmentation du répertoire variable avant interprétation des fragments ; suppression du seul octet technique prouvé, conservation des vrais caractères. Quatre occurrences de dates par bloc ; noms de variables affichés à la place de ______.
- Chaîne propriétaire avec couleurs RGB/palette reconnue. Trois paragraphes internes et cibles 700080/700080/700081 démontrées ; aucune condition évaluée. Fond mauve, contour bleu 0,24 pt, corps gras bleu 10 pt, largeurs CP/AV distinctes et marges uniformes 5,76 pt. Rapport et visuel partagent le rendu décoré.
- 239 tests finaux réussis, zéro saut/échec ; huit cas spécifiques positifs/négatifs. 14 chemins / 13 PUB distincts, 26 PDF / 2415 pages. 12 packages acceptés normalement ; FDC testé avec exception locale isolée, toujours refusé par le moteur livré car son en-tête n'est pas encore validé. Les 11 audits historiques conservent faits, contenus, règles et topologies.
- Revue : visuel CP 12 pages, zoom 2 ; rapport CP 1/2/3/7/8/201, zoom 7. Contrôles automatiques des autres pages. Aucun vide/débordement de page ni perte/doublon de contenu reconnu, ligne fractionnée ou paragraphe excessif signalé.
- Livraison : code complet 0.13.3, rapport CP 201 pages, visuel CP 12 pages, archive validation, journal. Pas de déploiement/recette système. Sources PUB inchangées, pas de PDF natif utilisé pour générer les sorties.
- Limites : compatibilité d'en-tête FDC non intégrée ; ressources d'images non reliées et pagination/styles non calibrés conservés comme limites. Le visuel documentaire expose toutes les conditions et les noms longs, donc sa hauteur n'est pas la hauteur composée native.
- Prochaine action : recette utilisateur des deux text boxes sur Plaisance CP ; pour le FDC, établir un profil structurel d'en-tête nul avant de modifier `binary.validate`. Pour NOA, la référence de l'image centrale reste à relier.

---

# État courant — Core Report 0.13.2 — 30 septembre 2026

**Itération 42 terminée : compositions graphiques compilées, ancrages et typographie indépendante. Image centrale NOA encore non résolue.**

- Base : 0.13.1 intacte ; travail sous `work_objects_0132/release/exstream-alterna`. Journal canonique version 29 vérifié, 126126 octets ; historique intégral conservé ci-dessous. Instructions projet, charte et actifs authentiques consultés.
- Nouveaux profils génériques : A0/107 à commandes comptées et balises Table/Row/Cell équilibrées ; propriétaire inline -251/-106 avec indices/déplacements corroborés. Polygones exacts et glyphes positionnés ; aucune sélection par nom, identifiant client, offset absolu ni empreinte.
- NOA titre : deux tableaux compilés et une image sur la même ligne. Titre gras bleu 10 pt et appel (1) 6 pt. Les objets sont décrits séparément des grilles à axes. `object_composition.py` et `object_render.py` partagés par le rapport et le visuel. L'image n'est pas reconstituée : rectangle source et mention explicite, descripteur opaque conservé.
- Ancrages : commutations -62/-63 admises avant le couple de référence, sans sauter d'opcode inconnu. Note vosAvantages après le tableau ; corrections génériques supplémentaires NOA, Adhésion et Obsèques. Styles indépendants du ciblage : promotion NOA à 8 pt, quatre unités FIP, une Adhésion, une Obsèques et variantes. Les portées non décodées restent non décodées.
- Conditions : fragments inline encadrés dans le visuel et les résumés ; plus de « 123 mois ». Aucun algorithme exécuté ou branche choisie ; repères Rn conservés dans le rapport.
- Validation : 231 cas uniques validés (suite globale et reprise ciblée de six profils), aucun échec résiduel ni saut. Quatre anciennes attentes de couverture ont été adaptées avec contrôle des unités retrouvées ; omission initiale du dossier de variantes corrigée. 12 chemins / 11 PUB distincts, 22 PDF / 1982 pages. Faits sources, textes, topologies et cibles existantes conservés ; anciens contenus visuels tous présents. Zéro vide/débordement de page et aucun placement perdu/dupliqué, ligne fractionnée ou paragraphe excessif.
- Revue : visuel NOA 11 pages sur planches + zoom page 2, rapport NOA 14/15/108, visuel Adhésion 1 et Obsèques 4. Contrôle automatique des autres pages. Sources PUB inchangées, aucun PDF de référence utilisé pour générer les sorties.
- Livraison : code complet, rapport et visuel NOA, ZIP validation, journal ; guide et bilan inclus. Aucun déploiement/recette Docker/Windows/navigateur/PostgreSQL/RQ. Le profil n'est pas déclaré universel pour tous les PUB.
- Prochaine action précise : établir les références de ressource du record A0/05 (rectangle NOA 700,30–765,95) et leur correspondance aux octets de l'image. Demander au besoin une variante compilée qui change uniquement l'image, sans confondre absence de décodage avec absence dans le PUB. La divergence Versement TITRE documentée en 41 reste ouverte.

---

# État courant — Core Report 0.13.1 — 30 septembre 2026

**Itération 41 terminée : quatre portées de bordures distinctes, cadres de tableaux décodés à partir des captures Versement.**

- Base : 0.13.0 conservée ; copie de travail `work_borders_0131/release/exstream-alterna`. Journal canonique v28 identifié et copie locale complète préservée (122761 octets). Instructions projet/charte et six captures jointes consultées localement.
- Nouvelle preuve utilisateur : Table Properties = pourtour extérieur ; Row Properties = trait haut/bas sur toute la largeur ; Column Properties = trait gauche/droit sur toute la hauteur ; Cell Properties = uniquement les côtés de la cellule. Correction de l'interprétation précédente en héritage effectif local.
- Décodage : propriétaire graphique lié au tableau compté par géométrie répétée, chaîne Pascal et deux flux TLV complets. Activation uint16 +100, style +102, épaisseur +106, couleur +110. Profil continu reconnu, types inconnus conservés sans dessin ; mesures en 1/300 de pouce, 2 unités = 0,016933 cm = 0,48 pt, affichage UI 0,02 cm. Aucun nom, offset absolu ou empreinte sélectionné en production.
- Résultat : sept cadres de tableaux du Versement retrouvés, dont CONSEILLER/CONTRAT/VOTRE_SITUATION correspondant aux captures. Deux colonnes 9,4827/8,9154 cm ; trait droit propre de la première et aucun trait propre de la seconde. Rendu indépendant des cellules, valable aussi pour cellules fusionnées/vides et fragments de lignes. Rapport : quatre portées auditées séparément ; déduplication : cadre inclus.
- Divergence à résoudre avec l'utilisateur : la capture Row Properties TITRE (1,10 cm, trait inférieur 0,02 cm) n'a pas de correspondant dans le PUB joint. Paragraphe 21:43432, plage 4365933–4369104 : objet texte, aucun axe -103/-109 ni conteneur -108. Ne pas inventer un trait ; demander le PUB compilé correspondant à la capture.
- Validation finale : 219 tests réussis, aucun échec/erreur/saut, 143.30 s ; 16 nouveaux tests structurels, mutations, calibration et tracés PDF. 12 chemins, 11 PUB distincts comparés à 0.13.0 ; faits sources, topologie et contenus visuels antérieurs conservés. 22 PDF, 1982 pages, aucun vide ni débordement de texte détecté ; visuels sans perte, doublon de placement, ligne fractionnée ou paragraphe excessif. Revue : cinq pages du visuel Versement, pages 5/11/12 du rapport. Autres pages contrôlées automatiquement, sans revue humaine exhaustive.
- Livraison : code complet 0.13.1, visuel et rapport Versement, archive de validation avec tous les PDF et captures, ce journal. Guide et bilan technique inclus. Sources client intactes ; aucun PUB dans les livrables. Aucun déploiement ni nouvelle recette Docker/Windows/navigateur/PostgreSQL/RQ.
- Limites : profils de cadres non reconnus, types non continus, priorité native des traits superposés, soulignement, rayon des arrondis, ressources externes et pagination native. Le peintre dessine les traits globaux puis locaux, convention annoncée ; aucune fermeture horizontale supplémentaire aux coupures de page.
- Prochaine action : installer 0.13.1 en conservant `.env` et volumes, reconstruire, relancer les analyses ; obtenir le PUB correspondant à la capture TITRE pour calibrer ce cas précis.

Historique intégral conservé ci-dessous.

---

# État courant — Core Report 0.13.0 — 30 septembre 2026

**Itération 40 terminée : ancrages des tableaux, bordures des quatre côtés et typographie source, validés sur tout le corpus disponible.**

- Demande : replacer le tableau FIP « formulesContratEtChoix » sous l'introduction finissant par « charges et revenus déclarés » ; analyser les bordures FIP/Versement et respecter la typographie dans le rapport et le visuel.
- Base : 0.12.1 conservée, copie finale `work_format_013/release/exstream-alterna`. Journal canonique v27 repris intégralement (117786 octets) ; placeholder joint exclu. Instructions projet, charte, actifs authentiques et sources disponibles consultés. Aucun dépôt Git ni AGENTS.md applicable, aucun Tools Report ou PDF externe utilisé comme entrée du moteur.
- Placement : les objets de tableau sont ancrés dans un paragraphe rich-text vide, alors que leur conteneur est sérialisé après le texte propriétaire entier. Profil borné avec paire -251/-106, propriétaire unique et objets comptés ; pied de conteneur contrôlé avec commutateurs 0/1. FIP formules : propriétaire text:4767305, paragraphe interne 2, position 311. FIP notreEntretien : text:4722313, index 4, position 610. Aucun identifiant/offset absolu sélectionné en production. Introduction et petit tableau regroupés sur la même page PDF.
- Bordures : quatre côtés locaux activés par masque et sélecteur, épaisseur distincte en 1/300 de pouce, couleurs RGB/palette ; traits haut/bas des lignes et gauche/droite des colonnes audités séparément. Les colonnes avec trait reconnu conservent leur largeur physique. Priorité locale bornée ; conflits partagés et contour global indépendant restent inconnus. Cellules vides à charge de quatre zéros récupérées après grammaire complète, notamment Code ISIN. Marges intérieures bornées dans les gouttières étroites sans modifier la largeur source.
- Typographie : tailles des slots, couleurs, gras/italique, alignements gauche/droite/centré/justifié, espacements, retours internes reconnus et appels en exposant ; rendu commun rapport/visuel. Source Sans Pro conservée, variantes DejaVu Sans de substitution incluses avec licence. Repères Rn du rapport conservés sans recoloration arbitraire du texte source. Soulignement non calibré, exposants de hauteur indicative.
- Régression détectée pendant la recette : une nouvelle région de grille Auto issue des cellules vides était exclue par la restauration de l'ancienne sous-liste des régions. Correction de cette restauration ; les textes antérieurs et leurs styles restent présents. La déduplication inclut le contenu des tableaux ancrés, les retours et les exposants.
- Tests finaux : 203 réussites, zéro échec/erreur/saut, 194.54 secondes, JUnit vérifié ; 19 nouveaux cas ciblés. Avertissement Starlette/httpx préexistant. Les essais intermédiaires sont exclus des preuves livrées.
- Corpus : 12 chemins, 11 contenus SHA-256 distincts, tous comparés à 0.12.1. Faits sources, algorithmes, cibles internes des règles et textes inchangés ; axes/cellules principaux conservés et coordonnées relues dans les octets. Conservation de chaque identifiant et fragment visuel antérieur vérifiée ; nouvelles unités bornées autorisées. Les styles et associations dérivés sont enrichis, sans revendication d'égalité complète des modèles.
- PDF : 22 FR, 1914 pages ; aucun PDF illisible, page vide ni texte hors page détecté. Visuels sans élément manquant, placement dupliqué, ligne fractionnée ou paragraphe trop long signalé. Revue : les dix pages du visuel FIP et les cinq pages du visuel Versement, les pages PDF 11 et 14 du rapport FIP, et les pages PDF 8 et 9 du rapport Versement. Aucune relecture humaine exhaustive des autres pages.
- Livraison : `GroupeAlterna_CoreReport_Code_v0.13.0.zip`, `GroupeAlterna_CoreReport_Validation_Presentation_v0.13.0.zip`, `GroupeAlterna_FIP_Visuel_corrige_v0.13.0.pdf`, `GroupeAlterna_Versement_Visuel_corrige_v0.13.0.pdf` et ce journal, dans `work_format_013/livraison`. Guide et bilan technique inclus dans le code ; les deux rapports complets sont dans l'archive de validation. API et parcours utilisateur inchangés ; version mise à jour.
- Limites : soulignement, rayon des arrondis, bordures partagées, contour global indépendant, traits non continus, retraits/puces/tabulations/interligne natif, ressources externes et pagination Exstream partiels. Variables affichées par leur nom, conditions non exécutées. Pas de déploiement ni nouvelle recette navigateur/Docker/Windows/PostgreSQL/RQ.
- Prochaine action : installer 0.13.0 en conservant `.env` et volumes, reconstruire, relancer les analyses ; pour calibrer le soulignement, comparer deux PUB identiques dont un seul mot est souligné dans le second, avec paragraphe/mot et capture des propriétés.

L'historique intégral de la version canonique précédente est conservé ci-dessous.

---

# État courant — Core Report 0.12.1 — 30 septembre 2026

**Itération 39 terminée : correction des lignes du tableau FIP « notreEntretien », validée sur tout le corpus disponible.**

- Demande : analyser et corriger le tableau de `PAR_AFR_EPI_NSE_FDC_DEVOIR_DE_CONSEIL_ESSENCIEL_BR_notreEntretien` dans `AFR_GENERIC_FIP_DEVIS_ESSENCIEL.pub`, qui doit présenter l’en-tête, Inhumation et Crémation.
- Base : moteur 0.12.0 conservé ; copie finale `work_fip_0121/final/exstream-alterna`. Journal canonique v26 repris intégralement, 113 189 octets ; placeholder joint exclu. Aucun dépôt Git ni AGENTS.md applicable trouvé.
- Cause : le lecteur exigeait à tort une sentinelle `0xffffffff` dans tous les axes. Les deux lignes de données possèdent des propriétés explicites avec zéro dans les deux champs concernés. Leur rejet réduisait la grille, excluant Crémation et la note. La valeur opaque 30 du pied de conteneur n’était pas reconnue non plus.
- Correction : profil de ligne validé sur l’ensemble de ses 883 octets, contrôle des enveloppes/TLV et des compteurs, pied 30 limité au profil reconnu, rejet d’une grille incomplète au lieu de compacter ses indices, conservation d’une dernière ligne vide quand le compteur l’établit. Aucun nom, ID, empreinte ou offset de ce PUB utilisé comme sélection en production.
- Résultat FIP : les trois lignes principales et les six variables de prix sont à leur place ; l’introduction reste hors du tableau. La note « Hors concessions, monuments et frais d’inhumation à l’étranger » est conservée en fusion sur quatre colonnes. Le format binaire représente cette note par un quatrième axe ; aucune donnée n’est supprimée pour forcer un compteur à trois.
- Rendu/audit : styles enrichis après finalisation des cellules ; petit tableau et note fusionnée conservés sur la même page du rapport, en FR/EN. Visuel corrigé page PDF 3 ; rapport complet page PDF 13, numéro imprimé 12.
- Tests : 184 réussites, zéro échec/erreur/saut, 161,83 s, bilan JUnit vérifié. Treize nouveaux cas couvrent le profil, les corruptions, les coordonnées, les variables, la note fusionnée, la dernière ligne vide et le rendu FR/EN. Avertissement Starlette/httpx préexistant. Les essais interrompus ou sans bilan complet ne sont pas comptés comme réussites.
- Corpus : 12 chemins, 11 contenus SHA-256 distincts, tous comparés à 0.12.0. Les axes et cellules précédents sont conservés ; chaque nouvel axe est justifié par le profil reconnu, toutes les coordonnées vérifiées dans les octets. 88 tables corrigées à travers les fichiers, dont les répétitions de composants partagés et une seconde table FIP. Les textes, déclarations de variables, algorithmes, cibles internes de règles, mappings, calculs, dictionnaire et XSD restent identiques. Les associations et usages dérivés changent volontairement ; aucune égalité globale du modèle n’est revendiquée.
- PDF : 22 FR, 1 889 pages, zéro page vide ni texte hors page selon les contrôles automatiques. Visuels sans élément manquant, placement dupliqué, ligne fractionnée ni paragraphe trop long signalé. Revue visuelle des neuf pages du visuel FIP et de la page du tableau dans le rapport ; pas de relecture humaine exhaustive des autres pages. Les cas FR/EN sont également vérifiés par tests.
- Consultés : instructions projet, charte et actifs existants, journal v26, sources 0.12.0, tous les PUB disponibles, structures binaires, tests, audits et PDF générés. Aucun Tools Report ni PDF externe utilisé comme entrée du moteur.
- Livraison : `work_fip_0121/livraison/GroupeAlterna_CoreReport_Code_v0.12.1.zip`, `GroupeAlterna_CoreReport_Validation_FIP_v0.12.1.zip`, `GroupeAlterna_FIP_Visuel_corrige_v0.12.1.pdf` et ce journal. Guide `MISE_A_JOUR_CORRECTIF_FIP_0.12.1.md` et bilan `docs/VALIDATION_FIP_0.12.1.md` inclus dans le code. Les preuves livrées proviennent uniquement de la validation finale.
- Limites : profils calibrés sur ce corpus, pas de conformité Exstream universelle. Rayon exact, côtés de bordures non calibrés, héritage, ressources externes et pagination native restent partiels. API et parcours utilisateur inchangés ; pas de nouveau test navigateur/Docker/Windows/PostgreSQL/RQ, pas de déploiement.
- Prochaine action exacte : installer 0.12.1 en conservant `.env` et volumes, reconstruire les services, puis relancer l’analyse FIP. Les résultats d’anciennes tâches restent inchangés.

L’historique intégral de la version canonique précédente est conservé ci-dessous.

# État courant — Core Report 0.12.0 — 29 septembre 2026

**Itération 38 terminée : intégration des dimensions et styles de tableaux, validée localement sur tout le corpus disponible.**

- Demande : intégrer au moteur les largeurs, fonds, contours et formes calibrés, puis utiliser tous les PUB pour valider. La sonde de calibration précédente est remplacée dans le parcours moteur par un profil structurel sans offsets absolus ni sélection par empreinte.
- Base : archive complète Core Report 0.11.0 conservée ; copie isolée `core_report/exstream-alterna`. Journal canonique v25 repris, 108 632 octets ; le placeholder joint de 16 octets n'est pas utilisé. Aucun dépôt Git ni AGENTS.md dans cette copie.
- Décodage : largeurs fixes au 1/300 de pouce, palette locale RGB, fond explicite, codes de forme 0/5/9/10, bordure supérieure locale calibrée et profil inférieur historique. Mesures, statuts et preuves dans `tables[].presentation`, schéma 1.0 étendu de façon optionnelle. Aucun changement des règles, variables, calculs, mappings, contenus ou associations préexistants.
- Rendu : dimensions et groupes de styles dans les rapports FR/EN ; visuel avec largeurs reconnues, réduction pour la page tracée dans les statistiques, fonds, formes et traits validés. Les dimensions automatiques/contraintes ne sont pas assimilées à des largeurs fixes. Rayon indicatif 3 pt distinct du rayon source nul.
- Tests : 171 réussites, zéro échec et zéro saut, 118,06 s. 21 nouveaux tests des valeurs contrôlées, tracés PDF, mutations de palette/métadonnées, unités, formes inconnues et structures corrompues. Un avertissement Starlette/httpx préexistant. Deux lancements initiaux de suite n'ont pas fourni de bilan complet ; ils ne sont pas comptabilisés comme réussites. La suite finale complète fournit le bilan ci-dessus.
- Corpus : 12 chemins / 11 SHA-256 distincts, dont les six courriers historiques et les cinq variantes Round/Width/Color/Black/BorderPink ; la référence Adhésion dupliquée est conservée comme alias. Tous les contenus ont été analysés avec 0.11.0 et 0.12.0 : aucune différence métier après exclusion des ajouts de présentation, de la version et de la liste des propriétés désormais interprétées.
- Livrables PDF : 22 FR, 1 890 pages ; deux EN BorderPink, 45 pages. Aucune page vide ni texte hors page dans les contrôles automatiques FR ; contrôle de limites EN également réussi. Tous les visuels ont une couverture complète sans placement dupliqué, fractionnement de ligne ou paragraphe trop long. Revue humaine ciblée des six tableaux contrôlés, de deux pages de rapport et des cinq autres courriers en page 1 ; pas de relecture humaine exhaustive des 1 935 pages.
- Itérations : rendu initial rejeté sur une table Adhésion automatique (valeurs 15/30). Garde structurel renforcé, correction du rendu, puis relance complète des tests et des 11 analyses. Les preuves des premières tentatives restent dans scratch ; seules les sorties finales sont livrées.
- Limites : rayon exact, côtés latéraux, priorités/héritage des bordures, styles de trait non calibrés, couleurs conditionnelles/CMJN, ressources externes et pagination native. Boîtes de dessin en 1/1000 inch non converties avec le profil 1/300. Color conserve les fonds bleus dans les champs contrôlés ; aucune substitution artificielle de rose/rouge. Aucun certificat de conformité Exstream universelle.
- Consultés : spécifications, charte Alterna et actifs authentiques, code 0.11.0, journal v25, corpus complet, captures/PDF de calibration, sonde et preuves antérieures, structures binaires, rapports/tests/schémas/scripts. Aucun Tools Report ; les PDF de référence ne sont pas une entrée du moteur.
- Livraison : `deliverables/GroupeAlterna_CoreReport_Code_v0.12.0.zip`, `deliverables/GroupeAlterna_CoreReport_Validation_Tableaux_v0.12.0.zip`, `deliverables/MISE_A_JOUR_TABLEAUX_0.12.0.md` et ce journal. Bilan détaillé intégré dans `docs/VALIDATION_TABLEAUX_0.12.0.md`. Pas de déploiement ; API/IHM inchangées, pas de nouvelle recette navigateur/Docker/Windows/PostgreSQL/RQ.
- Prochaine action exacte : installer le code 0.12.0 en conservant `.env` et volumes, reconstruire les services, puis lancer une nouvelle analyse. Pour poursuivre le décodage, fournir des variantes contrôlées par côté de bordure et par rayon afin de résoudre l'héritage et les propriétés encore inconnues.

L'historique intégral de la version canonique précédente est conservé ci-dessous.

# État courant — Core Report 0.11.0 — 29 septembre 2026

**Itération 37 terminée : identité Core Report et couvertures validées localement.**

- Identité IHM : Core Report en marine/bleu, accroche « Vos applications documentaires, en toute clarté. » et « Clarity for your document applications. » ; titre d’onglet et pied actualisés. Drapeaux FR/EN, choix de chapitres et parcours existants préservés. Accroche expressément autorisée par l’utilisateur, réservée au produit.
- Couverture : fond JPEG CMJN et logo originaux joints, fichiers copiés sans modification ; nom Core Report centré, nom exact d’application décodée dessous, sans slogan ni numéro. Nom jamais déduit du fichier ; noms multiples/longs conservés et absence explicitement signalée. Rapports structurés, diagnostics et comparaisons couverts ; visuel du courrier conservé sans page documentaire. Corps du rapport toujours numéroté à partir de 1.
- Fichiers consultés : journal canonique v24, application 0.10.0, charte/instructions, fond.docx et ses en-têtes/XML, JPEG/PNG joints, page/styles/i18n/layout, render/report_structure/report_detail/export/hierarchy, tests et scripts navigateur. Modèles Versement/FIP/NOA consultés pour la source du nom ; Versement et FIP analysés à nouveau. Aucun Tools Report ni modification des PDF de référence.
- Version : backend/frontend 0.11.0 ; copie isolée work_core_report/exstream-alterna. Décodeurs, relations, hiérarchie, API/jobs/export, quotas et visuel identiques à 0.10.0. Aucune migration de schéma.
- Tests : 150 réussites, zéro échec/saut, 79,89 s ; quatre cas de couverture ajoutés. Un test de comparaison limité artificiellement à 2 Mio a dû être calibré à 5 Mio pour accueillir trois fonds de 1 Mio, sans changer les seuils de saturation/concurrence ni la configuration produit. Un avertissement Starlette/httpx. Compilation Next.js/TypeScript réussie.
- Interface : bureau/mobile et clavier, identité et accroche FR/EN, actualisation, options/fichier conservés, analyse Versement réelle et deux téléchargements EN réussis ; aucune erreur JavaScript ni débordement horizontal.
- Rapports : huit PDF dans work_core_report/validation/iteration_37. Versement : rapports FR/EN 126/127 pages, visuels 5/5 ; FIP : 173/174, 9/9. Total 628 pages rendues ; quatre couvertures nouvelles, 624 pages de texte/rendu identiques à 0.10.0 hors numéro de version. Cache de rendu vidé entre pages pour neutraliser le rééchantillonnage du logo. Zéro mot hors page. Quatre couvertures et pages représentatives inspectées avec Poppler ; pas de nouvelle relecture humaine exhaustive des 624 pages inchangées.
- Livrables : work_core_report/livraison/GroupeAlterna_CoreReport_MiseAJour_v0.11.0.zip (patch depuis 0.10.0, sans .env), GroupeAlterna_CoreReport_Code_v0.11.0.zip (application complète, .env initial à marqueurs), GroupeAlterna_CoreReport_Validation_v0.11.0.zip, MISE_A_JOUR_CORE_REPORT_0.11.0.md, Core_Report_Apercu.pdf (couverture et introduction Versement), Core_Report_Interface.png, ETAT_VALIDATION_MOTEUR.md. Bilan docs/VALIDATION_CORE_REPORT_0.11.0.md inclus.
- Limites : Docker/Windows/PostgreSQL/RQ non exécutés ; recette locale SQLite/worker séparé. Fond original : environ 1,2 Mio supplémentaires par PDF couvert. Décodage métier et limites graphiques antérieurs inchangés ; aucune nouvelle conformité Exstream revendiquée. Aucun blocage restant pour cette évolution dans l’environnement testé.
- Prochaine action exacte : fusionner le patch dans l’installation 0.10.0 en conservant .env et volumes, reconstruire api/worker/purge/web, puis vérifier Core Report et la couverture d’une nouvelle analyse sur Docker Desktop.

Le journal d’ouverture et l’historique sont conservés ci-dessous.

# Itération 37 en cours — identité Core Report et couverture — 29 septembre 2026

- Base : 0.10.0 conservée ; copie isolée work_core_report/exstream-alterna. Aucun dépôt Git/AGENTS.md trouvé. Journal canonique v24 repris, placeholder joint non substitué.
- Demande : nom Core Report mis en valeur dans l’IHM ; accroche professionnelle autorisée par l’utilisateur ; couverture avec fond Alterna, titre centré et seul nom d’application en dessous.
- Consultés : journal, charte/instructions, JPEG CMJN et logos joints, XML/en-têtes de fond.docx, page/styles/i18n/layout, render/report_structure/report_detail/export/hierarchy, tests et scripts navigateur, modèles existants Versement/FIP/NOA pour localiser le nom d’application.
- Décision : nom issu des objets applications décodés, jamais déduit du nom de fichier. Couverture des rétro-documentations et comparaisons ; visuel du courrier conservé. Accroche réservée à l’IHM. Pages intérieures blanches et pagination métier conservées.
- Vérification prévue : couverture synthétique, noms longs/multiples/inconnus, deux PUB en FR/EN, contenus intérieurs inchangés, UI bureau/mobile/clavier et régressions.
- Prochaine action exacte : ajouter le gabarit de couverture commun et l’identité IHM, puis générer et inspecter les rendus.

# État courant — application bilingue 0.10.0 — 29 septembre 2026

**Itération 36 terminée : interface et présentation des PDF FR/EN validées localement. Installation Docker de l’utilisateur à vérifier.**

- Réalisation : drapeaux FR/EN en haut à droite, préférence persistante, textes d’interface et erreurs traduits ; langue figée à la soumission, conservée avec la tâche, utilisée dans la rétro-documentation, le visuel et les comparaisons. Anciens appels/tâches : français par défaut. Les rapports existants ne sont pas réécrits lors d’une bascule.
- Protection des sources : catalogue limité aux titres/rubriques/commentaires produits par le moteur. Aucun littéral PUB, nom, condition, algorithme, chemin XML ou preuve brute traduit ; modèles inchangés avant/après exports. Contexte de langue isolé pour les rendus concurrents. Modules de décodage et assets identiques à 0.9.1 ; schéma de base inchangé, correctif quota préservé.
- Fichiers consultés : journal canonique v23, charte/instructions consolidées, README/lanceurs, frontend page/styles, API/jobs/export/CLI, report_detail/report_structure/report_inventory/report_options, hierarchy, render/visual_render, tests et scripts navigateur ; PUB Versement, FIP Essenciel et NOA. La suite utilise aussi Adhésion, Auto et Obsèques. Aucun Tools Report ni nouvelle comparaison avec le PDF v6 historique.
- Corrections au cours de l’itération : isolation des textes source, catalogue des diagnostics numériques, styles locaux évitant un masquage de fonction, traductions des erreurs et retours historiques, boutons SVG accessibles sous Windows, indication de la langue réelle des PDF lorsque l’utilisateur change d’interface après soumission.
- Version : backend/frontend 0.10.0 ; copie de travail `work_i18n/exstream-alterna`. Historique, version 0.9.1 et références préservés.
- Tests : 146 réussites, zéro échec/saut, 71,106 s ; 14 nouveaux cas i18n ; un avertissement Starlette/httpx. Next.js production et TypeScript réussis. Navigateur bureau/mobile et clavier, FR/EN, actualisation, options/fichier conservés, erreur et états traduits, analyse Versement réelle avec worker séparé et deux téléchargements EN après bascule FR validés.
- PDF : 14 générations distinctes, 1 128 pages dans `work_i18n/validation/iteration_36` : Versement (rapports FR/EN 125/126, visuels 5/5), FIP (172/173, 9/9), NOA (235/235, 11/11), comparaison Versement/FIP (6/6). Tous rendus et revus sur 40 planches ; lecture détaillée de pages représentatives. Zéro mot hors page ; aucun défaut important nouveau observé. Ce contrôle n’est pas une relecture exhaustive des algorithmes bruts.
- Livrables : `work_i18n/livraison/GroupeAlterna_Exstream_Code_v0.10.0.zip`, `GroupeAlterna_MiseAJour_v0.10.0.zip`, `GroupeAlterna_Validation_v0.10.0.zip`, `MISE_A_JOUR_0.10.0.md` et `ETAT_VALIDATION_MOTEUR.md`. Le patch s’applique à 0.9.0/0.9.1 et exclut `.env` ; le code complet contient une configuration initiale à marqueurs pour une installation neuve. Bilan `docs/VALIDATION_I18N_0.10.0.md`.
- Limites : Docker/Windows/PostgreSQL/RQ non exécutés ; validation locale SQLite/processus séparé. Pagination légèrement différente entre langues. Aucun progrès de décodage ou conformité pixel par pixel revendiqué ; limites métier/graphiques antérieures conservées. Aucun blocage restant pour la fonctionnalité bilingue dans l’environnement local testé.
- Prochaine action exacte : installer le patch dans le même dossier existant selon le guide, conserver `.env` et volumes, reconstruire api/worker/purge/web puis vérifier une analyse FR et une EN sur le poste Docker de l’utilisateur.

Le journal d’ouverture d’itération et l’historique sont conservés ci-dessous.

# Itération 36 en cours — interface et rapports bilingues — 29 septembre 2026

- Base : application 0.9.1 et journal canonique conservé ; copie isolée work_i18n/exstream-alterna. Aucun AGENTS.md ni dépôt Git trouvé. Le fichier joint 18 est un simple placeholder, non substitué au journal complet.
- Demande : sélection Français / English en haut à droite, langue persistante de chaque analyse ; traduction des rubriques et commentaires seulement, jamais des contenus PUB.
- Consultés : journal, instructions/charte, page.tsx/styles, API/jobs/export, gabarits report_*, hierarchy et visual_render, tests et scripts navigateur.
- Plan : catalogue explicite pour les textes applicatifs et présentation ; langue persistée avec les options de tâche, défaut français pour compatibilité ; conservation des données et des sorties historiques.
- Vérification prévue : tests de non-traduction et concurrence, API/worker/CLI, interface bureau/mobile/clavier, PDF FR/EN sur trois packages et comparaison. Aucun accès Docker local.
- Prochaine action exacte : recenser les textes générés, isoler les données source puis brancher la langue de bout en bout.

# État courant — correctif stockage 0.9.1 — 28 septembre 2026

**Itération 35 terminée : défaut de réservation reproduit et corrigé. Installation Docker de l’utilisateur à vérifier après application du patch.**

- Signalement : IHM « Espace réservé insuffisant ; attendez la purge ». La version 0.9.0 conserve 320 Mio par tâche jusqu’à expiration ; six réservations peuvent bloquer la suivante sous 2 Gio.
- Fichiers consultés : archive canonique `GroupeAlterna_Exstream_Code_v0.9.0.zip`, journal canonique version 22, `backend/retro/{api,jobs,storage,config,db,worker,maintenance,export}.py`, Compose, Dockerfile, tests API/options/sécurité/quota et suite moteur. Documents officiels Docker Compose run/environment pour la procédure. Pas de Tools Reports.
- Corrections : réservation selon le nombre d’entrées, ajustement après réception, comptage réel à la fin du traitement, réconciliation non destructive des anciens succès, reprise explicite des échecs/annulations avec producteurs arrêtés, passage des paramètres de quota aux services. Le budget des tâches actives ou d’arrêt incertain reste réservé.
- Version : backend 0.9.1 ; fichiers frontend et moteurs d’analyse/rendu inchangés par comparaison avec 0.9.0. Schéma de base inchangé. Aucun `.env` livré dans le patch ; conserver celui de l’installation.
- Tests : reproduction avant correction (HTTP 507), puis 132 réussites et aucun saut, 71,30 secondes ; 13 cas supplémentaires de quota, annulation/échec, conservation, illisibilité et concurrence. Un avertissement de dépréciation Starlette/httpx. Commande CLI testée en sous-processus sur SQLite : trois tâches terminales réconciliées, tâche active et fichiers intacts. Compose vérifié statiquement.
- Corpus : régressions existantes sur Adhésion, Versement, FIP, Auto, Obsèques et NOA relancées et réussies. Pas de nouveau PDF métier livré ni de nouvelle inspection visuelle page par page ; analyse et rendu ne changent pas. Les livrables 0.9.0 restent les références graphiques existantes.
- Livrables : `diagnostic_quota/livraison/GroupeAlterna_Correctif_Quota_v0.9.1.zip`, `diagnostic_quota/livraison/CORRECTIF_QUOTA_0.9.1.md`, journal courant `diagnostic_quota/exstream-alterna/ETAT_VALIDATION_MOTEUR.md`. Le ZIP contient les fichiers modifiés, le guide, le journal et les preuves de validation. C’est un patch à fusionner dans 0.9.0, pas une application autonome.
- Preuves : `diagnostic_quota/validation/{reproduction_avant,tests_quota,tests_complets,repair_cli}.txt`, `fichiers_preserves.json` ; copies incluses dans l’archive sous `validation/quota_0.9.1`. Rapport détaillé `docs/VALIDATION_QUOTA_0.9.1.md`.
- Limites : runtime Docker indisponible ; Windows, PostgreSQL réel et Redis/RQ non exécutés ici. Un quota réellement rempli reste bloquant. Les anciens échecs/annulations sont recalculés seulement par la reprise arrêtée ; les dossiers illisibles conservent leur réservation. Les tâches actives ne sont pas libérées arbitrairement. Aucun nouveau progrès de décodage PUB ou de fidélité graphique revendiqué.
- Prochaine action exacte : fusionner le patch dans le dossier existant, garder `.env` et volumes, attendre la fin des analyses ; arrêter api/worker/purge, reconstruire ces images, lancer `docker compose run --rm --no-deps api python -m retro.storage --reconcile-stopped`, redémarrer les services, contrôler l’état Docker et tester une nouvelle analyse. En cas d’échec d’une commande, conserver le message d’erreur et ne pas supprimer de volume.

Les sections suivantes conservent le journal de début d’itération et l’historique antérieur.

# Correctif stockage 0.9.1 — itération 35 en cours — 28 septembre 2026

- Signalement : erreur IHM « Espace réservé insuffisant ; attendez la purge » après rétablissement du mot de passe PostgreSQL.
- Constat confirmé dans 0.9.0 : réservation fixe de 320 Mio par analyse, maintenue jusqu’à expiration (24 heures par défaut). Six réservations empêchent une septième sous le quota 2 Gio. Le Compose ne transmet pas DISK_QUOTA_BYTES à l’API/worker/purge.
- Source : archive 0.9.0, API submit, modèle Job, jobs run_job/purge, config, Compose, tests API et sécurité. Aucun fichier PUB ni PDF à modifier pour ce correctif.
- Étape : reproduction et tests ciblés, puis correction du calcul et reprise des réservations des succès antérieurs sans suppression.
- Contrat : conserver une réserve pleine pendant le traitement ; compter tous les fichiers privés après terminaison, y compris données internes. Ne pas sous-estimer les tâches dont l’arrêt n’est pas confirmé. Aucun changement visuel de l’IHM ou du moteur graphique.
- Prochaine action exacte : ajouter les régressions capacité/réconciliation/non-suppression/concurrence, valider et livrer 0.9.1.

# État courant — application et moteur 0.9.0 — 28 septembre 2026

**Intégration des deux PDF terminée et validée sur six packages. Fidélité Exstream exhaustive non acquise.**

- Itérations 31–34 terminées : port réutilisable du prototype graphique, correction des régions de page Auto et des enveloppes typographiques 134 Versement/FIP, export des deux PDF et liens de téléchargement. L’interface garde ses styles, son logo, ses options et ses interactions.
- Sources effectivement consultées : code 0.8.0, journal canonique, atelier NOA V9 et profil de calibration issu antérieurement du PUB NOA et du PDF natif ; les six PUB Adhésion, Versement, FIP, Auto, Obsèques et NOA ; binaires de ressources typographiques et contenus de page. Aucun Tools Report, aucun PDF de référence remplacé. Cette reprise ne revendique pas de comparaison nouvelle au PDF v6 historique.
- Modèle normal conservé : six comparaisons sémantiques identiques à 0.8.0 hors numéro de version et ajout graphique. API/jobs, gabarits normaux et CSS inchangés.
- Rapports finaux : `work_dual_pdf/validation/iteration_34/<nom_du_pub>/rapport.pdf` et `visuel.pdf`. Ils sont conservés dans `GroupeAlterna_Validation_v0.9.0.zip`, avec les rendus des visuels et les résultats de contrôle. Source applicative : `work_dual_pdf/exstream-alterna`, livrée dans `GroupeAlterna_Exstream_Code_v0.9.0.zip`.
- Pages visuelles : Adhésion 9, Versement 5, FIP 9, NOA 11, Obsèques 7, Auto 10 : 51 pages rendues et inspectées. 834 unités affichées, 53 regroupements intentionnels, aucune unité rattachée manquante ni doublon de placement. Zéro ligne scindée signalée sur ces six cas. Ces compteurs ne signifient pas décodage exhaustif du format.
- Résultats : 119 tests réussis, aucun sauté ; 76/76 contrôles de calibration ; Next/TypeScript compilés ; navigateur bureau/mobile et clavier, actualisation et téléchargement réel des deux PDF validés. `.env` initial vérifié, initialisation répétable sans régénérer les secrets existants.
- Inspection : les douze PDF sont techniquement lisibles, avec texte sélectionnable et aucun mot hors page. La revue visuelle nouvelle porte sur les 51 pages du second PDF. Les 927 pages normales n’ont pas été toutes réinspectées visuellement : données et gabarits préexistants sont inchangés. Aucune recette Docker/Windows/PostgreSQL/RQ exécutée ici.
- Limites : 48 styles non interprétés ; coordonnées absolues et pagination natives partielles ; ressources externes et symboles manquants ; répétitions/branches non évaluées ; certaines bordures, références de message et fusions inconnues. Arrondis seulement calibrés sur l’empreinte exacte NOA, sans prétendre décoder le rayon/masque dans le PUB.
- Guide : `MISE_A_JOUR_MOTEUR_0.9.0.md` ; bilan détaillé et tableau des écarts : `docs/VALIDATION_MOTEUR_0.9.0.md`.
- Prochaine action exacte : installer backend, frontend et assets 0.9.0 en conservant le `.env`, le dossier Compose et les volumes existants, reconstruire api/worker/purge/web, puis relancer une analyse. Pour poursuivre les arrondis, comparer deux PUB minimaux ne différant que par un rayon ou un coin activé ; ne pas transposer le profil NOA par nom de fichier.

Les sections suivantes sont l’historique de travail, pas le statut courant.

## Itération 34 — polices alternatives et recette complète — en cours

- Écart identifié par rendu : les bandeaux Versement étaient foncés avec texte noir, tous les styles Versement/FIP non interprétés.
- Preuve PUB : ressources typographiques avec tag 134 au lieu de 133, même enveloppe ID/nom Pascal/taille/résolution et mêmes références depuis les rich texts. Versement : première ressource à 15 973 ; FIP : à 15 582. La signature et les bornes restent contrôlées.
- Correction : prise en charge des deux tags, rejet des ressources incohérentes, diagnostic explicite pour police non résolue. Versement 25 ressources et 72 styles reconnus ; FIP 34 ressources et 78 styles reconnus.
- Inspection 32/33 : 42 pages visuelles déjà vues (Adhésion, Versement, Auto, Obsèques, NOA). FIP à recontrôler avec polices corrigées. Aucun débordement observé ; les colonnes étroites allongent les noms de variables, sans les remplacer par des valeurs client.
- Validation en cours : tests intégrés, corpus de six doubles PDF, conservation sémantique des modèles de rétro-documentation, calibration historique et interface bureau/mobile.
- Prochaine action exacte : exporter dans `validation/iteration_34`, rendre les six visuels corrigés et terminer les tests.

## Itérations 31–33 — moteur 0.9.0 — intégration en cours

- 31 : modèle de présentation isolé, profils typographiques/fonds/bordures portés ; premier essai sur six PUB. Cinq échecs de rendu dus à un nom local masquant une méthode, un échec Auto dû aux régions de page.
- 32 : correction du masquage, cinq visuels générés (9/5/9/11/7 pages). Rapports précédents conservés sous `work_dual_pdf/validation/iteration_32`.
- 33 : reconstruction des régions de page Auto après récupération des contenus, sans réaffectation aux décorations ; dix pages générées, 144 unités couvertes. Analyse/export branchés pour produire deux PDF ; comparaison cinq PDF. Liens UI adaptés, styles inchangés.
- Sources lues : modules nouveaux visual_recovery/model/graphics/render, layout/decode_page_regions, parser, export, jobs, API, tests, page.tsx, browser_checks, Dockerfile. Six PUB disponibles et calibration NOA existante ; aucune nouvelle information client importée.
- Tests : référence avant modifications 107 réussites ; premier passage intégré en cours. Inspections des 51 pages visuelles en cours. Champs radius PUB et coordonnées Exstream non établis.
- Prochaine action exacte : finir la revue visuelle, ajouter tests de couverture/calibration/échec transactionnel, puis produire les deux livrables sur les six PUB avec la chaîne complète.

## Reprise application 0.9.0 - itération 31 - 28 septembre 2026

- Étape : inspection terminée, intégration de deux PDF par analyse en cours.
- Base : archive 0.8.0 et atelier graphique NOA V9. Aucun dépôt Git ou AGENTS.md trouvé ; travail dans une copie isolée `work_dual_pdf/exstream-alterna` pour préserver les livraisons antérieures.
- Consultés : journal courant, parser/content/layout/scopes, export/jobs/API, interface et options de chapitres, tests existants, profils graphiques et récupération de contenus de l'atelier.
- Sources disponibles : six PUB (Adhésion, Versement, FIP, Auto, Obsèques, NOA), PDF natif NOA, spécification et cahier consolidé.
- Décision : conserver le rapport de rétro-documentation et son modèle existant, ajouter un modèle de présentation graphique isolé construit à chaque analyse depuis les octets du PUB. Ne jamais dépendre d'un modèle NOA pré-enregistré ni du PDF client à l'exécution. Les arrondis calibrés restent limités au package NOA connu par empreinte ; les autres PUB gardent cette propriété inconnue.
- Écarts à traiter : scripts expérimentaux avec chemins/globals fixes ; artefact visuel absent de l'export/API ; libellés de téléchargement uniques ; récupération des contenus courts limitée au NOA ; pagination à éprouver sur les six packages.
- Prochaine action exacte : porter les profils en classes par analyse, relier polices/palettes du fichier courant et tester les rendus avant de brancher le traitement complet.

## État courant - visuel NOA V9, 28 septembre 2026

**Statut : visualisation améliorée, calibration graphique partielle ; décodage autonome des arrondis PUB NON validé.**

- Étapes terminées : V7 épurée, V8 fonds/traits, V9 contours polygonaux natifs. Application de base 0.8.0 inchangée ; profil expérimental `NOA-native-calibration-0.3`.
- Sources effectivement consultées : PUB NOA, modèle enrichi et preuves V6, moteurs layout/binary/rendu, journal version 20, spécification et cahier consolidé ; trois pages du PDF `Devis Mon Auto-0000022870203904.pdf`, tracés vectoriels et polices. Aucun Tools Report.
- Corrections : huit paragraphes équivalents regroupés dans la vue ; suppression des titres techniques et mention de variante ; 25 fonds activés relus, 118 bordures basses corroborées ; glyphe Wingdings 2 « P » rendu comme la coche présente dans l'exemple ; contour polygonal calibré conservant les asymétries.
- Arrondis PDF : 14 fonds à quatre coins arrondis, deux demi-bandeaux à deux coins arrondis, un fond rectangulaire ; encadré « Pour souscrire » carré. Rayon nominal 3,6 pt, grille 0,24 pt ; retraits locaux 2,88/3,6 pt. Aucun champ binaire de rayon ou masque déclaré décodé.
- Couverture : 21 paragraphes gardés sur 29 ; 355 unités affichées sur 372, 17 retraits intentionnels seulement ; zéro unité manquante non justifiée, zéro double placement, zéro ligne scindée signalée.
- Livrables : `work_noa_visual/output/pdf/NOA_Visuel_Epure_V9.pdf` (10 pages), `NOA_Analyse_Arrondis.pdf` (1 page), `NOA_Bilan_Visuel_V9.md`. V7 et V8 préservés dans l'archive `NOA_Reconstruction_Atelier.zip`, avec scripts, modèles et preuves.
- Vérifications : 14 tests graphiques PASS ; 10 pages V9 et la planche rendues et inspectées ; aucune coupure hors page détectée ; quatre polices utilisées incorporées ; texte sélectionnable. 94 fichiers applicatifs comparés à l'archive source, inchangés. Tests applicatifs non relancés car aucune modification de l'application.
- Limites restantes : rayon/masque/héritage PUB, affectation des formes mauves aux ressources référencées, bordures autres que le profil inférieur corroboré, contour global « Pour souscrire », alignements/coordonnées/pagination natives, différences typographiques entre conception et édition, règles non évaluées. La calibration bleue est une déduction de style depuis l'exemple, pas une garantie universelle.
- Prochaine action exacte : repartir de `calibration_V8.json`, profil 0.3, et du contre-exemple tarif mensuel à 4 577 855 ; suivre les références des littéraux « Le +AXA » vers les ressources de message et identifier le niveau de style qui porte le masque/rayon. Si aucune preuve différenciante n'est trouvée, obtenir deux PUB ne différant que par la propriété d'un coin. Ne pas confondre les champs locaux +124…+136 avec les rayons.

## Arrondis NOA V9 - approfondissement du 28 septembre 2026

- Étape en cours : étude séparée de chaque coin des 17 fonds du PDF natif ; remplacement des Bézier génériques par le contour polygonal mesuré.
- Résultat nouveau : 14 formes à quatre coins arrondis, une à coins gauches arrondis, une à coins droits arrondis, une rectangulaire ; rayon de 3,6 pt pour chaque coin arrondi. L'encadré « Pour souscrire » a quatre coins droits, sans fond.
- Preuve : tracés `l` du PDF, 28 segments pour une forme complète, 16 pour chaque demi-bandeau, sur une grille de 0,24 pt. Pas de courbe Bézier sur ces fonds.
- Contre-exemple binaire : en-tête du tarif mensuel à 4 577 855, quatre valeurs locales +124/+128/+132/+136 nulles ; la forme correspondante du PDF reste arrondie. Ces valeurs ne constituent donc pas le rayon recherché.
- Nouvelle implémentation : prise en charge de la forme polygonale calibrée en conservant la séparation entre source PUB et source PDF ; aucune valeur client importée, aucune branche choisie depuis l'exemple.
- Prochaine action exacte : produire V9 et une planche de mesures sans donnée client, contrôler toutes les pages, puis conserver les tests et le journal. Le rayon PUB et les masques de coins restent non décodés.

## Calibration NOA V8 - exemple natif reçu le 28 septembre 2026

- Étape en cours : corrélation des propriétés graphiques et des tracés du PDF client fourni.
- Source nouvelle effectivement consultée : `upload/Devis Mon Auto-0000022870203904.pdf`, trois pages natives, toutes rendues et vues. Le document est une édition conditionnelle ; il ne sert pas à supprimer des contenus du PUB ni à importer ses valeurs client.
- V7 déjà générée : 10 pages, 21 paragraphes conservés sur 29, 8 groupes équivalents retirés de la projection visuelle ; contrôle de couverture sans perte hors regroupements. Inspection finale reportée vers V8.
- Constats : fonds RGB #D3E3F5 et #BDBCCD, traits #00008F de 0,48 pt ; dix fonds bleus arrondis avec rayon mesurable de 3,6 pt. Le PUB contient ces couleurs dans sa palette. Les en-têtes d'objets texte 113 apportent un état de fond distinct de la couleur. Le champ du rayon n'est pas identifié ; les quatre valeurs de 15 voisines des dimensions ne doivent pas être déclarées automatiquement comme des rayons.
- Prochaine action exacte : valider les associations bornées en-tête 113/texte, rendre les fonds activés et les bordures de cellule corroborées ; conserver les arrondis issus du PDF comme calibration explicite, puis inspecter V8. Aucun changement applicatif.

## Visuel NOA épuré - reprise du 28 septembre 2026 (18 h 11, Paris)

- Étape : suppression des annotations techniques et dédoublonnage de la visualisation uniquement.
- Sources relues : journal courant version 20, journal initial joint (simple marqueur), `render_visual.py`, `decode_graphics.py`, modèle enrichi et propriétés graphiques V6. Le modèle source et les fichiers applicatifs restent inchangés.
- Demande : retirer les noms de paragraphes et la mention « Variante conditionnelle », regrouper les contenus équivalents (dont JPG/SEG), poursuivre le décodage des fonds, traits et arrondis.
- Limite établie à la reprise : RGB connus mais affectation aux effets graphiques encore non certifiée. Un PDF natif édité depuis ce même PUB serait une source de calibration utile ; aucun exemple nouveau de ce courrier n'est actuellement joint.
- Prochaine action : comparer les empreintes de contenu par bloc, conserver un représentant de chaque groupe équivalent dans la vue, produire V7 puis inspecter toutes les pages et conserver le journal des regroupements.

## Visuel NOA - clôture de la tentative du 28 septembre 2026

**État : livrable partiel explicite, contrôlé ; reproduction graphique native NON validée.**

- Demande : visuel du courrier depuis `AFR_GENERIC_IARD_VEHIC_NOA_DEVIS.pub`, polices/couleurs/tableaux et zones graphiques.
- Version : base moteur 0.8.0 inchangée ; profil isolé `NOA-graphics-research-0.1`. Les 94 fichiers de l’archive applicative vérifiés sont identiques. Aucun changement d’IHM.
- Consultés : `.pub` NOA exact (14 192 201 octets), code ZIP 0.8.0, journal version 19, spécification déterministe et cahier des charges, ressources de police officielles Adobe. Aucun outil Reports.
- Résultats : 37 instances de police, 72 couleurs nommées, 364 unités avec police/couleur reliées par grammaire, 8 unités dont le style reste non interprété. Récupération de 86 enveloppes numériques/symboliques et de 7 littéraux A0 exclus précédemment. Treize références graphiques dynamiques matérialisées par cadres barrés sans mot intérieur.
- Six générations conservées : V1 16 pages ; V2 et V3 13 ; V4 20 et V5 19 (essais de regroupement non retenus) ; V6 13 pages retenues.
- Corrections : fusion horizontale préservée dans le profil de cellule à propriétés de 36 octets ; ordre des contrôles de fonte/couleur distinct de ceux des règles, variables et paragraphes vides ; regroupements évitant les titres orphelins sans conteneurs imbriqués excessifs.
- Couverture finale : 372 unités présentes une fois ; 29 paragraphes ; 31 grilles ; deux modèles de page dont les contenus sont présentés séparément.
- Rapport final : `/workspace/scratch/618aa466653a/work_noa_visual/output/pdf/NOA_Visuel_Reconstitue_V6.pdf`.
- Relevé : même dossier, `NOA_Releve_Graphique.md`, `NOA_Proprietes_Texte.csv` (867 fragments), `NOA_Proprietes_Tableaux.csv` (2 062 lignes de propriétés), `NOA_Palette.csv`.
- Reprise : `NOA_Reconstruction_Atelier.zip`, scripts `augment_content.py`, `decode_graphics.py`, `render_visual.py`, `test_graphics.py`, modèles internes et sources nécessaires.
- Contrôles : 39 tests ciblés existants PASS ; 9 contrôles graphiques PASS. Les 13 pages V6 rendues et inspectées ; aucun débordement hors page détecté ; texte sélectionnable ; polices utilisées incorporées. Rendu final PyMuPDF après sorties PNG Poppler tronquées dans cet environnement. Les tests n’établissent pas la fidélité au moteur natif Exstream.
- Limites bloquantes : affectation fond/trait des propriétés de tableaux ; orientation, activation, héritage, largeur et rayon d’arrondi ; placement global et ordre local des objets hors grille ; pagination native ; fichiers externes d’illustration et polices propriétaires ; huit styles non interprétés. Aucun flux client pour sélectionner les branches. Pas de comparaison à une édition native NOA disponible.
- Prochaine action exacte : reprendre les enregistrements de cellule `-102` de 36/484 octets dans `analysis/graphics.json` et les preuves CSV, établir les codes des quatre groupes d’arêtes avec activation et unités ; décoder ensuite les coordonnées des objets de page appariés 24:25225 et 24:25587. Ne pas réexécuter les étapes de récupération si l’archive et ses empreintes restent valides. Ne pas annoncer une version applicative nouvelle sur la base de cet atelier seul.

## Itération visuelle NOA V2 - 28 septembre 2026 - contrôle en cours

- Base inchangée : application 0.8.0, analyse expérimentale isolée `work_noa_visual`.
- V1 produite sur 16 pages. Inspection : cellules imbriquées très étroites pour certains textes ; cause trouvée dans une variante de propriétés de cellule de 36 octets, dont la fusion était ignorée par le profil de 484 octets.
- V2 : fusions conservées pour les deux variantes ; signatures courtes regroupées ; guides pointillés supprimés sur les lignes vides.
- Lecture supplémentaire : 86 enveloppes de texte exclues par le filtre alphabétique précédent (montants, pourcentages, symboles, références de pictogrammes) ; 7 textes littéraux A0 à longueur redondante ; 14 unités dans les deux pages appariées.
- Total du visuel : 372 unités couvertes une fois, 29 paragraphes, 31 grilles rattachées, 2 modèles de page. Aucun flux client, règle non évaluée.
- Propriétés : 37 instances de police du package ; 72 couleurs nommées décodées ; tables locales de police et couleur par texte. Source Sans Pro Regular/Bold/Light récupérée depuis le dépôt officiel Adobe pour incorporation.
- Limites : codes d'arêtes et d'arrondi, héritage des fonds, position absolue des éléments de page, Wingdings et ITC Franklin non résolus. Aucun effet visuel de tableau présenté comme certain sur cette base.
- Rapports : `work_noa_visual/output/pdf/NOA_Visuel_Reconstitue_V1.pdf` puis `NOA_Visuel_Reconstitue_V2.pdf`.
- Prochaine action : inspecter les pages V2, contrôler la couverture textuelle et les tests, consigner le bilan puis conserver les livrables.

## Reprise visuelle NOA — 28 septembre 2026 — itération V1 en cours

Demande : reconstruire le courrier NOA, rechercher typographies, couleurs, fonds, traits, arrondis et emplacements graphiques. Moteur de départ 0.8.0 ; copie de travail isolée, aucune modification de l’application livrée.
Sources consultées : PUB NOA original (Library version 0), archive code 0.8.0 version 8, journal version 19, spécification déterministe et cahier consolidé fournis ; modules binary, parser, content, scopes, layout, structure, component_properties, report_structure. Aucun Tools Report consulté.
Constats initiaux : 29 paragraphes documentaires distincts, 265 unités de texte rattachées (264 avec chaîne de portée complète), 39 grilles du package, 37 instances typographiques reconnues, palette nommée RGB retrouvée. Ces nombres ne constituent pas une validation exhaustive du rendu.
Livrables en cours : work_noa_visual/analysis/model_base.json, font_instances.json, palette.json. PDF non encore produit.
Contrôles : analyse complète exécutée en 5,8 s ; inventaire et probes binaires bornées. Reprise des tests à la prochaine étape.
Blocages : flux client et ressources dynamiques externes absents ; pagination Exstream non évaluée ; géométrie et certaines propriétés toujours à décoder.
Prochaine action exacte : relier les références de police/couleur du flux de glyphes et du payload aux tokens, puis décoder les propriétés de grille et les cadres graphiques.

# État de validation du moteur

État courant : **28 septembre 2026, application/moteur 0.8.0, itération 30 terminée**. Base de reprise : livraison 0.7.0 préservée. Les sections historiques ne constituent pas l'état actuel.
Objectif courant : structure toujours en introduction, choix indépendant des trois derniers chapitres et retrait des livrables techniques publics, avec conservation de l'apparence existante hors ajouts demandés.

## État actuel — livraison 0.8.0

Trois itérations 28–30. Rapports finaux : NOA 235 pages (tous les chapitres), Versement 16 pages (aucun complément), Obsèques 109 pages (valorisation et annuaire). Les 360 pages sont rendues et contrôlées. 107 tests réussis, aucun sauté ; 76/76 contrôles de calibration ; compilation Next/TypeScript et parcours navigateur bureau/mobile réussis. Les modèles préexistants restent identiques à 0.7.0 hors version, avec ajout du champ applications. Les styles antérieurs sont intégralement conservés ; seules les options et les mentions de livrables évoluent dans l'interface.

Les PDF finaux sont dans `validation/corpus3/iteration_30` de l'archive de validation ; copies dans `work_options/deliverables`. Guide : `MISE_A_JOUR_MOTEUR_0.8.0.md`. Bilan : `docs/VALIDATION_MOTEUR_0.8.0.md`. Il faut mettre à jour frontend ET backend, conserver le .env et les volumes, puis reconstruire api/worker/purge/web et relancer les analyses. Aucune migration de base.

Les parentages section/page non établis et les limites de décodage 0.7.0 restent explicites. Les chapitres décochés ne sont pas rendus, mais toutes les observations restent conservées en interne. La conformité exhaustive au format PUB ou au rendu Exstream n'est pas revendiquée. Cette évolution ne constitue pas une nouvelle comparaison au PDF v6 historique.

Prochaine action exacte : installer 0.8.0 selon le guide et analyser un PUB en vérifiant les cases souhaitées ; pour poursuivre le décodage, reprendre NOA `text:6611819` avec contrôle indépendant des bornes, sans refaire les inspections accessibles et valides de cette livraison.

## Historique — livraison NOA 0.7.0

Quatre itérations supplémentaires, 24–27. Six rapports finaux : NOA 234 pages, Adhésion 167, Versement 125, FIP 170, Obsèques 118, Auto 110. Les 924 pages sont rendues et inspectées. 84 tests réussis, aucun sauté ; 76/76 contrôles de calibration historique ; 48 invariants de contenu conservés. Les 27 fichiers protégés interface/API/services sont identiques. Corrections des conditions globales PAR, tableaux imbriqués, étendues horizontales contrôlées, noms de variables, retours internes et présentation. Chapitre séquentiel supprimé selon la demande courante.

Rapports : `validation/corpus6/iteration_27/<source>/rapport.pdf` et `.json`. Bilan : `docs/VALIDATION_MOTEUR_0.7.0.md`. Déploiement local : `MISE_A_JOUR_MOTEUR_0.7.0.md`. Preuves détaillées et rendus dans l'archive de validation 0.7.0.

La conformité exhaustive reste non acquise : une portée NOA, une Adhésion, quatre FIP, une Obsèques et une Auto demeurent non interprétées. Autres limites : origines externes, ordre runtime, profils graphiques fins, fusions non reconnues et ordre de régions Auto. Le PDF v6 historique n'était pas accessible à cette reprise ; comparaison courante avec rapport-2 et le PUB NOA uniquement. Prochaine action exacte : isoler et corroborer la chaîne de propriétés de lien de NOA `text:6611819` avant toute association supplémentaire, puis les quatre chaînes FIP. Recette locale : installer 0.7.0 et relancer les analyses sans remplacer le `.env` ni les volumes.

## Historique — révision V6, moteur 0.4.0

Douze itérations réalisées au total ; cette reprise couvre 10, 11 et 12. Dernier rapport : `validation/revision_v6/iteration_12/rapport.pdf`, 41 pages toutes rendues et inspectées. 49 tests passent ; calibration historique 76/76 sur quatre packages. Les dix règles internes du Bulletin ont douze cibles résolues (sept inline, cinq paragraphes), en complément des dix-huit règles de ligne. R28 cible uniquement « tte ». Interface/API/orchestration préservées. **Conformité V6 non acquise** : autres variantes, Pxx, exemples et rendu Exstream restent incomplets. Voir `docs/ECARTS_V6.md` et `docs/PROFIL_PORTEES_PUB.md`.

## Statuts de la livraison initiale

| Phase | Statut | Résultat |
|---|---|---|
| 0 — Inventaire | Terminé | Sources et charte consultées ; aucun dépôt préalable |
| 1 — Références et moteur | En cours ; validation complète bloquée | 4 références indépendantes partielles, moteur créé, 76 contrôles ciblés conformes |
| 2 — Application | Terminé pour le parcours local testé | Next.js, FastAPI, worker local, SQLite, PDF/JSON, comparaison et téléchargements protégés |
| 3 — Vérification | En cours ; recette intranet bloquée | 19 tests réussis, build/TypeScript réussis, contrôle navigateur bureau/mobile réussi ; Docker/RQ/PostgreSQL/SSO non exécutés |

## Résultats vérifiés

- Les quatre packages explicitement nommés ont été analysés : Adhésion, Versement, FIP Essen'Ciel et Projet Obsèques. Aucun de ces quatre fichiers n'est absent.
- 76 contrôles indépendants ciblés, 0 écart sur ce périmètre ; ce résultat ne valide pas le métier complet.
- 19 tests automatisés réussis ; un avertissement de dépréciation du client HTTP de test, sans échec.
- Compilation Next et TypeScript réussis ; vérification Ruff ciblée noms non définis réussie.
- Navigateur : véritable upload Versement, actualisation pendant le traitement, résultat retrouvé, PDF téléchargé et vérifié ; rejet extension invalide ; lien clavier d'évitement ; deux zones en comparaison ; capture bureau 1440 px et mobile 390 px sans débordement ; aucune erreur JavaScript.
- Le scénario navigateur a utilisé l'API, le worker séparé et le moteur réels. La comparaison et les états d'erreur/annulation/purge/accès non autorisé ont été testés via API sur fixtures synthétiques.
- 4 références PDF de 3 pages + 4 diagnostics PDF de 6 pages : 36 pages rendues et inspectées. DejaVu Sans utilisée ; logo authentique conservé.

## Livrables et emplacements

- Code : `backend/`, `frontend/`, `assets/`, `scripts/`, Docker Compose, `.env.example` et guides.
- Lancement Windows : `DEMARRER_WINDOWS.cmd`, `ARRETER_WINDOWS.cmd`, `LIRE_EN_PREMIER.md`. Scripts Docker/PowerShell fournis, non exécutés sous Windows.
- Références indépendantes : `references/` dans l'archive de validation séparée ; elles ont été gelées avant la création du moteur.
- Sorties et grilles : `validation/<package>/`, `validation/calibration.json`, résultats de tests et captures dans l'archive de validation.
- Écarts : `docs/ECARTS_VALIDATION.md`. Architecture et commandes : `README.md`. Sécurité : `docs/SECURITE_EXPLOITATION.md`.

## Sources disponibles et limites

Sources initiales : dossier `../project_sources`, inventaire et SHA-256 sous `validation/source_inventory.json`. Spécifications métier et technique, charte, tokens et logo consultés. Les préfixes numériques concernent les copies locales ; les noms métier sont conservés dans les références. Le fichier de suivi initial contenait seulement « fichier de suivi ». Le package Auto supplémentaire n'a pas été utilisé pour remplacer un fichier de calibration.

Absents : Tools Reports, anciens rapports complets, documentation OpenText citée, moteur de composition, flux et ressources externes client, environnement intranet/SSO. Les .pub et secrets ne sont pas inclus dans l'archive de code ; l'utilisateur fournit ses fichiers à l'application.

**Validation métier non acquise.** Ordre et relations des pages/blocs, visuels complets, frontières Pxx, cibles/portées exactes des règles, toutes propriétés de tables/lignes/colonnes/cellules, échantillons et lookup restent incomplets. Les PDF livrés sont des diagnostics abrégés et non des rétro-documentations exhaustives. XSD non généré faute de contraintes XML démontrées. Les signatures Repeat sont des candidats, jamais des REP-L/REP-C affirmés sans parent prouvé.

Aucune publication externe, aucun SSO configuré, aucun appel IA. RQ/Redis/PostgreSQL sont intégrés dans le code et Compose mais non testés en services réels ici. Aucun Docker disponible dans cet environnement.

## Prochaine action précise

Pour l'utilisateur : extraire le code, suivre LIRE_EN_PREMIER.md et lancer localement. Pour la suite métier : décoder les références parent/enfants et les champs de targeting à partir des preuves binaires, compléter l'oracle indépendant à l'aide des références de conception autorisées, puis reprendre les écarts bloquants sans refaire les 76 constats déjà validés. Exécuter séparément la recette Docker/RQ/PostgreSQL/SSO dans le périmètre client.

## Historique conservé

### Phase 1 — point de reprise : références figées avant moteur
Quatre références PDF/JSON indépendantes créées sous `references/`, à partir de sondes ciblées distinctes du futur moteur. Trois variables contrôlées dans chaque package : ID, type, cardinalité, mapping XML et offsets. Identifiants compilés inventoriés. Deux signatures de colonne anneeRac retrouvées dans Adhésion.
**Les références sont partielles** : elles ne constituent pas l'oracle fonctionnel complet requis. Ordre, visuels complets, portée, tables exhaustives et usages restent ouverts. Les documents ne sont pas présentés comme rétro-documentations complètes.
Version moteur : toujours inexistante au moment du gel `references/oracle_frozen.json`.
Prochaine action : créer le profil binaire prudent et l'application ; comparaison ciblée des preuves figées, sans déclarer de validation globale.

### Moteur 0.1.0 → 0.1.1
Premier essai Adhésion : rejet incorrect du header. Correction : le uint32 à l'offset 24 n'est pas une taille exacte (écarts constatés 12/144/188/232 octets dans le corpus) ; contrôle de borne uniquement, sans sémantique de longueur inventée. Signature de fichier et ancre de structure contrôlées séparément. Résultat initial consigné, nouvelle exécution en cours.

### Test corpus 0.1.1 et correction 0.1.2
Quatre exécutions réussies : 5 380 à 5 796 variables, 4 898 à 5 236 mappings, 29 à 184 règles distinctes. Écart découvert : aucune expression source rattachée (lecteur de longueur inadapté). Inspection indépendante Versement : record règle tag 108/classe 30/ID 790284 à 5139588 ; source à 5139839, longueur uint32 65 ; code compilé à 5140081. Correction 0.1.2 : liaison par ID commun de record, lecture source uint32 bornée, effet faux seulement avec initialisation compilée explicite contrôlée. Réexécution des quatre packages prévue ; cibles/portées toujours inconnues.

### Phase 2 et premiers tests d'intégration
Interface Next.js compilée et vérification TypeScript réussie. API FastAPI, worker local séparé, configuration RQ/PostgreSQL/Docker fournies. Aucun Docker disponible ici : orchestration non exécutée.
Première suite : 9 succès / 7 échecs (session API). Cause : annotation Request absente sur la dépendance CSRF, interprétée comme paramètre de requête. Correction appliquée. Aucun résultat client n'a été exposé. Profil d'entrée renforcé sur les deux signatures de version observées. Nouvelle suite en cours.

### Validation intermédiaire
Suite corrigée : 16 tests réussis (moteur, API, comparaison, rejet invalide/taille, annulation en attente, reprise HTTP, isolement utilisateur, signature de téléchargement, expiration, purge, erreur expurgée, CSRF).
Calibration 0.1.2 : 19 contrôles indépendants par package, soit 76 conformes / 0 écart sur ce périmètre ciblé. Expressions sources rattachées : 130/183 Adhésion, 100/146 Versement, 121/184 FIP, 17/29 Obsèques. Les autres variantes restent brutes. Schéma JSON et bornes de preuves vérifiés sur les quatre sorties.
PDF : 4 références de 3 pages et 4 diagnostics de 6 pages rendus et contrôlés visuellement (36 pages). Police de repli DejaVu Sans, logo authentique.
Contrôle navigateur : premier lancement bloqué par navigateur absent ; téléchargement Playwright retourné incomplet. Autre installation locale en cours. Application locale et worker démarrés.

### Livraison locale
Lanceurs et guides ajoutés ; parcours navigateur corrigé uniquement dans le harnais de test (URL de téléchargement absolue et sélecteur d’alerte précis). Aucun traitement simulé. Sauvegarde des archives et de cet état avant livraison.

### Correctif du lanceur Windows — 26 septembre 2026
Erreur utilisateur : stratégie PowerShell interdisant start-windows.ps1. DEMARRER_WINDOWS.cmd utilise désormais directement Docker et scripts/init_env.py. Aucun changement de politique Windows ; aucune option ExecutionPolicy Bypass. Le moteur reste en version 0.1.2. Préparation de secrets par conteneur Python sans réseau ; fichiers .env existants conservés, seuls placeholders remplacés. Contrôle statique effectué ; Docker/Windows non disponibles ici.

## Reprise moteur — comparaison V6, itération 1 en cours
Sources consultées : PDF v6 (46 pages toutes rendues et inspectées), rapport.pdf (6 pages), PUB Versement, spécification technique, cahier consolidé, charte, parser.py, render.py, binary.py, schema.py et tests existants. SHA-256 PUB identique à celui de la référence : f23ca63a540159156cc72f63277b238bf656751f1035791fae294b65b21f0877. Aucun dépôt Git ni AGENTS.md trouvé ; empreintes initiales sous tmp/revision/before_hashes.json. Interface préservée.
Écarts : PDF tronqué volontairement ; formules `_formula` ignorées par regex `_formulas` ; texte métier non extrait ; ordre sérialisé différent de l’ordre documentaire ; cibles/répétitions non résolues. Prochaine action : extraire les contenus structurés à longueur redondante, les formules et initialisations sans exécuter le code, puis rendre ces preuves.

### Itération 1 — terminée, itération 2 en cours
Rapport : validation/revision_v6/iteration_1/rapport.pdf (94 pages rendues et inspectées). Modèle : rapport.json. Formules : 37 → 57 ; fragments candidats : 161. 19 tests existants passés après correctif parseur. Défauts constatés à l’inspection : un faux positif de contenu, algorithmes génériques trop volumineux, code compilé peu lisible, usages séparés sur quelques sauts de page. Aucune conformité métier déclarée.
Itération 2 : renforcer l’ancre du contenu ; rattacher les sources de formules par ID, longueur et bornes de définition ; privilégier les sources lisibles aux fonctions génériques ; conserver les preuves complètes dans le JSON.

### Itération 2 — résultat
validation/revision_v6/iteration_2 : 65 pages rendues et inspectées, 142 unités ancrées, 57 calculs dont 20 sources de formules décodées. 22 tests réussis. Inspection : titres T et règles parfois séparés de leur contenu. Annuaire encore incorrectement élargi aux références dont la racine est flow.
### Itération 3 — résultat et reprise
Ajout de la variante de texte A3 à longueur uint16 redondante (titre du courrier retrouvé à 4368307), regroupement des fiches pour éviter les coupures. 22 tests réussis. Rapport intermédiaire sous iteration_3.
### Itération 4 — en cours
Correction des dépendances de règles à accès nommé, classification des sources INPUT / refFiles ; tests dédiés. Prochaine action : recalibration quatre packages, inspection finale, tableau d’écarts et sauvegarde des livrables.

### Itérations 3 et 4 — rendus rejetés
202 pages : regroupements KeepTogether imbriqués causant une page par fragment. Défaut de pagination identifié dès l’inspection ; ces rapports ne sont pas des livrables validés. Toutes les pages ont été rendues, revue visuelle interrompue après constat du défaut répétitif.
### Itération 5 — en cours
Suppression du regroupement imbriqué, maintien d’un seul groupe par fiche. 24 tests réussis pour les corrections de moteur précédentes. Prochaine action : contrôler le rendu corrigé intégral et finaliser la calibration.

### Itération 5 — résultat
73 pages rendues et inspectées ; défaut des regroupements imbriqués corrigé. Annuaire ramené à 77 mappings INPUT. Restent des titres et en-têtes absents à cause d’un contrôle de style trop restrictif (champ 35 pour les titres, 51 pour les corps, 0/0x00ffffff pour les en-têtes).
### Itération 6 — en cours
Conserver l’ancre structurelle 101 et la longueur redondante sans imposer les codes de style. Les styles restent non interprétés. Nouvelle génération et contrôle final.

### Itération 6 — vérifiée, amélioration partielle livrable
Moteur 0.2.0 ; 162 unités, 57 calculs dont 20 sources lisibles ; 146 règles dont les 28 identifiants de référence retrouvés. Rapport : validation/revision_v6/iteration_6/rapport.pdf et rapport.json. Toutes les 76 pages rendues et inspectées ; pas de superposition ou coupure majeure observée, espaces résiduels et forte densité technique. 24 tests réussis, calibration ciblée 76/76 sur quatre packages ; détails dans tests_final.txt, calibration_0.2.0.json et comparison_checks.json. Sources consultées : mêmes sources de l'itération 1, puis content.py, report_detail.py, tests et sorties de calibration. Aucun changement frontend, API ou worker.
Livrables : GroupeAlterna_Exstream_Code_v0.2.0.zip ; GroupeAlterna_Versement_Moteur_0.2.0_Iteration_6.pdf ; GroupeAlterna_Exstream_Validation_V6_v0.2.0.zip. Les originaux rapport.pdf et v6 restent intacts.
Blocage de conformité : les relations documentaires, portées exactes et structures de répétitions ne sont pas suffisamment décodées. Ce sont des limites du décodeur actuel ; aucune impossibilité intrinsèque du format n'est démontrée. Prochaine action exacte : sonder les relations autour de 4377580–4378107, établir une association texte/règle et table/répétition vérifiable, puis ajouter un test indépendant avant de généraliser. Reprendre depuis cet état sans régénérer les étapes encore valides.

## Nouvelle boucle — itération 7 en cours
Reprise depuis l’itération 6 (0.2.0), sources et rendus accessibles vérifiés. Journal 18 fourni : simple « fichier de suivi » ; journal du dépôt conservé comme état détaillé. Sondes binaires ciblées sur relations texte/règles, tables et répétitions. Empreintes avant modification : tmp/revision2/before_hashes.json. Prochaine action : vérifier le format des enregistrements et établir des relations indépendantes de la proximité.

### Itération 7 — revue terminée ; itération 8 en cours
Rapport 47 pages toutes rendues et inspectées. Décodage structurel : 8 paragraphes ordonnés (liste à 342549), 28 règles associées, quatre répétitions de ligne avec drivers exacts. 27 tests réussis. Défauts de revue : variante du header style non reconnue pour le code UC ; cellule rejetée et placée hors grille ; colonnes vides ISIN non conservées au rendu ; pages de vue trop aérées. Corrections prévues : profil style sur champ 16 bits et sentinelle, colonnes fixes, pagination fluide, sources des fonctions de lookup et chaîne d'appels.

### Itération 8 — vérifiée ; itération 9 en cours
42 pages rendues et inspectées. Code ISIN UC réintégré en ligne 6 / colonne 2, cellules ISIN vides conservées ; sources de calcul 20 → 42 par extension aux fonctions. Deux chaînes lookup démontrées (TITLE, DIST), ordre lexical des appels exposé avec limites. 32 tests passent dont trois contrôles sur le PUB exact ; calibration 76/76. Restent des titres/notes isolés en pagination et des conditions compilées simples peu lisibles. Itération 9 : regroupement des fiches règles, réserve de place pour cellules hautes, décodage strict des IF/ELSE compilés explicites, sans sémantique ajoutée pour absence/null.

### Itération 9 — vérifiée, version 0.3.0 sauvegardable
Étape : revue visuelle terminée, conformité partielle. 41 pages rendues et inspectées ; contrôle des bornes de tous les textes : 0 dépassement. Polices des textes intégrées et texte sélectionnable sur 41/41 pages. 33 tests réussis et calibration finale 76/76. Résultats : `validation/revision_v6/tests_0.3.0.txt`, `calibration_0.3.0.json`, `comparison_0.3.0.json`, `pdf_qa_0.3.0.json`. Rendus finaux conservés dans l'archive de validation.
Sources effectivement consultées pendant la boucle : le PUB Versement exact, la pièce jointe itération 6 (texte correspondant au précédent), PDF v6 et rendus de référence déjà validés, cahier consolidé et spécification extraits, charte 14, instructions 16, état 18, journal du dépôt ; parser.py, binary.py, rules.py, content.py, render.py, report_detail.py, schema.py, tests existants ; nouveaux layout.py, provenance.py, report_structure.py et tests ; quatre PUB lors de la calibration. Aucune source Tools Reports.
Corrections : identités de paragraphes par paire 111/104, ordre de section, coordonnées de cellules, 18 règles de ligne, 10 règles internes reliées sans spans, quatre répétitions de ligne, header de style compact, sources de fonctions, appels lexicaux et lookup, cinq conditions compilées strictes, regroupement des fiches PDF. Ces corrections sont génériques, sans noms/offsets métier dans le moteur.
Livrables : `GroupeAlterna_Exstream_Code_v0.3.0.zip`, `GroupeAlterna_Versement_Moteur_0.3.0_Iteration_9.pdf`, `GroupeAlterna_Exstream_Validation_V6_v0.3.0.zip`, ce journal et `docs/ECARTS_V6.md`. Les modèles JSON et PDF distincts des itérations 7/8/9 sont conservés dans la validation.
Blocages : plages exactes internes, sauts de ligne/styles fins, découpage Pxx, pagination et ressources Exstream, échantillons, politiques de longueur/null des répétitions, ordre global des événements. La prochaine action est de décoder les attributs de segments 4425526–4426608 pour le texte 4420501, prouver une plage Oui/Non avec test indépendant, puis généraliser. Ne pas déduire une portée de l'ordre de la liste de règles. Voir le tableau de correspondance des numéros R dans ECARTS_V6.md.

## Reprise portée exacte — itération 10 en cours
Reprise du moteur 0.3.0 / itération 9, livrables antérieurs accessibles. Aucun dépôt Git ni AGENTS.md ; empreintes avant modification : tmp/revision3/before_hashes.json. Journal fourni 18 = simple placeholder, état détaillé du dépôt conservé.
Sources consultées : nouvelle méthode GroupeAlterna_Determination_Portee_Exacte_Regles_Exstream_PUB_2026-09-26_v1.docx (intégralement), spécification 01 et cahier 02 (extraits concernant le ciblage), journal, tableau des écarts, layout/content/parser/schema/report_structure, tests et modèle JSON de l'itération 9 ; PUB Versement exact. PDF v6 et rendus de ses 46 pages disponibles, revue précédente conservée. Aucun Tools Report consulté.
Écarts : listes internes de règles sans plages ; assemblage ajoutant des espaces entre fragments ; objets de ciblage sans EvidenceBundle normalisé ; occurrences numériques non classées. Prochaine action exacte : vérifier la correspondance de l'attribut sérialisé de texte avec le payload, puis résoudre les marqueurs de ciblage sans utiliser la proximité ni les noms de règles.

### Itération 10 — revue terminée ; itération 11 en cours
Moteur 0.4.0 en préparation. 44 tests réussis ; rapport `validation/revision_v6/iteration_10/rapport.pdf` de 42 pages, toutes rendues et inspectées. Modèle JSON voisin ; images sous `tmp/revision3/it10`. Les 10 règles internes du bulletin ont désormais des propriétaires de paragraphe ou inline résolus : 7 plages inline et 5 cibles de paragraphe (dont un paragraphe composé uniquement de deux espaces). Les 18 règles de ligne sont conservées.
Preuves nouvelles : flux signé -244 (paragraphes), -254/index et -110 (inline), -384/ID et -111 (variables), nombre de glyphes concordant au caractère avec le payload et répertoire variable indépendant ; propriétés de paragraphe à double index et liste locale comptée. R28 = « tte » à 0x466EE5, ouverture 4620097, fermeture 4620117. R3 cible aussi le paragraphe TIN/SSN via record 4419547, contrairement au commentaire de la référence : différence conservée et à documenter. Aucun Tools Report utilisé.
Écarts corrigés : propriétaires explicites, spans par tokens sans indices finaux fictifs, coloration ciblée, distinction occurrences de définition/ciblage/non résolues, tests de corruptions. Revue : Oui/Non accolés visuellement ; certains contenus de repli accolés ; annuaire déborde sur une dernière ligne isolée. Noms de règles compilées encore corrompus pour certains headers.
Prochaine action exacte : corriger la lecture bornée des noms des définitions de règles, enrichir le modèle et la comparaison de portées, prendre en charge l'enveloppe de texte compacte pour les cellules de répétition ; améliorer les séparateurs éditoriaux et la pagination puis relancer tests/calibration/revue complète.

### Itération 11 — vérifiée ; itération 12 en cours
Rapport `validation/revision_v6/iteration_11/rapport.pdf` : 42 pages toutes rendues et inspectées ; JSON voisin, rendus sous tmp/revision3/it11. 49 tests passent ; calibration ciblée 76/76. 52/62 unités du courrier possèdent un flux textuel et un parent validés par le nouveau profil.
Corrections : enveloppe compacte des cellules, nom des règles à header paramétré (variable + littéral Pascal), conditions compilées à chaîne entre guillemets doubles sans inventer d'ELSE, comparaison des portées indépendante des offsets, validation des frontières des tokens, exposants Rn éditoriaux et espacement de repli restauré, annuaire sans dernière ligne isolée.
Les 12 cibles internes (10 règles distinctes) satisfont les quatre critères du document d'aide sur le profil reconnu ; confiance CERTAIN limitée à ce profil et preuves binaires, sans promesse universelle. Les règles de ligne conservent leur qualification empirique antérieure. Référence v6 pages 15 et 28 revue à nouveau : divergence TIN/SSN confirmée, accord sur « tte ».
Reste à corriger dans la présentation : répétition des explications de confiance alourdissant le catalogue (R28 isolée sur une page) ; afficher les offsets de ciblage distinctement des offsets de définition. Prochaine action exacte : normaliser ces repères dans le modèle et les fiches, régénérer itération 12, recontrôler toutes les pages puis livrer.

### Itération 12 — terminée, version 0.4.0
Étape : validation de la livraison. Rapport `validation/revision_v6/iteration_12/rapport.pdf` et JSON voisin ; 41 pages rendues et inspectées intégralement. Contrôle des bornes : zéro dépassement ; texte sélectionnable 41/41 ; DejaVu Sans/Sans Bold intégrées ; R28 « tte » rouge vérifiée dans le PDF. Modèle final enrichi avec les index non consommés conservés, sans changement du rendu.
Tests : 49 réussis, aucun sauté ; calibration historique 76/76. Nouveau profil reconnu sur 52/62 unités du Versement ; sept runs inline, cinq paragraphes pour dix règles distinctes. Les trois autres PUB gardent leur résultat antérieur et ne passent pas ce profil ; leurs portées ne sont pas déclarées exactes. Résultats : `tests_0.4.0.txt`, `calibration_0.4.0.json`, `targeting_0.4.0.json`, `comparison_0.4.0.json`, `pdf_qa_0.4.0.json`, `ui_preservation_0.4.0.json` sous validation/revision_v6.
Corrections finales : EvidenceBundle et repères de targeting normalisés, comparaison sémantique des portées, schéma de validation enrichi, catalogue resserré ; ancienne API et interface inchangées (17 fichiers contrôlés contre archive 0.3.0). Aucun Tools Report utilisé. Aucun PDF original remplacé. Les itérations 10/11/12 restent distinctes.
Livrables : `GroupeAlterna_Exstream_Code_v0.4.0.zip`, `GroupeAlterna_Versement_Moteur_0.4.0_Iteration_12.pdf`, `GroupeAlterna_Exstream_Validation_V6_v0.4.0.zip`, journal et tableau des écarts. Guide : `MISE_A_JOUR_MOTEUR_0.4.0.md` ; conserver le .env existant et les volumes Docker lors de la mise à jour.
Blocages : neuf unités de grille du Bulletin hors du profil strict, titre littéral distinct, autres variantes de packages, Pxx, exemples, ordre global d'événements, fusions/styles/pagination et ressources Exstream, politiques de répétition/null. Différence fondée sur le PUB : rule781268 cible également le paragraphe TIN/SSN, malgré le commentaire contraire de v6 p.15.
Prochaine action exacte : lire les issues du JSON final ; sonder la table de propriétés vide à partir du texte 4437952 et la propriété non redondante de 4574019, puis créer des fixtures indépendantes des variantes de glyphes des trois autres packages. Ne pas recommencer les inspections 10/11/12 si leurs artefacts restent accessibles. La conformité globale reste non acquise ; aucune impossibilité intrinsèque du format n'est démontrée.


## Corpus de quatre courriers — itération 13 en cours
Reprise de 0.4.0 / itération 12. Les quatre PUB demandés sont accessibles : Adhésion (03), Versement (04), FIP Essenciel (05), Devis Auto (07). Le cas Obsèques reste une régression historique, pas un remplacement du Devis Auto. Sources disponibles : PDF v6, rapport original, méthode de portée, cahier consolidé, spécification et ressources graphiques. Aucun Git/AGENTS trouvé ; changements existants préservés par empreintes tmp/corpus4/before_hashes.json.
Étape : diagnostic séparé des quatre packages avant modification. Sources effectivement relues : journal, parser.py, layout.py, report_structure.py, scopes.py (partie), état du dépôt. Aucun Tools Report. Version moteur : 0.4.0.
Écarts à confirmer : profil richtext absent sur les autres packages, propriétés des colonnes incomplètement inspectées, inventaire non rendu dans le rapport structuré, repères B au lieu de P, couverture des variables et calculs dépendants. Aucun rapport nouveau généré à ce stade.
Prochaine action exacte : analyser les quatre PUB avec 0.4.0, conserver leurs diagnostics puis comparer les enregistrements refusés, avant toute extension du profil.

### Itération 13 — diagnostic généré, rendu rejeté ; itération 14 en cours
Moteur 0.5.0 en préparation. Quatre rapports/JSON générés sous validation/corpus4/iteration_13 : Adhésion 295 pages, Versement 207, FIP 251, Auto 149. Contrôle automatique de toutes les bornes : aucun dépassement ; revue visuelle de 12 pages représentatives par rapport (48 pages) interrompue après constat du catalogue de fonctions mutualisées trop large. Ces PDF de diagnostic ne sont pas des livrables validés ; toutes leurs pages n’ont pas été inspectées visuellement. Tests existants : 49/49 après chaque série de corrections (tests_structurev2.txt et tests_iteration13.txt).
Corrections : racine DOC et sections imbriquées mixtes 205/206 ; nom accentué « solutionProposée » ; maintien des objets sans contenu décodé ; variantes du préambule texte ; propriétés de paragraphe 334/346 octets ; tables portées directement par une page Auto ; inspection de toutes les colonnes ; profil de Repeat-C.
Observation rectifiant le profil 0.4 : le champ +4 de propriété de paragraphe n’est pas une copie générale du ciblage +56. Adhésion/FIP présentent +4=0 et +56=-1 ou index local variable. Le champ +4 reste brut ; seul +56 est interprété comme index borné de la table locale. Les preuves et tests de corruption ont été adaptés, sans supprimer le contrôle d’index.
Sources effectivement consultées : quatre PUB, moteurs et tests, spécification §Repeat-colonne et cahier consolidé, méthode antérieure, modèles générés et vues de l’itération 13. Aucun Tools Report ; interface intacte. Deux colonnes anneeRac retrouvées après correction du contrôle de sentinelle de dimension (la première colonne peut avoir des propriétés de police non nulles).
Écarts restant corrigeables : sélection excessive des fonctions par écritures partagées ; flag du répertoire de variables 0 non accepté ; contrôles de mise en page -247/-159 ; contenus avec valeurs de conception ; associations de cellules à revérifier par le flux de style consommé.
Prochaine action exacte : valider les variantes par les bornes/ID indépendants, ajouter les tests corpus et négatifs, générer itération 14 puis inspecter intégralement les nouveaux rapports.

### Itération 14 — revue et correctif ; itération 15 en cours
Quatre rapports générés : Adhésion 99 pages, Versement 69, FIP 84, Auto 126. Toutes les pages rendues sous tmp/corpus4/it14 ; contrôle des bornes et texte sélectionnable effectué. Revue visuelle commencée (Versement pages 1–24), puis correction d’une régression de grille observée : l’un des deux champs de sentinelle peut être nul ; le contrôle doit accepter l’un ou l’autre avec les deux enveloppes vérifiées. Le bloc identité perdait une colonne ; un test métier et un test négatif spécifique ont été ajoutés. Les PDF de cette itération ne sont pas déclarés validés.
Tests : 65 succès avant cette correction. Nouvelles preuves : répertoire variable ID + bornes + index de format corroborant le flux de glyphes ; octets de format imprimables exclus uniquement sur ces bornes ; valeurs de conception identifiées (DF_PAR_title) conservées séparément et affichées comme variables ; glyphe spécial -159 compté ; deux Repeat-C anneeRac ; association erronée du texte FIP « Notre entretien » à une cellule rejetée par divergence du style consommé.
Sélection de calculs corrigée : les fonctions susceptibles d’écrire une variable restent des sites de valorisation, sans être toutes considérées comme appelées. Fermeture des dépendances sur formules et appels explicites ; aucun ordre événementiel global fabriqué.
Prochaine action exacte : générer itération 15 avec la grille rétablie et les réserves d’ordre local, exécuter les 66 tests, recalibrer l’historique et inspecter toutes les pages des quatre rapports finaux. Les profils de propriétés encore rejetés doivent rester signalés, avec offsets et preuves.

### Itération 15 — revue partielle, itération 16 en cours
Grille du Versement rétablie et vérifiée (2 colonnes au bloc situation), réserves d’ordre ajoutées ; 66 tests réussis. Quatre PDF générés (99 / 69 / 84 / 126 pages) et tous rendus. Revue Versement pages 1–48 : aucun écrêtage, mais la lecture de la section variables révèle une régression de sélection : formula107407 écrit les variables visibles sans être leur formule de retour directe. La correction de périmètre de l’itération 14 avait exclu son algorithme.
Correction en cours : conserver les formules qui affectent une variable utile, sans réintroduire l’ensemble des fonctions mutualisées comme appels supposés. Test métier spécifique sur WRK_AFR_EPI_NOE_BV_typeCourrier ajouté. Les sites de valorisation sont conservés même quand l’appel global est inconnu ; ne pas afficher « non établi » lorsqu’un site est démontré.
Prochaine action exacte : générer itération 16, relancer tests/calibration, contrôler l’algorithme formula107407 et les mappings associés, puis inspection complète des quatre PDF. Les précédents PDF ne sont pas supprimés et ne sont pas déclarés validés.

### Itération 16 — algorithmes restaurés ; itération 17 en cours
67 tests réussis. Les formules à affectations multiples et leurs appels explicites sont réintégrés (dont formula107407). Rapports générés : Adhésion 208 pages, FIP 210, Auto 152 ; premier fichier Versement trouvé vide au contrôle après génération malgré le retour du générateur. Cause de cette troncature non démontrée. Régénération distincte rapport_verifie.pdf : 161 pages, 364345 octets, enveloppe PDF valide. Aucun livrable vide retenu.
Itération 17 : amélioration de la lisibilité des longues sources (style de code compact, contenu intégral conservé) et export avec fichiers temporaires, validation %PDF/%%EOF puis publication. Test de non-publication d’un PDF vide avec préservation des livrables antérieurs. Preuve des chaînes de propriétés étendue aux bornes complètes (extrait binaire + empreinte).
Prochaine action exacte : produire les quatre rapports 17, vérifier leur intégrité et leur pagination, rendre et inspecter chaque page, puis sauvegarder le moteur et le tableau des limites.

### Itération 17 — revue en cours, correction de flux ; itération 18
68 tests réussis, quatre PDF intègres (185 / 141 / 182 / 145 pages), 653 pages rendues et contrôlées automatiquement : zéro dépassement des marges. Revue des pages 1–36 d’Adhésion : un bloc juridique long laisse son titre seul sur une page parce que son texte entier est regroupé.
Correction de présentation réutilisable : conserver les frontières de paragraphes internes décodées dans les objets PDF, au lieu de regrouper tout un texte mult paragraphe dans un seul élément insécable. Aucun texte ou algorithme supprimé. Les tableaux gardent des lignes indivisibles.
Prochaine action exacte : génération 18, inspection complète et contrôle de non-régression de contenu extrait, puis livraison sans déclaration de conformité générale. Les variantes de propriétés non reconnues restent des blocages de décodage documentés, pas une impossibilité intrinsèque démontrée du format.

### Itération 18 — revue finale en cours
68 tests réussis. PDF intègres : Adhésion 185 pages, Versement 141, FIP 184, Auto 146 ; toutes les 656 pages rendues. Contrôle automatique : zéro dépassement, toutes les pages sélectionnables. Adhésion 1–185 et Versement 1–141 inspectées visuellement via planches de 12 pages ; aucune troncature ni superposition majeure observée. Les longues sources restent denses et certaines transitions peu remplies. La vue Adhésion P20 ne laisse plus son titre seul. Restent à inspecter : FIP 1–184 puis Auto 1–146 ; zoom des pages signalées et comparaison de contenu V6 ; bilan des limites et sauvegarde finale. Sources supplémentaires consultées : rendus de l’itération 18 et QA, profils/documentation antérieurs.

### Itération 18 — revue complète, correction de source ; itération 19 en cours
Toutes les 656 pages inspectées visuellement. Le Devis Auto révèle un annuaire vide malgré les mappings décodés : défaut du test de chaîne INPUT suivi d’un espace. Dans le record 163 de la source 15:1520 (name_end=433172), INPUT est une chaîne Pascal de longueur 5 ; le caractère suivant est la longueur 62 du chemin, pas un séparateur. Le profil des trois autres packages contient la longueur 32, d’où le faux test historiquement passant. Correction générique : lire les deux chaînes Pascal après l’enveloppe 163 bornée, conserver rôle/chemin/preuve ; ne pas utiliser le nom de variable. Tests ajoutés : annuaire non vide sur les quatre sources, marque Auto liée à son mapping, faux INPUT dans le chemin rejeté. Prochaine action exacte : relancer tests, comparer les trois modèles déjà validés hors nouvelles preuves de source, générer Auto 19 et inspecter toutes ses pages.

### Itération 19 — livraison 0.5.0, validation partielle documentée

Étape : boucle de sept itérations 13–19 terminée pour cette livraison ; conformité exhaustive non acquise. Les itérations 13–17 ne sont pas déclarées validées. L’itération 18 a été intégralement inspectée, puis remplacée pour corriger la classification INPUT d’Auto. Le lecteur reste empirique ; la fiabilité de tout PUB n’est pas démontrée.

Sources effectivement consultées : PUB 03/04/05/07, spécification 01, cahier consolidé 02, méthode de portée jointe, charte/logo, PDF V6 et ses 46 rendus conservés, extraits et rapports précédents, moteur et tests. Composants concernés : parser.py, content.py, scopes.py, layout.py, coverage.py, structure.py, report_structure.py, report_inventory.py, export.py, schema.py et version ; schéma JSON, tests et script de calibration également. Aucun Tools Report. Originaux PUB, rapport.pdf, V6 et itération 6 conservés.

Correction finale : rôle INPUT et chemin lus séparément dans le descripteur 163 ; classification par racine /flow supprimée, source propriétaire unique exigée. Auto retrouve 488 mappings INPUT pour 437 variables dans le package, dont 86 mappings dans l’annuaire documentaire. Adhésion/Versement/FIP conservent leur rendu validé ; leurs 510 images sont identiques à celles de l’itération 18. Les 146 pages Auto de l’itération 19 ont été relues intégralement.

Rapports finaux : `validation/corpus4/iteration_19/<nom_du_PUB>/rapport.pdf` et `rapport.json` : Adhésion 185 pages, Versement 141, FIP 184, Auto 146. Les 656 pages sont rendues, sélectionnables et inspectées par planches, avec zooms des passages signalés ; zéro dépassement automatique, aucun écrêtage/superposition majeur observé. Quelques sources de code restent denses et des transitions peu remplies.

Vérifications finales : 73 tests réussis, aucun sauté, un avertissement de dépréciation httpx/Starlette ; calibration historique 76/76 sur Adhésion/Versement/FIP/Obsèques (Auto testé séparément dans la suite corpus). Recalcul des quatre modèles avec le code livré : identité exacte avec les JSON finaux. 22 fichiers frontend/API/worker/configuration/orchestration identiques aux empreintes de départ. Aucun test Docker/Windows/PostgreSQL exécuté ici.

Comparaison V6 : 28 IDs de règles présents, 73 noms de variables de l’annuaire retrouvés dans le nouvel annuaire INPUT, quatre répétitions de ligne. Concordance des 46 pages dans `validation/corpus4/CONCORDANCE_PAGES_V6.md`. Pagination 141 vs 46, découpage Pxx et densité différents ; cela n’est pas déclaré conforme. Cible TIN/SSN maintenue sur preuve du PUB malgré le commentaire V6. Aucun PDF de référence indépendant disponible pour les trois autres courriers.

Livrables : `GroupeAlterna_Exstream_Code_v0.5.0.zip`, quatre `GroupeAlterna_{Adhesion,Versement,FIP_Essenciel,Devis_Auto}_Moteur_0.5.0_Iteration_19.pdf`, `GroupeAlterna_Exstream_Validation_Corpus_v0.5.0.zip`, `docs/VALIDATION_CORPUS_0.5.0.md`, `docs/ECARTS_V6.md` et ce journal. Le code contient le guide `MISE_A_JOUR_MOTEUR_0.5.0.md`. Preuves de tests, QA, revue visuelle, métriques, non-régression interface et reproductibilité dans `validation/corpus4/`. Le profil 0.4 obsolète reste conservé avec avertissement ; `docs/PROFIL_PORTEES_PUB.md` décrit v2.

Blocages restants : sept unités de propriétés Adhésion, sept FIP et six Auto non décodées complètement ; Auto opcode -240 à 1254569 dans le texte 1252466 ; parentage de 25 contenus Auto et ordre entre régions inconnus ; fusions, certaines propriétés conditionnelles de colonnes, graphique Exstream, pagination évaluée et ordre global des événements non établis. Ce sont des limites du lecteur actuel, pas des impossibilités intrinsèques démontrées du format. Les 14 critères et offsets détaillés sont dans le bilan.

Prochaine action exacte : examiner Auto texte 1252466 / opcode -240 à 1254569 ; corroborer toute nouvelle arité par la table de lignes et le répertoire variable indépendants, ajouter un cas négatif, puis traiter une variante propriétaire Adhésion/FIP et les propriétés de fusion/colonne. Reprendre à partir des modèles et rendus 19 accessibles ; ne pas recommencer les inspections encore valides.

## Reprise du 27 septembre 2026 — Obsèques, itération 20 en cours
Base : ZIP livré 0.5.0 (SHA bbbbceb7191dbab18610e3dcff84b938905c508a88a67ea90aa6d48adc8029b4), extrait dans un dossier isolé ; ancien espace 0.1.2 conservé. Journal 0.5.0 lu. Sources consultées : rapport-1.pdf (118 pages, SHA 5ec2d1de7e45a45fbcb5826d26bf01f71f17d0ff3c20afe67c99895d8475ed72), PUB Obsèques 06 (SHA 78b79d2cf896722b8cc4a057a222b2df595af34a44fdb7bd1f1c402bdf7b2337), modules parser/content/layout/scopes/structure/provenance/coverage/report_structure, tests existants. PDF original conservé ; aucun Tools Report.
Écarts établis : titres préférant les IDs malgré noms décodés ; trois définitions de page peu visibles dans le rapport ; annotations Rn absentes aux frontières de paragraphes ; écritures des règles ignorées ; propriété +16 de trois colonnes portant 767773/767782/767783, chacune avec algorithme Contains puis trois affectations de choix/cotisations. Sources de ces règles à 4853262/4855436/4857634, bornées par longueur, manquées car elles commencent par Dim et non IF. R1/R2 concernent P10.12 ; l’ancien R3 concerne les cotisations du tableau suivant, pas ce texte.
Prochaine action : profil de colonne borné et testé négativement, extraction des sources complètes et des affectations de règles, annuaire de valorisation par variable, noms de page et titres métier, repères de début/fin exacts ; tests puis PDF distinct itération 20.

### Itération 20 — première génération, itération 21 en cours
Obsèques : 130 pages générées et toutes rendues ; revue pages 1–36 et ciblages/colonnes en cours. 78 tests réussis après adaptation d’un ancien test qui imposait à tort que toutes les colonnes restent non interprétées. Six règles rattachées contre trois ; propriétés de colonnes +16 corroborées par condition Contains et trois affectations compilées chacune. Neuf variables de choix/cotisation ont maintenant une origine calculée et un site exact. Trois pages nommées visibles en début de rapport. Titres métier et repères début/fin présents. L’ancien R3 de périodicité devient R6, après insertion des règles de colonnes R3/R4/R5 ; aucune troisième règle n’est ajoutée arbitrairement au texte P10.12.
Défaut visuel trouvé : dernière ligne de la note de source P10 renvoyée seule en haut de la page suivante dans la vue générale. Correction : garder chaque paragraphe décodé et son annotation finale ensemble. Les inventaires privilégient aussi les noms métier. La première version est conservée, non livrée comme finale.
Prochaine action : générer Obsèques 21, inspecter toutes les pages, zoomer les fiches des cotisations et les bornes P10 ; puis recalculer les quatre autres PUB avec le même moteur et vérifier leurs rapports.

### Itération 21 — inspection complète ; itération 22 en cours
Moteur 0.6.0. Les 130 pages Obsèques ont été rendues et inspectées (11 planches, zooms pages 5/15/27/30/96). Zéro dépassement automatique ; texte sélectionnable, aucun écrêtage majeur. Les repères R1/R2 de P10.12 sont placés aux frontières décodées ; les colonnes Viagère/10 ans/20 ans ont R3/R4/R5 et leurs neuf affectations. Les 29 variables directement utilisées dans les contenus ont une origine classée ; cela ne résout pas tout le package ni l'ordre événementiel global. Sources consultées : modèle 21, rendus complets, algorithmes compilés/source, parser/valuation/coverage/report_structure et tests. 78 tests réussis.
Dernier ajustement observé : certaines fiches de cotisations sont séparées entre deux pages. Itération 22 : garder les fiches à un seul site de valorisation ensemble ; générer de nouveau Obsèques et les quatre autres PUB. Extension du script de corpus par --include-obseques. Aucune modification frontend/API.
Prochaine action exacte : générer les cinq PDF/JSON dans validation/corpus5/iteration_22, exécuter les 78 tests et la calibration historique 76 contrôles ; rendre et inspecter toutes les pages, comparer les invariants avec 0.5.0 et consigner les limites avant livraison.

### Itération 22 — non-régression établie ; itération 23 en cours
Cinq PDF/JSON générés : Adhésion 196 pages, Versement 146, FIP 198, Obsèques 130, Auto 159. Toutes les pages rendues ; zéro dépassement des marges, aucune page vide. Revue visuelle complète Adhésion/Versement ; Obsèques : 123 images identiques à l'itération 21 et sept pages modifiées 93–99 inspectées. FIP/Auto pas encore relus intégralement à cette itération.
78 tests réussis ; calibration 76/76. Comparaison moteur 0.5.0/0.6.0 : 35 invariants vérifiés sur les cinq packages (variables/types/cardinalités, mappings, ordre structurel des paragraphes, contenus/parents, richtext/portées existantes, code compilé des règles et drivers Repeat). Script comparatif corrigé après une première erreur de nom de clé ; son exécution finale est complète et réussie.
Spécification 01 et cahier 02 relus sur colonnes, valorisation, annotations et exclusions. Aucune source Reports. Les deux chaînes de propriétés Obsèques encore refusées sont text:4534892 / P11.14 et text:4704658 / P17.02 ; conserver leur texte et preuve, sans coloration conjecturale.
Défaut restant de présentation : le titre général des fiches de variables peut rester seul en bas de page (Obsèques 93, Versement 100). Itération 23 : réserver la place du titre et de la première fiche. Prochaine action : générer les cinq rapports 23, rendre toutes les pages, réutiliser seulement les inspections d'images dont l'identité est vérifiée et inspecter toutes les nouvelles images, puis livrer.

### Itération 23 — livraison du moteur 0.6.0, limites documentées

Étape : quatre itérations 20–23 terminées pour cette livraison. Les cinq PDF/JSON finaux sont dans `validation/corpus5/iteration_23/<nom_du_PUB>/rapport.pdf` et `rapport.json` de l'archive de validation. Rapports nommés `GroupeAlterna_<courrier>_Moteur_0.6.0_Iteration_23.pdf` : Adhésion 196 pages, Versement 146, FIP Essenciel 198, Obsèques 130, Devis Auto 159. Code et preuves : `GroupeAlterna_Exstream_Code_v0.6.0.zip` et `GroupeAlterna_Exstream_Validation_Corpus_v0.6.0.zip`. Les PDF des itérations 20–22 restent conservés séparément.

Fichiers effectivement consultés : les cinq PUB 03–07, `upload/rapport-1.pdf`, spécification déterministe 01 et cahier consolidé 02, journal initial, ZIP code 0.5.0, modules et tests du moteur, modèles et rendus des itérations 20–23. Aucun Tools Report. Les références de l'ancien dossier 0.1.2 n'ont pas servi à l'analyse. Le PDF historique V6 n'était pas accessible dans les ressources matérialisées de cette reprise : aucune nouvelle comparaison directe V6 n'a été effectuée. Les comparaisons V6 des sections antérieures restent historiques.

Corrections : extraction bornée des règles commençant par Dim et autres préambules, noms métier accentués, analyse des affectations dans les règles/calculs avec sources/index/gardes locales et preuves, arguments des appels, composants pages nommés, titres métier, profil de ciblage de colonnes, repères Rn aux frontières exactes décodées et regroupements de paragraphes/annotations/fiches. Les neuf variables de choix/cotisations Obsèques ont une valorisation démontrée dans les trois règles de colonnes. P10.12 conserve uniquement ses deux règles prouvées R1/R2 ; l'ancienne R3 de périodicité porte ailleurs et devient R6. Le moteur commun retrouve également 11/4/11/1 origines supplémentaires dans Adhésion/Versement/FIP/Auto, sans perdre d'affectation reconnue par 0.5.0.

Tests : 78 réussis, aucun sauté, un avertissement de dépréciation httpx/Starlette (`analysis/tests_iteration23.txt`). Calibration 76/76 dans `validation/revision_v6/calibration_0.6.0.json` ; 35 invariants de non-régression comparés avec 0.5.0 sur les cinq modèles. Les fichiers `analysis/non_regression_050.json`, `metrics_final.json`, `interface_non_regression.json` et les scripts de contrôle sont conservés. Interface/API/services inchangés : 27 fichiers comparés par empreintes. Aucun test Docker Desktop, Windows ou PostgreSQL dans cet environnement.

Inspections : les 829 pages finales sont rendues dans `analysis/render23`. FIP 1–198 et Auto 1–159 relus intégralement ; Adhésion/Versement relus en 22 puis inspection des pages 143 / 100–101 modifiées en 23 ; Obsèques relu intégralement en 21 puis pages 93–99 de 22 et 93–94 de 23. L'identité de toutes les autres images réutilisées est vérifiée dans `obseques_visual_reuse.json` et `visual_reuse23.json`. Zooms supplémentaires des cibles, colonnes, calculs et fiches. Texte sélectionnable partout, polices utilisées intégrées, numérotation séquentielle, zéro page vide ou dépassement de marge ; aucun écrêtage/superposition important observé. Sources longues parfois denses, transitions parfois peu remplies. Originaux PUB et rapport-1.pdf conservés, empreintes vérifiées.

Blocages restants : deux chaînes de propriétés Obsèques P11.14/text:4534892 (4535341–4540223) et P17.02/text:4704658 (4705890–4717749) non résolues ; sept unités Adhésion, sept FIP, six Auto dont opcode -240 à 1254569 ; origines non établies de 4 variables directes Adhésion, 1 FIP et 15 Auto ; ordre global des événements, certains parentages, fusions et paramètres graphiques fins non établis. Les 29 variables directes Obsèques sont classées (9 INPUT, 20 calculées), sans prétendre résoudre tout le package. Ces limites du lecteur ne démontrent pas une impossibilité intrinsèque du format. La conformité exhaustive n'est pas déclarée.

Bilan détaillé : `docs/VALIDATION_MOTEUR_0.6.0.md` ; installation : `MISE_A_JOUR_MOTEUR_0.6.0.md` (conserver le .env et les volumes de l'installation existante). Le ZIP code inclut `.env.example` et les lanceurs qui créent le .env d'une installation neuve, sans secret utilisateur embarqué.

Prochaine action exacte : reprendre les deux chaînes Obsèques refusées à partir des offsets ci-dessus, établir indépendamment le propriétaire et les bornes des enregistrements avant d'étendre le profil ; ajouter cas positif et cas négatif, puis examiner Auto text:1252466 / opcode -240. Réutiliser les artefacts 23 et leurs inspections si leurs empreintes restent valides. Ne pas repartir du dossier historique 0.1.2.


## Reprise NOA du 28 septembre 2026 — itération 24 en cours
Base isolée : moteur 0.6.0 livré, identique à la copie locale vérifiée. Journal courant v12 consulté ; anciens travaux préservés. Source : upload/AFR_GENERIC_IARD_VEHIC_NOA_DEVIS.pub, SHA 331bd9af95813d30daad1b9a0da4209bbaa127b4bb19195ec31d2bc6bc197f52 ; rapport-2.pdf, 233 pages, SHA af5a842f018f719a62cda068070f00dd08cd87efa63cbec9dd350523e9668a52. Modèle initial sous work_noa/analysis/baseline_noa.json, empreintes avant modification dans before_hashes.json. 78 tests de base réussis.
Fichiers consultés : journal courant, rapport-2 extrait, PUB NOA, parser/content/layout/structure/scopes/coverage/report_structure et tests existants. Aucun Tools Report ; interface non modifiée.
Écarts : les références globales de règles se trouvent dans le record 136 de la définition PAR (R57 historique = 524781/DF_RUL_pdf, champ name_end+92 pour 21:25233) ; profil à corroborer indépendamment avant interprétation. Noms variables perdus quand les propriétés de portée échouent ; plages de texte et retours internes ignorés au rendu ; grilles multiples et styles de cellules mal reconnus ; chapitre séquentiel et propriétés sans effet trop redondants.
Demandes de présentation : titres par nom PAR, un tableau Rn/nom/algorithme dédupliqué par bloc, suppression du chapitre Analyse séquentielle et preuves et des commentaires de cibles internes, tableaux de propriétés limités aux axes ayant règle ou répétition, contenu réel de la ligne dans la colonne Ligne. Inspection de toutes les colonnes conservée dans le modèle.
Prochaine action exacte : borner le profil global PAR et séparer la lecture du contenu de celle des portées ; sonder les chaînes NOA Conducteurs_Assures et les grilles Garanties, ajouter des tests positifs/négatifs, puis générer itération 24 et contrôler les cinq packages historiques.

### Itération 24 — première génération NOA ; itération 25 en cours
Moteur 0.7.0 en préparation. Rapport 24 : 236 pages, toutes rendues ; pages 1–48 inspectées. Zéro dépassement de marge automatique. Chapitre séquentiel supprimé, titres PAR et récapitulatifs dédupliqués par bloc, propriétés filtrées aux axes conditionnels. 24 paragraphes principaux ont une condition globale prouvée ; ancienne R57 = DF_RUL_pdf devient R1. Les variables de Conducteurs_Assures et 25 cibles internes sont rétablies par la variante de puce type 5. Tableaux imbriqués identifiés par compteur -108, axes et fermeture indépendants ; étendues horizontales explicites contrôlées.
Tests 24 : 82 réussis, 2 échecs dans des assertions historiques fondées sur anciens Rn / tuples d'ordre à deux éléments. Les IDs compilés et les coordonnées restent exacts ; assertions adaptées sans retirer les contrôles des plages ou de l'ordre.
Défauts observés : Rn à trois chiffres trop étroits dans les récapitulatifs ; coupures de lignes visuelles par splitInRow ; propriétés répétitives de lignes sans texte. Itération 25 : élargir Rn, rendre les repères insécables, préserver les lignes de tableaux, regrouper les propriétés strictement identiques sans perdre indices/offsets. Décodage étendu à la puce de type 2 (longueur et terminaison corroborées) et à une variante bornée de table de règles vide ; les noms de variables restent récupérables indépendamment d'une portée non décodable.
Prochaine action exacte : générer NOA 25, relancer les 84 tests et la calibration ; vérifier chaque page, puis les quatre courriers historiques et Obsèques en régression supplémentaire.

### Itération 25 — corrections de présentation ; itération 26 en cours
NOA 25 : 235 pages rendues, contrôle automatique zéro dépassement ; comparaison des passages corrigés en cours. Les lignes de tableaux sont maintenant insécables et Rn possède une largeur adaptée. Les propriétés identiques sont regroupées avec tous leurs indices et offsets ; les 29 blocs restent présents.
Les sondes des chaînes restantes démontrent les styles de puces 1–5 à longueur explicite ainsi qu'une variante de préfixe avec deux mots supplémentaires ; la première chaîne porte aussi le nombre de paragraphes, désormais contrôlé indépendamment. L'itération 26 intègre ce décodage strict et la variante de table de ciblage vide 2/1/0, sans assouplissement des bornes. L'échec résiduel des tests 25 était une troisième assertion historique utilisant R2 en dur ; elle est remplacée par la correspondance à l'ID compilé, en gardant le contrôle des frontières.
Prochaine action exacte : terminer les tests 26, générer les six rapports (NOA, quatre historiques, Obsèques), contrôler la calibration et les invariants de contenu, inspecter toutes les pages finales.

### Itération 26 — corpus généré, revue complète en cours
84 tests réussis, aucun sauté ; calibration historique 76/76. Six PDF/JSON produits sous validation/corpus6/iteration_26 : NOA 234 pages, Adhésion 167, Versement 125, FIP 170, Obsèques 118, Auto 110. Total 924 pages ; rendu intégral lancé. La nouvelle grammaire retrouve 264/265 contenus principaux NOA avec leurs portées ; le dernier conserve un contrôle apparié -252/-109 comme opaque et son répertoire de texte validé, mais ses propriétés de lien restent non interprétées. Les 113 colonnes du package sont inspectées.
Fichiers supplémentaires consultés : sondes des compteurs de tables, des pieds de grilles et préfixes de paragraphes ; spécification 01 et cahier 02 extraits ; rendus 24/25. Les demandes du 28 septembre remplacent la présentation antérieure : le chapitre séquentiel est supprimé, l'inspection interne des propriétés reste complète.
Prochaine action exacte : vérifier les invariants 0.6/0.7, inspecter les 924 pages et zooms, corriger toute coupure ou répétition de présentation encore observée, puis consigner les écarts et sauvegarder la livraison.

### Itération 26 — revue NOA terminée ; itération 27 en cours
Les 234 pages NOA 26 sont inspectées ; pas de coupure ni superposition majeure observée. Les tableaux imbriqués insécables causent des espaces libres, sans suppression de cellules. 48 invariants de contenu 0.6/0.7 passent et 27 fichiers interface/services restent identiques. Le script de comparaison a été corrigé pour la clé optionnelle repetitions absente lorsque le package ne contient aucune répétition reconnue.
La revue de la dernière page montre une ancienne mention générique « fusions non interprétées » qui ne distingue pas les nouvelles étendues horizontales bornées. Correction de ce texte de limite dans layout.py ; aucun algorithme ni donnée modifié. Itération 27 : régénérer les six modèles/PDF, relancer les tests et vérifier par empreinte d’image les pages inchangées avant toute réutilisation de leur inspection. Prochaine action exacte : terminer la revue des cinq courriers historiques, rendre les six PDF 27 et inspecter leurs pages modifiées.

### Itération 27 — terminée, livraison 0.7.0

Les 924 pages de l'itération 26 ont été inspectées via toutes les planches, sans saut. Six modèles/PDF 27 régénérés dans `validation/corpus6/iteration_27` puis intégralement rendus. 918 images sont identiques aux pages déjà inspectées ; les six différentes sont inspectées individuellement : Adhésion 167, Versement 125, FIP 170, NOA 234, Obsèques 118, Auto 109. Zooms supplémentaires NOA 2/15/39/43/46 et Obsèques 7/16. Aucun dépassement de marge, page vide, coupure ou superposition majeure observé ; texte sélectionnable, DejaVu incorporées, pagination continue. Les lignes imbriquées insécables laissent parfois de l'espace libre.

Fichiers consultés pendant la clôture : modèles et PDF 26/27 des six sources, leurs rendus, résultats pytest/calibration, modèle NOA initial, modèles 0.6.0 historiques, `before_hashes.json`, code `component_properties.py`, `scopes.py`, `layout.py`, `coverage.py`, `report_structure.py`, tests nouveaux et existants, guides 0.6.0 et profil PUB. Sources initiales inchangées, aucun Tools Report. La comparaison modèle 26/27 démontre que seul le texte de limite `unknowns` a changé.

Contrôles finaux : 84 tests passent sans saut ; 76/76 contrôles de calibration historique passent. Huit invariants pour chacun des six fichiers, soit 48, restent vrais ; aucun ancien ciblage exact perdu. 27 fichiers interface/API/services préservés par empreinte. Tests et métriques sous `work_noa/analysis/`, contenus dans l'archive de validation. Docker/Windows/PostgreSQL non exécutés.

Écarts corrigés : titres PAR, tableau Rn/nom/algorithme unique par bloc, vrais tableaux et grilles imbriquées, noms variables Conducteurs, retours internes, condition globale `DF_RUL_pdf` sur le premier titre (ancienne R57 → R1, ID 524781 inchangé), suppression du chapitre séquentiel et des commentaires internes, propriétés affichées seulement avec règle/répétition, contenu de ligne complet et réduction des duplications. Profils génériques, sans branche conditionnée par un nom de fichier métier.

Blocages conservés : NOA P17.03/text:6611819 (propriété de ciblage non encadrée) ; Adhésion P22.01/text:5023442 ; FIP text:4702030/4920764/4943885/4958948 ; Obsèques P17.02/text:4704658 ; Auto text:1252466/opcode -240 à 1254569. Origines directes non résolues : NOA 4, Adhésion 4, FIP 1, Auto 15. Les preuves et informations non interprétées restent dans les JSON et rapports. Aucun résultat déclaré conforme à tout PUB ni au rendu Exstream exact.

Livrables préparés dans `work_noa/deliverables` : code `GroupeAlterna_Exstream_Code_v0.7.0.zip`, archive `GroupeAlterna_Exstream_Validation_Corpus_v0.7.0.zip`, six PDF nommés `GroupeAlterna_<courrier>_Moteur_0.7.0_Iteration_27.pdf`, bilan, guide, ce journal et manifeste. Les archives et versions antérieures sont conservées dans l'historique.

Prochaine action exacte de reprise : lire ce résumé et `docs/VALIDATION_MOTEUR_0.7.0.md`, vérifier les empreintes des livrables, puis sonder la chaîne de propriétés de lien NOA text:6611819 autour de 6611979–6614481 avec un contrôle indépendant des bornes avant d'étendre le profil. Ne pas recommencer les 924 inspections si les images restent identiques. Pour la recette utilisateur, suivre le guide de mise à jour et analyser de nouveau les six PUB avec le moteur 0.7.0.


## Reprise du 28 septembre 2026 — itération 28 en cours, moteur 0.8.0

Base 0.7.0 isolée dans work_options/exstream-alterna ; les 88 fichiers de livraison et les sources sont préservés. Journal 0.7.0 lu avant modification. Tests de base : 84 réussis, aucun sauté. Fichiers consultés : api.py, jobs.py, db.py, export.py, render.py, report_structure.py, report_detail.py, report_inventory.py, structure.py, parser.py, compare.py, page.tsx, globals.css, tests existants et guides. Aucun AGENTS.md ni dépôt git détecté.

Demande : structure de l'application toujours en introduction ; trois chapitres finaux optionnels (valorisation, annuaire du flux, inventaire/limites), tous activés par défaut et désactivables indépendamment ; aucun téléchargement ni mention de JSON dans l'interface ou le rapport. Modèle technique interne conservé. L'interface évolue uniquement pour ces choix et libellés. Les relations de page non établies restent signalées.

Validation prévue : NOA, Versement et Obsèques pour les rapports ; toutes les combinaisons de chapitres sur fixture contrôlée ; API/worker et téléchargements anciens/nouveaux ; compilation frontend et parcours navigateur bureau/mobile. Pas de migration de base nécessaire : les options de tâche seront persistées dans les métadonnées existantes.

Prochaine action exacte : ajouter la représentation de structure avec preuves et options de rendu, propager la sélection du formulaire au worker, filtrer les livrables exposés, puis générer l'itération 28 et exécuter les tests.


### Itération 28 — générée et contrôlée ; itération 29 en cours

Moteur 0.8.0 : structure toujours en introduction ; options indépendantes propagées du formulaire au worker et au PDF ; livrables techniques internes retirés des sorties publiques, y compris pour les anciennes tâches. Les relations APP→DOC proviennent d'une liste comptée bornée, avec référence aux définitions et preuves. Le flux de sections reste distinct de la première page tant que leur affectation n'est pas démontrée.

107 tests réussis, aucun sauté ; calibration historique 76/76. Compilation Next et TypeScript réussies. Parcours navigateur bureau/mobile réussi : trois cases activées par défaut, clavier, comparaison à deux entrées conservée, analyse réelle de Versement avec annuaire seul, reprise après actualisation, PDF téléchargé et aucune sortie technique proposée. Les premières tentatives du script navigateur ont nécessité des corrections du banc (serveurs dans le même espace réseau, sélecteur d'alerte précis, URL de base), sans modification supplémentaire de l'application.

Rapports 28 sous validation/corpus3/iteration_28 : NOA 236 pages (trois chapitres), Versement 16 pages (aucun), Obsèques 110 pages (valorisation et annuaire). Les 362 pages sont rendues sous work_options/analysis/render28. Texte sélectionnable, zéro dépassement de marge, zéro page vide, aucune mention publique de format technique. NOA 1–236, Versement 1–16 et Obsèques 1–24 inspectés ; zooms NOA 1–3, 62–63. Pas de défaut majeur observé. L'introduction Obsèques laisse toutefois son plan se poursuivre seul sur une troisième page.

Prochaine correction, itération 29 : compacter les positions de la hiérarchie sur la même ligne que le type d'objet et garder ensemble le plan de l'introduction. Le modèle et le contenu métier restent identiques. Puis régénérer les trois PDF, vérifier les images inchangées avant réutilisation de la revue et inspecter toutes les pages restantes. Fichiers consultés supplémentaires : hierarchy.py, report_options.py, nouveaux tests de hiérarchie/chapitres, trois modèles et PDF 28, rendus 28, captures UI, journaux de test/compilation/calibration.


### Itération 29 — contrôlée ; itération 30 en cours

Les 107 tests passent après la compaction. Les trois modèles ont tous leurs champs préexistants identiques à 0.7.0 : seuls applications et engine_version sont ajoutés/modifiés (analysis/non_regression_070.json). Les 362 pages 28 sont désormais toutes inspectées. La génération 29 compte NOA 236, Versement 16 et Obsèques 109 pages, toutes rendues, zéro dépassement détecté. Le plan Obsèques est regroupé correctement ; le zoom NOA 29 montre toutefois la seule mention des sources repoussée sur une troisième page d'introduction.

Prochaine action exacte, itération 30 : réduire d'un point l'espacement avant/après les lignes de hiérarchie et garder la mention des sources avec le plan. Régénérer sous iteration_30 sans remplacer 28/29, relancer les tests, contrôler l'introduction de chaque rapport et vérifier par rendu les pages de contenu inchangées avant de réutiliser leur inspection. Aucun nouveau décodage métier ni modification d'interface à cette étape.


### Itération 30 — terminée, livraison 0.8.0

La hiérarchie compacte et le plan accompagné des sources tiennent sur deux pages d'introduction pour les trois rapports. NOA 235 pages, Versement 16, Obsèques 109 : 360 pages finales sous validation/corpus3/iteration_30, avec fichiers distincts de 28 et 29. Les 362 pages 28 ont toutes été inspectées ; les 354 rendus de corps de page identiques en 30 sont rapprochés par empreinte dans analysis/visual_reuse30.json. Les six pages d'introduction différentes sont inspectées individuellement. Tous les pieds de page 30 sont contrôlés séparément. Zéro dépassement, page vide ou mention de format technique public ; polices effectivement utilisées incorporées ; texte sélectionnable. Aucune coupure ni superposition importante observée.

Tests finaux : 107 réussis, aucun sauté, un avertissement de dépréciation httpx/Starlette. Calibration 76/76. Build Next standard, TypeScript et navigateur bureau/mobile réussis. Les huit combinaisons de chapitres sont couvertes en API/worker/PDF et rendu structuré. L'annuaire seul est vérifié avec une analyse Versement réelle téléchargée par navigateur. Anciennes tâches sans options compatibles, anciens liens techniques refusés. Pas de recette Docker Desktop/Windows/PostgreSQL/RQ dans cet environnement.

Fichiers consultés à la clôture : les trois modèles/PDF des itérations 28–30, les 362 rendus 28 et les 360 rendus 30, images UI bureau/mobile/résultat, résultats des tests/calibration/compilation, modèle NOA 0.7.0, code 0.7.0 isolé et scripts/guides. Les trois analyses relancées avec 0.7.0 ont les mêmes données préexistantes : seul applications est ajouté et engine_version change. Les modèles 28/29/30 sont identiques. Sources PUB et 88 fichiers de base préservés ; 68 fichiers livrés restent inchangés, 20 ont été adaptés avant ajout du guide/bilan et des nouveaux modules/tests. Aucun Tools Report ni référence PDF utilisé comme entrée moteur.

Livraison : work_options/deliverables/GroupeAlterna_Exstream_Code_v0.8.0.zip ; GroupeAlterna_Rapports_Validation_v0.8.0.zip (les trois PDF finaux) ; GroupeAlterna_Exstream_Validation_Corpus_v0.8.0.zip (preuves, modèles, rendus, tests et captures) ; guide de mise à jour, bilan et présent journal. Le ZIP code contient .env.example et les lanceurs qui créent .env pour une installation neuve ; il n'embarque aucun secret ni PUB client. Conserver le .env existant lors d'une mise à jour.

Blocages métier inchangés : rattachement exact des sections aux pages, NOA P17.03/text:6611819, Obsèques P17.02/text:4704658, origines externes/techniques et ordre global de valorisation. Les autres limites historiques sont conservées dans le bilan 0.7.0. Aucune règle, valeur, mapping ou relation non démontrée ajoutée. La sélection de chapitres est un filtre de restitution uniquement.

Prochaine action exacte : télécharger et décompresser le code 0.8.0, remplacer les fichiers du programme dans l'installation existante en conservant .env et volumes, reconstruire api/worker/purge/web puis lancer une nouvelle analyse. Pour une reprise technique ultérieure, lire ce résumé, docs/VALIDATION_MOTEUR_0.8.0.md, analysis/final_checks.json et le manifeste, vérifier les empreintes et reprendre la limite ciblée sans régénérer les résultats encore valides.
