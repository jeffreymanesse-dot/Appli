# Core Report — correctif FIP 0.12.1

Le tableau de `PAR_AFR_EPI_NSE_FDC_DEVOIR_DE_CONSEIL_ESSENCIEL_BR_notreEntretien` dans `AFR_GENERIC_FIP_DEVIS_ESSENCIEL.pub` retrouve ses trois lignes principales : en-tête, Inhumation et Crémation. Les six variables de coût occupent leur ligne et leur colonne d'origine. La note « Hors concessions, monuments et frais d'inhumation à l'étranger » reste fusionnée sous le tableau.

Le lecteur exigeait à tort un marqueur de valeur par défaut sur tous les axes. Les deux lignes de données utilisent un autre profil de propriétés ; leur rejet réduisait la grille et excluait les cellules de Crémation. Le correctif reconnaît ce profil complet et vérifie les compteurs du PUB. Il s'applique également aux composants partagés de même structure, sans sélection par nom de fichier ou de paragraphe.

## Installation existante

1. Arrêter les services et sauvegarder l'installation.
2. Décompresser `GroupeAlterna_CoreReport_Code_v0.12.1.zip` dans un dossier distinct.
3. Remplacer les fichiers du programme par ceux du dossier `exstream-alterna`, en conservant le `.env` configuré et les volumes de données.
4. Reconstruire et relancer les services depuis l'installation :

```bash
docker compose up -d --build
```

5. Lancer une nouvelle analyse du PUB FIP. Les résultats des anciennes tâches ne sont pas modifiés automatiquement.

L'archive contient le `.env` initial à marqueurs, identique à `.env.example`, destiné aux installations neuves. Aucune migration de base ni nouvelle dépendance n'est nécessaire. Pour une installation neuve, suivre `LIRE_EN_PREMIER.md`.

## Vérification

- 184 tests réussis, aucun échec ni saut, dont les tests de rendu FR/EN du tableau et de sa note sur une même page.
- Tous les 12 chemins PUB disponibles ont été pris en compte : 11 contenus distincts après déduplication SHA-256.
- 22 PDF générés, 1 889 pages contrôlées automatiquement ; aucune page vide ni texte hors page détecté.
- Les neuf pages du visuel FIP ont été inspectées, ainsi que la page du tableau dans le rapport. Le tableau corrigé est à la page PDF 3 du visuel fourni, et à la page PDF 13 du rapport complet (numéro imprimé 12).

Le ZIP de validation contient les résultats, les audits comparés à 0.12.0, les PDF et les captures. Le détail technique figure dans `docs/VALIDATION_FIP_0.12.1.md`. Les dimensions et styles déjà calibrés restent testés par la suite complète.

Cette livraison n'a pas été déployée. Aucune nouvelle recette Docker, Windows, navigateur ou PostgreSQL/RQ n'a été exécutée pour ce correctif du moteur.
