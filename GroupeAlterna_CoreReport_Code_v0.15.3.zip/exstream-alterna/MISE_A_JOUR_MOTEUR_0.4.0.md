# Mise à jour du moteur 0.4.0

L'archive contient l'application complète. L'interface, les routes de l'API,
les dépendances et la configuration Docker sont conservées.

## Installation déjà utilisée

1. Conservez une copie de votre installation actuelle et de son fichier `.env`.
2. Dans ce même dossier d'installation, remplacez le dossier `backend/retro`
   par celui de cette archive. Il comprend le nouveau fichier `scopes.py`.
   Conservez votre `.env` actuel et vos volumes Docker.
3. Depuis PowerShell, dans le dossier contenant `docker-compose.yml` :

```powershell
docker compose up -d --build api worker purge
docker compose ps
```

4. Déposez à nouveau le `.pub` et lancez une nouvelle analyse. Les rapports
   déjà créés gardent leur version précédente.

Ne relancez pas une initialisation avec un nouveau `.env` pour mettre à jour
une base existante : le mot de passe stocké dans PostgreSQL doit rester en
accord avec la configuration conservée. Ne supprimez pas les volumes.

## Installation neuve

Suivez `LIRE_EN_PREMIER.md`, puis `DEMARRER_WINDOWS.cmd`.

## Résultats et limites

49 tests réussis, calibration existante 76/76. Rapport final d'itération 12 :
41 pages rendues et inspectées. Lire `docs/ECARTS_V6.md`,
`docs/PROFIL_PORTEES_PUB.md` et `ETAT_VALIDATION_MOTEUR.md`.

Le nouveau décodage des portées est vérifié sur le Bulletin de Versement ;
la prise en charge de variantes d'autres packages reste partielle.
Docker/Windows n'ont pas pu être exécutés dans cet environnement.
