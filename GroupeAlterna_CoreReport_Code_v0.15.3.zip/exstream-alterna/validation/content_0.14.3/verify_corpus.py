from pathlib import Path
import gzip,json,hashlib,time,sys,collections
from retro.parser import analyze
from retro.schema import validate_model
from retro.binary import InvalidPackage
from retro.export import export
ROOT=Path('/workspace/scratch/eb99e680c9aa');OUT=ROOT/'analysis/content_0143'
(OUT/'models').mkdir(exist_ok=True)
rows=[]
for item in json.loads((ROOT/'analysis/order_0141/corpus.json').read_text()):
 t=time.time();row={k:item[k] for k in ('name','sha256','size')};sha=item['sha256'];path=Path(item['source'])
 assert hashlib.sha256(path.read_bytes()).hexdigest()==sha
 try:
  cache=OUT/'models'/(sha+'.json.gz')
  if '--reuse' in sys.argv and cache.exists():m=json.load(gzip.open(cache))
  else:m=analyze(path)
  from retro.content_integrity import validate_content
  m['content_integrity']=validate_content(m)
  validate_model(m)
  old=json.load(gzip.open(ROOT/'analysis/flow_0142/models'/(sha+'.json.gz')))
  before={u['id']:u for u in old['content_units']};after={u['id']:u for u in m['content_units']}
  assert before.keys()<=after.keys(), 'Lost core unit'
  assert m['document_flow']==old['document_flow'], 'Changed document flow'
  assert all(m[k]==old[k] for k in ('applications','document_order','data_sections','data_section_bindings','rule_catalog_audit','object_compositions')), 'Changed preserved structures'
  assert m['definitions']==old['definitions'] and m['mappings']==old['mappings'], 'Changed source facts'
  assert [(r['compiled_id'],r['variants'])for r in m['rules']]==[(r['compiled_id'],r['variants'])for r in old['rules']], 'Changed algorithms/names'
  recovered=[u for u in m['content_units'] if u['id'] not in before]
  old_tokens={(u['id'],p['offset']):p for u in old['content_units'] for p in u['parts']}
  corrected=[]
  for u in m['content_units']:
   for p in u['parts']:
    if p['kind']=='variable' and old_tokens.get((u['id'],p['offset']),{}).get('kind')!='variable':
     corrected.append({'content_id':u['id'],'paragraph_id':u.get('parent_id'),'offset':p['offset'],'variable':p.get('variable_name',p['text']),'design_value':p.get('design_value'),'was_known_unit':u['id'] in before})
  prior_p={p['id']:p for p in old['paragraphs']};empty_fixed=[p['name']for p in m['paragraphs']if p['id'] in m['document_paragraph_ids'] and not prior_p.get(p['id'],{}).get('content_ids') and any(any(t['text'].strip()for t in after[i]['parts'])for i in p['content_ids'])]
  oldvis={u['id']:u for u in old['visual']['content_units']};newvis={u['id']:u for u in m['visual']['content_units']}
  assert oldvis.keys()<=newvis.keys(), 'Lost visual unit '+str(oldvis.keys()-newvis.keys())
  row.update(status='analyzed',source_facts_preserved=True,old_units=len(before),new_units=len(after),added_units=len(recovered),added_nonempty=sum(any(p['text'].strip()for p in u['parts'])for u in recovered),restored_paragraphs=empty_fixed,corrected_variables=corrected,content_integrity=m['content_integrity'],scope_issues=m['coverage']['scope_issues'],recovery_failures=m['content_recovery']['uninterpreted_candidates'],old_visual_units=len(oldvis),new_visual_units=len(newvis))
  with gzip.open(cache,'wt')as f:json.dump(m,f,ensure_ascii=False)
  if '--export' in sys.argv:
   d=OUT/'pdfs'/sha;export(m,d)
   stats=json.loads((d/'rapport.json').read_text())['visual_validation']
   row['visual_validation']={k:stats[k] for k in ('pages','units_source','units_rendered','missing','duplicate_placements','occurrence_errors')}
 except InvalidPackage as exc:
  assert not (ROOT/'analysis/flow_0142/models'/(sha+'.json.gz')).exists(), 'New rejection: '+str(exc)
  row.update(status='rejected',reason=str(exc))
 row['seconds']=round(time.time()-t,2);rows.append(row)
 (OUT/'comparison.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2))
 print(row['name'],row['status'],'added',row.get('added_units'),'titles',len(row.get('restored_paragraphs',[])),'variables',len(row.get('corrected_variables',[])),row['seconds'],flush=True)
