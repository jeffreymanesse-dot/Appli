from pathlib import Path
import json,gzip,fitz,collections
from PIL import Image,ImageDraw
from retro.document_flow import paragraph_occurrences
ROOT=Path('/workspace/scratch/eb99e680c9aa');OUT=ROOT/'analysis/content_0143';QA=OUT/'pdf_review';QA.mkdir(exist_ok=True)
checks=[]
for row in json.loads((OUT/'comparison.json').read_text()):
 if row['status']!='analyzed':continue
 d=OUT/'pdfs'/row['sha256'];m=json.loads((d/'rapport.json').read_text());r={'name':row['name'],'sha256':row['sha256']}
 for kind in ('rapport','visuel'):
  doc=fitz.open(d/(kind+'.pdf'));outside=[];empty=[]
  for i,p in enumerate(doc):
   blocks=p.get_text('blocks');top=70 if kind=='rapport' else 30
   if any(x0< -1 or y0< -1 or x1>p.rect.width+1 or y1>p.rect.height+1 for x0,y0,x1,y1,*_ in blocks):outside.append(i+1)
   if not any(top<(y0+y1)/2<775 for x0,y0,x1,y1,t,*_ in blocks if t.strip()):empty.append(i+1)
  r[kind]={'pages':len(doc),'outside_page_bounds':outside,'empty_body_pages':empty}
  assert not outside and not empty,(row['name'],kind,outside,empty)
  if 'WEBLURE' not in row['name']:continue
  texts=[''.join(p.get_text().split())for p in doc];joined=''.join(texts)
  if kind=='rapport':
   title='1.Vuecomplètedescontenusrattachés';start=joined.index(title,joined.index(title)+len(title))+len(title)
   end=joined.index('2.Tablesetrépétitions',start);body=joined[start:end]
   ps={p['id']:p for p in m['paragraphs']};us={u['id']:u for u in m['content_units']};occs=paragraph_occurrences(m);positions=[];cursor=0
   for o in occs:
    name=''.join(ps[o['source_id']]['name'].split());pos=body.find(name,cursor);assert pos>=0,o
    positions.append(pos);cursor=pos+len(name)
   pp=[]
   for i,o in enumerate(occs):
    snippet=body[positions[i]:positions[i+1] if i+1<len(positions)else len(body)]
    pid=o['source_id'];p=ps[pid]
    if 'Titre' in p['name']:
     literal=[''.join(t['text'].split())for uid in p['content_ids']for t in us[uid]['parts']if t['kind']=='text' and t['text'].strip()]
     assert all(t in snippet for t in literal),(p['name'],'missing title')
    if pid=='21:27810':
     assert 'DF_FIC_SD_SIMURENTE_SIMBYPRODUCT_annuityEffectiveDate' in snippet and '03/08/2008' not in snippet
    pp.append(next(j+1 for j in range(len(texts))if sum(map(len,texts[:j+1]))>start+positions[i]))
   for i in range(1,len(occs)):
    if occs[i]['source_document_id']!=occs[i-1]['source_document_id']:assert pp[i]>pp[i-1]
   for cid in (574465,574466,577090):assert 'IDcompilé'+str(cid)in joined
   r['title_checks']='all decoded title fragments present; sample replaced by variable'
   r['paragraph_occurrences']=len(positions)
   r['document_start_pages']={d['name']:pp[next(i for i,o in enumerate(occs)if o['source_document_id']==d['id'])]for d in m['documents']}
   r['table_occurrences']=sum(o['source_id']=='21:27644'for o in occs);assert r['table_occurrences']==2
   zooms=sorted({1,*r['document_start_pages'].values(),*[pp[i]for i,o in enumerate(occs)if 'Titre' in ps[o['source_id']]['name']]})
  else:zooms=[1,2,5,8,10,13,len(doc)]
  for start in range(0,len(doc),12):
   tw,th=260,370;sheet=Image.new('RGB',(tw*3,(th+24)*4),'#e5e5e5');draw=ImageDraw.Draw(sheet)
   for k,n in enumerate(range(start,min(start+12,len(doc)))):
    pix=doc[n].get_pixmap(matrix=fitz.Matrix(.48,.48),alpha=False);im=Image.frombytes('RGB',(pix.width,pix.height),pix.samples);im.thumbnail((tw,th));x=k%3*tw;y=k//3*(th+24)
    sheet.paste(im,(x+(tw-im.width)//2,y+24));draw.text((x+8,y+5),f'{kind} - {n+1}',fill='black')
   sheet.save(QA/f'{kind}_{start+1:03d}.jpg',quality=85)
  for n in zooms:
   if n<=len(doc):doc[n-1].get_pixmap(matrix=fitz.Matrix(1.2,1.2),alpha=False).save(QA/f'zoom_{kind}_{n:03d}.png')
 checks.append(r)
 print(row['name'],r['rapport']['pages'],r['visuel']['pages'],flush=True)
(OUT/'pdf_checks.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2))
