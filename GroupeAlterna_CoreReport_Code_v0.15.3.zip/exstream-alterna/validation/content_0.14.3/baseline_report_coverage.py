"""Instrument the unmodified 0.14.2 report builder; never infer rendered omissions from inventory counts."""
from pathlib import Path
import gzip,json,collections
from retro import report_structure,visual_render
ROOT=Path('/workspace/scratch/eb99e680c9aa');records=[];captured=[]
Base=visual_render.VisualRenderer
class Spy(Base):
 def __init__(self,*args,**kwargs):super().__init__(*args,**kwargs);captured.append(self)
visual_render.VisualRenderer=Spy
report_structure.build_with_cover=lambda *args,**kwargs:None
for p in sorted((ROOT/'analysis/flow_0142/models').glob('*.gz')):
 m=json.load(gzip.open(p));captured.clear()
 report_structure.report_structure(m,ROOT/'analysis/content_0143/unused.pdf',chapters=[])
 renderer=captured[0];placed=set(renderer.PLACED);main=set(m['document_paragraph_ids']);ps={p['id']:p['name']for p in m['paragraphs']}
 omitted=[{'id':u['id'],'paragraph':ps[u['parent_id']],'text':u['text']}for u in m['visual']['content_units']if u.get('parent_id') in main and u['id']not in placed and any(t['text'].strip()for t in u['parts'])]
 records.append({'sha256':m['metadata']['sha256'],'name':m['metadata']['source_name'],'omitted_nonempty_units':omitted})
 print(m['metadata']['source_name'],len(omitted),flush=True)
(ROOT/'analysis/content_0143/baseline_report_coverage.json').write_text(json.dumps(records,ensure_ascii=False,indent=2))
