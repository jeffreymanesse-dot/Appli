from pathlib import Path
import gzip,json,hashlib

ROOT=Path('/workspace/scratch/eb99e680c9aa/analysis/order_0141')
before=json.loads((ROOT/'before/summary.json').read_text());after=json.loads((ROOT/'after/summary.json').read_text())
assert len(before)==len(after)==14
after={x['sha256']:x for x in after}
EDITORIAL={'document_id','document_rule_id'}
def scrub(x):
    if isinstance(x,dict):return {k:scrub(v) for k,v in x.items() if k not in EDITORIAL}
    if isinstance(x,list):return [scrub(v) for v in x]
    return x
def invariant_model(m):
    m=scrub(m)
    for k in ('engine_version','document_order','document_paragraph_ids','unresolved_document_paragraph_ids','document_rule_ids'):m.pop(k,None)
    m['documents']=sorted(m['documents'],key=lambda d:d['id'])
    m['visual'].pop('document_paragraph_ids',None)
    return m
def digest(x):return hashlib.sha256(json.dumps(x,ensure_ascii=False,sort_keys=True).encode()).hexdigest()
def differences(a,b,path='',out=None):
    if out is None:out=[]
    if len(out)>=40:return out
    if type(a)!=type(b):out.append(path+' [type]')
    elif isinstance(a,dict):
        for k in sorted(a.keys()|b.keys()):
            if k not in a or k not in b:out.append(path+'/'+k+' [key]')
            else:differences(a[k],b[k],path+'/'+k,out)
    elif isinstance(a,list):
        if len(a)!=len(b):out.append(path+' [length]')
        for i,(x,y) in enumerate(zip(a,b)):differences(x,y,path+'/'+str(i),out)
    elif a!=b:out.append(path)
    return out
result=[]
for old in before:
    new=after[old['sha256']];r={k:old[k] for k in ('name','sha256','aliases')}
    assert old['status']==new['status']
    r['status']=new['status']
    if old['status']=='rejected':
        r.update(reason=new['reason'],same_rejection=old['reason']==new['reason']);result.append(r);continue
    with gzip.open(ROOT/'before'/(old['sha256']+'.json.gz'),'rt')as f:a=json.load(f)
    with gzip.open(ROOT/'after'/(old['sha256']+'.json.gz'),'rt')as f:b=json.load(f)
    x,y=invariant_model(a),invariant_model(b)
    r.update(before_documents=old['documents'],after_documents=new['documents'],
             document_order_changed=old['documents']!=new['documents'],
             paragraph_order_changed=old['paragraphs']!=new['paragraphs'],
             visual_order_changed=old['visual_paragraphs']!=new['visual_paragraphs'],
             content_membership_preserved=set(old['paragraphs'])==set(new['paragraphs']),
             rule_membership_preserved=set(a['document_rule_ids'])==set(b['document_rule_ids']),
             unresolved_references_preserved=sorted(a['unresolved_document_paragraph_ids'])==sorted(b['unresolved_document_paragraph_ids']),
             invariant_hash_before=digest(x),invariant_hash_after=digest(y),invariants_equal=x==y,
             unexpected_differences=differences(x,y) if x!=y else [],counts=new['counts'],
             order_status=new.get('document_order',{}).get('status'))
    r['field_checks']={k:x.get(k)==y.get(k) for k in ('definitions','variables','mappings','rules','calculations','content_units','paragraphs','tables','repetitions','document_sections','documents','structural_edges','data_sections','data_section_bindings','coverage','visual')}
    result.append(r)
    print(r['name'],'order_changed='+str(r['document_order_changed']),'invariants='+str(r['invariants_equal']),r['unexpected_differences'],flush=True)
(ROOT/'comparison.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
assert all(r.get('invariants_equal',True) and r.get('same_rejection',True) and r.get('content_membership_preserved',True) and r.get('rule_membership_preserved',True) for r in result)
