from pathlib import Path
import gzip,hashlib,json,sys,time
from retro.parser import analyze
from retro.schema import validate_model
from retro.binary import InvalidPackage
from retro.hierarchy import hierarchy_rows
from retro.visual_render import VisualRenderer

ROOT=Path('/workspace/scratch/eb99e680c9aa')
out=ROOT/'analysis/order_0141'/sys.argv[1];out.mkdir(exist_ok=True)
summary=[]
for item in json.loads((ROOT/'analysis/order_0141/corpus.json').read_text()):
    start=time.time();path=Path(item['source']);row=dict(item)
    assert hashlib.sha256(path.read_bytes()).hexdigest()==item['sha256']
    try:
        m=analyze(path);validate_model(m)
        with gzip.open(out/(item['sha256']+'.json.gz'),'wt',encoding='utf-8') as f:json.dump(m,f,ensure_ascii=False,sort_keys=True)
        names={d['id']:d['name'] for d in m['definitions']}
        kept,removed=VisualRenderer(m['visual']).projection()
        row.update(status='analyzed',engine_version=m['engine_version'],
                   documents=[d['name'] for d in m['documents']],
                   applications=[{'id':a['id'],'status':a['relation_status'],'documents':[names[d] for d in a['document_ids']]} for a in m['applications']],
                   paragraphs=m['document_paragraph_ids'],visual_paragraphs=m['visual']['document_paragraph_ids'],
                   projected_paragraphs=kept,projected_removed=removed,
                   hierarchy_documents=[r['name'] for r in hierarchy_rows(m) if r['kind']=='Document'],
                   document_order=m.get('document_order'),
                   counts={k:len(m.get(k,[])) for k in ['rules','variables','mappings','content_units','tables','repetitions','data_sections','data_section_bindings']})
    except InvalidPackage as e:row.update(status='rejected',reason=str(e))
    row['seconds']=round(time.time()-start,2);summary.append(row)
    (out/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
    print(item['name'],row['status'],row['seconds'],row.get('documents',row.get('reason')),flush=True)
