from pathlib import Path
import gzip,json,hashlib,time,sys
from retro.parser import analyze
from retro.schema import validate_model
from retro.binary import InvalidPackage
from retro.document_flow import paragraph_occurrences
from retro.visual_render import VisualRenderer
from retro.export import export

ROOT=Path('/workspace/scratch/eb99e680c9aa');OUT=ROOT/'analysis/flow_0142'
(OUT/'models').mkdir(exist_ok=True);(OUT/'visuals').mkdir(exist_ok=True)
old_summary={x['sha256']:x for x in json.loads((ROOT/'analysis/order_0141/after/summary.json').read_text())}
results=[]
for item in json.loads((ROOT/'analysis/order_0141/corpus.json').read_text()):
    row={k:item[k] for k in ('name','sha256','size')};start=time.time()
    assert hashlib.sha256(Path(item['source']).read_bytes()).hexdigest()==item['sha256']
    try:
        cached=OUT/'models'/(item['sha256']+'.json.gz')
        if '--reuse-models' in sys.argv and cached.exists():
            with gzip.open(cached,'rt') as f:model=json.load(f)
        else:model=analyze(item['source'])
        validate_model(model)
        with gzip.open(ROOT/'analysis/order_0141/after'/(item['sha256']+'.json.gz'),'rt') as f:old=json.load(f)
        before=json.loads(json.dumps(old));after=json.loads(json.dumps(model))
        after.pop('document_flow');after['visual'].pop('document_flow')
        after['engine_version']=before['engine_version']
        assert after==before,'Unexpected source-model change: '+item['name']
        with gzip.open(OUT/'models'/(item['sha256']+'.json.gz'),'wt',encoding='utf-8') as f:json.dump(model,f,ensure_ascii=False)
        occurrences=paragraph_occurrences(model);renderer=VisualRenderer(model['visual']);kept,removed=renderer.occurrence_projection()
        old_projection=old_summary[item['sha256']]['projected_paragraphs']
        is_web=item['sha256'].startswith('45ff5ce4')
        if is_web:
            dest=OUT/'weblure';export(model,dest)
            generated=json.loads((dest/'rapport.json').read_text());stats=generated['visual_validation']
            for name,kind in [('rapport','Rapport'),('visuel','Visuel')]:
                (dest/(name+'.pdf')).replace(ROOT/f'deliverables_flow_0142/GroupeAlterna_WEBLURE_{kind}_CoreReport_0.14.2.pdf')
        else:stats=renderer.render(OUT/'visuals'/(item['sha256']+'.pdf'))
        row.update(status='analyzed',source_model_unchanged=True,
            unique_paragraphs=len(model['document_paragraph_ids']),paragraph_occurrences=len(occurrences),
            report_sequence_changed=[p['source_id'] for p in occurrences]!=model['document_paragraph_ids'],
            visual_sequence_changed=[p['source_id'] for p in kept]!=old_projection,
            visual_occurrences_before=len(old_projection),visual_occurrences_after=len(kept),
            repeated_occurrences=[p for p in occurrences if sum(q['source_id']==p['source_id'] for q in occurrences)>1],
            document_ids=[d['id'] for d in model['documents']],
            visual_stats={k:stats[k] for k in ('pages','units_source','units_rendered','unit_occurrences_rendered','missing','duplicate_placements','occurrence_errors','split_rows','long_paragraphs')})
    except InvalidPackage as e:
        assert old_summary[item['sha256']]['status']=='rejected'
        assert old_summary[item['sha256']]['reason']==str(e)
        row.update(status='rejected',same_rejection=True,reason=str(e))
    row['seconds']=round(time.time()-start,2);results.append(row)
    (OUT/'comparison.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
    print(row['name'],row['status'],row.get('paragraph_occurrences'),row.get('visual_occurrences_before'),row.get('visual_occurrences_after'),row['seconds'],flush=True)
assert len(results)==14
