from pathlib import Path
import fitz,gzip,json
from PIL import Image,ImageDraw
from retro.document_flow import paragraph_occurrences

ROOT=Path('/workspace/scratch/eb99e680c9aa');OUT=ROOT/'analysis/flow_0142'
QA=OUT/'pdf_review';QA.mkdir(exist_ok=True)
model=json.loads((OUT/'weblure/rapport.json').read_text())
paragraphs={p['id']:p for p in model['paragraphs']};occ=paragraph_occurrences(model)
checks={}
for kind in ('Rapport','Visuel'):
    pdf=fitz.open(ROOT/f'deliverables_flow_0142/GroupeAlterna_WEBLURE_{kind}_CoreReport_0.14.2.pdf')
    texts=[''.join(p.get_text().split()) for p in pdf];joined=''.join(texts)
    bounds=[];empty=[]
    for i,page in enumerate(pdf):
        blocks=page.get_text('blocks')
        if any(x0< -1 or y0< -1 or x1>page.rect.width+1 or y1>page.rect.height+1 for x0,y0,x1,y1,*_ in blocks):bounds.append(i+1)
        # Ignore the ordinary footer/header; a page with only furniture is empty.
        top=70 if kind=='Rapport' else 30
        if not any(top<(y0+y1)/2<775 for x0,y0,x1,y1,text,*_ in blocks if text.strip()):empty.append(i+1)
    c={'pages':len(pdf),'empty_body_pages':empty,'outside_page_bounds':bounds}
    if kind=='Rapport':
        chapter='1.Vuecomplètedescontenusrattachés';start=joined.index(chapter,joined.index(chapter)+len(chapter))+len(chapter)
        body=joined[start:].split('2.Tablesetrépétitions',1)[0];cursor=0;positions=[]
        for o in occ:
            name=''.join(paragraphs[o['source_id']]['name'].split());pos=body.find(name,cursor)
            assert pos>=0,('Missing occurrence',o)
            positions.append(start+pos);cursor=pos+len(name)
        def page_at(position):
            boundary=0
            for i,t in enumerate(texts):
                boundary+=len(t)
                if position<boundary:return i+1
        c['paragraph_occurrences_verified']=len(positions)
        c['table_occurrences_in_body']=body.count('PAR_AFR_EPI_WEBLURE_TABLE')
        c['table_after_beneficiary']=body.index('PAR_AFR_EPI_WEBLURE_TABLE',body.index('PAR_WEBLURE_Simul_Rente_Benef_Nom'))>body.index('PAR_WEBLURE_Simul_Rente_Benef_Nom')
        c['document_start_pages']={d['name']:page_at(positions[next(i for i,o in enumerate(occ) if o['source_document_id']==d['id'])]) for d in model['documents']}
        c['table_pages']=[page_at(positions[i]) for i,o in enumerate(occ) if o['source_id']=='21:27644']
        for i in range(1,len(occ)):
            if occ[i]['source_document_id']!=occ[i-1]['source_document_id']:assert page_at(positions[i])>page_at(positions[i-1])
        assert c['table_occurrences_in_body']==2
        zooms=sorted({1,7,*c['document_start_pages'].values(),*c['table_pages']})
    else:zooms=[1,2,4,5,7,8,10,12]
    assert not bounds and not empty,c
    checks[kind]=c
    for start in range(0,len(pdf),12):
        tw,th=260,370;sheet=Image.new('RGB',(tw*3,(th+24)*4),'#E5E5E5');draw=ImageDraw.Draw(sheet)
        for k,n in enumerate(range(start,min(start+12,len(pdf)))):
            pix=pdf[n].get_pixmap(matrix=fitz.Matrix(.48,.48),alpha=False)
            im=Image.frombytes('RGB',(pix.width,pix.height),pix.samples);im.thumbnail((tw,th))
            x=k%3*tw;y=k//3*(th+24);sheet.paste(im,(x+(tw-im.width)//2,y+24));draw.text((x+8,y+5),f'{kind} - page {n+1}',fill='black')
        sheet.save(QA/f'{kind}_{start+1:03d}_{min(start+12,len(pdf)):03d}.jpg',quality=86)
    for n in zooms:
        if n<=len(pdf):pdf[n-1].get_pixmap(matrix=fitz.Matrix(1.15,1.15),alpha=False).save(QA/f'zoom_{kind}_{n}.png')
checks['visual_coverage']={k:model['visual_validation'][k] for k in ('pages','units_source','units_rendered','unit_occurrences_rendered','missing','duplicate_placements','occurrence_errors','split_rows','long_paragraphs')}
(OUT/'pdf_checks.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2))
print(json.dumps(checks,ensure_ascii=False,indent=2))
