# Mise à jour du moteur 0.3.0

L'archive contient l'application complète. L'interface et le contrat de téléchargement sont conservés.

Pour mettre à jour une installation existante :
1. Conserver une copie du dossier actuel et son fichier `.env`.
2. Copier le dossier `backend/retro` de cette archive dans l'installation, avec les nouveaux fichiers `layout.py`, `provenance.py`, `report_structure.py`. Ne pas supprimer les fichiers de configuration ou les volumes Docker.
3. Depuis le dossier de l'application, reconstruire les services Python : `docker compose up -d --build api worker purge`.
4. Déposer à nouveau le PUB et lancer une nouvelle analyse : les anciens rapports restent des résultats de leur ancienne version.

Pour une installation neuve, suivre `LIRE_EN_PREMIER.md` et `DEMARRER_WINDOWS.cmd`.

Les dépendances Python n'ont pas changé. Docker n'a pas été exécuté dans l'environnement de développement de cette révision. Le rapport livré reste partiel ; consulter `docs/ECARTS_V6.md`.
