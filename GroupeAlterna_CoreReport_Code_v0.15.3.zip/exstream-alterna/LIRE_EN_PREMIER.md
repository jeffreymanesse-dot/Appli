# Livraison 0.15.3

Lire `MISE_A_JOUR_LECTURE_0.15.3.md`. Le chapitre 4 précise le Compute Time des Formula et inclut les formules déclenchées par événement, dont initPage. Le Visuel est allégé et les tableaux sans trait source disposent d’un contour gris léger. `DEMARRER_WINDOWS.cmd` attend cinq secondes avant d’ouvrir le navigateur. Conserver `.env` et les volumes, reconstruire les services puis lancer une nouvelle analyse.

# Livraison 0.15.2

Règles des images, contenus de signature, types et propriétés de lignes, ancrages de tableaux et entrées DOCUMENT/PAGE/SECTION corrigés par des lecteurs génériques. Rapport allégé et tableaux de lignes fusionnés. Lire `MISE_A_JOUR_PROPRIETES_0.15.2.md` et `docs/VALIDATION_PROPRIETES_0.15.2.md`. Conserver `.env` et les volumes, reconstruire les services puis lancer une nouvelle analyse.

# Livraison 0.15.1

Le PDF **Visuel du courrier** ne contient plus la section « Pages, composants et débordements ». L’annexe **Template et Page** reste disponible dans le rapport principal. Lire `MISE_A_JOUR_VISUEL_0.15.1.md` et `docs/VALIDATION_VISUEL_0.15.1.md`. Conserver `.env` et les volumes, reconstruire les services puis lancer une nouvelle analyse.

# Version 0.15.0

Lire `MISE_A_JOUR_TEMPLATE_PAGE_0.15.0.md`. La case **Template et Page** ajoute l’annexe en fin de rapport. Conserver `.env` et les volumes, reconstruire l’API, le worker et l’interface, puis lancer une nouvelle analyse. Les tâches et PDF existants gardent leurs choix antérieurs.

## Version 0.14.9

Lire `MISE_A_JOUR_PRESENTATION_0.14.9.md` et `docs/VALIDATION_PRESENTATION_0.14.9.md`. Conserver `.env` et les volumes, reconstruire notamment l'API et le worker, puis lancer une nouvelle analyse du PUB. Les PDF existants ne sont pas recalculés automatiquement.

## Version 0.14.8

Lire `MISE_A_JOUR_LOGIC_0.14.8.md` et `docs/VALIDATION_LOGIC_0.14.8.md`. Conserver `.env` et les volumes, reconstruire les services, puis lancer une nouvelle analyse du PUB.

## Version 0.14.7

Lire `MISE_A_JOUR_SOURCES_0.14.7.md` et `docs/VALIDATION_SOURCES_0.14.7.md`. Conserver `.env` et les volumes, reconstruire pour installer les dépendances, puis lancer une nouvelle analyse du PUB.

## Version 0.14.6

Lire `MISE_A_JOUR_RAPPORT_0.14.6.md` et `docs/VALIDATION_RAPPORT_0.14.6.md`. Conserver `.env` et les volumes, reconstruire, puis lancer une nouvelle analyse pour obtenir le rapport corrigé.

## Version 0.14.5

Lire `MISE_A_JOUR_VARIABLES_SYSTEME_0.14.5.md` et `docs/VALIDATION_VARIABLES_SYSTEME_0.14.5.md`. Conserver `.env` et les volumes, reconstruire, puis créer une nouvelle analyse.

## Historique 0.14.4

Consulter `MISE_A_JOUR_CONTENUS_0.14.4.md` puis `docs/VALIDATION_CONTENUS_0.14.4.md`.

# Livraison 0.14.4

Lire `MISE_A_JOUR_CONTENUS_0.14.4.md` et `docs/VALIDATION_CONTENUS_0.14.4.md`.

# Mise à jour 0.14.2

Lire `MISE_A_JOUR_FLUX_0.14.2.md`, conserver `.env` et les volumes, puis créer une nouvelle analyse.

# Mise à jour 0.14.1

Lire `MISE_A_JOUR_ORDRE_0.14.1.md`, conserver `.env` et les volumes, puis créer une nouvelle analyse.

# Mise à jour 0.14.0

Lire `MISE_A_JOUR_DATA_SECTIONS_0.14.0.md`, conserver `.env` et les volumes, puis relancer une nouvelle analyse.

# Lancer l'application sur votre ordinateur

Pour mettre à jour une installation existante, suivre `MISE_A_JOUR_CORE_REPORT_0.11.0.md` et conserver son `.env`.

## Windows — Docker Desktop

1. Installez **Docker Desktop**, activez son moteur WSL2 et démarrez-le.
2. Décompressez entièrement l'archive dans un dossier, par exemple `C:\Alterna\exstream-alterna`.
3. Lancez **DEMARRER_WINDOWS.cmd**. Ce script crée les secrets locaux, construit les services et ouvre le navigateur.
4. L'application est disponible à **http://localhost:3000**. Le premier démarrage nécessite Internet pour télécharger les dépendances et les images Docker ; les fichiers .pub restent traités localement.
5. Déposez vos propres fichiers `.pub` dans l'interface. En analyse, cochez les chapitres complémentaires souhaités (les quatre sont activés par défaut). La structure de l’application apparaît toujours en introduction. Deux PDF sont produits : rétro-documentation et visuel du courrier.

Pour arrêter : **ARRETER_WINDOWS.cmd**. Vos volumes sont conservés. Ne lancez pas `docker compose down -v` si vous souhaitez les conserver.

Le lanceur corrigé n'utilise pas PowerShell et ne change aucune politique d'exécution Windows. Il utilise Docker pour générer la configuration avec le script Python fourni ; Python n'a pas besoin d'être installé sur Windows. Le conteneur de préparation n'a pas de réseau.

**Limite de vérification :** Docker Desktop et Windows ne sont pas disponibles dans l'environnement de création. Le lanceur a été contrôlé, mais son exécution sur Windows reste à vérifier sur votre poste.

## Linux ou WSL2 — sans Docker

Prérequis : Python 3.12+, Node.js 22+ avec npm, et polices DejaVu (`fonts-dejavu-core` sous Debian/Ubuntu).

Dans le dossier `exstream-alterna` :

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r backend/requirements-dev.txt
npm --prefix frontend ci
python scripts/init_env.py
bash scripts/dev.sh
```

Ouvrez **http://localhost:3000**. Conservez le terminal ouvert ; `Ctrl+C` arrête le lancement local. Les ports 3000 et 8000 doivent être disponibles.

## Docker — commandes manuelles

Avec Python installé et Docker démarré :

```bash
python scripts/init_env.py
docker compose up --build -d
```

Ouvrez **http://localhost:3000**. Pour consulter les messages : `docker compose logs --tail=100`. Pour arrêter : `docker compose down`.

## Ce que contient l'archive

Code Next.js/React/TypeScript, API Python/FastAPI, Core Report 0.15.3, worker, configuration PostgreSQL/RQ/Redis, `.env` initial à personnaliser automatiquement, `.env.example`, scripts de lancement, tests, documentation, état de reprise, schéma interne, logo authentique et charte Groupe Alterna. Les dépendances sont installées au premier lancement à partir des manifestes et du lock npm.

Les fichiers client `.pub`, les secrets de développement, les dépendances préinstallées et les données temporaires ne sont pas inclus. Ils ne sont pas nécessaires pour installer le programme ; sélectionnez ensuite les `.pub` depuis votre poste.

## Limite fonctionnelle importante

Le moteur reste **expérimental et partiel** : extraction de structures, variables, mappings et règles, rapports PDF personnalisables, comparaison de versions. Le second PDF restitue les contenus et propriétés graphiques décodés. La fidélité complète au rendu Exstream (pagination, placement, ressources externes et arrondis) n’est pas validée. Aucun XSD n'est inventé. La session de développement n'est pas une intégration SSO de production.

Les drapeaux FR/EN de l’en-tête sélectionnent la langue de l’interface et des futurs rapports. Le contenu du `.pub` conserve sa langue d’origine.

Détails actuels : `docs/VALIDATION_MOTEUR_0.9.0.md` et `ETAT_VALIDATION_MOTEUR.md`. `docs/ECARTS_VALIDATION.md` conserve l'état historique de la livraison initiale.
