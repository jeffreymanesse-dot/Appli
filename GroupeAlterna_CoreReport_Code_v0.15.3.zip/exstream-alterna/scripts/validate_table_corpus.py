"""Validate every PUB in supplied folders, deduplicating by bytes, never by name.

PYTHONPATH=backend python scripts/validate_table_corpus.py --source-dir DIR \
    --source-dir OTHER --output-dir EMPTY --baseline-backend OLD/backend
Each analysis runs in a separate process. No customer package is redistributed.
"""
import argparse, hashlib, json, os, subprocess, sys
from pathlib import Path


def digest(value):
    return hashlib.sha256(json.dumps(value,ensure_ascii=False,sort_keys=True).encode()).hexdigest()


def semantic_hashes(model):
    excluded={'engine_version','visual','table_style_profile','table_style_coverage'}
    out={k:digest(v) for k,v in model.items() if k not in excluded and k!='tables'}
    out['tables']=digest([{k:v for k,v in t.items() if k not in ('presentation','uninterpreted_properties')}
                          for t in model['tables']])
    return out


def worker(source, output, baseline=False):
    from retro.parser import analyze
    from retro.schema import validate_model
    model=analyze(source);validate_model(model)
    output.mkdir(parents=True,exist_ok=True)
    result={'source':str(source),'sha256':model['metadata']['sha256'],
            'engine_version':model['engine_version'],'semantic_hashes':semantic_hashes(model),
            'analysis_status':model['analysis_status'],'coverage':model['coverage']}
    if not baseline:
        import fitz
        from retro.render import report
        from retro.export import check_pdf
        from retro.visual_render import VisualRenderer
        report(model,output/'rapport.pdf')
        result['visual_validation']=VisualRenderer(model['visual']).render(output/'visuel.pdf')
        result['table_style_coverage']=model['table_style_coverage']
        audit={'source':result['source'],'sha256':result['sha256'],'profile':model['table_style_profile'],
               'tables':{t['id']:t['presentation'] for t in model['tables']},
               'visual_tables':model['visual']['graphics']['table_styles']}
        (output/'table_styles.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2))
        result['pdf_checks']={}
        for name in ('rapport.pdf','visuel.pdf'):
            file=output/name;check_pdf(file);doc=fitz.open(file)
            empty=[];overflow=[]
            for i,page in enumerate(doc):
                if not page.get_text().strip():empty.append(i+1)
                for b in page.get_text('blocks'):
                    x0,y0,x1,y1=b[:4]
                    if x0 < -1 or y0 < -1 or x1>page.rect.width+1 or y1>page.rect.height+1:
                        overflow.append(i+1);break
            result['pdf_checks'][name]={'pages':len(doc),'empty_pages':empty,'text_outside_page':overflow,
                                      'sha256':hashlib.sha256(file.read_bytes()).hexdigest()}
            doc.close()
            if empty or overflow:raise ValueError(f'PDF bounds check failed: {name} {empty} {overflow}')
    (output/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
    return result


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--source-dir',type=Path,action='append',default=[])
    ap.add_argument('--output-dir',type=Path,required=True)
    ap.add_argument('--baseline-backend',type=Path)
    ap.add_argument('--worker-source',type=Path);ap.add_argument('--baseline',action='store_true')
    args=ap.parse_args()
    if args.worker_source:
        worker(args.worker_source,args.output_dir,args.baseline);return
    if args.output_dir.exists() and any(args.output_dir.iterdir()):ap.error('Choose a new, empty output directory')
    files=sorted({p.resolve() for d in args.source_dir for p in d.rglob('*') if p.is_file() and p.suffix.lower()=='.pub'})
    if not files:ap.error('No PUB files found')
    groups={}
    for path in files:groups.setdefault(hashlib.sha256(path.read_bytes()).hexdigest(),[]).append(path)
    args.output_dir.mkdir(parents=True,exist_ok=True)
    summary={'files_found':len(files),'unique_packages':len(groups),'results':[]}
    failures=[]
    for n,(sha,aliases) in enumerate(groups.items(),1):
        source=aliases[0];dest=args.output_dir/(f'{n:02d}_'+source.stem)
        dest.mkdir();row={'source':source.name,'aliases':[str(p) for p in aliases],'sha256':sha}
        command=[sys.executable,str(Path(__file__).resolve()),'--worker-source',str(source),'--output-dir',str(dest)]
        print(f'[{n}/{len(groups)}] {source.name}',flush=True)
        with (dest/'run.log').open('w') as log:
            code=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT).returncode
        row['success']=code==0
        if code==0:
            row.update(json.loads((dest/'result.json').read_text()))
            if args.baseline_backend:
                old=dest/'baseline';env={**os.environ,'PYTHONPATH':str(args.baseline_backend.resolve())}
                with (dest/'baseline.log').open('w') as log:
                    code=subprocess.run(command[:-1]+[str(old),'--baseline'],env=env,stdout=log,stderr=subprocess.STDOUT).returncode
                if code==0:
                    prior=json.loads((old/'result.json').read_text())
                    changed=[k for k,v in prior['semantic_hashes'].items() if row['semantic_hashes'].get(k)!=v]
                    row['baseline_semantic_changes']=changed;row['success']=not changed
                else:row['success']=False;row['baseline_error']=code
        if not row['success']:failures.append(source.name)
        summary['results'].append(row)
        summary['failures']=failures
        (args.output_dir/'corpus_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
    print(json.dumps({'files_found':len(files),'unique_packages':len(groups),'failures':failures}),flush=True)
    if failures:raise SystemExit(1)

if __name__=='__main__':main()
