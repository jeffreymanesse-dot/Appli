"""Repeatable corpus calibration, without a reference PDF as engine input.

Usage: PYTHONPATH=backend python scripts/validate_corpus.py --source-dir DIR --output-dir NEW_DIR
Choose a new output directory for every iteration. Raw customer packages are not bundled.
"""
import argparse,json
from pathlib import Path
from retro import __version__
from retro.parser import analyze
from retro.export import export

FILES=('AFR_EPI_NOE_BULLETIN_ADHESION.pub','AFR_EPI_NOE_BULLETIN_VERSEMENT.pub',
       'AFR_GENERIC_FIP_DEVIS_ESSENCIEL.pub','AFR_IARD_DEVIS_AUTO.pub')

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--source-dir',type=Path,required=True);ap.add_argument('--output-dir',type=Path,required=True)
    ap.add_argument('--include-obseques',action='store_true',help='Ajouter le cas de régression Obsèques aux quatre courriers historiques.')
    ap.add_argument('--extra-pub',action='append',default=[],help='Nom exact d’un PUB supplémentaire ; option répétable.')
    args=ap.parse_args()
    if args.output_dir.exists() and any(args.output_dir.iterdir()):ap.error('Choisir un dossier de sortie vide pour préserver les itérations précédentes.')
    inputs=[]
    for name in dict.fromkeys(FILES+(('AFR_GENERIC_PROJET_OBSEQUES_ESSENCIEL.pub',) if args.include_obseques else ())+tuple(args.extra_pub)):
        found=list(args.source_dir.glob('*'+name))
        if len(found)!=1:ap.error(f'Source absente ou ambiguë : {name}')
        inputs.append((name,found[0]))
    args.output_dir.mkdir(parents=True,exist_ok=True);results=[]
    for name,path in inputs:
        m=analyze(path,name);target=args.output_dir/Path(name).stem;outputs=export(m,target)
        results.append({'source':name,'sha256':m['metadata']['sha256'],'engine_version':__version__,
            'analysis_status':m['analysis_status'],'coverage':m['coverage'],'structure_issues':m.get('structure_issues',[]),
            'document_rules':len(m['document_rule_ids']),'repetitions':[{k:r[k] for k in ('document_id','axis','driver_internal_id','driver_name','table_id')} for r in m.get('repetitions',[])],
            'outputs':outputs})
    (args.output_dir/'calibration_corpus.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')
    print(f'{len(results)} analyses produites. Vérifier les limites du JSON et inspecter les PDF ; ce contrôle ne vaut pas certification métier.')

if __name__=='__main__':main()
