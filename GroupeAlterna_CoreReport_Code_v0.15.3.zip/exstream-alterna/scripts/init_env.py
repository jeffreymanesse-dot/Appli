"""Crée uniquement les secrets manquants des placeholders fournis."""
from pathlib import Path
import secrets
root=Path(__file__).resolve().parents[1]
p=root/'.env'
s=p.read_text() if p.exists() else (root/'.env.example').read_text()
for token in ('REPLACE_WITH_AT_LEAST_32_RANDOM_CHARACTERS','REPLACE_WITH_RANDOM_PASSWORD'):
    s=s.replace(token,secrets.token_hex(32))
p.write_text(s);p.chmod(0o600)
print('Configuration locale prête. Aucun secret affiché.')
