"""Compare with 0.14.6 and prove native source bytes before rendering reports."""
import argparse
import copy
import gzip
import hashlib
import json
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'backend'))
from retro.parser import analyze
from retro.schema import validate_model
from retro.source_archive import original_bytes
from retro.design_source import source_available


SOURCE_FIELDS={'source_expression','source_ast','incomplete','condition_readable',
    'effect_true','effect_false','false_effect_origin','interpretation','decoded_expression','design_condition'}


def projection(model):
    m=json.loads(json.dumps(model));m.pop('engine_version',None)
    for r in m['rules']:
        for v in r['variants']:
            for key in SOURCE_FIELDS:v.pop(key,None)
            v['evidence']=[e for e in v['evidence'] if e.get('decoder')!='OBS-rule-source-u32-v1']
    for c in m['calculations']:
        c.pop('source_expression',None)
        c['evidence']=[e for e in c['evidence'] if e.get('decoder')!='OBS-formula-source-u32-v1']
    for v in m['variables']:
        for site in v.get('valuation_sites',[]):
            site.pop('algorithm_source',None)
            site['evidence']=[e for e in site.get('evidence',[]) if e.get('decoder')!='OBS-formula-source-u32-v1']
    return m


def audit(old,model,data):
    before,after=projection(old),projection(model)
    # A newly recovered condition enriches existing scope evidence. Check the
    # precise addition rather than masking unrelated association differences.
    enriched={r['compiled_id']:r for r in model['rules'] if any(
        v.get('source_expression') and not ov.get('source_expression')
        for v,ov in zip(r['variants'],next(o for o in old['rules'] if o['compiled_id']==r['compiled_id'])['variants']))}
    scope_annotations=[]
    def scopes(a,b,path=''):
        if isinstance(a,dict) and isinstance(b,dict):
            if b.get('rule_id') in enriched and a.get('confidence')!=b.get('confidence'):
                rule=enriched[b['rule_id']]
                assert a['confidence']=='TRÈS PROBABLE' and b['confidence']=='CERTAIN',path
                assert b['evidence']==a['evidence']+[e for v in rule['variants'] for e in v['evidence']],path
                assert b['confidence_reason']==a['confidence_reason'].replace('Identité/condition de règle encore partielle ; ','Nom, condition et ID concordants ; '),path
                scope_annotations.append(path)
                for field in ('evidence','confidence','confidence_reason'):b[field]=copy.deepcopy(a[field])
            for k in a.keys()&b.keys():scopes(a[k],b[k],path+'.'+k)
        elif isinstance(a,list) and isinstance(b,list):
            for i,(x,y) in enumerate(zip(a,b)):scopes(x,y,path+'.'+str(i))
    scopes(before,after)
    differences=[k for k in before.keys()|after.keys() if before.get(k)!=after.get(k)]
    assert not differences,differences
    sources=[];restored=[];parameter_rules=[];bytecode=0
    old_items={('rule',r['compiled_id'],i):v for r in old['rules'] for i,v in enumerate(r['variants'])}
    old_items.update({('calculation',c['id'],0):c for c in old['calculations']})
    items=[(('rule',r['compiled_id'],i),v) for r in model['rules'] for i,v in enumerate(r['variants'])]
    items += [(('calculation',c['id'],0),c) for c in model['calculations']]
    for key,item in items:
        compiled=item.get('compiled_code',item.get('source_code'))
        assert compiled==old_items[key].get('compiled_code',old_items[key].get('source_code'))
        raw=compiled.encode('latin1');assert data[item['offset']:item['offset']+len(raw)]==raw
        bytecode+=1
        if old_items[key].get('source_expression'):assert item.get('source_expression'),key
        if item.get('source_expression'):
            raw=original_bytes(item);assert raw is not None,key
            ev=next(e for e in item['evidence'] if e.get('decoder') in ('OBS-rule-source-u32-v1','OBS-formula-source-u32-v1'))
            assert data[ev['offset_start']:ev['offset_end']]==raw,key
            sources.append({'owner':key,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'printable':source_available(item)})
            if not old_items[key].get('source_expression'):restored.append(key)
        if item.get('design_condition'):
            d=item['design_condition'];ev=d['evidence'][0]
            assert hashlib.sha256(data[ev['offset_start']:ev['offset_end']]).hexdigest()==ev['sha256']
            parameter_rules.append(key)
    return {'model_unchanged_except_native_source_annotations':True,'compiled_algorithms_unchanged':bytecode,
            'scope_annotations_enriched':scope_annotations,
            'native_sources':sources,'newly_recovered_sources':restored,'parameter_rules':parameter_rules}


def main():
    parser=argparse.ArgumentParser()
    for name in ('corpus','source-root','baseline-models','output','save-models'):parser.add_argument('--'+name,type=Path,required=True)
    args=parser.parse_args();results=[]
    args.save_models.mkdir(parents=True,exist_ok=True);args.output.parent.mkdir(parents=True,exist_ok=True)
    rows=json.loads(args.corpus.read_text())
    for i,row in enumerate(rows,1):
        print(f'[{i}/{len(rows)}] {row["name"]}',flush=True)
        p=args.source_root/row['source'];data=p.read_bytes();assert hashlib.sha256(data).hexdigest()==row['sha256']
        model=analyze(p);validate_model(model)
        old=json.load(gzip.open(args.baseline_models/(row['sha256']+'.json.gz'),'rt'))
        result={'source':row['source'],'sha256':row['sha256'],**audit(old,model,data)}
        results.append(result)
        with gzip.open(args.save_models/(row['sha256']+'.json.gz'),'wt',encoding='utf8') as stream:json.dump(model,stream,ensure_ascii=False)
        args.output.write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n')
        print(' PASS; restored sources:',len(result['newly_recovered_sources']),flush=True)


if __name__=='__main__':main()
