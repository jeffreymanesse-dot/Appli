#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
if [ ! -f .env ]; then echo 'Copiez .env.example vers .env et configurez APP_SIGNING_KEY.'; exit 1; fi
set -a
source .env
set +a
export PYTHONPATH="$PWD/backend" NEXT_TELEMETRY_DISABLED=1
python -m uvicorn retro.api:app --host 127.0.0.1 --port 8000 --no-access-log & api_pid=$!
python -m retro.worker & worker_pid=$!
npm --prefix frontend run dev & web_pid=$!
trap 'kill "$api_pid" "$worker_pid" "$web_pid" 2>/dev/null || true' EXIT INT TERM
wait
