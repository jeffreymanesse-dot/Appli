"""Audit the full corpus against 0.14.5, including every stored rule algorithm."""
import argparse
import gzip
import hashlib
import json
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'backend'))
from retro.parser import analyze
from retro.schema import validate_model
from retro.rule_labels import rule_algorithms


def canonical(value):
    if isinstance(value,dict):return {str(k):canonical(v) for k,v in value.items()}
    if isinstance(value,(tuple,list)):return [canonical(v) for v in value]
    return value


def digest(value):
    return hashlib.sha256(json.dumps(canonical(value),ensure_ascii=False,sort_keys=True).encode()).hexdigest()


def compare(baseline,model):
    before=canonical(baseline);after=canonical(model)
    additions=[]
    for current,old in ((after,before),(after['visual'],before['visual'])):
        base={c['id']:c for c in old.get('object_compositions',[])}
        new={c['id']:c for c in current.get('object_compositions',[])}
        assert all(new.get(key)==value for key,value in base.items()),'An existing composition changed'
        additions.extend(c['paragraph_id'] for key,c in new.items() if key not in base)
        current['object_compositions']=old.get('object_compositions',[])
    after.pop('campaigns',None)
    for app in after.get('applications',[]):
        app.pop('campaign_ids',None);app.pop('campaign_reference_status',None)
    after['engine_version']=before['engine_version']
    changed=[k for k in sorted(set(after)|set(before)) if after.get(k)!=before.get(k)]
    assert not changed,changed
    return {'preexisting_model_unchanged':True,'semantic_sha256':digest(before),
            'new_graphic_owners':list(dict.fromkeys(additions))}


def rule_audit(model,data):
    rows=[]
    for rule in model['rules']:
        for variant in rule['variants']:
            code=variant['compiled_code'].encode('latin1');start=variant['offset']
            assert data[start:start+len(code)]==code
            source=variant.get('source_expression')
            if source:
                ev=next(e for e in variant['evidence'] if e['decoder']=='OBS-rule-source-u32-v1')
                assert data[ev['offset_start']:ev['offset_end']].decode('latin1')==source
            rows.append({'rule':rule['document_id'],'compiled_id':rule['compiled_id'],
                'source_script_available':bool(source),'compiled_sha256':hashlib.sha256(code).hexdigest(),
                'displayed_algorithm_sha256':hashlib.sha256((source or variant['compiled_code']).encode('latin1')).hexdigest()})
        assert all(code in [v.get('source_expression') or v['compiled_code'] for v in rule['variants']]
                   for label,code in rule_algorithms(rule))
    return rows


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--corpus',type=Path,required=True);p.add_argument('--source-root',type=Path,required=True)
    p.add_argument('--baseline-models',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    p.add_argument('--save-models',type=Path,required=True)
    args=p.parse_args();rows=json.loads(args.corpus.read_text());result={'packages':[]}
    args.output.parent.mkdir(parents=True,exist_ok=True);args.save_models.mkdir(parents=True,exist_ok=True)
    for i,row in enumerate(rows,1):
        source=args.source_root/row['source'];print(f'[{i}/{len(rows)}] {source.name}',flush=True)
        data=source.read_bytes();assert hashlib.sha256(data).hexdigest()==row['sha256']
        model=analyze(source);validate_model(model)
        baseline=json.load(gzip.open(args.baseline_models/(row['sha256']+'.json.gz'),'rt'))
        stats=compare(baseline,model);audit=rule_audit(model,data)
        result['packages'].append({'source':row['source'],'sha256':row['sha256'],**stats,
            'campaigns':[{k:c[k] for k in ('id','name','message_ids')} for c in model['campaigns']],
            'rule_variants_audited':len(audit),'rules':audit})
        with gzip.open(args.save_models/(row['sha256']+'.json.gz'),'wt',encoding='utf8') as f:json.dump(model,f,ensure_ascii=False)
        args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
        print(f'  PASS; {len(audit)} rule variants unchanged and source-verified',flush=True)
    print(f'PASS: {len(rows)} packages',flush=True)


if __name__=='__main__':main()
