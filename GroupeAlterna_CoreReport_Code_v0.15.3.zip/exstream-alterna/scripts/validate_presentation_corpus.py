"""Compare source facts and audit table/typography presentation against an older engine.

Unlike an exact model comparison, this permits row topology corrections only
when old axes/cells are preserved and extra rows carry the recognised profile.
Input PUBs are never modified or copied into the output folder.
"""
import argparse, hashlib, json, os, struct, subprocess, sys
from pathlib import Path
from validate_table_corpus import digest


def facts(model):
    out={k:digest(model[k]) for k in ('metadata','sources','definitions','inventory','strings',
         'mappings','calculations','input_dictionary','xsd')}
    out['variable_declarations']=digest([{k:v for k,v in x.items() if k not in ('usage_evidence','valuation_sites')}
                                          for x in model['variables']])
    out['rule_algorithms']=digest({r['compiled_id']:r['variants'] for r in model['rules']})
    out['texts_and_variables']=digest({u['id']:{k:u.get(k) for k in ('parts','serialized_parts','variable_names')}
                                        for u in model['content_units']})
    keys=('rule_id','kind','token_slices','target_fragment_text','rule_reference_offset','owner_record_offset','scope_open_offset')
    out['internal_rule_targets']=digest({u['id']:[{k:t.get(k) for k in keys} for t in u.get('rule_targets',[])]
                                         for u in model['content_units']})
    return out


def topology(model,data):
    out={}
    for t in model['tables']:
        out[t['id']]={'rows':[r['offset'] for r in t['rows']], 'columns':[c['offset'] for c in t['columns']],
            'styled_rows':[r['offset'] for r in t['rows'] if any(e['decoder']=='OBS-styled-row-axis-v2' for e in r['evidence'])],
            'cells':[[c['row'],c['column'],c['offset'],c.get('content_id'),c.get('nested_table_id')] for c in t['cells']]}
        for c in t['cells']:
            assert struct.unpack_from('<II',data,c['offset']+8)==(c['column'],c['row'])
    return out


def worker(source,output,baseline):
    from retro.parser import analyze
    from retro.schema import validate_model
    model=analyze(source);validate_model(model);data=source.read_bytes();output.mkdir(parents=True,exist_ok=True)
    result={'source':str(source),'sha256':model['metadata']['sha256'],'engine_version':model['engine_version'],
            'facts':facts(model),'topology':topology(model,data),
            'visual_contents':{u['id']:digest(u['parts']) for u in model['visual']['content_units']}}
    if not baseline:
        from retro.render import report
        from retro.visual_render import VisualRenderer
        from retro.export import check_pdf
        import fitz
        report(model,output/'rapport.pdf')
        result['visual_validation']=VisualRenderer(model['visual']).render(output/'visuel.pdf')
        result['coverage']=model['coverage'];result['table_style_coverage']=model['table_style_coverage']
        result['object_compositions']=[{'id':c['id'],'paragraph_id':c['paragraph_id'],'objects':len(c['objects']),
            'tables':sum(o['kind']=='compiled_table' for o in c['objects']), 'image_resources':c['image_resources']} for c in model.get('object_compositions',[])]
        (output/'object_compositions.json').write_text(json.dumps(model.get('object_compositions',[]),ensure_ascii=False,indent=2))
        from collections import Counter
        graphics=model['visual']['graphics']
        result['presentation_summary']={'anchored_tables':[{'id':t['id'],**t['inline_anchor']} for t in model['tables'] if t.get('inline_anchor')],
            'alignment_counts':dict(Counter(p.get('alignment','uninterpreted') for gx in graphics['units'].values() for p in gx.get('paragraphs',[]))),
            'source_font_names':sorted({f['name'] for gx in graphics['units'].values() for f in gx.get('fonts',[])}),
            'inline_breaks':sum(len(gx.get('inline_breaks',[])) for gx in graphics['units'].values()),
            'raised_callouts':sum(len(gx.get('superscript_spans',[])) for gx in graphics['units'].values()),'visual_style_coverage':graphics['table_style_coverage']}
        (output/'typography.json').write_text(json.dumps({'fonts':graphics['fonts'],'units':graphics['units']},ensure_ascii=False,indent=2))
        result['pdf_checks']={}
        for name in ('rapport.pdf','visuel.pdf'):
            check_pdf(output/name)
            with fitz.open(output/name) as pdf:
                empty=[];overflow=[]
                for i,p in enumerate(pdf):
                    if not p.get_text().strip():empty.append(i+1)
                    if any(b[0]<-1 or b[1]<-1 or b[2]>p.rect.width+1 or b[3]>p.rect.height+1 for b in p.get_text('blocks')):overflow.append(i+1)
                result['pdf_checks'][name]={'pages':len(pdf),'empty_pages':empty,'text_outside_page':overflow}
                assert not empty and not overflow
        audit={'sha256':result['sha256'],'tables':model['tables'],'visual_tables':model['visual']['tables'],'visual_table_styles':graphics['table_styles']}
        (output/'tables.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2))
    (output/'audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))


def compare(old,new):
    changed_facts=[k for k,v in old['facts'].items() if v!=new['facts'].get(k)]
    assert not changed_facts, f'Source facts changed: {changed_facts}'
    lost=[uid for uid,value in old['visual_contents'].items() if new['visual_contents'].get(uid)!=value]
    assert not lost, f'Previous visual text lost or altered: {lost}'
    before,after=old['topology'],new['topology']
    assert set(before)==set(after), 'Table set changed unexpectedly'
    changes=[]
    for tid,a in before.items():
        b=after[tid]
        if a==b:continue
        assert a['columns']==b['columns'],(tid,'Columns changed')
        assert all(r in b['rows'] for r in a['rows']),(tid,'Old row lost')
        added=[r for r in b['rows'] if r not in a['rows']]
        assert added and all(r in b['styled_rows'] for r in added),(tid,'Unexplained topology change')
        assert all(c in b['cells'] for c in a['cells']),(tid,'Old cell lost or moved')
        changes.append({'table_id':tid,'rows_before':len(a['rows']),'rows_after':len(b['rows']),
                        'new_row_offsets':added,'cells_added':[c for c in b['cells'] if c not in a['cells']]})
    stats=new['visual_validation']
    assert not any(stats[k] for k in ('missing','duplicate_placements','split_rows','long_paragraphs'))
    return changes


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--source-dir',type=Path,action='append',default=[])
    ap.add_argument('--output-dir',type=Path,required=True);ap.add_argument('--baseline-backend',type=Path)
    ap.add_argument('--worker-source',type=Path);ap.add_argument('--baseline',action='store_true')
    args=ap.parse_args()
    if args.worker_source:worker(args.worker_source,args.output_dir,args.baseline);return
    if not args.baseline_backend:ap.error('A baseline backend is required')
    if args.output_dir.exists() and any(args.output_dir.iterdir()):ap.error('Choose an empty output directory')
    files=sorted({p.resolve() for root in args.source_dir for p in root.rglob('*') if p.is_file() and p.suffix.lower()=='.pub'})
    if not files:ap.error('No PUB files found')
    groups={}
    for p in files:groups.setdefault(hashlib.sha256(p.read_bytes()).hexdigest(),[]).append(p)
    args.output_dir.mkdir(parents=True,exist_ok=True)
    result={'files_found':len(files),'unique_packages':len(groups),'results':[],'failures':[]}
    for n,(sha,paths) in enumerate(groups.items(),1):
        source=paths[0];dest=args.output_dir/(f'{n:02d}_'+source.stem);dest.mkdir()
        item={'source':source.name,'sha256':sha,'aliases':[str(p) for p in paths],'success':False}
        print(f'[{n}/{len(groups)}] {source.name}',flush=True)
        try:
            for baseline in (True,False):
                target=dest/'baseline' if baseline else dest
                command=[sys.executable,str(Path(__file__).resolve()),'--worker-source',str(source),'--output-dir',str(target)]
                env=os.environ.copy()
                if baseline:command.append('--baseline');env['PYTHONPATH']=str(args.baseline_backend.resolve())
                with (dest/('baseline.log' if baseline else 'run.log')).open('w') as log:
                    subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
            old=json.loads((dest/'baseline/audit.json').read_text());new=json.loads((dest/'audit.json').read_text())
            item['corrections']=compare(old,new);item['source_facts_unchanged']=True
            item['pdf_checks']=new['pdf_checks'];item['presentation_summary']=new['presentation_summary'];item['success']=True
        except (AssertionError,subprocess.CalledProcessError) as e:
            item['error']=str(e);result['failures'].append(source.name)
        result['results'].append(item)
        (args.output_dir/'regression_summary.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
    print(json.dumps({'unique_packages':len(groups),'failures':result['failures']}),flush=True)
    if result['failures']:raise SystemExit(1)

if __name__=='__main__':main()
