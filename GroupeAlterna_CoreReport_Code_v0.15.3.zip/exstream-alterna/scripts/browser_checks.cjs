// Optional end-to-end test. Run from the project root with the application started.
// Install Playwright locally first; set PUB_TEST_PATH to an authorized real package.
const { chromium } = require('playwright');
const fs = require('fs');
(async () => {
  if (!process.env.PUB_TEST_PATH) throw new Error('Set PUB_TEST_PATH to your local .pub file');
  const out=process.env.UI_TEST_OUTPUT || 'validation/ui';
  fs.mkdirSync(out, {recursive:true});
  const browser = await chromium.launch({headless:true,
    ...(process.env.CHROME_BIN ? {executablePath:process.env.CHROME_BIN,args:['--no-sandbox','--disable-dev-shm-usage']} : {})});
  try {
    const page = await browser.newPage({baseURL:process.env.APP_TEST_URL || 'http://localhost:3000',viewport:{width:1440,height:1100},reducedMotion:'reduce'});
    const errors=[];page.on('pageerror',e=>errors.push(e.message));
    await page.goto(process.env.APP_TEST_URL || 'http://localhost:3000',{waitUntil:'networkidle'});
    const options=page.getByRole('checkbox');
    if(await options.count()!==3) throw new Error('Three chapter options expected');
    for(let i=0;i<3;i++) if(!await options.nth(i).isChecked()) throw new Error('Default chapter missing');
    if(/json/i.test(await page.locator('body').innerText())) throw new Error('Technical output mentioned');
    await page.screenshot({path:out+'/desktop.png',fullPage:true});
    await page.keyboard.press('Tab');
    if (!(await page.evaluate(()=>document.activeElement.textContent)).includes('Aller au contenu')) throw new Error('Missing keyboard skip link');
    await page.getByRole('button',{name:'Comparer deux versions',exact:true}).click();
    if(await options.count() || await page.locator('input[type=file]').count()!==2) throw new Error('Comparison controls changed');
    await page.screenshot({path:out+'/comparison.png',fullPage:true});
    await page.getByRole('button',{name:'Analyser un fichier',exact:true}).click();
    await page.getByRole('checkbox',{name:'Valorisation et origine des variables',exact:true}).uncheck();
    await page.getByRole('checkbox',{name:'Inventaire et limites de reconstruction',exact:true}).uncheck();
    await page.getByRole('checkbox',{name:'Annuaire des données du flux',exact:true}).focus();
    await page.keyboard.press('Space');
    if(await options.nth(1).isChecked()) throw new Error('Keyboard toggle failed');
    await page.keyboard.press('Space');
    await page.locator('input[type=file]').setInputFiles({name:'invalid.txt',mimeType:'text/plain',buffer:Buffer.from('invalid')});
    await page.getByRole('alert').filter({hasText:'Sélectionnez un fichier Exstream'}).waitFor();
    await page.locator('input[type=file]').setInputFiles(process.env.PUB_TEST_PATH);
    const posted=page.waitForResponse(r=>r.url().endsWith('/api/jobs') && r.request().method()==='POST');
    await page.getByRole('button',{name:'Lancer l’analyse',exact:true}).click();
    const accepted=await posted;if(accepted.status()!==202) throw new Error('Submission failed');
    const jid=(await accepted.json()).id;
    await page.locator('.job-id').waitFor();
    await page.reload({waitUntil:'networkidle'});
    await page.getByRole('heading',{name:'Analyse terminée',exact:true}).waitFor({timeout:120000});
    const status=await (await page.request.get('/api/jobs/'+jid)).json();
    if(JSON.stringify(status.summary.report_chapters)!==JSON.stringify(['input_dictionary'])) throw new Error('Selection not persisted');
    await page.getByRole('button',{name:'Préparer les téléchargements'}).click();
    await page.getByRole('link',{name:'PDF · Rétro-documentation',exact:true}).waitFor();
    if(await page.locator('.downloads a').count()!==2) throw new Error('Two PDF downloads expected');
    if(/json/i.test(await page.locator('body').innerText())) throw new Error('Technical output mentioned in result');
    for (const [label,file] of [['PDF · Rétro-documentation','rapport_annuaire_seul.pdf'],['PDF · Visuel du courrier','visuel.pdf']]) {
      const download=await page.request.get(await page.getByRole('link',{name:label,exact:true}).getAttribute('href'));
      const bytes=await download.body();
      if(!download.ok() || !bytes.subarray(0,4).equals(Buffer.from('%PDF'))) throw new Error('Download is not a PDF');
      fs.writeFileSync(out+'/'+file,bytes);
    }
    await page.setViewportSize({width:390,height:844});
    if(await page.evaluate(()=>document.documentElement.scrollWidth>window.innerWidth)) throw new Error('Mobile result overflow');
    await page.screenshot({path:out+'/mobile_result.png',fullPage:true});
    await page.setViewportSize({width:1440,height:1100});
    await page.screenshot({path:out+'/result.png',fullPage:true});
    await page.getByRole('button',{name:/Nouvelle analyse/}).click();
    await page.setViewportSize({width:390,height:844});
    if(await page.evaluate(()=>document.documentElement.scrollWidth>window.innerWidth)) throw new Error('Mobile overflow');
    if(await options.count()!==3 || !await options.nth(1).isChecked()) throw new Error('Mobile options lost');
    await page.screenshot({path:out+'/mobile.png',fullPage:true});
    if(errors.length) throw new Error(errors.join('\n'));
    const result={success:true,desktop:[1440,1100],mobile:[390,844],keyboard:true,default_all:true,
      compare_controls:true,refresh_resumed:true,chapters:status.summary.report_chapters,
      pdf_downloads:2,public_json:false,mobile_overflow:false,page_errors:errors};
    fs.writeFileSync(out+'/browser.json',JSON.stringify(result,null,2));
    console.log(JSON.stringify(result));
  } finally {await browser.close();}
})().catch(e=>{console.error(e.message);process.exit(1);});
