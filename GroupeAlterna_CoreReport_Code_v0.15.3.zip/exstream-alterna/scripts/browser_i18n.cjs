// End-to-end locale checks against a running local app. No external services.
const {chromium}=require('playwright');const fs=require('fs');
(async()=>{
 const out=process.env.UI_TEST_OUTPUT||'validation/i18n_ui';fs.mkdirSync(out,{recursive:true});
 const executablePath=process.env.CHROME_BIN;
 const browser=await chromium.launch({headless:true,...(executablePath?{executablePath,args:['--no-sandbox','--disable-dev-shm-usage']}: {})});
 try{
  const page=await browser.newPage({baseURL:process.env.APP_TEST_URL||'http://localhost:3000',viewport:{width:1440,height:1100},reducedMotion:'reduce'});
  const errors=[];page.on('pageerror',e=>errors.push(e.message));
  await page.goto('/',{waitUntil:'networkidle'});
  if(await page.locator('html').getAttribute('lang')!=='fr')throw Error('French default missing');
  await page.screenshot({path:out+'/desktop_fr.png',fullPage:true});
  await page.keyboard.press('Tab');if(!(await page.locator(':focus').innerText()).includes('Aller au contenu'))throw Error('Skip link');
  await page.getByRole('button',{name:'English',exact:true}).focus();await page.keyboard.press('Enter');
  await page.getByRole('button',{name:'Analyse a file',exact:true}).waitFor();
  if(await page.locator('html').getAttribute('lang')!=='en')throw Error('Page language not updated');
  await page.reload({waitUntil:'networkidle'});
  await page.getByRole('button',{name:'Analyse a file',exact:true}).waitFor();
  await page.screenshot({path:out+'/desktop_en.png',fullPage:true});
  await page.getByRole('button',{name:'Compare two versions',exact:true}).click();
  if(await page.locator('input[type=file]').count()!==2)throw Error('Comparison inputs');
  await page.screenshot({path:out+'/compare_en.png',fullPage:true});
  await page.getByRole('button',{name:'Analyse a file',exact:true}).click();
  await page.getByRole('checkbox',{name:'Variable assignment and origins',exact:true}).uncheck();
  await page.getByRole('checkbox',{name:'Inventory and reconstruction limitations',exact:true}).uncheck();
  await page.locator('input[type=file]').setInputFiles({name:'bad.txt',mimeType:'text/plain',buffer:Buffer.from('bad')});
  await page.getByRole('alert').filter({hasText:'Select an Exstream .pub file.'}).waitFor();
  await page.getByRole('button',{name:'Français',exact:true}).click();
  await page.getByRole('alert').filter({hasText:'Sélectionnez un fichier Exstream'}).waitFor();
  await page.locator('input[type=file]').setInputFiles(process.env.PUB_TEST_PATH);
  const filename=await page.locator('.filename').innerText();
  await page.getByRole('button',{name:'English',exact:true}).click();
  if(await page.locator('.filename').innerText()!==filename)throw Error('File lost on locale switch');
  if(await page.getByRole('checkbox',{name:'Variable assignment and origins',exact:true}).isChecked())throw Error('Options lost');
  await page.setViewportSize({width:390,height:844});
  if(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth))throw Error('Mobile EN overflow');
  await page.screenshot({path:out+'/mobile_en.png',fullPage:true});
  const accepted=page.waitForResponse(r=>r.url().endsWith('/api/jobs')&&r.request().method()==='POST');
  await page.getByRole('button',{name:'Start analysis',exact:true}).click();
  const response=await accepted;if(response.status()!==202)throw Error('Upload failed '+await response.text());
  const jid=(await response.json()).id;
  await page.getByRole('button',{name:'Français',exact:true}).click();
  await page.reload({waitUntil:'networkidle'});
  await page.getByRole('heading',{name:'Analyse terminée',exact:true}).waitFor({timeout:120000});
  const status=await(await page.request.get('/api/jobs/'+jid)).json();
  if(status.report_language!=='en'||JSON.stringify(status.summary.report_chapters)!=='["input_dictionary"]')throw Error('Job locale/options changed');
  if(!(await page.locator('.job').innerText()).includes('Relancez une analyse'))throw Error('Existing PDF language not explained');
  await page.getByRole('button',{name:'Préparer les téléchargements',exact:true}).click();
  await page.locator('.downloads a').first().waitFor();
  for(const [label,file]of [['PDF · Rétro-documentation','rapport_en.pdf'],['PDF · Visuel du courrier','visuel_en.pdf']]){
   const response=await page.request.get(await page.getByRole('link',{name:label,exact:true}).getAttribute('href'));
   const bytes=await response.body();if(!bytes.subarray(0,4).equals(Buffer.from('%PDF'))||response.headers()['content-language']!=='en')throw Error('Download language');
   fs.writeFileSync(out+'/'+file,bytes);
  }
  if(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth))throw Error('Mobile FR result overflow');
  await page.screenshot({path:out+'/mobile_fr_result.png',fullPage:true});
  await page.setViewportSize({width:1440,height:1100});
  await page.getByRole('button',{name:'English',exact:true}).click();
  await page.screenshot({path:out+'/desktop_en_result.png',fullPage:true});
  if(/json/i.test(await page.locator('body').innerText()))throw Error('Internal format exposed');
  if(errors.length)throw Error(errors.join('\n'));
  fs.writeFileSync(out+'/browser_result.json',JSON.stringify({success:true,default_fr:true,preference_restored:true,keyboard:true,selection_preserved:true,report_language_frozen:true,refresh:true,downloaded_pdfs:2,desktop:true,mobile:true,page_errors:errors},null,2));
  console.log('Browser FR/EN, desktop/mobile, keyboard, refresh, real upload and two downloads: PASS');
 }finally{await browser.close();}
})().catch(e=>{console.error(e.stack);process.exit(1)});
