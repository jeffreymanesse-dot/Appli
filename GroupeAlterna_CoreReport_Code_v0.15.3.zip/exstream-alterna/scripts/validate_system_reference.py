"""Regression audit against cached baseline models; no client files are bundled.

Use --corpus pointing to an array of {source, sha256}, --source-root for relative
paths, --baseline-models for SHA256.json.gz models, and --output for evidence.
"""
import argparse
from collections import Counter
import gzip
import hashlib
import json
from pathlib import Path
import re
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'backend'))
from retro.parser import analyze
from retro.schema import validate_model
from retro.system_variables import CATALOG

ANNOTATIONS = {'system_variable', 'system_variable_details', 'system_variable_catalog'}


def canonical(value):
    if isinstance(value, dict):
        # JSON caches stringify numeric keys (notably visual rule dictionaries).
        return {str(k): canonical(v) for k, v in value.items() if k not in ANNOTATIONS | {'engine_version'}}
    if isinstance(value, (list, tuple)):
        return [canonical(v) for v in value]
    return value


def digest(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True,
                                    separators=(',', ':')).encode()).hexdigest()


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--corpus', type=Path, required=True)
    p.add_argument('--source-root', type=Path, required=True)
    p.add_argument('--baseline-models', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--reference-text', type=Path)
    p.add_argument('--save-models', type=Path)
    args = p.parse_args()
    result = {'packages': []}
    if args.reference_text:
        extracted = Counter((page, n) for page, text in enumerate(args.reference_text.read_text().split('\f'), 1)
                            for n in re.findall(r'^[ \t]{0,4}(SYS_\w+)[ \t]{2,}', text, re.M))
        catalog = Counter((x['pdf_page'], n) for n, e in CATALOG.items() for x in e['source_occurrences'])
        assert extracted == catalog, (extracted - catalog, catalog - extracted)
        result['reference'] = {'exact_table_names_and_pages': True, 'table_rows': sum(extracted.values()),
                               'distinct_table_names': len({n for _, n in extracted})}
    sources = json.loads(args.corpus.read_text())
    for i, row in enumerate(sources, 1):
        source = args.source_root / row['source']
        print(f'[{i}/{len(sources)}] {source.name}', flush=True)
        assert hashlib.sha256(source.read_bytes()).hexdigest() == row['sha256']
        model = analyze(source)
        validate_model(model)
        with gzip.open(args.baseline_models / (row['sha256'] + '.json.gz'), 'rt') as f:
            baseline = json.load(f)
        before = canonical(baseline); after = canonical(model)
        changes = [key for key in sorted(set(before) | set(after)) if before.get(key) != after.get(key)]
        assert not changes, f'{source.name}: unexpected changes: {changes}'
        stats = model['system_variable_catalog']
        result['packages'].append({'source': row['source'], 'sha256': row['sha256'],
            'baseline_semantic_sha256': digest(before), 'new_semantic_sha256': digest(after),
            'preexisting_model_unchanged': True,
            'documented_names': stats['present_in_package_names'],
            'document_names': stats['present_in_document_names'],
            'uncatalogued_names': stats['uncatalogued_system_names']})
        if args.save_models:
            args.save_models.mkdir(parents=True, exist_ok=True)
            with gzip.open(args.save_models / (row['sha256'] + '.json.gz'), 'wt', encoding='utf-8') as f:
                json.dump(model, f, ensure_ascii=False)
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
        print(f"  unchanged; {len(stats['present_in_package_names'])} documented system names", flush=True)
    print(f'PASS: {len(result["packages"])} packages', flush=True)


if __name__ == '__main__':
    main()
