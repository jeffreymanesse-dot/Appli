"""Re-run the frozen calibration; no reference PDF is consumed by the engine."""
import json,hashlib,re
from pathlib import Path
from retro.parser import analyze
from retro import __version__
from retro.schema import validate_model
root=Path(__file__).resolve().parents[1];sources=root.parent/'project_sources';out=root/'validation/revision_v6';out.mkdir(parents=True,exist_ok=True)
results=[]
for old in json.loads((root/'validation/calibration.json').read_text()):
    path=next(sources.glob('*-'+old['file']));m=analyze(path,old['file']);validate_model(m)
    checks=[];byname={v['name']:v for v in m['variables']};paths={x['xml_path'] for x in m['mappings']}
    for c in old['checks']:
        key=c['expected']
        if key=='compiled_rule_ids':value=[x['compiled_id'] for x in m['rules']]
        elif key.startswith('/'):value=key if key in paths else None
        else:
            name,field=key.rsplit('.',1);value=byname.get(name,{}).get(field)
        checks.append({'check':key,'passed':value==c['reference']})
    targets=[t for u in m['content_units'] for t in u.get('rule_targets',[])]
    results.append({'file':path.name,'checks':checks,'passed':sum(x['passed'] for x in checks),'total':len(checks),'content_units':len(m['content_units']),'calculations':len(m['calculations']),
                    'scope_profile_statistics':{'decoded_text_records':sum('richtext' in u for u in m['content_units']),
                      'inline_targets':sum(t['kind']=='inline_run' for t in targets),
                      'paragraph_targets':sum(t['kind']=='text_paragraph' for t in targets),
                      'uninterpreted_records':sum('scope_decode_issue' in u for u in m['content_units']),
                      'note':'Statistiques de profil ; ne constituent pas un oracle métier indépendant.'}})
(out/f'calibration_{__version__}.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
print(json.dumps(results,ensure_ascii=False))
assert all(x['passed']==x['total'] for x in results)
