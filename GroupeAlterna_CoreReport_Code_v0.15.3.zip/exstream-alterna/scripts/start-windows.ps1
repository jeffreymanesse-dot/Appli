$ErrorActionPreference = 'Stop'
Set-Location (Join-Path $PSScriptRoot '..')
if (-not (Get-Command docker -ErrorAction SilentlyContinue)) {
    throw 'Installez Docker Desktop avec le moteur WSL2, lancez-le, puis relancez DEMARRER_WINDOWS.cmd.'
}
& docker info *> $null
if ($LASTEXITCODE -ne 0) { throw 'Docker Desktop doit etre demarre.' }
if (-not (Test-Path '.env')) { Copy-Item '.env.example' '.env' }
function New-HexSecret {
    $bytes = New-Object byte[] 32
    $rng = [System.Security.Cryptography.RandomNumberGenerator]::Create()
    try { $rng.GetBytes($bytes) } finally { $rng.Dispose() }
    return -join ($bytes | ForEach-Object { $_.ToString('x2') })
}
$config = [System.IO.File]::ReadAllText((Join-Path (Get-Location) '.env'))
$config = $config.Replace('REPLACE_WITH_AT_LEAST_32_RANDOM_CHARACTERS', (New-HexSecret))
$config = $config.Replace('REPLACE_WITH_RANDOM_PASSWORD', (New-HexSecret))
[System.IO.File]::WriteAllText((Join-Path (Get-Location) '.env'), $config, (New-Object System.Text.UTF8Encoding($false)))
Write-Host 'Construction et lancement local. La premiere installation telecharge les dependances.'
& docker compose up --build --detach
if ($LASTEXITCODE -ne 0) { throw 'Le demarrage Docker a echoue. Conservez le message affiche pour le diagnostic.' }
Write-Host 'Application : http://localhost:3000'
Write-Host 'Laissez quelques secondes aux services pour demarrer.'
Write-Host 'Arret : docker compose down (les volumes sont conserves).'
Start-Process 'http://localhost:3000'
