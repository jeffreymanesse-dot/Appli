"""Regress native function declarations against the complete preceding models."""
import argparse,gzip,hashlib,json,re,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'backend'))
from retro.parser import analyze
from retro.schema import validate_model
from retro.function_signature import read_signature


def audit(data,before,after):
    a=json.loads(json.dumps(before));b=json.loads(json.dumps(after))
    a.pop('engine_version');b.pop('engine_version')
    declarations=[];definitions={d['id']:d for d in after['definitions']}
    for c in b['calculations']:
        sig=c.pop('design_signature',None)
        if c['id'].startswith('function'):
            assert sig is not None,c['id']
            native=read_signature(data,definitions['159:'+c['id'].removeprefix('function')],c['offset'])
            assert sig==native
            compiled_args=re.match(r"_functions\['[^']+'\]\s*=\s*function\(([^)]*)\)",c['source_code']).group(1)
            names=[n.strip() for n in compiled_args.split(',') if n.strip()]
            expected=[];reference_index=0
            for arg in sig['arguments']:
                if arg['passing_mode_code']==0:
                    alias='__argByRef_'+str(reference_index);reference_index+=1;expected.append(alias)
                    assert re.search(r'var\s+_'+re.escape(arg['name'])+r'\s*=\s*'+alias+r'\.value\s*;',c['source_code'])
                else:expected.append('_'+arg['name'])
            assert names==expected,c['id']
            for ev in sig['evidence']+[e for arg in sig['arguments'] for e in arg['evidence']]:
                assert hashlib.sha256(data[ev['offset_start']:ev['offset_end']]).hexdigest()==ev['sha256']
            declarations.append({'id':c['id'],'name':c['definition_name'],'kind':sig['kind'],
                'argument_count':len(sig['arguments']),'return_type':sig['return_type']})
        else:assert sig is None
    assert a==b,[k for k in a.keys()|b.keys() if a.get(k)!=b.get(k)]
    return {'preexisting_model_unchanged':True,'declarations':declarations,
        'argument_names_match_compiled_signature':True,'evidence_bytes_verified':True}


def main():
    p=argparse.ArgumentParser()
    for n in ('corpus','source-root','baseline-models','output','save-models'):p.add_argument('--'+n,type=Path,required=True)
    p.add_argument('--resume',action='store_true')
    args=p.parse_args();rows=json.loads(args.corpus.read_text());out=[]
    args.save_models.mkdir(parents=True,exist_ok=True);args.output.parent.mkdir(parents=True,exist_ok=True)
    for i,r in enumerate(rows,1):
        print(i,r['name'],flush=True);source=args.source_root/r['source'];data=source.read_bytes()
        assert hashlib.sha256(data).hexdigest()==r['sha256']
        cached=args.save_models/(r['sha256']+'.json.gz')
        model=json.load(gzip.open(cached,'rt')) if args.resume and cached.exists() else analyze(source)
        from retro import __version__
        assert model['engine_version']==__version__ and model['metadata']['sha256']==r['sha256']
        validate_model(model)
        before=json.load(gzip.open(args.baseline_models/(r['sha256']+'.json.gz'),'rt'))
        result={'source':r['source'],'sha256':r['sha256'],**audit(data,before,model)};out.append(result)
        with gzip.open(args.save_models/(r['sha256']+'.json.gz'),'wt',encoding='utf8') as f:json.dump(model,f,ensure_ascii=False)
        args.output.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
        print('PASS',len(result['declarations']),'declarations',flush=True)
if __name__=='__main__':main()
