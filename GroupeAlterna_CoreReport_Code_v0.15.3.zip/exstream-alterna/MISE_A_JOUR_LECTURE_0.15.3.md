# Groupe Alterna — CoreReport 0.15.3

Cette version simplifie le Visuel, rend les tableaux sans bordure plus repérables et complète le chapitre Variables et fonctions.

- La partie Lecture de cette visualisation est retirée entièrement du PDF Visuel. Si aucun contenu de courrier n'est disponible, un message bref évite de livrer un PDF vide.
- Les paragraphes Règles des objets de la page sont supprimés de la vue détaillée. Les règles restent analysées et leurs définitions et cibles sont conservées dans le catalogue et l'annexe.
- Un contour gris léger délimite les tableaux sans bordure visible, dans le rapport et dans le Visuel. C'est un repère de lecture ; aucune propriété de conception, largeur ou hauteur n'est modifiée. Les tableaux ayant déjà des bordures conservent leurs traits.
- Chaque variable présentée sous Formula affiche son Compute Time. Le mode Named section précise aussi le nom enregistré de la section lorsque le profil est reconnu.
- Les formules à déclenchement automatique sont incluses dans le périmètre du chapitre 4, avec les fonctions qu'elles appellent, même si leur résultat n'est pas imprimé.
- Le lanceur DEMARRER_WINDOWS.cmd attend cinq secondes avant d'ouvrir http://localhost:3000, après le lancement réussi des services.

## Pourquoi initPage était absente

La variable WRK_AFR_EPI_WEBLURE_COURRIER_SIMUL_initPage et sa Formula étaient déjà extraites. Le filtre de sélection du chapitre 4 partait des variables utilisées par les contenus et les règles. Il omettait cette formule dont le résultat n'est pas imprimé et dont le Compute Time est Page. Le filtre prend maintenant en compte les événements reconnus dans les propriétés enregistrées. Le script d'origine, ses commentaires et ses appels restent inchangés.

## Installation

1. Conserver `.env` et les volumes de l'installation existante.
2. Remplacer les fichiers du programme par le dossier `exstream-alterna` de cette archive.
3. Reconstruire avec `docker compose up -d --build`, ou utiliser le lanceur Windows habituel.
4. Lancer une nouvelle analyse du PUB pour produire les nouveaux PDF.

Les PDF historiques ne sont pas recalculés automatiquement. Aucune dépendance ni migration ajoutée. L'attente de cinq secondes ne remplace pas le contrôle de santé des services. L'exécution sur Windows n'a pas été rejouée dans l'environnement de développement.

Voir `docs/VALIDATION_LECTURE_0.15.3.md` pour les contrôles et limites.
