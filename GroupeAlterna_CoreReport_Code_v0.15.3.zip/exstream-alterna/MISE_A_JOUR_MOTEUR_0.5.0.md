# Moteur 0.5.0 — calibration sur quatre packages

Cette version étend le décodeur et le rapport PDF ; l’interface, les routes API et l’orchestration restent inchangées.

## Installation dans votre application existante

1. Arrêter les traitements en cours et conserver une copie de votre installation.
2. Copier `backend/retro` depuis cette archive dans votre dossier `exstream-alterna/backend/retro` existant. Les nouveaux modules `structure.py`, `coverage.py` et `report_inventory.py` sont nécessaires.
3. Copier aussi les tests et scripts si vous souhaitez relancer la calibration.
4. Depuis le dossier existant, reconstruire les services du moteur :

```powershell
docker compose up -d --build api worker purge
```

Conserver le fichier `.env` existant et les volumes Docker : les identifiants de la base déjà initialisée doivent rester cohérents. Le frontend n’a pas besoin d’être remplacé. Docker/Windows n’étaient pas disponibles dans l’environnement de validation ; ces commandes n’y ont pas été exécutées.

## Calibration reproductible avec Python

Après installation des dépendances de `backend/requirements.txt`, placer les quatre PUB dans un dossier de sources. Depuis la racine de l’application, sous PowerShell :

```powershell
$env:PYTHONPATH="backend"
python scripts/validate_corpus.py --source-dir "C:\Documents\PUB" --output-dir "validation\nouvelle_iteration"
```

Les fichiers peuvent porter leur nom exact ou un préfixe tel que `03-`. Le script refuse un dossier de sortie déjà rempli. Il génère les quatre PDF, leurs modèles JSON et un récapitulatif de couverture. Il n’utilise aucun PDF de référence ni Tools Report pour analyser le package.

Les tests sont lancés avec `python -m pytest backend/tests -q` après installation de pytest et des dépendances de développement. Les tests sur les packages clients sont sautés si leurs fichiers ne sont pas disponibles dans `../project_sources` ; les PUB ne sont pas redistribués dans l’archive du code.

## Portée réelle

Le moteur reste un décodeur empirique partiel. Les nouveaux profils couvrent des sections imbriquées, des pages sans PAR, des variantes de texte et de propriétés, deux répétitions de colonnes d’Adhésion et des portées inline dans Auto. Il conserve les cas non reconnus et ne reconstitue pas les ressources externes, les fusions ni l’ordre global des événements.

Les rapports sont plus volumineux que la référence car ils conservent les algorithmes transitivement appelés et des inventaires de ressources mutualisées. Les octets témoins, bornes, empreintes et sources de code complètes se trouvent dans le JSON. Le `.pub` original reste nécessaire pour reprendre le décodage des zones non interprétées.

Consulter `docs/VALIDATION_CORPUS_0.5.0.md` et `ETAT_VALIDATION_MOTEUR.md` avant de considérer un rapport exploitable. Les résultats ne prouvent pas la conformité de tout fichier portant l’extension `.pub`.
