# Groupe Alterna - Core Report 0.14.9

Cette version reprend la base complète 0.14.8. Elle corrige la présentation des conditions paramétrées et allège le rapport.

## Ce qui change

- Les conditions paramétrées affichent leur type et leur comparaison en police de code. R3 et R6 portent sur des chaînes : `"true"` et `"false"`. R7 porte sur le booléen `true`. Ces paramètres sont lus dans le PUB ; aucun script IF/ELSE n'est fabriqué.
- Les scripts enregistrés restent reproduits avec leurs commentaires, leur indentation et leurs lignes vides.
- L'annuaire affiche uniquement la variable, son chemin XML et son type/cardinalité. Les usages disparaissent du tableau.
- Le chapitre 6 ne garde que le tableau récapitulatif de l'inventaire. Les listes de noms, contenus non rattachés, règles hors périmètre, inventaire complet des calculs et autres développements de cette annexe sont retirés.
- « Origine des variables de référence » et « Fiches des variables hors flux utilisées par le courrier », déjà retirés en 0.14.8, restent absents.

Le modèle interne reste complet. Le chapitre 4 conserve ses 31 calculs et fonctions, leurs signatures natives et les zones Logic/Formula.

## Résultat du contrôle du bleu

Le titre, le conseiller et les textes du contrat utilisent tous `#00008F`, dans le PUB et dans les deux PDF générés. Le conseiller n'a pas de fond explicite ; le contrat possède un bandeau rempli de ce bleu avec du texte blanc. Le trait du titre et le cadre du conseiller ont une épaisseur native de 0,48 pt avant adaptation à la largeur du rapport : leur lissage à l'écran produit une apparence plus claire qu'un aplat.

Cette vérification ne justifie aucune recoloration ni ajout de fond. Les couleurs, fonds et épaisseurs enregistrés sont conservés. Des tests contrôlent désormais directement les couleurs écrites dans le rapport et le visuel.

## Installation et nouveau rapport

1. Conserver `.env` et les volumes Docker de l'installation.
2. Remplacer les fichiers du programme par le dossier `exstream-alterna` de l'archive 0.14.9.
3. Exécuter `docker compose up -d --build` depuis ce dossier, pour reconstruire notamment l'API et le worker, ou utiliser le lanceur Windows habituel.
4. Lancer une **nouvelle analyse** du dernier PUB. Une mise à jour ne recalcule pas les PDF des analyses déjà terminées.
5. Vérifier la mention `0.14.9` dans le pied du nouveau PDF. Le Bulletin fourni produit ici un rapport de 92 pages et un visuel de 8 pages.

Aucune nouvelle dépendance ni migration. Aucun déploiement sur votre installation n'est effectué par cette livraison. Le bilan figure dans `docs/VALIDATION_PRESENTATION_0.14.9.md`.
