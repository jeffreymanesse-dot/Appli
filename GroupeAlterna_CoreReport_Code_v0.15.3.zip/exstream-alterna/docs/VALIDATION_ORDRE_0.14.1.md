# Validation de la correction d'ordre — 0.14.1

## Comparaison réelle sur tout le corpus disponible

15 chemins ont été récupérés et vérifiés, soit 14 contenus distincts par SHA-256. Le PUB Adhésion de référence contenu dans `PUB.zip` est identique au fichier attaché : il est compté une seule fois. `Privé.zip` ne contient pas de PUB supplémentaire. Les sources n'ont pas été modifiées.

Chaque contenu a été soumis au moteur livré 0.14.0 puis au moteur corrigé 0.14.1. Aucun contournement du contrôle d'en-tête n'a été employé.

| PUB | Effet observé | Faits extraits hors ordre et repères éditoriaux |
| --- | --- | --- |
| `03-AFR_EPI_NOE_BULLETIN_ADHESION.pub` | Séquence inchangée | Identiques |
| `04-AFR_EPI_NOE_BULLETIN_VERSEMENT.pub` | Séquence inchangée | Identiques |
| `05-AFR_GENERIC_FIP_DEVIS_ESSENCIEL.pub` | Séquence inchangée ; annexe non décodée conservée | Identiques |
| `06-AFR_GENERIC_PROJET_OBSEQUES_ESSENCIEL.pub` | Séquence inchangée | Identiques |
| `07-AFR_IARD_DEVIS_AUTO.pub` | Séquence inchangée ; ordre documentaire incomplet | Identiques |
| `AFR_GENERIC_IARD_VEHIC_NOA_DEVIS.pub` | Séquence inchangée | Identiques |
| `AFR_GENERIC_IARD_VEHIC_PLAISANCE_CP_DEVIS.pub` | Séquence inchangée | Identiques |
| `AFR_GENERIC_IARD_VEHIC_PLAISANCE_FDC.pub` | Même refus d’en-tête avant/après ; non validé | Non comparable |
| `AFR_EPI_NOE_BULLETIN_ADHESION_Color.pub` | Séquence inchangée | Identiques |
| `AFR_EPI_NOE_BULLETIN_ADHESION_Round.pub` | Séquence inchangée | Identiques |
| `AFR_EPI_NOE_BULLETIN_ADHESION_Width.pub` | Séquence inchangée | Identiques |
| `AFR_EPI_NOE_BULLETIN_ADHESION_Black.pub` | Séquence inchangée | Identiques |
| `AFR_EPI_NOE_BULLETIN_ADHESION_BorderPink.pub` | Séquence inchangée | Identiques |
| `AFR_EPI_WEBLURE_COURRIER_SIMUL.txt` | Ordre APP corrigé | Identiques |

Conclusion limitée à ce corpus : seul WEBLURE reçoit une correction d'ordre. Les douze autres PUB acceptés ne montrent aucun changement de séquence. Plaisance FDC reste refusé, donc son contenu et son ordre ne peuvent pas être validés par cette comparaison.

## Méthode de non-régression

Comparaison profonde des modèles complets après neutralisation explicite de la version, du nouvel audit `document_order`, de l'ordre des documents/paragraphes/règles racines et des repères éditoriaux `document_id`/`document_rule_id`. Les documents sont comparés par identifiant compilé ; les listes internes de sections et paragraphes restent comparées dans leur ordre. Les appartenances des paragraphes/règles et les références non décodées sont contrôlées séparément. Les textes, variables, algorithmes, mappings, data sections/rattachements, topologies de tableaux, répétitions, styles et relations sont identiques dans les treize cas.

Les scripts de comparaison et d'analyse, les empreintes sources, les résultats JSON et le log des tests sont inclus sous `validation/order_0.14.1`. Ils ne contiennent pas les PUB ni les modèles client complets. Les scripts documentent les chemins du banc de validation ; pour une reproduction sur un autre poste, adapter leur dossier de travail et fournir les mêmes sources.

## Tests et sorties PDF

276 tests réussis, aucun échec ni saut, un avertissement. Les seize nouveaux cas couvrent listes APP, ambiguïtés, références manquantes, documents non référencés, non-régression mono-document, divergences bloquées avant export et génération des deux sorties sur WEBLURE réel. Le test d'export trace l'ordre effectif des paragraphes du moteur visuel, et vérifie les titres de début de document dans le corps du PDF de rapport.

Rapport WEBLURE : 300 pages ; visuel : 13 pages. Vérification des 53 titres de paragraphes dans l'ordre, contrôle automatique de toutes les pages et de la couverture des 237 unités visuelles. Aucune page vide ni dépassement physique, aucune unité reconnue manquante/dupliquée, aucune ligne fractionnée signalée. Toutes les pages ont été rendues puis parcourues en planches ; agrandissements ciblés sur la structure, le courrier et les tableaux. Aucun changement de charte ni de moteur de rendu. La densité préexistante du tableau à 19 colonnes reste une limite ; le contrôle ne certifie pas la pagination native Exstream.

## Limites conservées

FIP : annexe référencée mais non décodée. Auto : régions de pages, sans flux documentaire complet établi. WEBLURE : référence `21:38941` toujours non décodée. Data sections de lignes, Header/Footer, héritages, pagination native et ressources d'images : état de connaissance inchangé. Aucune autre erreur n'est présentée comme corrigée.

Les fichiers de rendu, de décodage binaire et de tableaux, l'interface (hors numéro de version) et les scripts de démarrage sont identiques à la 0.14.0. Aucun test Windows/Docker/PostgreSQL/RQ/navigateur ni déploiement utilisateur n'a été exécuté dans cette itération.
