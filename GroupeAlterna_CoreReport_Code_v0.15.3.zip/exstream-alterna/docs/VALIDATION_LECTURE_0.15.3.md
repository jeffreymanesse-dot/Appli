# Validation CoreReport 0.15.3

Base complète 0.15.2 conservée. Date : 9 octobre 2026. Source principale : package WEBLURE fourni sous l'extension .txt.

## Compute Time et sélection des formules

Le lecteur `formula_timing.py` valide la définition de variable, l'enveloppe de propriétés, le type, la source Formula, le nom dupliqué, la cardinalité, l'identité de la formule et les bornes du record. Il lit le champ de Compute Time enregistré ; aucun nom métier ni commentaire ne déclenche son interprétation.

| Code reconnu dans le profil | Valeur présentée |
| --- | --- |
| 0 | As-needed |
| 1 | Customer |
| 3 | Page |
| 6 | Initialization |
| 8 | Named section |

Le nom de la section est lu dans une enveloppe de propriétés distincte, après la source native. Sa longueur, ses sentinelles et l'unicité du champ sont contrôlées. Une chaîne trouvée dans le code ou un commentaire ne suffit pas.

Ces cinq valeurs sont les valeurs corroborées dans le corpus de cette livraison. Un code inconnu ou un profil non reconnu reste non déterminé ; il n'est pas remplacé par une valeur supposée. La propriété de conception est distincte du Reset Time et de l'instant effectif d'exécution lié aux dépendances. L'exécution des événements n'est pas simulée.

Les libellés et la signification des options sont recoupés avec le manuel OpenText Exstream 16.6, *Using Data to Drive an Application*, section 3.2.2, pages 67-68 ([copie du manuel éditeur consultée](https://fr.scribd.com/document/467850590/Exstream06DataProvider-pdf)). Le manuel décrit les options ; il ne documente pas les codes binaires. L'association des codes relève du profil de décodage, avec les limites ci-dessus.

Les formules Customer, Page, Initialization et Named section sont maintenant des points d'entrée du calcul du périmètre documentaire. Leurs dépendances et appels sont ensuite suivis par la fermeture existante. Les formules As-needed ne sont pas toutes ajoutées arbitrairement au chapitre. Les variables de résultat des calculs sélectionnés sont également conservées dans le périmètre des variables.

WEBLURE contient 29 variables Formula dont les Compute Time sont reconnus : 20 As-needed, 1 Customer, 1 Page, 2 Initialization et 5 Named section. Les cinq noms de sections sont retrouvés. La sélection du chapitre 4 passe de 63 à 79 calculs et fonctions, dont initPage et ses appels. L'ajout de ces points d'entrée ne signifie pas que tous leurs effets se produisent dans tous les scénarios.

## Présentation

La page de lecture du Visuel est supprimée avec ses descriptions, statistiques et mentions de substitution. Le contrôle interne de couverture est conservé. Le cas sans courrier produit uniquement un message explicite.

Le paragraphe récapitulant les règles des objets d'une PAGE est retiré. Les règles globales DOCUMENT/PAGE/SECTION et les cibles exactes des règles restent disponibles selon leur périmètre ; les données d'analyse ne sont pas effacées.

Les tableaux sans trait source visible reçoivent un contour gris de 0,45 point, peint indépendamment des propriétés source. Le cadre suit les lignes rendues et leur largeur, y compris lors du fractionnement. Il ne crée aucune nouvelle bordure dans le modèle. Les tableaux ayant un cadre ou des traits de ligne, colonne ou cellule conservent leur représentation précédente. Les text boxes ne sont pas transformées en tableaux.

## Tests

90 tests ciblés réussis, 1 test API désélectionné. Ils couvrent les déclarations de fonctions, les sources natives, les propriétés WEBLURE, les portées de bordures, le Visuel en français et en anglais, ainsi que les nouveaux cas suivants : propriétés renommées et déplacées ; codes connus et inconnus ; enveloppes, noms, propriétaires, source, cardinalité et bornes corrompus ; section nommée absente ou ambiguë ; sélection de initPage et de ses appels ; contour du tableau inline et conservation d'un cadre source existant.

Les assertions des tests API de langue et d'options sont adaptées à la suppression de la page de lecture. Ces tests API ne sont pas relancés dans cette livraison. La suite complète historique n'est pas revendiquée.

Le lanceur garde ses fins de ligne Windows et ses branches d'erreur. `timeout /t 5 /nobreak >nul` est placé avant l'unique ouverture du navigateur, après le retour réussi de Docker Compose. Il s'agit d'un contrôle du script ; Windows et Docker Desktop n'ont pas été exécutés ici.

Les résultats de génération, le nombre final de pages, les contrôles de couverture sur trois autres packages et les contrôles de géométrie sont consignés dans `validation/reading_0.15.3/checks.json`. Le journal courant complète ce bilan. Les sources natives, commentaires et algorithmes des règles et calculs sont comparés à 0.15.2. Les changements de contours restent des annotations de rendu ; le modèle de contenu et de mise en page est inchangé.

Le rapport WEBLURE final comporte 271 pages, annexe comprise, et le Visuel 14 pages. Toutes les pages ont été rasterisées et inspectées en planches ; les pages du tableau inline, de initPage et de fin du Visuel ont également été inspectées en grand format. Aucun texte hors page ni défaut nouveau de placement n’a été détecté. La densité des grands tableaux à nombreuses colonnes reste celle du rendu existant.

Les trois contrôles de corpus réussis portent sur le Bulletin d’adhésion, le FIP Devis Essentiel et le dernier Bulletin de versement : schéma et couverture du Visuel valides, sans perte, duplication ni erreur d’occurrence. Deux Formula du FIP portent un Compute Time non reconnu et restent explicitement non déterminées ; aucune valeur n’a été déduite de leur nom.
