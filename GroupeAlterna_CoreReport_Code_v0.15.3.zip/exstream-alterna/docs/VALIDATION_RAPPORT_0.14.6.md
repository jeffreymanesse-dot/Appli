# Groupe Alterna - validation Core Report 0.14.6

## Sources et base

- Base : archive complète 0.14.5, empreinte SHA-256 `b8293b13aa12e38506d94f9c008958a9095459dc63d52c6c4d433f0bc3110331`.
- Dernier Bulletin de versement : SHA-256 `99bc04e0aa443034dadfab2a5598ac73bdde3411e5e3ce1ab7806bd6ccb45520`.
- Deux photos de Design Manager fournies le 8 octobre 2026 : contrôle de l’ordre des sections, paragraphes et messages sous les campagnes CTC et GUT.
- Charte et actifs Groupe Alterna conservés. Les sources PUB et les photos ne sont pas redistribuées dans l’archive du programme.

## Suivi des demandes

| Point | Résultat |
|---|---|
| Mention initiale « propriété sérialisée dans cette page » | Retirée de l’arborescence. Les détails des composants PAGE restent dans l’inventaire facultatif. |
| 1. Rattachement à une section non établi | Mention supprimée dans l’arborescence ; les sections restent sous le document, à côté des pages. |
| 2. Règles de composition dans le sommaire | Sous-entrées de règles supprimées de l’arborescence. Le catalogue des règles conserve son chapitre. |
| 3. Page Flow décodé | Mention retirée ; les pages initiales et de débordement restent identifiées. |
| 4. Présence dans le package, rôle non interprété | Mention retirée de la structure. |
| 5. Commentaire sous le sommaire | Paragraphe sur les sources, Tools Report et exécution supprimé. |
| 6. Messages rattachés aux campagnes | Liens décodés par identifiants et liste comptée : 7 messages CTC, 13 messages GUT. Aucun rattachement par simple préfixe de nom. |
| 7. Architecture des photos | Application, document, pages et section avec ses 8 paragraphes ; campagnes sous l’application, messages enfants dans l’ordre des photos. |
| 8. Mise en forme du TITRE | Format graphique A3 désormais reconnu : Source Sans Pro Bold 19 pt, couleur source #00008f, positions des caractères et trait horizontal. Réduction proportionnelle si la largeur documentaire l’exige. |
| 9. Premier paragraphe du chapitre 1 | Reformulé en deux phrases qui présentent l’ordre, les contenus, les variables et les conditions. |
| 10. Profil empirique versionné | Expression supprimée du paragraphe de lecture. |
| 11. Commentaire avant les tableaux de règles | « Règles utilisées dans ce bloc » supprimé. |
| 12. R22 et vérification générale | Suppression de la présentation d’un pseudo-algorithme comme source. Tous les scripts et fonctions compilées sont vérifiés octet par octet ; aucune correction métier. |
| 13. R27, R28 et R29 | Même traitement. Les branches `else` existent dans les fonctions compilées et restent visibles comme telles, sans prétendre reproduire un script de conception absent. |
| 14. Règles non nommées | Libellé « Règle non nommée » ; les identités et associations des différentes règles restent séparées. |
| 15. Introduction du chapitre 2 | Les deux paragraphes demandés sont supprimés. |
| 16. Valeur brute / preuve | Colonne supprimée du tableau des largeurs. |
| 17. Positions binaires | Retirées des tableaux, fiches, catalogues et inventaires du rapport. Les preuves internes sont conservées. |
| 18. Aucun trait propre | Les lignes correspondantes du tableau de portée sont omises. |
| 19. Sans bordure locale et sans fond | Les groupes de cellules sans ces propriétés sont omis du résumé des styles. |
| 20. Forme sans fond | Ni rectangle ni arrondi n’est affiché pour une cellule sans fond explicite. Une bordure reconnue reste décrite. |
| 21. Répétitions remontées | Types de lignes, drivers et règles Rn déplacés dans le paragraphe concerné, avant son tableau d’algorithmes. |
| 22. Titre du chapitre 2 | « Mise en forme des tableaux » dans le plan et le chapitre. |

## Règles : ce que la vérification établit

Les 15 packages du corpus ont été analysés. **3 344 variantes compilées** ont été rapprochées des octets sources ; chaque script de conception affichable a également été rapproché de sa zone source. Les algorithmes, noms source, identifiants, associations et repères Rn préexistants restent inchangés.

Pour les règles sans script source textuel, l’ancienne reconstruction `IF ... THEN INCLUDE ELSE EXCLUDE ENDIF` n’est plus présentée comme l’algorithme d’origine. Le rapport reproduit la fonction compilée exacte et indique que le script de conception est absent. Les commentaires du script de règle présent sont conservés, ainsi que ses branches. Aucune expression logique, valeur littérale, condition, branche ou opérateur n’est corrigé. Cette présentation s’applique aussi aux règles non rattachées : leurs anciens résumés vrai/faux sont remplacés par les algorithmes conservés.

| Repère du dernier Bulletin | Identifiant interne | Source disponible pour l’algorithme |
|---|---:|---|
| R22 | 781331 | Fonction compilée, comparaison du taux dérogé à 0.000000 |
| R27 | 790440 | Fonction compilée, test du drapeau fonds UC |
| R28 | 790441 | Fonction compilée, test du drapeau fonds Euro Croissance |
| R29 | 789194 | Fonction compilée, test du drapeau fonds du moment |

La concordance avec un éventuel autre état de développement ne peut pas être établie à partir de ces seules sources. Pour comparer cet état, il faudrait son script de règle ou sa propriété de conception exportée.

## Décodage et non-régression

Le lien Application → Campagne utilise la liste de références déjà conservée dans le modèle ; chaque cible doit être une campagne décodée. Les messages proviennent d’une liste comptée de définitions de classe 21. Les listes tronquées, cibles inconnues et terminaisons incohérentes sont rejetées.

Le titre était retrouvé comme simple texte littéral alors que ses commandes graphiques étaient présentes. Le lecteur accepte maintenant le format A3 borné, ses rôles table/ligne/cellule équilibrés, le répertoire de police, les glyphes et le trait horizontal. L’objet reste relié à son propriétaire vide par un contrôle explicite. Les commandes, ressources, compteurs et terminaisons inconnus ne sont pas extrapolés. Le même format récupère aussi certains objets de pied de page du corpus.

Après retrait des seuls liens de campagne ajoutés, des nouveaux objets graphiques et du numéro de version, les modèles complets des 15 PUB sont identiques à ceux de 0.14.5. Toutes les anciennes compositions graphiques sont elles-mêmes comparées et conservées intégralement. Les données, textes, tables, règles, variables, mappings, Data Files, Data Sections et Page Flow ne sont pas remplacés par des valeurs supposées.

Preuves reproductibles : `scripts/validate_report_revision.py` et `validation/report_0.14.6/`.

## Vérifications de livraison

- Suite complète : **383 tests réussis**, aucun échec ni test ignoré ; un avertissement de dépréciation Starlette/httpx. Après les derniers ajustements des noms et de l’inventaire, les **21 tests ciblés** sont repassés avec succès.
- **15 rapports régénérés et contrôlés** : aucun texte hors page, aucune page de corps vide, aucune des mentions supprimées retrouvée. Pour toutes les règles, rattachées ou non, le texte des algorithmes affichés est recherché dans les PDF après normalisation des seuls espaces de mise en page.
- Dernier Bulletin : **149 pages de rapport et 8 pages de visuel**. Le titre, l’arborescence, les répétitions, R22/R27/R28/R29 et les styles des tableaux ont été examinés en agrandissement ; toutes les pages ont été parcourues en planches. Aucune unité ni occurrence attendue n’est signalée manquante par le contrôle du visuel.
- Archive complète vérifiée par empreintes de fichiers et CRC : tous les fichiers de la base 0.14.5 sont conservés ; seuls les fichiers explicitement listés dans le bilan de changements sont modifiés. Les actifs de marque et l’historique intégral du journal sont conservés.

## Limites conservées

Cette livraison ne simule pas l’exécution Exstream : les branches ne sont pas évaluées et les variables restent apparentes. Les ressources externes, la pagination native et les propriétés encore inconnues restent soumises aux limites précédentes. Aucun déploiement sur le poste utilisateur ni contrôle natif dans Design Manager n’est revendiqué. La version 0.14.5 et ses livrables sont préservés.
