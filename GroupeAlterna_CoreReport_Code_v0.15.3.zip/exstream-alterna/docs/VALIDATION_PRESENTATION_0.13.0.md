# Validation — tableaux et typographie 0.13.0

Date : 30 septembre 2026. Base : moteur 0.12.1 conservé. Sources PUB inchangées. Aucun nom de fichier, identifiant de paragraphe, empreinte de package ou offset absolu n'est utilisé pour sélectionner les nouveaux profils en production.

## Position du tableau FIP

Dans `PAR_AFR_EPI_NSE_FDC_DEVOIR_DE_CONSEIL_ESSENCIEL_BR_formulesContratEtChoix` (`21:42707`), le propriétaire de texte `text:4767305` contient un paragraphe interne vide d'index 2, à la position de conception 311. Ce paragraphe se trouve après « charges et revenus déclarés » et avant « Vous avez choisi… ».

La suite signée `[-244, 2, -251, 0, -106, 0]` désigne, sur le profil observé, le premier objet de tableau à cet emplacement. Le tableau complet commence à 4 776 996 et finit à 4 825 631 ; il est sérialisé après le texte propriétaire entier. Trier simplement les offsets plaçait donc le tableau trop tard. Le nouveau lecteur exige un propriétaire unique, un paragraphe vide borné, la paire d'opcodes adjacente, des indices d'objets consécutifs et des conteneurs comptés complets. Une corruption du motif annule l'ancrage.

Le pied du conteneur utilise deux commutateurs de disposition à +60/+64 : leur valeur peut être 0 ou 1, et n'est pas toujours 1/1. Le profil v3 contrôle toute la chaîne TLV du pied et les compteurs. Les zéros seuls ne suffisent pas à accepter un conteneur.

Le même profil établit l'ancrage de « notreEntretien » (`21:42706`, propriétaire `text:4722313`, paragraphe interne 4, position 610). Les trois lignes principales et la note fusionnée restent conservées. La mise en page PDF regroupe l'introduction et un tableau court quand l'ensemble tient sur une page ; elle ne prétend pas reproduire les sauts de page Exstream.

## Bordures, couleurs et unités

Les groupes de propriétés d'une cellule portent quatre traits indépendants. Le code de côté et le masque de cellule ne sont pas identiques :

| Code du groupe | Côté | Bit du masque de cellule |
|---:|---|---:|
| 1 | Supérieur | 4 |
| 2 | Droit | 2 |
| 4 | Inférieur | 8 |
| 8 | Gauche | 1 |

Dans chaque groupe de 112 octets, +64 porte le profil, +68 le type de trait, +72 l'épaisseur, +76 la couleur et +92 le sélecteur d'activation. Ce dernier n'est pas une épaisseur. Le masque de cellule et le sélecteur doivent tous deux activer le côté. Le profil solide reconnu est 0 ; `0xffffffff` signale l'absence explicite. Les autres valeurs restent non interprétées.

Les axes portent aussi leurs propres traits : supérieur/inférieur pour une ligne, gauche/droite pour une colonne. Les types sont à +12/+16, les couleurs à +20/+36 et les épaisseurs à +52/+56. Ces champs ne sont donc pas des contraintes de largeur. Une colonne avec une bordure reconnue conserve sa largeur physique si les autres contrôles de dimensionnement le permettent.

Les mesures reconnues sont en **1/300 de pouce** : `cm = brut × 2,54 / 300`, `pt = brut × 72 / 300`. Une épaisseur brute de 2 donne 0,48 pt ; la variante BorderPink brute 6 donne 1,44 pt (environ 0,0508 cm). Ces conversions ne sont pas appliquées aux boîtes graphiques de profil inconnu. Les valeurs sources restent dans l'audit, même si le PDF doit réduire un tableau trop large.

FIP : traits bleus `#00008f` des lignes et des cellules, séparateurs blancs d'en-tête, fonds de cellules et alignements sont retrouvés. Versement : séparateur de colonne de « VOTRE_SITUATION », côtés du tableau « DETAIL_VERSEMENT », dont les cases vides « Code ISIN ». Une bordure locale active a priorité sur le même côté d'axe ; un trait local inconnu ne provoque pas une substitution silencieuse par le trait d'axe. Les conflits entre cellules voisines et les contours globaux indépendants ne sont pas établis.

Les propriétaires rich-text réellement vides peuvent avoir une charge de quatre octets nuls. Ils sont acceptés uniquement après validation de la grammaire complète, sans texte fictif. Leur récupération complète les fonds et contours. Pour les gouttières très étroites, seule la marge intérieure d'affichage est bornée afin d'éviter une largeur utile négative ; la largeur de colonne source reste conservée.

## Polices et paragraphes

Les ressources de police 133/134 donnent le nom et les drapeaux gras/italique. La taille utilisée provient du slot rich-text, en dixièmes de point ; la taille nominale de la ressource est conservée séparément. Les couleurs sont résolues dans la palette du package ou dans une valeur RGB locale, sans palette cliente codée en dur.

Le préfixe de paragraphe reconnu donne l'alignement à +52 : 0 gauche, 1 droite, 2 centré, 3 justifié. Les espacements avant/après et la liaison au paragraphe suivant sont décodés sur ce profil. Les retraits et modes de puce restent bruts. Les retours internes reconnus (-156 et charge nulle adjacente validée) et les appels en exposant (-246/-247, argument 9) sont restitués ; la hauteur des exposants est une approximation d'affichage.

Les polices Source Sans Pro Regular/Bold/Light existantes restent utilisées. Pour une autre famille ou une variante italique indisponible, les quatre variantes DejaVu Sans fournies avec licence conservent gras/italique ; cette substitution reste annoncée. Le soulignement n'est pas déduit du nom ni inventé : les champs de décoration sont conservés avec le statut non calibré.

Le rapport et le visuel partagent le même rendu des contenus sources. Les en-têtes de tableau utilisent ainsi leur fond, leur texte blanc et leur gras reconnus. Les repères `[Rn]` du rapport signalent les règles sans recolorer tout le texte conditionnel. La mise en forme documentaire des titres de rubriques et des tableaux d'audit reste distincte du contenu client.

La déduplication du visuel inclut les tableaux ancrés, les styles, les retours et les exposants. Les champs de provenance (offsets différents) ne créent pas artificiellement des variantes. Les grilles reconstruites dans les packages sans paragraphes conservent toutes les régions nouvellement établies ; rétablir seulement une ancienne sous-liste de régions ferait disparaître des textes Auto, risque corrigé pendant la recette.

## Contrôles

Suite finale : **203 réussites, zéro échec, erreur ou saut**, en 194.54 secondes, bilan JUnit vérifié. Les 19 nouveaux cas couvrent les ancrages, leurs corruptions, les garde-fous du pied, les quatre côtés, les traits d'axes, les cellules vides, les gouttières étroites, la typographie, la déduplication et les deux PDF. Les contrôles historiques de styles ont été adaptés aux nouveaux traits désormais reconnus, tout en conservant les calibrations Black/BorderPink/Color/Round/Width. Un avertissement Starlette/httpx préexistant est conservé.

Les 12 chemins disponibles correspondent à 11 contenus SHA-256 distincts ; la référence Adhésion présente dans deux dossiers est enregistrée comme alias. Chaque contenu est analysé dans un processus séparé avec 0.12.1 puis 0.13.0.

| PUB | Rapport, pages | Visuel, pages |
|---|---:|---:|
| AFR_GENERIC_IARD_VEHIC_NOA_DEVIS.pub | 256 | 11 |
| 03-AFR_EPI_NOE_BULLETIN_ADHESION.pub | 172 | 10 |
| 04-AFR_EPI_NOE_BULLETIN_VERSEMENT.pub | 129 | 5 |
| 05-AFR_GENERIC_FIP_DEVIS_ESSENCIEL.pub | 173 | 10 |
| 06-AFR_GENERIC_PROJET_OBSEQUES_ESSENCIEL.pub | 126 | 8 |
| 07-AFR_IARD_DEVIS_AUTO.pub | 116 | 13 |
| AFR_EPI_NOE_BULLETIN_ADHESION_Color.pub | 167 | 10 |
| AFR_EPI_NOE_BULLETIN_ADHESION_Round.pub | 167 | 10 |
| AFR_EPI_NOE_BULLETIN_ADHESION_Width.pub | 167 | 10 |
| AFR_EPI_NOE_BULLETIN_ADHESION_Black.pub | 167 | 10 |
| AFR_EPI_NOE_BULLETIN_ADHESION_BorderPink.pub | 167 | 10 |

`validate_presentation_corpus.py` vérifie les mêmes faits sources : métadonnées, textes, variables, algorithmes, cibles internes des règles, mappings, calculs, dictionnaire et XSD. Les colonnes, axes et cellules principaux restent conservés, avec vérification des coordonnées dans les octets. Tous les contenus visuels antérieurs gardent leur identifiant et leurs fragments ; la récupération peut ajouter des unités bornées, notamment vides. Les styles, associations et présentations dérivés sont volontairement enrichis.

Les **22 PDF / 1914 pages** s'ouvrent, sans page vide ni texte hors page détecté. Les visuels signalent zéro contenu manquant, placement dupliqué, ligne fractionnée ou paragraphe trop long. Les regroupements intentionnels sont audités. Revue visuelle : les dix pages du visuel FIP et les cinq pages du visuel Versement, les pages PDF 11 et 14 du rapport FIP, et les pages PDF 8 et 9 du rapport Versement. Les autres pages bénéficient des contrôles automatiques ; aucune relecture humaine exhaustive des rapports n'est revendiquée.

## Reproduction et livraison

Installer les dépendances de développement. Placer les six PUB historiques dans `../project_sources` ; définir `PUB_TABLE_CORPUS` vers la racine contenant `pub_variants` et `pub_variants2`. Les fichiers client absents provoquent des sauts, qui ne constituent pas une recette complète.

```bash
PUB_TABLE_CORPUS=/chemin/corpus PYTHONPATH=backend python -m pytest backend/tests -q --junitxml=../tests_013.xml
PYTHONPATH=backend python scripts/validate_presentation_corpus.py --source-dir ../project_sources --source-dir ../pub_variants --source-dir ../pub_variants2 --source-dir '/chemin/Conception Appli' --output-dir ../validation_013 --baseline-backend /chemin/0.12.1/exstream-alterna/backend
```

Le dossier de sortie doit être vide. Les sources PUB ne sont ni modifiées ni intégrées aux livrables. Le code complet, les PDF FIP/Versement, l'archive de preuves finales et le journal avec historique sont livrés. L'archive de preuves contient les 22 PDF, audits, typographie, tests et captures finales ; les essais intermédiaires sont exclus. Aucun déploiement ni nouvelle recette navigateur/Docker/Windows/PostgreSQL/RQ.

Les profils restent empiriques et bornés au corpus disponible. Restent notamment à calibrer : soulignement, rayon exact des arrondis, traits non continus, conflits de bordures partagées et contour global indépendant, retraits/puces/tabulations/interligne natif, pagination Exstream et ressources externes. Les valeurs client et les conditions métier ne sont pas exécutées.
