# Profil de portée des règles - moteur 0.4.0

> Historique, remplacé par `PROFIL_PORTEES_PUB.md` (0.5.0). L’hypothèse de deux copies concordantes de l’index de ciblage est invalidée sur Adhésion/FIP : +56 est interprété, +4 reste brut. Ne pas réutiliser ce profil comme spécification actuelle.

Le profil `OBS-richtext-113-244-254-v1` est une observation binaire du corpus,
pas une spécification officielle d'OpenText. Le moteur ne lit ni le PDF v6 ni
un Tools Report. Aucun nom métier, identifiant de règle ou offset du Bulletin
n'est codé dans le décodeur. Les constantes métier se trouvent uniquement dans
les tests optionnels sur le fichier client identifié par son SHA-256.

## Relation résolue

Une définition de règle porte un identifiant compilé. Un record texte 113
possède une table locale d'identifiants de règles à compteur redondant.
Deux structures peuvent référencer un index de cette table :

- les propriétés d'un paragraphe interne, avec deux copies concordantes de
  l'index ;
- une instruction -254 du flux de composition, fermée par -110 : fragment
  inline, au sein d'un paragraphe ouvert par -244.

Le flux est consommé séquentiellement, avec une grammaire bornée. Il ne s'agit
pas de chercher l'entier -254 à proximité d'un mot. Les coordonnées positives
comptent les caractères de conception. Les instructions de variable -384/-111
sont contrôlées par ID, par nom exact, par frontière de token et par un
répertoire indépendant contenant des bornes dans le payload sérialisé.

Le nombre total de positions doit correspondre à tous les caractères du
contenu décodé. Les paragraphes doivent porter des indices consécutifs. Les
ouvertures et fermetures doivent être équilibrées ; un inline ne traverse pas
un paragraphe. Une variable ne peut pas être ciblée partiellement.

L'enveloppe propriétaire est reconstruite à partir du nombre de paragraphes,
puis contrôlée intégralement par signatures, longueur du texte, chaîne des
records de propriétés et fin exactement située au début du payload. Les deux
variantes de fin, compacte et étendue, sont reconnues. Les dimensions et
propriétés typographiques non interprétées ne deviennent pas des faits métier.

## Modèle de sortie et preuves

Les données suivantes enrichissent le modèle JSON sans modifier les routes API :

- `content_units[].parts[].id` : identité du token dans ce package ;
- `content_units[].richtext` : paragraphes, bornes de composition, références
  de variables et profil du décodeur ;
- `content_units[].rule_targets` : cibles internes avec propriétaire, chaîne
  de parents, index local de règle et fragments de tokens ;
- `rules[].targets` : toutes les associations résolues, y compris les règles
  de ligne déjà reconnues. Les anciens champs monovalents `target` et `scope`
  restent conservés pour compatibilité ; utiliser `targets` pour ces nouvelles
  associations, qui peuvent être multiples ;
- `target_candidates[].classification` : définition, référence de ciblage ou
  occurrence numérique non résolue. Une occurrence tardive n'est pas
  automatiquement classée comme métadonnée ;
- `scope_decode_issue` : motif de rejet et preuve conservée pour un record
  hors du profil. Les index locaux non consommés restent également conservés.

Chaque cible interne expose `owner_object_id`, `owner_kind`, `parent_chain`,
`rule_reference_offset`, `owner_record_offset`, `scope_open_offset`,
`target_token_start`, `target_token_end` (fin exclue), `token_slices`,
`target_fragment_text`, `confidence`, `confidence_reason` et `evidence`.
Les preuves contiennent offsets, octets, empreinte et version du décodeur.
Les fragments d'une variable désignent son objet, jamais une valeur supposée.

`composed_character_start` et `composed_character_end` restent null : les noms
de variables ont des longueurs différentes des valeurs finales. Les index de
conception ne sont donc pas des positions absolues dans le courrier évalué.

CERTAIN signifie que les quatre critères de la méthode fournie sont satisfaits
sur ce profil : nom/condition/ID concordants, référence de targeting, propriétaire
résolu, frontières de contenu contrôlées. En cas d'identité/condition incomplète,
la qualification reste TRÈS PROBABLE. Une incohérence structurelle interdit toute
nouvelle coloration et conserve la preuve non interprétée.

## Périmètre vérifié et limites

Sur le Bulletin de Versement exact : 52 unités de texte reconnues sur les 62
unités du courrier, sept plages inline et cinq cibles de paragraphe, pour dix
règles internes distinctes. Les dix-huit règles de ligne conservent leur profil
et leur niveau de preuve antérieurs. Les règles imbriquées restent distinctes.
R28 encadre uniquement les trois caractères « tte ». R27 cible aussi un
paragraphe de deux espaces, conservé comme tel.

Une différence avec la référence v6 p.15 est établie par la nouvelle lecture :
rule781268 est utilisée pour le mot « Oui » et pour le paragraphe TIN/SSN.
Le commentaire de la référence annonçant ce dernier inconditionnel n'est pas
recopié. La propriété de paragraphe aux offsets 4419551/4419603 vaut l'index 0,
qui référence 781268 à 4426352 ; les frontières -244 sont 4423574 et 4424050.

La calibration existante de 76 contrôles passe sur les quatre packages. Elle
ne valide pas les nouvelles portées sur les trois autres packages : leur
variante de flux ne passe pas les contrôles de ce profil et reste non
interprétée. Les statistiques de calibration le signalent explicitement.
Les tests de corruption couvrent index hors limites, fermeture absente,
opcode inconnu, ID variable contradictoire, propriétés non redondantes,
compteurs contradictoires et parentage invalide.

La conformité exhaustive à la référence reste non acquise : découpage Pxx,
échantillons, ordre global des événements et rendu/pagination Exstream ne sont
pas établis. Ce sont des limites du lecteur actuel et des ressources disponibles,
pas une preuve d'impossibilité intrinsèque du format.
