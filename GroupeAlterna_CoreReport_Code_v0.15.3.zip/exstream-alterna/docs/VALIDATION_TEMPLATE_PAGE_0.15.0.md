# Groupe Alterna - Validation Core Report 0.15.0

Date : 8 octobre 2026. Base : archive complète 0.14.9. Périmètre : annexe facultative Template et Page, analyse des implantations de Page et sélection dans CoreReport.

## Bulletin de versement

La validation utilise le dernier PUB fourni dans `upload`, distinct du Bulletin historique placé dans `project_sources`. Le modèle réanalysé conserve tous les champs de 0.14.9, à l’exception du numéro de version ; le nouveau champ `page_layouts` s’ajoute sans modifier la numérotation, les algorithmes ou les rattachements préexistants.

| Contrôle | Résultat |
|---|---|
| Pages sélectionnées | DF_PAG_MAIN_withoutCtcGutAdr_BR et DF_PAG_FLOW_standard_BR |
| Objets décrits | 22 + 5 ; 27 noms et emprises recoupés avec l’étude acceptée |
| Format natif | 2480 × 3508 unités au 1/300 pouce, soit 209,97 × 297,01 mm |
| Échelle PDF | 0,24 point par unité native ; plans 1:1 sur feuilles A3 |
| Rotations | 26 cadres recoupés, dont 2 à −90° ; rotation de l’image directe laissée non confirmée |
| Images intégrées | S1FLECBR 119 × 118 et S1LOAPRS 368 × 216 ; octets JPEG et emprises conservés |
| Superpositions | Cadres conservés, y compris la paire Triman exactement superposée |
| Répétitions évitées | 8 styles partagés, 2 renvois de contenu et 12 renvois aux règles du catalogue |
| Conditions supplémentaires | 6 : 4 scripts natifs et 2 conditions paramétrées |
| Rapport complet | 100 pages, dont 8 d’annexe ; 92 pages sans l’option |
| Visuel séparé | 8 pages ; contenu antérieur conservé |
| Sources jointes | Même archive avec ou sans annexe ; 174 scripts natifs inchangés octet pour octet |

Les commentaires, lignes vides et ELSE présents dans les sources restent conservés. Aucun IF/ELSE ni effet n’est reconstruit depuis le code compilé. Les contrôles antérieurs sur R3/R6/R7, les couleurs du titre et du conseiller, les sections supprimées, l’annuaire sans usages et le chapitre 6 limité au tableau continuent de s’appliquer.

## Moteur et sélection

Le décodeur utilise les identités de composants, listes comptées, unités déclarées, dimensions répétées, polygones et commandes d’image bornées. Il ne dépend ni d’un nom de fichier, ni d’une empreinte de package, ni de positions absolues propres au Bulletin. Une incohérence ne devient pas une coordonnée supposée. Les images externes ou dynamiques ne sont pas remplacées par des logos de présentation.

La case `include_template_pages` est indépendante des trois autres choix. Les 16 combinaisons sont vérifiées à travers réception API, file de traitement, génération, actualisation du résultat et téléchargement, ainsi que dans le rendu structuré. La suppression de l’option enlève l’entrée d’organisation et l’annexe, tout en conservant l’archive jointe. Les trois choix des tâches historiques ne reçoivent pas automatiquement un quatrième choix.

L’annexe utilise des repères locaux Pn.nn et TP-R ; les règles déjà documentées gardent leurs repères Rn. La numérotation des chapitres précédents ne change pas. Les titres français et anglais sont vérifiés, sans traduction des noms ou du code du PUB.

## Vérifications

- 66 contrôles ciblés des options, langues et présentations, puis 14 tests propres aux pages, réussis.
- Corruptions testées : nombre d’objets, dimensions, unité, polygone, rotation, coordonnées et JPEG.
- 15 packages réanalysés ; modèle validé par schéma, champs existants inchangés avant/après le décodeur, annexes générées sans texte hors page. Sur leurs 33 pages sélectionnées : 26 décodées, 2 partielles et 5 non interprétées.
- Les 100 pages du rapport et les 8 du visuel ont été rendues et parcourues en planches ; les 8 pages de l’annexe ont aussi été inspectées en grand format. Aucun rognage constaté. Les superpositions natives des plans sont intentionnellement conservées.
- Contrôles de couleur effectués sur les valeurs écrites dans les PDF : titre, conseiller et contrat restent en #00008F.
- TypeScript et compilation Next.js de production réussis ; HTML compilé vérifié avec quatre cases libellées et cochées par défaut. Libellé anglais présent. Aucun navigateur Chromium n’était disponible pour rejouer les clics : la persistance des choix et les téléchargements sont vérifiés par API.

Suite complète : **471 tests réussis**, aucun échec ni saut ; un avertissement de dépréciation préexistant. Journal : `validation/template_page_0.15.0/tests_full.log`.

## Limites conservées

Les relations vers un composant Template, le rôle du rectangle interne de page, les valeurs dynamiques, les priorités d’impression et les ressources externes non interprétés restent explicitement inconnus. La page blanche sans propriétaire reconnu n’est pas ajoutée au périmètre du Bulletin. Certaines variantes du corpus, notamment FIP et IARD Auto, ne satisfont pas ce profil d’implantation ; leurs coordonnées ne sont pas dessinées.

Les plans ne constituent pas une composition de production Exstream et ne simulent aucun scénario d’affichage. Les contenus des paragraphes du courrier restent décrits dans le corps du rapport. Aucun déploiement externe ni validation native Exstream n’est revendiqué.

La livraison conserve tous les fichiers de la base 0.14.9, les actifs de marque et le journal historique. Aucune dépendance ni migration ajoutée. Reconstituer le rapport en lançant une nouvelle analyse après installation.
