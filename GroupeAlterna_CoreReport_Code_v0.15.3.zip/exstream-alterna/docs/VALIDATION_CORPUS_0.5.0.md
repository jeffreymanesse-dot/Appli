# Validation du moteur 0.5.0 — quatre courriers

État au 26 septembre 2026 : amélioration vérifiée sur les quatre packages fournis, **conformité exhaustive non acquise**. Cette boucle est une amélioration du décodeur avec tests de régression ; elle ne démontre pas la fiabilité de tout fichier portant l’extension `.pub`.

## Résultats mesurés

Les nombres de blocs désignent le périmètre structurel reconstruit. Les nombres de règles et de répétitions ci-dessous concernent ce périmètre, pas toutes les ressources mutualisées du package. Un zéro de répétition signifie « aucune répétition démontrée sur le profil reconnu », jamais « absence universellement prouvée ».

| Mesure | Adhésion | Versement | FIP Essenciel | Devis Auto |
|---|---:|---:|---:|---:|
| Pages du PDF final, itération 19 | 185 | 141 | 184 | 146 |
| Blocs Pxx structurels | 31 | 8 | 31 | 12 régions/ensembles de page |
| Unités de contenu du courrier | 74 | 62 | 61 | 142 |
| Unités dont le rich-text est décodé | 67 | 61 + titre littéral distinct | 54 | 136 |
| Règles rattachées au courrier | 44 | 28 | 34 | 138 |
| Répétitions de lignes / colonnes | 4 / 2 | 4 / 0 | 0 / 0 | 0 / 0 |
| Colonnes inspectées dans le package | 25 | 25 | 15 | 21 |
| Mappings INPUT dans l’annuaire du PDF | 345 | 342 | 336 | 86 |
| Variables inventoriées dans le JSON | 5774 | 5796 | 5713 | 801 |
| Mappings inventoriés dans le JSON | 5057 | 5236 | 5154 | 515 |
| Règles compilées dans le package | 183 | 146 | 184 | 235 |
| Fonctions/formules inventoriées | 78 | 57 | 72 | 19 |

Les annuaires PDF incluent les dépendances explicites des calculs sélectionnés. Ils sont donc plus étendus que les seuls champs visibles du courrier. Le JSON conserve aussi les mappings des sources de référence, séparés de l’annuaire INPUT. Les 86 mappings Auto correspondent au périmètre documentaire sélectionné ; le package contient 488 mappings classés INPUT pour 437 variables distinctes.

Par rapport au moteur 0.4.0 : le périmètre rattaché passe de 21 à 74 unités pour l’Adhésion, de 9 à 61 pour le FIP et de 0 à 142 pour Auto. Le Versement conserve ses 62 unités et passe de 52 à 61 unités rich-text décodées. Ce sont des mesures de couverture du lecteur, pas des pourcentages de justesse métier.

## Les quatorze exigences

« Vérifié » désigne le corpus et le profil indiqués. Une information non interprétée reste explicitement telle.

| # | Exigence | Résultat et réserve |
|---|---|---|
| 1 | Inventaires APP/DOC/PAG/CMP/PAR/STY/RUL, fonctions, formules, variables | Présents dans les quatre modèles et synthétisés dans les PDF. Distinction entre nom observé et objet défini ; plusieurs classes et propriétés ne sont pas calibrées. L’absence de PAR Auto n’est pas remplacée par des objets fictifs. Toutes les variables sont dans le JSON ; le PDF détaille le périmètre sélectionné. |
| 2 | Ordre structurel | DOC → sections comptées imbriquées → PAR pour les trois premiers. Ordre de cellules corroboré par coordonnées. Auto : parentage de trois pages et grilles reconnu, ordre entre régions et objets libres non démontré. Les occurrences répétées d’un même PAR ne sont pas toutes développées comme instances distinctes. |
| 3 | Flux / références / calculs / technique | Classification par descripteur de source et écritures explicites. Préfixes techniques conservés comme indices, sans imposer une origine. Variables sans preuve classées unresolved. |
| 4 | Origine, type, cardinalité, usages, valorisation, algorithme | Champs et preuves conservés ; formules de retour et affectations multiples reliées, appels explicites suivis. Type/cardinalité inconnus restent inconnus. Ordre lexical local seulement ; ordre global des événements non décodé. |
| 5 | Mappings XML démontrés | Records 115, tuple élément/parent redondant, ID de variable concordant et bornes contrôlées. Aucune construction à partir du nom de variable. INPUT exige le descripteur 163 borné ; la seule racine /flow ne suffit pas. Cardinalité XML des parents et namespaces non établis. |
| 6 | Règles complètes et portée exacte | Conditions source/compilées conservées, lecture des formes reconnues, branches explicites et propriétaires. Portées de ligne et internes sur profils contrôlés. 7 / 0 / 7 / 6 unités du périmètre conservent une erreur de décodage interne. Les règles non rattachées restent dans l’inventaire et le JSON. |
| 7 | Ciblage vs variable dynamique | Rouge uniquement sur cible prouvée de ligne, paragraphe ou fragment. Une variable dynamique seule n’est pas colorée. Les valeurs de conception sont distinguées des valeurs client. |
| 8 | Tables, lignes, colonnes, cellules, fusions | Grilles, coordonnées, lignes vides, ciblages reconnus et preuves conservés. **Fusions, certaines propriétés conditionnelles et géométrie fine non interprétées** : ce critère reste partiel. |
| 9 | Inspection de toutes les colonnes | Effectuée et publiée, même sans Repeat ; dimensions et 17 champs bruts conservés. Ciblage/fusion de colonne restent marqués non interprétés. |
| 10 | Drivers de répétition | IDs sérialisés, flag Array et profil de propriété corroborés. Deux Repeat-C `anneeRac` sur Adhésion, quatre Repeat-L sur Adhésion et Versement. Pas de choix arbitraire de la première variable de ligne. Politique d’indexation, longueurs différentes et null non déduites. |
| 11 | Rn, REP-Ln, REP-Cn | Numérotation cohérente entre modèle, annotations et catalogues ; IDs compilés conservés. Rn dépend du parcours structurel, donc certains numéros diffèrent de V6. |
| 12 | Vue complète puis Pxx | Vue de tous les contenus rattachés, suivie de l’analyse Pxx. Objets non rattachés conservés en annexe. **Ce n’est pas le rendu complet Exstream garanti**, surtout pour Auto ; pagination d’origine et découpage P00…P25 V6 non reproduits. Aucun extrait image recadré utilisé. |
| 13 | Annuaire des seules données XML d’entrée | Présent et non vide dans les quatre PDF ; sélection par source INPUT et dépendances. Aucun référentiel ajouté sous prétexte que son chemin commence par /flow. |
| 14 | Conservation des limites et non interprétés | Offsets, extraits binaires, empreintes, codes, occurrences et motifs de rejet conservés. Le PUB original reste nécessaire pour examiner les octets au-delà des extraits de preuve. |

## Corrections et indices vérifiables

| Écart | Preuve dans les sources | Correction réutilisable |
|---|---|---|
| Sections imbriquées perdues | Adhésion : DOC 10:5280, racine SEC 206:6198 ; graphe compte 31 PAR. Les relations placent 41514 avant 41513 et 41753 avant 41699. | Lecture du record racine 120 et membres de section 205/206, avec compteurs, signatures et détection de cycle. |
| Nom accentué ignoré | FIP : PAR 21:42708 `solutionProposée`. | Définition Pascal imprimable, sans restriction ASCII supprimant le nom. |
| Contenu Auto absent de la reconstruction | Paires ouverture 111/classe 24 et fermeture 104 de même ID, puis axes de grilles ; aucune définition PAR. | Régions portées par une page ; avertissement explicite sur l’ordre inter-régions. |
| Texte et styles incompatibles avec le profil 0.4 | Flux consommé : glyphes, table de lignes, répertoire des variables, table de polices et style ; variantes des propriétaires 334/346 octets. | Profil v2 borné, fermeture et compte de glyphes indépendants ; aucun balayage de proximité pour attribuer une portée. |
| Double index de propriété supposé à tort | Adhésion/FIP : les champs +4 et +56 ne sont pas toujours égaux. | +56 interprété comme index de ciblage local borné ; +4 conservé brut. L’ancien profil est corrigé, pas « assoupli » sans preuve. |
| Valeur de conception confondue avec du texte | Adhésion texte 5047803 : répertoire variable vers `DF_PAR_title`, valeur de conception « Mesdames, Messieurs ». | ID et bornes de répertoire corroborent le token ; rendu `[DF_PAR_title]`, valeur brute conservée séparément. |
| Fausse cellule FIP | Texte 4722313 « Notre entretien » : style consommé différent du style avant le trailer trouvé. | Association rejetée et conservée comme preuve, ordre local explicitement inconnu. |
| Colonnes non inspectées / Repeat-C manqué | Grilles Adhésion 21:41698 et 21:41753, colonne index 1, driver sérialisé 105522. | Inspection systématique des propriétés, contrôle des deux variantes de sentinelle et répétitions de colonnes. |
| Algorithme indirect absent | Versement formula107407 : affectations de typeCourrier/typeAvenant, en plus du résultat de formule ; source compilée vers 5277199. | Sélection par affectation explicite, puis dépendances et appels ; aucun ordre d’exécution global inventé. |
| Annuaire Auto vide | Source 15:1520, record 163 à 433216 : Pascal `INPUT` (5 caractères), puis longueur 62 du chemin ; les autres sources avaient une longueur 32. | Lecture de deux chaînes Pascal ; suppression du test erroné `INPUT ` et de l’inférence par racine /flow. Mapping de marque : record 487783 → `/PFEL/HPDATA/AGRT-VEH_make`. |
| Export PDF vide accepté | Itération 16 : un fichier Versement vide a été observé malgré le retour de génération ; cause initiale non démontrée. | Génération temporaire, contrôle de l’enveloppe PDF et publication après validation. Test conservant les précédents livrables quand le rendu produit zéro octet. |
| Gros bloc avec titre isolé | Revue Adhésion itération 17, vue P20. | Conservation des frontières de paragraphes décodées dans le flux PDF ; lignes de tableaux indivisibles. |

## Validation et comparaison V6

- **73 tests réussis, aucun sauté**, dont les cas des quatre PUB exacts, corruptions de ciblage, descripteurs INPUT/référence et intégrité d’export. Un avertissement de dépréciation httpx/Starlette subsiste.
- **76/76 contrôles historiques** relancés : Adhésion, Versement, FIP, **Obsèques**. Obsèques ne remplace pas Auto : Auto possède ses propres contrôles dans `test_corpus_generalization.py`.
- Les quatre PDF finaux comportent **656 pages** : toutes rendues, texte sélectionnable partout, aucun dépassement détecté. Chaque page a fait l’objet d’une revue de mise en page par planches ; zooms sur blocs denses et alertes de pagination. Auto 19 relu intégralement ; les 510 autres pages ont un rendu identique aux pages 18 déjà toutes inspectées.
- Les polices utilisées pour les textes sont DejaVu Sans/Sans Bold intégrées. Helvetica est déclarée par ReportLab mais n’est pas utilisée par les spans de texte extraits. Aucune superposition ou troncature majeure observée. Code dense, noms longs repliés et certaines transitions peu remplies restent visibles.
- **22 fichiers frontend/API/worker/configuration/orchestration identiques** aux empreintes initiales. Aucun changement d’apparence ni de route de téléchargement. Docker, Windows et PostgreSQL n’ont pas été exécutés ici.
- Versement : les **28 IDs de règles** V6 sont retrouvés, ainsi que les **73 noms de variables** identifiés dans son annuaire, tous présents dans le nouvel annuaire INPUT. Les quatre drivers de répétition sont conservés. Ce contrôle de présence n’est pas une validation de tous les effets ni du rendu.
- V6 : 46 pages, nouveau rapport : 141. Vue générale d’abord, analyse séquentielle, règles, répétitions, algorithmes et annuaire sont présents ; ordre des rubriques, pagination, densité et Pxx restent différents. La conservation des algorithmes appelés explique une grande partie du volume supplémentaire.
- Divergence maintenue : rule781268 cible aussi TIN/SSN selon le PUB (propriété 4419547, champ +56 à 4419603, table locale 4426352), contrairement au commentaire V6 p.15. R28 cible uniquement « tte », comme V6 p.28. Aucune correction fondée sur la seule référence ne remplace la preuve du PUB.
- Les rubriques de redéveloppement et de scénarios de tests de V6 p.39–40 sont exclues par le cahier consolidé ; elles ne sont pas injectées dans le rapport métier.

Les tableaux détaillés sont dans `validation/corpus4/metrics_final_0.5.0.json`, `comparison_v6_0.5.0.json`, `CONCORDANCE_PAGES_V6.md`, `iteration_19/pdf_qa.json`, `visual_review.json` et `render_comparison_to_18.json`. Les modèles finaux ont été recalculés avec le code livré et comparés exactement aux JSON générés.

## Sources et limites de reprise

Sources effectivement utilisées : les quatre PUB 03/04/05/07 ; spécification déterministe 01 et cahier consolidé 02 ; méthode de détermination de portée jointe ; charte et logo disponibles ; dépôt, tests, journal, modèles et rapports antérieurs. V6 et ses 46 rendus servent à la comparaison uniquement ; `rapport.pdf` et l’itération 6 restent intacts. Aucun Tools Report ni code embarqué n’a été exécuté. Aucun rapport de référence complet n’est disponible pour Adhésion, FIP ou Auto : leurs contrôles reposent sur les enregistrements des PUB et les exigences, pas une comparaison visuelle à un document métier absent.

Blocages de lecture reproductibles restant dans le périmètre :

- Adhésion : textes 4858436, 4945944, 5009066, 5023442, 5189828, 5198690, 5207983 — chaînes de propriétés non résolues.
- FIP : 4702030, 4786726, 4920764, 4943885, 4958948, 5018523, 5035820 — même réserve.
- Auto : texte 1252466, opcode -240 à 1254569 ; propriétés des textes 1416734, 1423250, 1444345, 1455903, 1611153. 25 contenus restent sans parent résolu ; ordre entre régions non prouvé.
- Tous : fusions, propriétés conditionnelles de colonnes, ressources graphiques Exstream, frontières de pages évaluées, déclenchement global des événements, valeurs d’entrée client et référentiels externes effectifs. Aucun paramètre manquant n’est remplacé par une valeur par défaut inventée.

Prochaine action exacte : commencer par le flux Auto 1252466 autour de l’opcode -240 à 1254569, en comparant la table de lignes et le répertoire variable indépendants ; accepter une nouvelle arité seulement si le comptage et les frontières concordent, puis ajouter une fixture négative. Traiter ensuite une variante propriétaire Adhésion/FIP, puis les attributs de fusion/colonne. Ces limites sont celles du lecteur actuel ; aucune impossibilité intrinsèque du format n’est démontrée.

## Livrables

Code complet : `GroupeAlterna_Exstream_Code_v0.5.0.zip`, avec guide `MISE_A_JOUR_MOTEUR_0.5.0.md`. Rapports : `GroupeAlterna_{Adhesion,Versement,FIP_Essenciel,Devis_Auto}_Moteur_0.5.0_Iteration_19.pdf`. Archive d’audit : `GroupeAlterna_Exstream_Validation_Corpus_v0.5.0.zip` (JSON/PDF des itérations, rendu final, tests et preuves de validation). Journal : `ETAT_VALIDATION_MOTEUR.md`.
