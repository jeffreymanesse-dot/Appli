# Validation — Core Report 0.14.4 — 8 octobre 2026

## Résultat de la passe

Le moteur a réanalysé **15 packages distincts** (comparés par SHA-256), dont la nouvelle version du Bulletin de versement. Il a produit **30 PDF** — un rapport et un visuel pour chacun — totalisant 3352 pages. Les 15 packages ont passé la validation du modèle et l’export; les contrôles automatiques ne trouvent ni page PDF vide ni texte hors des limites. La couverture interne du rapport et du visuel ne signale aucun contenu manquant ni occurrence incohérente.

| Package analysé | SHA-256 (début) | Documents | PAGE | Data Files | Sections utilisées | Rapport / visuel (pages) |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| 03-AFR_EPI_NOE_BULLETIN_ADHESION.pub | `5f3ce5cdf6e2` | 1 | 3 | 22 | 0 | 204 / 13 |
| 04-AFR_EPI_NOE_BULLETIN_VERSEMENT.pub | `f23ca63a5401` | 1 | 3 | 22 | 0 | 150 / 8 |
| 05-AFR_GENERIC_FIP_DEVIS_ESSENCIEL.pub | `efb587a1afbb` | 1 | 4 | 22 | 0 | 200 / 14 |
| 06-AFR_GENERIC_PROJET_OBSEQUES_ESSENCIEL.pub | `78b79d2cf896` | 1 | 3 | 22 | 0 | 140 / 11 |
| 07-AFR_IARD_DEVIS_AUTO.pub | `4487df70b922` | 0 | 3 | 6 | 0 | 146 / 17 |
| AFR_GENERIC_IARD_VEHIC_NOA_DEVIS.pub | `331bd9af9581` | 1 | 2 | 22 | 0 | 319 / 18 |
| AFR_GENERIC_IARD_VEHIC_PLAISANCE_CP_DEVIS.pub | `ab18c96f5756` | 1 | 3 | 22 | 0 | 257 / 17 |
| AFR_GENERIC_IARD_VEHIC_PLAISANCE_FDC.pub | `c93cdf4bb9dd` | 1 | 2 | 22 | 0 | 246 / 14 |
| AFR_EPI_NOE_BULLETIN_ADHESION_Color.pub | `3a1b75dc7ee4` | 1 | 3 | 22 | 0 | 196 / 13 |
| AFR_EPI_NOE_BULLETIN_ADHESION_Round.pub | `f9e41440092b` | 1 | 3 | 22 | 0 | 196 / 13 |
| AFR_EPI_NOE_BULLETIN_ADHESION_Width.pub | `b47e2aaf803a` | 1 | 3 | 22 | 0 | 196 / 13 |
| AFR_EPI_NOE_BULLETIN_ADHESION_Black.pub | `f4e46134dc7f` | 1 | 3 | 22 | 0 | 196 / 13 |
| AFR_EPI_NOE_BULLETIN_ADHESION_BorderPink.pub | `c44363b692ec` | 1 | 3 | 22 | 0 | 196 / 13 |
| AFR_EPI_WEBLURE_COURRIER_SIMUL.txt | `45ff5ce41fef` | 4 | 5 | 21 | 8 | 352 / 22 |
| AFR_EPI_NOE_BULLETIN_VERSEMENT.pub | `99bc04e0aa44` | 1 | 3 | 22 | 0 | 151 / 8 |

Les 13 modèles déjà validés ont été comparés aux sorties actuelles : définitions, graphe d’ordre, sections de documents, cibles existantes des mappings, IDs/noms/algorithmes des règles et anciens contenus sont conservés. Les nouvelles associations de PAGE et les mappings de clés CSV sont ajoutés avec preuves; ils ne remplacent pas les anciens IDs. Un mapping supplémentaire apparaît sur Auto et huit candidats de mapping sont récupérés sur les autres packages comparés. Les listes de fichiers APP sont maintenant décodées, sans modifier l’ordre des documents.

## Corrections génériques livrées

- Le parseur de règles retire les commentaires avant de vérifier une expression complète. Un bloc de commentaire contenant un `IF` ne devient pas une condition active.
- Les paragraphes et cellules reconnus par plusieurs profils de texte sont conservés par enregistrement binaire, même si leur contenu est identique. Les variables sont affichées par leur nom lorsqu’un lien borné concorde; la valeur de design sample reste distincte.
- Les data sections ne sont décrites que lorsqu’elles sont utilisées par le document. La dernière version du Bulletin contient 39 déclarations partagées et aucune section utilisée; elles n’apparaissent donc pas comme données du courrier. Weblure a 8 sections reliées au document.
- Les lignes de tableau couvrent maintenant les types H+, R, F et F+, ainsi que leurs critères de répétition. Dans le nouveau Bulletin, les lignes 5 à 8 affichent les quatre drivers définis; la ligne 8 conserve `790289` comme référence candidate, sans la présenter comme règle active. Les conditions actives des lignes 4 et 9 restent rattachées à leurs IDs compilés.
- Le moteur parcourt la liste des Data Files de l’application et conserve les files d’entrée, d’initialisation, de référence et de rapport rencontrés. Les types 0 à 3 sont identifiés selon le profil observé; les autres codes restent bruts. Les variables préfixées `SYS_` sont classées « système », suivant la règle que tu as fournie.
- Les PAGE utilisées et les liens de débordement sont suivis par IDs. Les profils constatés sont reconnus pour les propriétés PAGE portant les tags 136 et 139, et les propriétés de règles de composants pour les tags 1020 et 1021. Les associations PAGE alimentent également le visuel.
- Le visuel conserve les occurrences séparées et commence chaque DOCUMENT sur une nouvelle page. Dans Weblure, les quatre débuts du visuel sont aux pages 1, 3, 7, 11. Le rapport les situe aux pages 11, 20, 37, 43 de son chapitre principal.

## Vérifications du nouveau Bulletin et de Weblure

Le Bulletin de versement du SHA-256 `99bc04e0aa443034dadfab2a5598ac73bdde3411e5e3ce1ab7806bd6ccb45520` est accepté. Les types et répétitions des lignes 4 à 10 concordent avec les éléments fournis; 0 section de données est considérée utilisée, et les variables `SYS_` observées sont classées système.

Weblure conserve l’ordre des 54 occurrences de paragraphes et affiche deux fois `PAR_AFR_EPI_WEBLURE_TABLE`. Le contrôle du titre `PAR_WEBLURE_Simul_Titre` vérifie dans son passage que `03/08/2008` est remplacé par `[DF_FIC_SD_SIMURENTE_SIMBYPRODUCT_annuityEffectiveDate]`. Les quatre documents sont rendus dans l’ordre défini par l’application. Le visuel contient les composants `DF_CMP_HEAD_h0857v0030JpgPh` et `DF_CMP_HEAD_h0857v0030SegPh`, avec les règles compilées 510262 et 512304 sur leur PAGE.

L’en-tête supplémentaire du package Plaisance FDC est maintenant accepté uniquement lorsque les champs nuls, le jeton opaque, la signature Pascal et le marqueur Exstream concordent. Le modèle et les deux PDF FDC ont passé les mêmes contrôles que les autres packages.

## Recette automatisée et limites connues

Suite complète : **251 tests réussis, 67 ignorés**. Les tests spécifiques vérifient les deux profils de règles PAGE, le chainage réel des pages Weblure et les lignes du nouveau Bulletin.

Les fichiers de documentation fournis ici décrivent le projet et les exigences de rétro-analyse; ils ne contiennent pas le guide technique OpenText Exstream détaillant l’ensemble des types de Data Files, les variables système ou les Page templates. Je ne peux donc pas confirmer que les codes 0–3 couvrent tous les types possibles. Les types inconnus sont conservés sous leur code brut.

La référence binaire du `Page template` n’est pas encore décodée : le rapport le signale au lieu de déduire un modèle du nom. Les ressources image qui ne sont pas embarquées ou reliées par le package conservent un cadre explicite dans le visuel; aucun fichier image n’est choisi par ressemblance de nom. Les styles et la pagination native restent partiels.
