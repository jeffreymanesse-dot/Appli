# Validation du moteur 0.6.0 — itérations 20 à 23

27 septembre 2026. Base : code livré 0.5.0. Cas principal : `AFR_GENERIC_PROJET_OBSEQUES_ESSENCIEL.pub`, comparé au rapport fourni `rapport-1.pdf` (118 pages). Les quatre autres PUB ont ensuite été recalculés avec le même moteur. Aucun contenu statique propre à ces rapports n'a remplacé l'analyse du binaire. L'interface, son apparence et le contrat API sont inchangés.

Les corrections demandées sont intégrées et testées. Cette livraison n'est pas une certification de complétude de tout le package ni de fiabilité sur tout PUB : les limites recensées ci-dessous restent explicites.

## Écarts du rapport Obsèques et corrections

| Retour | Cause / preuve dans le PUB | Correction et résultat | État |
|---|---|---|---|
| Origine des variables incomplète | Les sources des règles 767773/767782/767783 commencent par `Dim`, aux offsets 4853262/4855436/4857634. L'ancienne extraction cherchait notamment un début `IF` et la valorisation ne recensait pas leurs écritures. | Sources bornées par longueur ; lecture des appels d'affectation dans les règles et calculs ; expressions brutes et lisibles, index, variables lues, gardes locales et ordre lexical conservés. Neuf variables de choix/cotisations retrouvent leur valorisation. | Corrigé pour les neuf variables ; ordre événementiel global non établi. |
| Noms des composants pages absents du rapport | Trois définitions de classe 24 : 24:42523 à 4813312, 24:25582 à 4814343, 24:42630 à 4831200. | Tableau des noms `DF_PAG_MAIN_ficheInfos_BR`, `DF_PAG_BLANK`, `DF_PAG_FLOW_ficheInfos_BR` ; relation de première page établie avec le document, autres usages réservés lorsqu'inconnus. | Corrigé. |
| Titres `function895` / `rule767727` | Les noms métier existent dans leurs définitions. Les noms accentués étaient trop strictement filtrés. | Titres privilégiant `DF_FCT_IMG_getImage` et `RUL_AFR_EPI_NSE_PROJET_OBSEQUES_LieuSouhaite_rempli` ; identifiants techniques gardés comme preuves. Même principe pour formules, inventaires et règles non rattachées. | Corrigé. |
| Règles absentes des plages de P10.12 | `text:4497508` contient deux règles distinctes : 767727 sur les paragraphes locaux 2, 3 vide et 4 ; 767726 sur le paragraphe 5. | Repères `[R1]…[/R1]` et `[R2]…[/R2]` aux frontières décodées ; rouge limité à ces portées. L'ancienne R3 (767743, périodicité) porte sur le tableau suivant : elle devient R6, aucune troisième règle n'est ajoutée artificiellement à P10.12. | Corrigé pour les plages démontrées. |
| Règles des colonnes de FINANCEMENT_SIMULATION absentes | Grille 21:42545, 4 × 4. Propriétés des colonnes aux offsets 4575518, 4576275, 4577032 ; champ +16 = 767773, 767782, 767783. Enveloppes, axe et sentinelles contrôlés indépendamment. | R3/R4/R5 rattachées aux colonnes Viagère / 10 ans / 20 ans ; cibles et algorithmes présentés dans la grille et le catalogue. La colonne de libellés n'a pas de règle dans ce profil. | Corrigé pour cette variante du format. |
| Paragraphes, notes et fiches séparés | Revue des rendus 20 puis 21 et 22. | Regroupement d'un paragraphe avec son annotation ; fiches courtes insécables ; réserve d'espace avant leur titre de chapitre. | Corrigé dans les rendus finaux inspectés. |

Les règles de colonnes possèdent dans le package un nom de composant commun. Le moteur conserve ce nom réel, les IDs techniques et les identifiants R3/R4/R5 ; il n'invente pas trois noms RUL distincts.

## Valorisation démontrée des cotisations

Chaque règle cherche sa durée par `Contains` dans `DF_FIC_SD_sousPrev_formulesCtrTab_dureeTypeCotis` (106394). Sous la garde locale `n > 0`, elle inclut sa cible et affecte les trois variables suivantes à partir de l'indice `n` :

| Règle / colonne | Choix — source 106397 | Cotisation annuelle — source 106395 | Cotisation fractionnée — source 106396 |
|---|---|---|---|
| R3 / Viagère | cible 106461 | cible 106460 | cible 106457 |
| R4 / 10 ans | cible 106462 | cible 106463 | cible 106464 |
| R5 / 20 ans | cible 106465 | cible 106466 | cible 106467 |

Les noms complets, expressions et preuves sont présents dans les fiches du PDF et le JSON. Les sources sont respectivement `…isOptChoisie(n)`, `…mntCotisAnn(n)` et `…mntCotisFrac(n)`. L'ordre présenté est celui des instructions dans chaque algorithme, sans simuler un ordre global d'exécution. Une valeur absente ou nulle ne permet pas d'inventer l'exécution de la branche opposée.

Les arguments des appels de fonctions sont également affichés, notamment les clés littérales passées à `DF_FCT_IMG_getImage` dans `DF_WRK_AFR_EPI_NSE_PROJET_OBSEQUES_initCust_BR`. Une fonction susceptible d'écrire une variable reste distinguée d'un appel effectivement démontré.

## Résultats des cinq analyses

Les variables « directement utilisées » ci-dessous sont celles référencées par les unités de contenu du courrier principal. Ce sous-ensemble ne représente pas toutes les variables embarquées dans le package. L'annuaire INPUT inclut aussi les dépendances sélectionnées : son nombre de mappings peut donc dépasser le nombre de variables directement visibles.

| Courrier | Pages finales | Règles documentaires | Variables directement utilisées | Flux / calculées / référence / origine non établie | Nouvelles origines retrouvées dans le package | Colonnes inspectées |
|---|---:|---:|---:|---|---:|---:|
| Adhésion | 196 | 44 | 71 | 53 / 13 / 1 / 4 | 11 | 25 |
| Versement | 146 | 28 | 61 | 54 / 5 / 2 / 0 | 4 | 25 |
| FIP Essenciel | 198 | 34 | 60 | 41 / 14 / 4 / 1 | 11 | 15 |
| Obsèques | 130 | 6 | 29 | 9 / 20 / 0 / 0 | 9 | 16 |
| Devis Auto | 159 | 138 | 89 | 61 / 13 / 0 / 15 | 1 | 21 |

Les gains sur les autres packages concernent notamment des lignes d'adresse, le découpage d'e-mails et `WRK_AFR_IAR_COMMON_OUTPUT`. Les 36 origines supplémentaires correspondent à des couples variable/package, pas nécessairement à 36 noms différents. Aucune affectation déjà reconnue en 0.5.0 n'a été perdue.

L'annuaire documentaire conserve uniquement les mappings dont la source INPUT est démontrée : 345 / 342 / 336 / 303 / 86 mappings respectivement. Aucun chemin XML n'a été fabriqué à partir d'un nom de variable. Les inventaires, relations documentaires et répétitions existantes sont conservés ; les propriétés de toutes les colonnes sont inspectées, y compris en l'absence de Repeat de colonne.

## Vérification effectuée

- Base 0.5.0 : 73 tests réussis. Après corrections, itérations 20 corrigée, 21, 22 et 23 : 78 tests réussis, aucun sauté. Un avertissement de dépréciation httpx/Starlette, sans échec.
- Calibration historique : 76/76 contrôles réussis après les corrections du moteur. Le dernier ajustement de l'itération 23 concerne seulement la mise en page.
- Non-régression des cinq modèles face à 0.5.0 : 35 invariants réussis, couvrant variables/types/cardinalités, mappings, ordre des paragraphes structurels, contenus et parents, portées existantes, code compilé des règles, drivers de répétition.
- 829 pages finales rendues. Revue de toutes les pages par planches et zooms ; inspections antérieures réutilisées uniquement après identité des images vérifiée. Détail dans `REVUE_VISUELLE.md` de l'archive de validation.
- Toutes les pages contiennent du texte sélectionnable, les polices DejaVu utilisées sont intégrées, pagination séquentielle, zéro page vide et zéro dépassement des marges selon le contrôle automatique. Aucun écrêtage ou chevauchement important observé. Les longues sources restent denses et certaines transitions laissent de l'espace blanc.
- 27 fichiers protégés (interface, actifs graphiques, API, services, configuration et scripts de lancement) identiques aux empreintes initiales. Aucun test Docker Desktop/Windows/PostgreSQL exécuté dans cet environnement.

## Limites restantes

| Limite | État exact / conservation |
|---|---|
| Propriétés de deux textes Obsèques | P11.14 `text:4534892`, intervalle 4535341–4540223 ; P17.02 `text:4704658`, intervalle 4705890–4717749. Chaîne propriétaire/propriétés non résolue ou index refusé. Texte et preuve binaire conservés ; aucune portée rouge supposée. |
| Autres portées refusées | Sept unités Adhésion, sept FIP, six Auto. Pour Auto P00.07, opcode -240 à 1254569 dans `text:1252466`. Liste complète avec offsets et empreintes dans `metrics_final.json` et les JSON des rapports. |
| Origines encore inconnues | Quatre libellés de signature Adhésion ; `DF_FIC_CD_AGRT_effStartDate` pour FIP ; quinze variables Auto, dont références, distributeur, contrat et compteurs SYS. Leurs noms seuls ne prouvent ni une source INPUT ni un algorithme. Liste exhaustive dans les métriques. Zéro origine inconnue dans les 29 variables directes Obsèques ne signifie pas que tout son package est résolu. |
| Exécution | Analyse statique : événements, ordre global des valorisations, état initial et conditions d'appel non intégralement décodés. Les gardes locales reconnues ne constituent pas un simulateur. |
| Structure et graphique | Certaines relations de parentage et certains ordres entre régions restent réservés, notamment dans Auto ; fusions et variantes conditionnelles non reconnues, styles fins, ressources et pagination évaluée Exstream non reconstitués intégralement. Le visuel complet est une reconstruction documentaire annotée. |
| Référence historique V6 | Le PDF V6 lui-même n'était pas accessible dans les ressources matérialisées de cette reprise. Aucune nouvelle comparaison page par page au V6 n'est revendiquée. Le journal conserve la comparaison historique 0.5.0 ; la présente comparaison porte sur `rapport-1.pdf`, les PUB et les modèles 0.5.0. |

Ces points sont des limites démontrées du lecteur actuel, pas une impossibilité intrinsèque du format. Aucune déclaration de conformité exhaustive ou de reproduction pixel par pixel n'est faite.

## Sources réellement consultées et livraison

Sources : les cinq PUB, `rapport-1.pdf`, spécification déterministe 01, cahier consolidé 02, journal antérieur, code 0.5.0, tests, profils documentés, JSON et rendus générés. Aucun Tools Report utilisé. Les originaux et les ressources graphiques ont été préservés.

Code : `GroupeAlterna_Exstream_Code_v0.6.0.zip`. Rapports : `GroupeAlterna_<courrier>_Moteur_0.6.0_Iteration_23.pdf`. Preuves : `GroupeAlterna_Exstream_Validation_Corpus_v0.6.0.zip`, avec les PDF/JSON des itérations, rendus finaux, tests, métriques et contrôles. Guide : `MISE_A_JOUR_MOTEUR_0.6.0.md`. Reprise : `ETAT_VALIDATION_MOTEUR.md`.

Prochaine investigation précise : partir des deux chaînes Obsèques P11.14/P17.02 conservées, établir les bornes et le propriétaire de chaque enregistrement refusé sans forcer le profil existant ; seulement après corroboration indépendante, ajouter des fixtures positives et négatives, puis reprendre l'opcode Auto -240. Les inspections encore valides ne sont pas à recommencer.
