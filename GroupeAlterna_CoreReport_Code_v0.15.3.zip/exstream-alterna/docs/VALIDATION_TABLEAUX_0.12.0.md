# Core Report 0.12.0 — validation des tableaux

29 septembre 2026. Profil `OBS-table-styles-300-2026-v1`.

## Intégration

Le module `backend/retro/table_styles.py` parcourt les colonnes et cellules reconnues par le moteur. Les adresses viennent des enveloppes structurelles, des propriétaires rich-text et des trailers de cellules. Aucun nom de fichier, nom métier, identifiant de table, empreinte de package ou offset absolu ne sélectionne ce nouveau profil. Les palettes sont résolues dans chaque fichier ; les couleurs ne sont pas codées en dur.

Le modèle contient `tables[].presentation`, `table_style_profile` et `table_style_coverage`. Les mesures portent valeur brute, unité, cm, points et preuves binaires. Le schéma JSON 1.0 reçoit des propriétés optionnelles ; aucune migration de base de données. Le modèle visuel possède les mêmes styles pour ses objets récupérés. Les données métier antérieures sont conservées.

Les rapports FR/EN détaillent les largeurs et regroupent les styles de cellules. Le visuel applique fonds, formes et bordures locales reconnues. Il conserve la largeur physique quand elle tient dans la zone disponible, sinon réduit les colonnes et les traits ; le facteur est enregistré dans `visual_validation.table_layouts`. Les variables restent affichées et peuvent provoquer un retour à la ligne : les polices et la pagination ne sont pas une composition Exstream native. Les tableaux à largeur automatique/non reconnue utilisent un rendu proportionnel signalé.

## Contrôles indépendants des résultats moteur

| Cas contrôlé | Résultat vérifié |
|---|---|
| Référence | Largeurs brutes 966 / 517 / 690 ; 8,1788 / 4,377267 / 5,8420 cm |
| Width | 945 / 517 / 591 ; 8,0010 / 4,377267 / 5,0038 cm, compatibles avec les saisies 8,00 et 5,00 cm quantifiées |
| Round | Codes 9 / 5 / 10 : Rounded left / Rounded / Rounded right |
| Black | Fond de (1,1) RGB(0,0,0), résolu par sa ressource de palette |
| BorderPink | Trait supérieur de (1,1) RGB(255,180,206), brut 6, soit 1,44 pt / 0,0508 cm |
| Color | Les trois fonds contrôlés restent bleus ; les groupes inspectés ne portent pas les couleurs rose/rouge annoncées. Les valeurs brutes et sélecteurs différents sont conservés. Aucune correction artificielle du fichier. |

Les assertions des tests comparent aussi les tracés réellement émis dans le PDF : largeur, couleur et position supérieure du trait rose, courbes des trois arrondis. Mutation de palette et métadonnées renommées, profil de forme inconnu, enveloppes corrompues/tronquées et dimensions automatiques sont testés séparément.

## Corpus complet

12 chemins trouvés, 11 contenus distincts. Les deux références Adhésion identiques sont enregistrées comme alias d'une même empreinte. Tous les chemins et SHA-256 figurent dans `corpus_summary.json`. Chaque contenu distinct a été analysé dans 0.11.0 puis 0.12.0. Zéro différence dans les champs métier préexistants après exclusion des ajouts de présentation, de la version et de la liste de propriétés désormais interprétées. Les anciennes données du visuel sont une restitution et ne font pas partie de cette égalité métier.

| Fichier | Colonnes en unité reconnue / non interprétées | Cellules | Fonds RGB | Formes arrondies | Traits locaux validés | Pages rapport / visuel |
|---|---:|---:|---:|---:|---:|---:|
| AFR_GENERIC_IARD_VEHIC_NOA_DEVIS.pub | 113 / 0 | 306 | 24 | 24 | 83 | 250 / 12 |
| 03-AFR_EPI_NOE_BULLETIN_ADHESION.pub | 34 / 4 | 98 | 10 | 0 | 0 | 172 / 9 |
| 04-AFR_EPI_NOE_BULLETIN_VERSEMENT.pub | 29 / 1 | 112 | 10 | 17 | 0 | 129 / 5 |
| 05-AFR_GENERIC_FIP_DEVIS_ESSENCIEL.pub | 20 / 4 | 73 | 10 | 0 | 0 | 174 / 10 |
| 06-AFR_GENERIC_PROJET_OBSEQUES_ESSENCIEL.pub | 33 / 2 | 69 | 45 | 0 | 17 | 124 / 7 |
| 07-AFR_IARD_DEVIS_AUTO.pub | 21 / 0 | 110 | 0 | 0 | 0 | 112 / 11 |
| AFR_EPI_NOE_BULLETIN_ADHESION_Color.pub | 34 / 4 | 98 | 10 | 0 | 0 | 166 / 9 |
| AFR_EPI_NOE_BULLETIN_ADHESION_Round.pub | 34 / 4 | 98 | 10 | 3 | 0 | 166 / 9 |
| AFR_EPI_NOE_BULLETIN_ADHESION_Width.pub | 34 / 4 | 98 | 10 | 0 | 0 | 166 / 9 |
| AFR_EPI_NOE_BULLETIN_ADHESION_Black.pub | 34 / 4 | 98 | 10 | 0 | 0 | 166 / 9 |
| AFR_EPI_NOE_BULLETIN_ADHESION_BorderPink.pub | 34 / 4 | 98 | 10 | 0 | 1 | 166 / 9 |

Les décomptes de styles concernent le modèle documentaire et peuvent inclure des ressources non projetées dans le courrier final. Chaque bordure non validée reste conservée avec son statut ; absence de trait émis ne signifie pas absence de propriété dans Exstream.

## Résultats

- 171 tests réussis, zéro échec, zéro saut, 118,06 s. Un avertissement préexistant Starlette/httpx.
- 22 PDF français : 1 890 pages. Contrôle automatique des fichiers complets et des blocs de texte sur chaque page : aucune page vide ni texte hors page détecté.
- Deux PDF anglais supplémentaires, BorderPink : rapport de 36 pages avec chapitres optionnels désactivés, visuel de 9 pages ; libellés traduits et valeurs sources conservées, aucun texte hors page.
- Visuels des 11 contenus : aucune unité manquante, aucun placement dupliqué, aucune ligne fractionnée ni avertissement de paragraphe trop long. Les équivalents volontairement regroupés restent comptabilisés.
- Inspection humaine ciblée : les six tableaux de contrôle Adhésion, deux pages du nouveau chapitre technique et la première page des cinq autres courriers. Les captures et leur manifeste sont fournis. Il ne s'agit pas d'une relecture visuelle humaine exhaustive des 1 935 pages.
- Une première tentative de rendu a révélé que 15/30 dans un tableau à colonnes répétées ne pouvaient pas être traités comme des largeurs fixes. Le garde structurel exclut maintenant contraintes et modes dynamiques ; la nouvelle suite complète et tout le corpus ont été relancés après correction.

## Limites conservées

Le rayon n'est pas décodé : le visuel utilise 3 points à titre indicatif pour les formes reconnues ; `radius_cm` reste nul. Le profil historique NOA issu de référence reste borné à son package pour les formes non décodées. Les côtés latéraux et priorités table/ligne/colonne/cellule, styles de trait non calibrés, couleurs conditionnelles, espaces CMJN et pagination native restent incomplets. La conversion 1/300 inch est réservée aux familles de mesures validées ; elle n'est pas appliquée aux coordonnées de boîtes de dessin en 1/1000 inch.

Aucun déploiement réalisé. L'interface et les API ne changent pas. Pas de nouvelle recette navigateur, Docker Desktop/Windows/PostgreSQL/RQ ; validation locale Python/SQLite, exports et tests de worker. Les PUB client, dépendances installées, données de travail et secrets ne sont pas inclus dans le ZIP de code.

## Reproduction

Installer `backend/requirements-dev.txt` (PyMuPDF ajouté pour les contrôles PDF), placer les six originaux dans `../project_sources`, et les variantes sous `pub_variants` / `pub_variants2` de la racine de corpus. Depuis le dossier du moteur :

```bash
PUB_TABLE_CORPUS=/chemin/corpus PYTHONPATH=backend python -m pytest backend/tests -q
PYTHONPATH=backend python scripts/validate_table_corpus.py --source-dir /chemin/originaux --source-dir /chemin/variantes --output-dir /chemin/nouvelle_validation --baseline-backend /chemin/0.11.0/backend
```

Le script traite les PUB récursivement, déduplique leurs octets, isole les analyses dans des processus distincts et préserve les validations antérieures en exigeant un dossier de sortie vide.
