# Core Report 0.13.1 — portées des bordures

Les bordures du tableau, des lignes, des colonnes et des cellules sont désormais conservées et dessinées séparément dans le rapport et le visuel.

| Propriété | Étendue |
|---|---|
| Table Properties | Cadre extérieur du tableau complet |
| Row Properties | Trait supérieur ou inférieur sur toute la largeur du tableau |
| Column Properties | Trait gauche ou droit sur toute la hauteur du tableau |
| Cell Properties | Uniquement les côtés activés de la cellule concernée |

Le cadre du tableau ne crée pas une grille interne. Un trait de colonne traverse aussi une cellule fusionnée ; une cellule sans bordure propre n'efface pas un trait de ligne ou de colonne. Les cellules vides restent prises en compte. Le rapport distingue les propriétés des quatre portées ; la couleur enregistrée ne signifie pas qu'un trait est activé.

Les captures fournies correspondent aux cadres de CONSEILLER, CONTRAT et VOTRE_SITUATION : bleu RGB(0,0,143), trait continu, épaisseur affichée 0,02 cm. La valeur binaire vaut 2/300 de pouce, soit 0,016933 cm ou 0,48 pt. Le même profil est présent dans les sept tableaux du courrier Versement. VOTRE_SITUATION : colonnes de 9,4827 cm et 8,9154 cm (affichage 9,48 et 8,92), trait droit de la première colonne, aucun trait propre sur la seconde.

**Point à confirmer : TITRE.** Le PUB disponible (SHA-256 `f23ca63a540159156cc72f63277b238bf656751f1035791fae294b65b21f0877`) ne contient aucun axe de ligne, de colonne ni conteneur de tableau dans `PAR_AFR_EPI_NOE_BULLETIN_VERSEMENT_TITRE` (21:43432). Il contient un objet texte. La capture Row Properties (hauteur 1,10 cm, trait inférieur 0,02 cm) ne peut donc pas être rattachée à ce paragraphe dans cette version. Fournir le PUB compilé correspondant à cette capture pour valider ce cas ; aucun trait n'a été ajouté par libellé ou codé en dur.

## Installation

Décompresser `GroupeAlterna_CoreReport_Code_v0.13.1.zip`. Remplacer le programme en conservant votre `.env` configuré et les volumes de données, puis reconstruire les services et lancer une nouvelle analyse :

```bash
docker compose up -d --build
```

Les anciennes sorties ne sont pas modifiées automatiquement. Le `.env` livré est le modèle initial, identique à `.env.example`. Aucune nouvelle dépendance applicative ni migration de base. Aucun déploiement ou test Docker/Windows/navigateur n'est revendiqué pour cette livraison.

## Validation

219 tests réussis, zéro échec, erreur ou saut, en 143.30 secondes. Les 12 chemins PUB (11 contenus SHA-256 distincts) sont comparés à 0.13.0. Textes, variables, règles, faits sources, topologie principale et contenus visuels antérieurs conservés. Les 22 PDF totalisent 1982 pages, sans page vide ni texte hors page détecté. Les cinq pages du visuel Versement et les pages PDF 5, 11 et 12 de son rapport ont été inspectées ; les autres pages ont subi les contrôles automatiques.

La restitution est bornée aux profils reconnus. Les types de traits non continus et la priorité native entre traits superposés restent à calibrer : le PDF dessine les propriétés globales puis les propriétés locales, sans présenter cet ordre comme une règle d'héritage Exstream. En cas de passage sur plusieurs pages, aucun cadre horizontal supplémentaire n'est inventé à la coupure. Le soulignement, le rayon exact des arrondis, la pagination native et les ressources externes restent partiels.

## Décodage et architecture

`backend/retro/table_frames.py` reconnaît le propriétaire graphique d'un tableau compté, indépendamment de ses cellules. Le nom de l'objet est lu comme chaîne Pascal ; la fin de cette chaîne et deux flux TLV validés doivent mener exactement à l'ouverture -108. La géométrie rectangulaire répétée et les enveloppes de couleur sont contrôlées. Aucune sélection par nom de courrier, paragraphe ou offset absolu.

Par rapport au début du propriétaire reconnu : activation uint16 à +100, type de trait uint32 à +102, épaisseur à +106 et couleur à +110. Sur le profil observé : activation 1 et type 0 = continu ; activation 0 et type 0xffffffff = absent. Les autres valeurs ne deviennent pas arbitrairement des traits continus. Les valeurs excessives d'épaisseur sont rejetées sans interrompre l'analyse.

`table_styles.py` ajoute `presentation.frame`, garde les traits d'axes dans `rows[].borders` et `columns[].borders`, et les traits locaux dans `cells[].borders`. L'ancien champ `effective_borders` reste pour compatibilité mais contient uniquement les traits locaux ; il ne matérialise plus un héritage artificiel.

`scoped_borders.py` calcule les étendues indépendamment de l'existence de cellules : cadre aux extrémités du tableau, traits de lignes sur la somme des largeurs, traits de colonnes à leur abscisse exacte sur la hauteur de chaque fragment. Son sous-type ReportLab dessine ces traits après les fonds et avant les bordures locales, même à travers une fusion. Le rendu partagé `visual_render.py` l'utilise dans les deux PDF et tient compte du cadre dans la déduplication. `report_table_styles.py` ajoute l'audit explicite des portées, y compris les traits absents. La typographie et les ancrages de 0.13.0 restent conservés.

## Preuves et reproduction

16 nouveaux tests : trois cadres des captures, largeur/traits des deux colonnes, cinq corruptions structurelles, type inconnu, absence explicite, épaisseur hors domaine, étendues indépendantes, fragments de ligne, traits réellement présents dans un PDF avec cellule fusionnée et constat d'absence de tableau TITRE. Les tests historiques restent présents ; l'assertion d'héritage locale de 0.13.0 a été remplacée par la séparation des portées établie par l'utilisateur.

La validation finale utilise les audits immuables 0.13.0 et régénère les 22 PDF avec 0.13.1 dans des processus indépendants. Les anciens contenus visuels sont vérifiés par identifiant et empreinte de fragments, en plus des contrôles de faits sources et coordonnées. Les sources PUB ne sont pas distribuées dans le code ou les preuves. L'archive de validation contient les six captures de calibration, les audits, la typographie, les PDF, les résultats JUnit et les vues inspectées.

| PUB | Rapport, pages | Visuel, pages |
|---|---:|---:|
| AFR_GENERIC_IARD_VEHIC_NOA_DEVIS.pub | 280 | 11 |
| 03-AFR_EPI_NOE_BULLETIN_ADHESION.pub | 176 | 10 |
| 04-AFR_EPI_NOE_BULLETIN_VERSEMENT.pub | 133 | 5 |
| 05-AFR_GENERIC_FIP_DEVIS_ESSENCIEL.pub | 174 | 10 |
| 06-AFR_GENERIC_PROJET_OBSEQUES_ESSENCIEL.pub | 131 | 8 |
| 07-AFR_IARD_DEVIS_AUTO.pub | 126 | 13 |
| AFR_EPI_NOE_BULLETIN_ADHESION_Color.pub | 171 | 10 |
| AFR_EPI_NOE_BULLETIN_ADHESION_Round.pub | 171 | 10 |
| AFR_EPI_NOE_BULLETIN_ADHESION_Width.pub | 171 | 10 |
| AFR_EPI_NOE_BULLETIN_ADHESION_Black.pub | 171 | 10 |
| AFR_EPI_NOE_BULLETIN_ADHESION_BorderPink.pub | 171 | 10 |

Depuis le dossier du projet, placer les six PUB historiques dans `../project_sources`, et les variantes sous la racine `PUB_TABLE_CORPUS` :

```bash
PUB_TABLE_CORPUS=/chemin/corpus PYTHONPATH=backend python -m pytest backend/tests -q
PYTHONPATH=backend python scripts/validate_presentation_corpus.py --source-dir ../project_sources --source-dir ../pub_variants --source-dir ../pub_variants2 --source-dir '/chemin/Conception Appli' --output-dir ../validation --baseline-backend /chemin/0.13.0/exstream-alterna/backend
```

Les fixtures manquantes entraînent des sauts ; ceux-ci ne constituent pas une validation complète. Un avertissement de dépréciation Starlette/httpx préexistant est conservé.
