# Groupe Alterna - Validation Core Report 0.14.9

Date : 8 octobre 2026. Base : archive complète 0.14.8.

Le contrôle utilise le dernier `AFR_EPI_NOE_BULLETIN_VERSEMENT.pub` fourni dans `upload`, distinct du Bulletin historique placé dans `project_sources`. Le modèle est réanalysé et comparé au modèle 0.14.8 : tous les champs sont identiques après normalisation JSON et exclusion du seul numéro de version.

## Règles R3, R6 et R7

La présentation antérieure « Variable / Comparaison / Valeur » ne montrait pas le type et présentait `true` de la même façon pour une chaîne et pour un booléen. Le problème portait sur la restitution, pas sur une modification de l'algorithme.

| Règle | Variable enregistrée | Type | Valeur présentée |
|---|---|---|---|
| R3 | DF_FIC_SD_NOE_gest_infoClient_citoyenAmericain | String | `"true"` |
| R6 | DF_FIC_SD_NOE_gest_infoClient_citoyenAmericain | String | `"false"` |
| R7 | DF_FIC_SD_NOE_gest_questions_objectifTransmettreEpargne | Boolean | `true` |

Ces trois enregistrements contiennent une comparaison paramétrée native, sans champ de script Basic associé. Le rapport les identifie comme « Condition paramétrée » et affiche l'égalité avec la valeur typée. Cette expression est une présentation des paramètres enregistrés, pas la prétendue copie d'un script absent. Aucun IF, INCLUDE, ELSE ou EXCLUDE n'est déduit du code compilé pour cet affichage.

Le même correctif s'applique aux sept conditions paramétrées du périmètre : R3, R6, R7, R22, R27, R28 et R29. Les autres scripts, notamment leurs ELSE explicites et commentaires, restent inchangés. Les formats non reconnus conservent leurs champs littéraux, sans conversion supposée.

## Couleur des premiers paragraphes

| Élément contrôlé | Couleur dans le PDF | Présentation enregistrée |
|---|---|---|
| Texte du titre | `#00008F` | Texte gras sur fond blanc |
| Texte du conseiller | `#00008F` | Texte et cadre, sans fond de cellule explicite |
| Texte du contrat | `#00008F` | Texte courant sur fond blanc |
| Bandeau du contrat | `#00008F` | Fond rempli et texte presque blanc (`#FEFEFE`) |

Les deux premiers paragraphes n'emploient donc pas un autre bleu dans ces PDF. Les traits fins, le lissage à l'écran, la graisse des caractères et l'opposition texte bleu/fond blanc ou texte blanc/fond bleu expliquent leur apparence différente. Les traits du titre et du cadre du conseiller sont enregistrés à 0,48 pt avant adaptation de largeur. La vérification antérieure du seul modèle était insuffisante ; les tests portent maintenant aussi sur les valeurs réellement écrites dans chacun des deux PDF.

Les titres documentaires du rapport utilisent séparément le bleu fonctionnel de la charte Alterna. Aucune couleur du courrier n'est remplacée par cette couleur éditoriale.

Le PUB contient également des règles de changement de palette dépendant des données. Aucune n'est exécutée ni aucun scénario sélectionné pour le visuel statique. Une validation du rendu de production Exstream nécessiterait son scénario et ses ressources.

## Rapport allégé

- L'annuaire conserve ses 342 mappings, avec trois colonnes : Variable, Chemin XML, Type/cardinalité. Les libellés et détails d'usages sont absents.
- Le chapitre 6 contient uniquement le tableau récapitulatif sous « Inventaire du package ».
- Les sections « Origine des variables de référence », « Fiches des variables hors flux utilisées par le courrier », « Contenus non rattachés - conservation explicite », « Règles sans rattachement au périmètre reconstruit » et « Calculs et fonctions - inventaire complet » sont absentes du rapport.
- Les 148 règles et les 57 calculs restent dans le modèle interne. Les 31 calculs du chapitre 4 sont conservés.
- L'archive jointe conserve les 174 scripts natifs octet pour octet, y compris les commentaires et caractères non imprimables. Seuls les fichiers décrivant les conditions paramétrées sont enrichis de leur type. Aucun code compilé n'y est ajouté.

## Vérifications réalisées

- **441 tests réussis**, aucun échec ni saut ; un avertissement de dépréciation préexistant du client HTTP de test.
- **39 contrôles ciblés réussis**, dont 18 nouveaux cas sur les conditions typées, l'absence des sections retirées, l'inventaire seul, les couleurs des PDF et les sources jointes.
- Rapport : **92 pages**, contre 118 en 0.14.8 ; visuel : **8 pages**.
- Contrôle des 100 pages rendues en planches, avec agrandissements des pages modifiées. Aucun rognage ni chevauchement constaté. Les pages aérées de transition et suites de scripts restent présentes.
- 66 scripts natifs imprimables et 7 conditions paramétrées du périmètre retrouvés dans le texte du rapport ; 174 scripts originaux joints et inchangés.
- Tous les champs d'analyse sont inchangés, sauf le numéro de version. Les noms de variables, types, valeurs, cibles, commentaires, couleurs et géométries ne sont pas modifiés.

Les contrôles automatisés et le journal de tests sont inclus dans `validation/presentation_0.14.9/`. Tests reproductibles : `pytest -q backend/tests`, avec les fichiers PUB du corpus de recette pour activer les vérifications correspondantes.

## Application et limites

Les PDF historiques sont des fichiers conservés, sans recalcul lors d'une mise à jour. Il faut reconstruire les services et lancer une nouvelle analyse pour voir ces changements. La présence des sections retirées dès 0.14.8 dans un PDF consulté peut signaler un rapport antérieur ; l'installation utilisateur n'a pas été inspectée et cette cause n'est pas affirmée.

Le moteur restitue la conception reconnue, sans exécuter le code embarqué. Les limites existantes de pagination native, de ressources graphiques externes et de scripts contenant des caractères non imprimables restent inchangées. Aucune conformité au moteur de composition Exstream ni aucun déploiement utilisateur n'est revendiqué.
