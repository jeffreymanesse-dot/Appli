# Validation du moteur 0.8.0 — 28 septembre 2026

## Résultat

Trois itérations, 28–30, réalisées à partir de la livraison 0.7.0 préservée. La structure est ajoutée à l’introduction, les trois chapitres complémentaires sont sélectionnables et les livrables techniques ne sont plus exposés dans l’interface, ses liens ou le rapport. Les options sont conservées avec la tâche et restaurées après actualisation. Elles ne changent pas l’extraction du package.

| Source | Chapitres complémentaires retenus | Pages finales | Introduction |
|---|---|---:|---|
| AFR_GENERIC_IARD_VEHIC_NOA_DEVIS.pub | Les trois | 235 | Pages 1–2 |
| AFR_EPI_NOE_BULLETIN_VERSEMENT.pub | Aucun | 16 | Pages 1–2 |
| AFR_GENERIC_PROJET_OBSEQUES_ESSENCIEL.pub | Valorisation et annuaire | 109 | Pages 1–2 |

Les 360 pages finales sont rendues et contrôlées. Les rapports portent le suffixe `Moteur_0.8.0_Iteration_30.pdf`, dans `validation/corpus3/iteration_30` de l’archive de validation séparée. Le ZIP des rapports contient uniquement ces trois PDF.

## Changements réutilisables

- `hierarchy.py` reconnaît l’en-tête APP et sa liste comptée de documents après une liste de sélecteurs opaque. Le profil contrôle la signature, les bornes, les compteurs, l’unicité et les références aux définitions DOC. Les preuves restent associées aux relations ; confiance du profil APP→DOC : TRÈS PROBABLE.
- La hiérarchie utilise les relations document/sections existantes et garde les instances répétées, les positions locales et les noms. La page initiale est présentée séparément du flux de sections : aucun parentage section/page n’est ajouté sans preuve. Pages et paragraphes non rattachés sont signalés séparément. Les cycles interrompent le développement avec une mention explicite.
- `report_options.py` centralise les trois choix, les valeurs par défaut et le plan numéroté. Les rendus structuré et de repli respectent les huit combinaisons. Les rapports de comparaison présentent aussi les structures des deux sources.
- L’API reçoit trois booléens facultatifs : `include_valuation`, `include_input_dictionary`, `include_reconstruction`, tous vrais par défaut. La sélection est enregistrée dans les métadonnées existantes de la tâche, puis lue par le worker. Une sélection vide reste vide. Les tâches anciennes sans options conservent le comportement complet.
- Statut, création des liens et téléchargement filtrent tous les sorties publiques. Un ancien lien signé vers un livrable technique est refusé, même si une ancienne tâche le liste encore. Le modèle interne reste complet et privé.
- L’interface conserve ses couleurs, sa composition et ses interactions existantes. Les ajouts se limitent aux trois cases, au récapitulatif du choix et aux libellés de livrables. Les styles existants sont conservés ; les styles des options sont ajoutés à la fin du fichier.

## Écarts et itérations

| Écart | Correction | Statut |
|---|---|---|
| Structure absente en introduction | En-tête APP, liens DOC et arbre ordonné, avec limites explicites | Corrigé sur les trois sources |
| Chapitres finaux obligatoires | Choix indépendants dans le formulaire, la tâche et le rendu | Corrigé, huit combinaisons testées |
| Sorties techniques encore proposées | Filtrage API/worker/interface, anciens résultats inclus ; retrait des mentions PDF | Corrigé |
| Numérotation après exclusion | Plan recalculé, sans trous ni chapitres exclus dans le plan | Corrigé |
| Plan Obsèques isolé sur une page presque vide en 28 | Hiérarchie plus compacte et plan groupé en 29 | Corrigé |
| Mention de sources isolée sur une page NOA en 29 | Espacement ajusté et sources gardées avec le plan en 30 | Corrigé |
| Affectation exacte de toutes les sections aux pages | Les relations non établies sont séparées au lieu d’être inventées | Limite conservée |

Itération 28 : 362 pages générées et toutes inspectées. Itération 29 : 361 pages, revue ciblée de l’introduction. Itération 30 : 360 pages, toutes rendues. Les 354 images de corps de page inchangées par rapport à 28 sont vérifiées par empreinte du rendu, pied de page exclu ; les six pages d’introduction différentes sont inspectées individuellement. La pagination des pieds de page est vérifiée séparément pour les 360 pages. Ce contrôle ne compare ni les octets ni les métadonnées PDF.

Les zooms supplémentaires portent sur les trois introductions et NOA 62–63 de l’itération 28. Aucun dépassement de marge, page vide, coupure ou superposition importante n’est observé. Le texte est sélectionnable ; les polices effectivement utilisées sont DejaVu Sans et DejaVu Sans Bold, incorporées. Les lignes de tableaux restent insécables. Des algorithmes volumineux et des noms longs rendent certaines pages denses, comme dans la version précédente.

## Tests et preuves

- Base 0.7.0 : 84 tests réussis avant modification. Version 0.8.0 : 107 tests réussis aux itérations 28, 29 et 30, aucun sauté ; un avertissement de dépréciation httpx/Starlette sans échec.
- 23 nouveaux cas : huit combinaisons via API/worker/PDF téléchargé ; huit combinaisons du rendu structuré ; compatibilité des anciennes tâches et interdiction des anciens liens techniques ; rejet des options invalides ; ordre des documents, références invalides, réutilisation des sections, cycles et pages non rattachées.
- Calibration historique : 76/76 contrôles réussis sur Adhésion, Versement, FIP et Obsèques. Les tests de corpus existants couvrent aussi Auto et NOA.
- Comparaison des modèles 0.7.0/0.8.0 sur les trois sources : tous les champs préexistants restent identiques, sauf `engine_version`. Le seul nouveau champ est `applications`. Les modèles des itérations de présentation 28–30 restent identiques.
- Frontend : contrôle TypeScript et build Next.js réussis. Chromium, écrans 1440×1100 et 390×844 : cases par défaut, activation clavier, comparaison à deux entrées, extension invalide, dépôt réel Versement, choix annuaire seul, actualisation, tâche terminée, PDF téléchargé, absence de sortie technique publique et absence de débordement horizontal. Aucune erreur JavaScript observée.
- Le PDF téléchargé par le navigateur contient bien la structure et « 4. Annuaire des données du flux », sans les deux chapitres décochés. Ce contrôle supplémentaire porte sur l’intégration ; les trois PDF du tableau constituent les livrables de revue complète.

Fichiers de preuve : `analysis/tests_iteration30.txt`, `frontend_build.txt`, `browser_checks.txt`, `ui/browser.json`, `non_regression_070.json`, `visual_reuse30.json`, `final_checks.json`, les rendus `analysis/render28` et `analysis/render30`, les modèles/PDF de chaque itération et `validation/revision_v6/calibration_0.8.0.json`.

Les premières tentatives du banc navigateur ont été ajustées pour partager le réseau des services, cibler précisément l’alerte de fichier et fournir une URL de base. Le build initial avec un lien symbolique externe de dépendances a été relancé avec des dépendances locales ; la compilation standard réussit. Ces ajustements de l’environnement de test n’ont pas modifié l’application.

## Sources et limites

Entrées du moteur : uniquement les trois PUB autorisés. Aucun Tools Report, PDF de référence ou donnée de démonstration injecté dans l’extraction. Le code livré, le journal 0.7.0, les tests et les résultats 28–30 sont les autres ressources consultées pour cette évolution. Les sources et la version 0.7.0 sont préservées.

Les limites antérieures restent présentes : NOA `P17.03 / text:6611819`, Obsèques `P17.02 / text:4704658`, quatre origines directes NOA non établies, ordre global des événements et certains paramètres graphiques. Les sources externes ne sont pas simulées. Désactiver le chapitre d’inventaire retire son détail du PDF, sans le supprimer du modèle ; l’introduction et les avertissements locaux restent présents. Aucun décodage exhaustif de tout PUB ni reproduction exacte du moteur Exstream n’est revendiqué.

La recette de cette version ne porte pas sur une nouvelle comparaison au PDF v6 historique : elle valide les changements demandés, le contenu extrait, le rendu et les régressions. Docker Desktop/Windows/PostgreSQL/RQ ne sont pas exécutés ; le parcours intégré utilise SQLite et le worker local.

## Reproduire les contrôles

Installer les dépendances de développement et DejaVu. Placer les six PUB du corpus dans `../project_sources`, aux noms indiqués dans le guide 0.7.0, puis :

```bash
PYTHONPATH=backend python -m pytest backend/tests -q
PYTHONPATH=backend python scripts/validate_revision.py
npm --prefix frontend run typecheck
NEXT_TELEMETRY_DISABLED=1 npm --prefix frontend run build
```

Sans les sources, les tests de corpus correspondants sont sautés. Pour reproduire les trois sélections de rapport, utiliser les cases de l’interface avec les choix du premier tableau. Le banc optionnel `scripts/browser_checks.cjs` requiert Playwright, l’application démarrée et `PUB_TEST_PATH` ; `APP_TEST_URL`, `CHROME_BIN` et `UI_TEST_OUTPUT` sont facultatifs.

Reprise : consulter `ETAT_VALIDATION_MOTEUR.md` et vérifier les empreintes avant de réutiliser les livrables.
