# Validation des compositions et ancrages — Core Report 0.13.2

30 septembre 2026 — itération 42. Base 0.13.1 conservée.

## Résultat

Le moteur reconnaît les listes graphiques compilées A0/107 avec commandes comptées, balises Table/Row/Cell équilibrées et propriétaire rich-text borné qui référence les objets par index et déplacement. Les critères sont des signatures, des compteurs, des coordonnées et des références de police/couleur. Aucun nom de paragraphe, fichier, identifiant client, offset absolu ou empreinte ne sélectionne ce nouveau profil.

NOA, DF_PAR_plusAdvantageShort2_BR : deux tableaux graphiques et une image sur une même ligne ; contours polygonaux arrondis repris depuis les points sources, titre Source Sans Pro Bold 10 pt bleu #00008f et appel (1) 6 pt conservés. Les rôles sémantiques 9/8/7 identifient les tables compilées, indépendamment du libellé « Table 2 ». Ces objets déjà composés sont conservés dans `object_compositions`, séparément des grilles éditables à axes : aucune fausse ligne/colonne n’est créée. Le rapport et le visuel utilisent le même peintre. Géométrie observée : 1548 × 65 unités de 1/300 pouce, soit 371,52 × 15,60 pt ; image 65 × 65 unités entre les deux tableaux.

**Limite non résolue : le contenu de l’image centrale.** Le record graphique fournit son rectangle et des champs de ressource, mais leur liaison aux octets de l’image n’est pas établie. Un cadre croisé occupe exactement ce rectangle, accompagné d’une mention explicite. Aucun pictogramme de remplacement ni image issue d’un PDF de référence n’a été utilisé. L’évolution reconnaît l’objet image ; elle ne prétend pas reconstruire son contenu. Prochaine recherche : établir la signification du descripteur image A0/05, ses références et le répertoire des ressources ; utiliser une variante contrôlée changeant uniquement cette image si nécessaire.

NOA vosAvantages : l’ancrage -251/-106 dans le paragraphe vide accepte désormais les commutations de police/couleur -62/-63 intermédiaires. Le tableau précède la note « Conditions sur axa.fr… ». Le profil reste limité à un propriétaire unique, des indices exhaustifs, des bornes exactes et une suite d’opcodes autorisés. Les ancrages FIP existants restent valides. L’extension trouve aussi un autre ancrage NOA, celui des données personnelles Adhésion (dont variantes) et un tableau Obsèques.

La typographie peut être décodée depuis la grammaire indépendante du texte lorsque le ciblage ultérieur échoue. Les tailles, polices et couleurs ont des frontières vérifiées ; aucune règle non décodée n’est inventée. Le texte promotionnel NOA retrouve ses 8 pt. Autres récupérations : une unité Adhésion, quatre FIP, une Obsèques et une dans chacune des variantes. La propriété de lien/ciblage NOA reste opaque, sans empêcher ce rendu.

Les fragments conditionnels du visuel et des résumés de lignes sont encadrés : `[1] [2] [3] mois…` et `remboursé[s]`. Cela distingue les fragments sans évaluer les conditions ni supposer leur exclusivité. Le rapport conserve ses repères Rn et algorithmes. Les crochets constituent une convention documentaire, et non un caractère source ; les variables continuent aussi à être encadrées.

## Architecture

| Fichier | Rôle |
|---|---|
| backend/retro/object_composition.py | Grammaire A0, balises équilibrées, polygones, positions de glyphes, rectangle d’image ; association aux objets inline |
| backend/retro/object_render.py | Peinture commune à coordonnées sources ; substitution de police selon le mécanisme existant ; image non résolue explicitée |
| backend/retro/parser.py, visual_model.py | Enrichissement du modèle principal et du modèle de présentation |
| backend/retro/table_anchors.py | Extension bornée des commutations avant l’objet ancré |
| backend/retro/scopes.py, visual_graphics.py | Police/couleur depuis le texte indépendant ; portée conditionnelle non élargie |
| backend/retro/visual_render.py, report_structure.py | Composition, placements, conservation des autres contenus du paragraphe et séparation des fragments conditionnels |
| backend/tests/test_object_composition.py | 12 nouveaux tests : cas réel, données synthétiques, décalage/renommage, corruptions, image non résolue, typographie et conditions |
| backend/tests/test_visual_export.py | Comptages exacts actualisés et vérification des identifiants nouvellement stylés |
| scripts/validate_presentation_corpus.py | Audit des compositions ajouté aux preuves existantes |

## Vérification

231 cas uniques validés, aucun échec résiduel ni saut : suite globale puis reprise ciblée des six profils graphiques après ajustement des attentes de couverture. Les premiers échecs étaient quatre attentes de comptage anciennes ; le premier lancement avait aussi omis PUB_TABLE_CORPUS. Ces incidents du banc n’ont pas nécessité de changement du moteur après les PDF finaux. Les journaux de la suite globale et de la reprise sont conservés, avec une synthèse qui distingue les deux exécutions. Avertissement Starlette/httpx préexistant.

12 chemins / 11 empreintes PUB distinctes ; 22 PDF / 1982 pages. Comparaison avec 0.13.1 : faits sources, topologies existantes, textes et ciblages reconnus inchangés ; tous les anciens contenus visuels conservés. Aucun manque, doublon de placement, ligne coupée ou paragraphe excessif signalé par le visuel. Aucun PDF vide, page vide ou texte hors page. Les polices récupérées et nouveaux ancrages enrichissent la présentation ; les modèles entiers ne sont pas prétendus identiques.

Revue : onze pages du visuel NOA sur planches, zoom de la page 2 ; rapport NOA pages 14/15/108 ; Adhésion visuel page 1 ; Obsèques visuel page 4. Les autres pages sont contrôlées automatiquement, sans revendication de revue humaine exhaustive.

| PUB | Rapport | Visuel |
|---|---:|---:|
| AFR_GENERIC_IARD_VEHIC_NOA_DEVIS.pub | 280 | 11 |
| 03-AFR_EPI_NOE_BULLETIN_ADHESION.pub | 176 | 10 |
| 04-AFR_EPI_NOE_BULLETIN_VERSEMENT.pub | 133 | 5 |
| 05-AFR_GENERIC_FIP_DEVIS_ESSENCIEL.pub | 174 | 10 |
| 06-AFR_GENERIC_PROJET_OBSEQUES_ESSENCIEL.pub | 131 | 8 |
| 07-AFR_IARD_DEVIS_AUTO.pub | 126 | 13 |
| AFR_EPI_NOE_BULLETIN_ADHESION_Color.pub | 171 | 10 |
| AFR_EPI_NOE_BULLETIN_ADHESION_Round.pub | 171 | 10 |
| AFR_EPI_NOE_BULLETIN_ADHESION_Width.pub | 171 | 10 |
| AFR_EPI_NOE_BULLETIN_ADHESION_Black.pub | 171 | 10 |
| AFR_EPI_NOE_BULLETIN_ADHESION_BorderPink.pub | 171 | 10 |

## Reproduction et limites

Depuis le projet : `PYTHONPATH=backend PUB_TABLE_CORPUS=/chemin/corpus python -m pytest backend/tests -q`. Les six PUB historiques doivent être présents dans `../project_sources`, et les variantes dans les sous-dossiers `pub_variants` / `pub_variants2` de PUB_TABLE_CORPUS. Sans les sources client, certains tests sont explicitement sautés. Les sources ne sont pas redistribuées.

Les nouvelles signatures ne prouvent pas la prise en charge universelle de tout objet Exstream. Opérations graphiques inconnues, images non reliées, liens/soulignement non calibrés, pagination native, évaluations des règles et ressources externes restent partiels. La calibration graphique NOA historique existante n’a pas été étendue à d’autres empreintes ; le nouveau profil de composition n’utilise pas cette calibration. Pas de recette Docker/Windows/navigateur/PostgreSQL/RQ ni de déploiement dans cette itération.
