# Profils de lecture PUB — moteur 0.7.0

Ce sont des profils empiriques contrôlés sur les packages fournis, pas une spécification officielle d’OpenText. Le décodeur ne lit ni PDF de référence ni Tools Report. Les noms, identifiants et offsets métier servent aux tests du corpus et à cette documentation ; ils ne pilotent pas les branches du moteur.

Le profil 0.4.0 est conservé dans `PROFIL_PORTEES_PUB_0.4.0_HISTORIQUE.md` pour la reprise. Sa supposition de deux copies concordantes d’index dans les propriétés de paragraphe est **invalidée** par Adhésion/FIP. Le présent document et `scopes.py` décrivent le profil actuel.

## Ordre et périmètre

`structure.py` consomme le record racine DOC 120, ses compteurs et les membres 205/206 des sections imbriquées. Il conserve les références non résolues, contrôle les bornes et les cycles. L’ordre obtenu vient des relations sérialisées, pas des offsets des noms. Les instances répétées d’un même PAR ne sont pas toutes développées ; cette limite reste dans le modèle.

Pour les documents sans PAR, les ouvertures 111/classe 24 et fermetures 104 de même ID permettent d’établir le parentage de page. Les grilles sont rattachées à leur page. L’ordre entre régions et objets libres Auto n’est pas démontré et demeure explicitement inconnu.

## Portées internes : OBS-richtext-bounded-properties-v2

Le lecteur consomme successivement :

1. l’enveloppe du texte à longueurs redondantes ;
2. le flux de glyphes jusqu’à sa terminaison ;
3. la table de lignes de taille contrôlée ;
4. le répertoire indépendant des variables ;
5. les tables de polices et le style final ;
6. la liste locale de règles à compteur redondant ;
7. la chaîne des propriétés propriétaires, reconstruite jusqu’aux frontières vérifiées.

Les instructions -244 ouvrent les paragraphes ; -254/-110 encadrent les fragments ciblés. -384/-111 encadrent les variables. Les contrôles de composition reconnus mais non interprétés restent dans `opaque_controls`. L’opcode -240 observé dans Auto n’est pas accepté : son arité n’est pas démontrée.

Les positions comptent les caractères du payload de conception, **pas** les caractères du courrier après évaluation. Une valeur de conception peut être différente du nom de variable. L’ID, les bornes et le flag du répertoire variable doivent corroborer le flux de glyphes ; la valeur brute est alors conservée comme `design_value`, et le PDF affiche le nom de variable. Un en-tête de format imprimable n’est retiré qu’avec cette preuve indépendante. Une variable partiellement ciblée est rejetée.

Le style est atteint par consommation de la structure, jamais par proximité avec un mot. Les propriétaires acceptent les variantes de suffixe 214/226 octets, préfixes 120 ou de taille contrôlée, préambules de style et en-têtes 256/272. Plusieurs chaînes candidates ou une borne incohérente font échouer le décodage.

Dans une propriété de paragraphe, **le champ +56 est l’index local de ciblage**, contrôlé contre la liste locale ; `0xffffffff` signifie aucun index sur ce profil. Le champ +4 est conservé dans `raw_leading_property` : il n’est pas interprété comme une seconde copie générale de l’index. Les bornes de la chaîne entière, un extrait binaire et son empreinte accompagnent la preuve.

Le rouge du PDF est réservé aux cibles démontrées : ligne, colonne, paragraphe ou fragment. Le seul caractère dynamique d’une variable ne déclenche pas cette couleur. Les conditions source et compilées sont conservées. Seules les formes reconnues reçoivent une traduction ; une valeur absente ou nulle n’est jamais assimilée automatiquement à la branche opposée.

## Tables et répétitions

Les axes contrôlent deux variantes de sentinelle avec les enveloppes voisines et les propriétés de police. Chaque colonne est inspectée même sans Repeat : largeur, 17 champs bruts et statut d’interprétation sont conservés. Une cellule candidate dont le style consommé contredit le trailer est rejetée avec sa preuve.

Le profil de Repeat-C exige la suite de propriétés contrôlée : +36=2, +40=1, +44=ID du driver, +48=0, +52=1. Le driver doit être une variable Array connue ; il n’est pas choisi parmi les variables visibles. Deux cas sont démontrés dans Adhésion. Les répétitions de lignes gardent de même le driver sérialisé et leurs preuves. Seuls les profils de ciblage de colonnes et d'étendue horizontale décrits plus bas sont interprétés ; autres fusions, ciblages et politiques d'indexation restent non interprétés.

## Sources XML : OBS-source-descriptor-163-v2

Les mappings viennent des records 115 avec IDs, parents et bornes contrôlés. Leur origine INPUT exige une source propriétaire unique et un descripteur 163 valide. Celui-ci contient un en-tête, une chaîne Pascal de rôle puis une chaîne Pascal de chemin.

L’ancien test d’octets `INPUT ` était faux : l’espace était en réalité la longueur 32 du chemin suivant. Auto possède une longueur 62. Le nouveau lecteur sépare les deux chaînes, vérifie leurs bornes et conserve les preuves. Un mot INPUT dans le chemin ou une racine XML `/flow` ne suffisent jamais à classer une source comme flux d’entrée. Les sources de référence sont séparées ; les cas non résolus restent `unknown`.

## Validation et limites

Les tests comprennent les six PUB disponibles, des altérations de l’index de ciblage et du répertoire variable, les sentinelles d’axes, les descripteurs de source et l’export PDF vide. Les résultats historiques figurent dans `VALIDATION_CORPUS_0.5.0.md` et `VALIDATION_MOTEUR_0.6.0.md` ; NOA, les nouveaux profils et les contrôles finaux sont dans `VALIDATION_MOTEUR_0.7.0.md`.

Ce profil ne donne pas les ressources graphiques Exstream, la pagination évaluée, les valeurs client, l’ordre global d’exécution ni toutes les propriétés binaires. Une erreur de décodage conserve le contenu et les preuves disponibles, accompagnés de son motif ; elle ne devient pas une absence de règle ou de répétition.


## Ciblage de colonnes : OBS-column-targeting-v1 (0.6.0)

Le lecteur part d'une colonne issue des axes bornés et des enveloppes redondantes déjà contrôlées. Au début `q` de sa propriété, le champ `q+16` référence une règle compilée. Le profil exige `+4=1`, `+12=0`, `+20=0`, `+68=0xffffff9a` et `+72=4`. L'ID non nul doit exister dans le catalogue de règles. Un ID inconnu ou un garde invalide reste non interprété ; zéro sur ce profil indique seulement l'absence de règle sur ce champ reconnu. Le champ +8 n'est pas utilisé comme constante.

L'association `grid_column` désigne la table, l'index de colonne, les contenus rattachés et l'offset exact de la référence. Elle couvre aussi les cellules vides de la colonne. La grille n'est pas déduite du texte ou du nom de la règle. Les fusions ne sont pas déduites de cette association. Obsèques fournit trois cas aux offsets 4575518, 4576275, 4577032 ; les tests altèrent séparément l'ID et le garde.

## Valorisation statique : OBS-static-assignment-v1 (0.6.0)

Les affectations `UserLogic.setValue`/`setValueAt` sont recherchées dans les calculs et dans toutes les variantes de règles compilées. Le parseur masque commentaires et chaînes pour détecter les appels, consomme leurs parenthèses équilibrées, puis résout une cible uniquement par ID connu ou nom exact. Les arguments et leur code brut, l'offset, le rang lexical, les lectures directes de l'expression et les IF/ELSE englobants reconnus sont conservés. Les dépendances via une variable locale restent à lire dans l'algorithme complet ; aucun ordre global ni résultat de branche n'est évalué.

Les arguments des appels de fonctions sont également conservés, notamment les clés littérales d'images dans initCust. Le propriétaire conserve son nom métier et son ID compilé. Les sources de règles bornées peuvent commencer par `Dim` avant la condition : sélectionner uniquement un début IF perdait les calculs de recherche d'index Obsèques.

## Pages et annotations (0.6.0)

`page_components` reprend les définitions de classe 24 avec leurs preuves. Une relation de première page est exposée uniquement si le record DOC la fournit ; l'ordre des instances de pages n'est pas déduit de leur nom. Les titres de calculs et règles privilégient les noms sérialisés, y compris accentués.

Le PDF marque le début et la fin de chaque portée par `[Rn]` et `[/Rn]`, au niveau paragraphe ou fragment et jusqu'au milieu d'un token statique si nécessaire. Une variable dynamique non ciblée reste noire. Une cible vide est conservée dans les preuves sans colorer son voisin. Les fiches courtes et annotations sont gardées ensemble ; le titre du chapitre des fiches garde assez de place pour la première fiche.

## Condition du composant PAR entier : OBS-paragraph-global-rule-136-v1 (0.7.0)

`component_properties.py` exige une ouverture 111/classe 21 et une définition 104/classe 21 de même identifiant. À partir de la fin du nom de définition, le record 136 doit se trouver à +44 ; sa référence de règle est à +48 dans le record (soit name_end+92). Les tags précédents 102/103/104, champs +40/+44 et tags suivants 120/121/122/123 sont contrôlés avec les bornes. L'identifiant doit appartenir au catalogue compilé pour produire une association `paragraph_global`.

Zéro n'indique aucune règle que pour ce champ reconnu. Un identifiant inconnu reste `unresolved_rule_id`. Aucune association ne vient d'une occurrence voisine du nom ou du numéro. La preuve est marquée TRÈS PROBABLE car le profil est empirique. Exemple NOA : PAR 21:25233, champ à 4556914 = 524781/DF_RUL_pdf. Une corruption du garde supprime l'association attendue dans le test.

## Contenu indépendant et préfixes de propriétés (0.7.0)

Le flux de glyphes, sa longueur, le répertoire variable, les frontières de paragraphes et la terminaison peuvent être validés avant la chaîne propriétaire des règles. Si cette dernière échoue, `text_structure` conserve le contenu et les noms démontrés, tandis que `scope_decode_issue` conserve le motif et les octets ; aucune cible interne n'est ajoutée. Une condition globale indépendamment prouvée reste distincte de cet échec.

Les variantes de propriétés à préfixe borné et puces de types 1–5 sont consommées avec leurs longueurs et terminaisons ; le nombre de paragraphes dans le premier préfixe constitue un contrôle supplémentaire. Une table locale de règles vide 2/1/0 n'est acceptée qu'à sa position structurelle validée. Le contrôle -252 de forme reconnue, argument nul, avec ouverture -62 et fermeture -109 positive est conservé comme opaque : cela permet de valider un payload, pas d'inventer le sens de ses propriétés de lien. L'opcode -240 d'Auto reste rejeté.

NOA Conducteurs_Assures (`text:4743194`) fournit 16 paragraphes et 25 cibles contrôlées. Un index de ciblage volontairement corrompu dans le test fait échouer la portée tout en préservant les noms de variables et leur couleur neutre.

## Grilles multiples et imbriquées : OBS-counted-table-108-v1 (0.7.0)

L'ouverture int32 -108 est corroborée par le préambule de 44 octets, ses compteurs de colonnes/lignes et son champ nul. Les groupes d'axes -103/-109 sont validés indépendamment ; leur pied à signature contrôlée ferme la grille. La grille ouverte la plus interne doit avoir les mêmes compteurs. Toute ouverture non appariée, croisement ou coordonnée d'enfant hors limites rejette ce profil, sans aplatir arbitrairement les tables.

Une grille enfant est rattachée à la cellule de son parent par le trailer -105 et ses coordonnées sérialisées. Les coordonnées d'ordre sont alors hiérarchiques. Les règles de ligne externes restent associées aux contenus imbriqués. Exemple NOA Garanties : racine à 4920109 (7 × 19), enfant à 5012737 (3 × 23) dans la cellule parent (ligne 9, colonne 0). Le test altère un compteur pour vérifier le rejet de l'arbre partiel.

## Étendue horizontale : OBS-cell-horizontal-extent-v1 (0.7.0)

Dans une cellule déjà rattachée à une grille contrôlée, la propriété packed exige mode nul à +16, champ nul à +17, span à +21, champs nuls à +25 et +33. Le span doit être compris entre 1 et les colonnes restantes ; il ne peut recouvrir une autre cellule occupée de cette ligne. Ces gardes permettent une étendue horizontale TRÈS PROBABLE, jamais une fusion déduite d'un blanc ou d'un libellé long. Les étendues verticales et autres modes ne sont pas interprétés.

## Restitution documentaire (0.7.0)

Les titres sont les noms PAR. Les règles d'un bloc sont dédupliquées par ID compilé dans le récapitulatif Rn/nom/algorithme. Le chapitre séquentiel et les commentaires de portée interne sont supprimés selon la demande du 28 septembre. Le catalogue garde ses informations et renvoie aux algorithmes déjà présentés.

Les frontières internes deviennent des retours, y compris dans un token littéral. Le rendu affiche les noms démontrés des variables, pas leurs `design_value`. Les tableaux utilisent les grilles, largeurs relatives et spans reconnus. Les lignes et repères sont insécables ; les grands tableaux peuvent se répartir entre pages par lignes entières. Le chapitre des propriétés détaille uniquement les axes ayant règle ou Repeat, avec leur contenu complet. Le modèle conserve néanmoins l'inspection de toutes les colonnes et les propriétés brutes non comprises.
