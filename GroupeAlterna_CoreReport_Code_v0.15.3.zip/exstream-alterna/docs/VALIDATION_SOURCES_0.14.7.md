# Groupe Alterna — Validation Core Report 0.14.7

8 octobre 2026. Base : livraison complète 0.14.6, conservée sans retrait de fichier.

## Demandes et résultat

| Demande | Correction |
|---|---|
| Retirer la partie du référentiel système | Section supprimée du rapport ; données conservées dans le moteur pour reconnaître les variables utilisées. |
| Retirer les empreintes et les mentions « Source de conception » | Absentes des 15 rapports contrôlés. Les preuves restent internes. |
| Retirer les deux paragraphes sous le nom du PUB | Introduction allégée, conservant le nom, le tableau de périmètre et la structure. |
| Renommer les chapitres | « 1. Vue détaillée » et « 4. Variables et fonctions » dans le rapport standard et son plan. |
| Ne jamais afficher le code compilé | Suppression des replis vers le JavaScript et des expressions compilées dans les fiches de variables, fonctions et inventaires de règles. |
| Garder les commentaires et la forme des scripts | Extraction sans restriction sur le premier mot, conservation des commentaires et blancs, mise en page en police à chasse fixe ; octets originaux joints au PDF. |
| Corriger R3 et R6 | Lecture des propriétés natives de comparaison, sans fabriquer un script absent. |
| Vérifier la couleur des deux premiers paragraphes | Même bleu source confirmé ; fonds différents conservés. Résolution RGB et palette commune aux textes riches et objets graphiques. |

## Causes établies

L’ancien lecteur n’acceptait que certains débuts de script. Il ignorait notamment des textes commençant par `Integer`, `String`, `Resize(...)`, une affectation directe ou des lignes vides. De plus, certaines vues supprimaient les commentaires et revenaient au code compilé quand aucun script reconnu n’était disponible.

Le nouveau lecteur vérifie le champ texte complet, sa longueur, sa terminaison et ses limites à l’intérieur du propriétaire. Il ne traduit pas le JavaScript et ne complète pas un texte manquant. Les expressions d’affectation dérivées du compilé ont été retirées de la présentation ; les fiches renvoient au script réel de la fonction ou de la règle.

Dans le dernier Bulletin, R3 et R6 conservent une variable, une comparaison d’égalité et un littéral. La source textuelle originale n’est pas présente dans leur enregistrement reconnu. Le rapport présente donc les paramètres : `DF_FIC_SD_NOE_gest_infoClient_citoyenAmericain`, égalité, `true` pour R3 et `false` pour R6. Cela ne permet pas d’affirmer comment le développeur avait saisi ces règles dans l’éditeur.

Le même contrôle concerne R22, R27, R28 et R29. Le moteur ne transforme plus les branches `else` du compilé en instructions source `ELSE EXCLUDE`. Les scripts réellement présents conservent, eux, toutes leurs branches et tous leurs commentaires.

## Couleurs et mise en forme

Le titre `PAR_AFR_EPI_NOE_BULLETIN_VERSEMENT_TITRE`, les coordonnées du conseiller et le texte du contrat utilisent le même RGB `(0, 0, 143)`, soit `#00008f`. Le conseiller n’a pas de fond explicite, alors que l’en-tête du contrat a un fond bleu. Le titre emploie aussi une police et une graisse distinctes, enregistrées dans le package. Le contraste de fond et la graisse expliquent la différence perçue ; aucun changement arbitraire de teinte n’est appliqué.

Le résolveur de couleurs est partagé entre les objets graphiques et les textes riches. Les profils inconnus restent non résolus. Les compositions et couleurs préexistantes des 15 modèles sont conservées.

Les noms de chapitres, les suppressions et les styles de code sont communs aux sorties concernées. Le logo et les actifs de la marque sont inchangés. Le rapport conserve son profil technique compact et le visuel conserve les styles du PUB ; les longs scripts restent consultables et copiables sans retours de mise en page dans la pièce jointe.

## Conservation des sources

Sur le dernier Bulletin : 148 règles, 117 scripts de règles natifs et 31 présentations paramétrées ; 57 calculs/fonctions avec leur script natif, dont 16 récupérés en plus. Les variantes identiques sont regroupées pour l’affichage sans fabriquer de source.

Le chapitre 4 conserve son périmètre de 31 calculs/fonctions rattachés ou fournisseurs de références. Les autres restent dans l’inventaire. L’archive jointe contient tous les scripts natifs récupérés du package, y compris ceux hors de ce périmètre.

`DF_FCT_removeAccentuatedChars` contient des octets non imprimables dans une table de caractères. Le PDF affiche une notice à sa place ; son texte intégral est conservé byte pour byte dans la pièce jointe et dans l’archive séparée. Les autres scripts du périmètre sont imprimés avec leurs commentaires. Aucun code compilé n’est joint.

Les `.bas` conservent les fins de ligne, les espaces et les octets Windows-1252 d’origine. Les `_parametres.txt` sont une description UTF-8 des propriétés, pas un export inventé de script. Les empreintes sont vérifiées lors de l’archivage mais ne sont pas affichées dans le rapport.

## Vérifications

- Suite complète : 404 tests réussis, aucun échec ni saut ; un avertissement de dépréciation Starlette/httpx préexistant.
- Tests ciblés après les derniers ajustements de présentation : 56 réussis ; résultat consigné dans `validation/sources_0.14.7/tests_targeted_final.log`.
- 15 modèles comparés à 0.14.6 : 4 409 algorithmes compilés de règles/calculs inchangés ; 3 544 sources natives vérifiées sur les octets des PUB, dont 358 retrouvées en plus ; 538 enregistrements de comparaisons paramétrées.
- Les champs préexistants restent identiques après retrait des annotations de source. Une règle WEBLURE récupérée enrichit les preuves et la confiance de ses liens existants, sans changer leurs cibles, leur ordre ou leur portée. Cette différence précise est contrôlée et journalisée.
- 15 rapports régénérés : absence des mentions demandées et du code compilé, présence des scripts du périmètre sans réécriture, contrôle des pièces jointes et des paramètres, aucune page de contenu vide ni texte hors page.
- Dernier Bulletin : rapport de 128 pages et visuel de 8 pages, parcourus intégralement en planches ; agrandissements du titre/conseiller, R3/R6 et des commentaires de `DF_FCT_title_build`. Aucun contenu manquant dans l’audit du visuel.

Les preuves compactes sont dans `validation/sources_0.14.7/`. Le contrôle des modèles est reproductible avec `scripts/validate_design_sources.py`, les PUB du corpus et les modèles de référence 0.14.6.

## Limites et mise en service

Le format textuel absent de R3/R6 ne peut pas être récupéré fidèlement depuis le seul compilé. Un export de l’éditeur serait nécessaire pour comparer ce format avec ce qui a été saisi. Les propriétés non reconnues ne donnent lieu à aucune invention.

Les limites antérieures sur la pagination native, les ressources externes et les propriétés non décodées restent applicables. Aucun algorithme embarqué n’a été exécuté ni corrigé. Aucun déploiement sur le poste utilisateur ni validation par Exstream natif n’est revendiqué.

Conserver `.env` et les volumes, reconstruire les services pour installer la dépendance `pypdf`, puis créer une nouvelle analyse. Les anciens rapports restent inchangés.
