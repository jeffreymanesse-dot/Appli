# Groupe Alterna — Validation Core Report 0.14.8

8 octobre 2026. Base complète : Core Report 0.14.7.

## Demande appliquée

Le chapitre 4 affiche désormais les arguments d’entrée et leurs types uniquement lorsqu’ils sont déclarés. Le type de retour est affiché uniquement pour les objets de type `Function`. Le code natif est regroupé sous `Logic` pour les fonctions et sous-routines, sous `Formula` pour les variables calculées.

Les listes générées « Lectures » et « Écritures », les fiches de dépendances détaillées et les paragraphes de provenance sont retirés de ce chapitre pour ne conserver que la signature utile et le script. Les fonctions fournisseurs de références restent présentes, une seule fois. Les données de provenance sont conservées dans le modèle interne.

## Décodage

Le profil `OBS-function-declaration-103-v1` lit la déclaration dans son propriétaire de classe 159 : enveloppe de propriétés, nature Function/Subroutine, type de retour et nombre d’arguments. Chaque argument est lu dans un enregistrement compté avec nom, type, indicateur de tableau, caractère facultatif et terminaison vérifiée. Les champs de format et de passage sont conservés ou contrôlés sans servir à deviner un type.

Une déclaration invalide, tronquée, ambiguë ou de profil inconnu n’est pas affichée. L’absence de signature reconnue n’est pas assimilée à une déclaration sans argument. Aucun type n’est extrapolé depuis le code compilé, le nom de l’argument ou un commentaire.

Les noms et l’ordre des paramètres sont également recoupés avec la signature compilée pour la validation. Le compilateur remplace les arguments passés par référence par des alias techniques : ce cas est vérifié séparément, tout en conservant le nom natif dans le rapport. Cette vérification ne fournit pas les informations affichées et n’exécute aucun code.

## Résultat sur le dernier Bulletin

Le package contient 37 déclarations reconnues : 13 `Function` et 24 `Subroutine`. Le chapitre 4 conserve le même périmètre de 31 calculs : 7 `Function`, 18 `Subroutine` et 6 formules de variables, soit 25 zones `Logic` et 6 zones `Formula`.

| Exemple | Présentation |
|---|---|
| `DF_FCT_APPLI_get` | Argument `argMd_key : String`, puis `Logic` ; aucun type de retour. |
| `DF_FCT_COPY_init` | `Logic` directement, sans argument ni retour ajoutés. |
| `DF_FCT_COPY_counterOnGoingDependingOnRecipient` | Argument `argMd_recipientNumber : Integer`, retour `Integer`, puis `Logic`. |
| `DF_FCT_title_build` | Deux arguments `String` facultatifs, puis `Logic`. |
| `WRK_AFR_EPI_NOE_BULLETIN_VERSEMENT_initCust_BR` | Code original sous `Formula`. |

Le rapport comporte 118 pages. Les scripts imprimables de son périmètre sont présents sans réécriture ; leurs commentaires sont conservés, même s’ils décrivent eux-mêmes des entrées et sorties. Les sources jointes au PDF sont identiques octet pour octet à celles de 0.14.7.

La fonction contenant des caractères non imprimables garde sa notice et son texte intégral dans la pièce jointe, comme en 0.14.7. Aucun caractère n’est remplacé pour produire un faux code lisible.

## Validation

- 19 nouveaux tests : types de retour, arguments ordonnés, tableaux, arguments facultatifs, absence d’arguments, distinction Function/Subroutine, rejet des champs corrompus et présentation dans les deux chemins de rapport.
- Suite complète : 423 tests réussis, aucun échec ni saut ; un avertissement de dépréciation préexistant. Résultat consigné dans `validation/logic_0.14.8/tests_full.log`.
- Comparaison sur les 15 packages du corpus : 738 déclarations natives vérifiées. Les champs préexistants du modèle restent identiques, hors version ; seules les déclarations natives s’ajoutent. Les scripts, algorithmes compilés, relations, couleurs et mises en page source sont inchangés.
- Contrôle du PDF : absence des listes retirées et du code compilé, présence des scripts natifs attendus, des paramètres et des zones `Logic`/`Formula`, absence de débordement hors page et de page de contenu vide.
- Revue des 118 pages en planches et agrandissement de fiches de sous-routine, de fonction avec retour et de variables avec formule.

Le contrôle des modèles est reproductible avec `scripts/validate_function_signatures.py`, les packages sources et les modèles 0.14.7. Les résultats compacts sont conservés dans `validation/logic_0.14.8/`.

## Limites

Les signatures reconnues sont des déclarations, pas une simulation de l’exécution. Les types inconnus ne sont pas présentés comme certains. Les limites antérieures de pagination native, ressources externes et propriétés non reconnues restent applicables. Aucun déploiement utilisateur ni validation native Exstream n’est revendiqué.
