# Migration initiale 001

Implémentation exécutable : `backend/retro/db.py`, fonction `initialize()`.
Elle crée `schema_migrations`, contrôle la version, crée la table `jobs` et ses index, puis inscrit la version 1 dans la même transaction. Verrou PostgreSQL transactionnel ou BEGIN IMMEDIATE SQLite pour éviter deux initialisations concurrentes. Une version inconnue provoque un arrêt.

Données : propriétaire haché/opaque, tâches, historique d'étapes, horodatages, empreintes d'entrée, noms de sortie, version moteur et réservation disque. Aucun contenu documentaire dans les logs. Les métadonnées de tâche restent privées ; noms de fichiers et empreintes sont présents dans cette base.

Première installation : l'API et le worker appellent `initialize()`. Mise à jour future : sauvegarder la base, ajouter une migration explicite version 2 et tester sur une copie. Ne pas supprimer le contrôle de version. Aucun retour arrière destructif automatique fourni.
