# Validation Core Report 0.11.0 — itération 37

Date : 29 septembre 2026. Base : 0.10.0 préservée, copie isolée.

## Identité et couverture

- Core Report mis en valeur dans l'introduction de l'IHM, titre de l'onglet et pied de page.
- Accroche autorisée explicitement par l'utilisateur, réservée à l'IHM et traduite en anglais. Cette accroche de produit n'est pas présentée comme un slogan institutionnel du Groupe.
- Fond JPEG CMJN et logo 825 px fournis copiés sans modification. Couverture A4, proportions conservées, pas de transparence ajoutée, texte marine sélectionnable et police DejaVu incorporée.
- Nom tiré de `applications` et des structures décodées pour les comparaisons, jamais du nom du fichier. Noms multiples, longs, accents et caractères XML protégés ; absence de nom explicitement signalée en FR/EN.
- Gabarit commun aux rapports structurés, aux rapports partiels et aux comparaisons. Une seule page ajoutée, sans pied ni numéro ; pagination intérieure conservée. Aucun changement du visuel du courrier.

## Corpus et conservation du contenu

| Package | Application décodée | Rapport FR | Rapport EN | Visuel FR/EN |
|---|---|---:|---:|---:|
| Bulletin de Versement | APP_AFR_EPI_NOE_BULLETIN_VERSEMENT | 126 | 127 | 5 / 5 |
| FIP Essenciel | APP_AFR_EPI_NSE_FDC_DEVOIR_DE_CONSEIL_ESSENCIEL_BR | 173 | 174 | 9 / 9 |

Huit PDF, 628 pages. Quatre couvertures ajoutées ; les 624 pages préexistantes ont le même texte et le même rendu que 0.10.0, après exclusion du seul numéro de version du moteur. Comparaison par page, et non des octets ou métadonnées PDF. Le cache de redimensionnement des images du moteur de rendu est vidé entre pages pour éviter des écarts artificiels d'anticrénelage sur le logo.

Les 628 pages ont été rendues. Les quatre couvertures et des pages représentatives d'introduction, de tableaux et de limites ont été inspectées en images issues de Poppler. Aucun mot hors page signalé. Pas de nouvelle inspection humaine ligne par ligne des 624 pages inchangées : leur conservation est vérifiée automatiquement.

## Tests et interface

Les tests de couverture vérifient le nom source exact, les caractères spéciaux, les noms longs et multiples, le cas inconnu, la pagination et la comparaison. Les tests FR/EN, exports, sécurité, quota et les régressions des six PUB sont relancés.

Le test de succès de comparaison utilisait une réserve artificielle de 2 Mio, inférieure au poids des trois fonds originaux. Sa réserve est portée à 5 Mio pour ce seul scénario de test. Les scénarios de refus, concurrence et saturation conservent leurs seuils, et les quotas de l'application restent inchangés.

Next.js/TypeScript compilent. Navigateur réel : nom Core Report, accroche FR/EN, bureau 1 440 px et mobile 390 px, clavier, actualisation, choix de fichier et options conservés, analyse Versement et deux téléchargements réels réussis. Aucun débordement horizontal ni erreur JavaScript observé.

Résultat final : **150 tests réussis, zéro échec et zéro saut**, 79,89 secondes. Un avertissement de dépréciation Starlette/httpx subsiste. Les preuves sont conservées avec le journal.

## Sources et limites

Consultés : application 0.10.0, journal canonique v24, charte et instructions, fond.docx et ses en-têtes, JPEG CMJN et logos joints, gabarits PDF, modèle de hiérarchie, IHM et tests. Deux PUB analysés à nouveau : Versement et FIP. Régressions existantes sur les six packages. Aucun Tools Report ni remplacement du PDF de référence.

La demande explicite d'une accroche de produit prévaut sur l'interdiction générale d'inventer un slogan dans la charte. Le dessin du logo reste intact.

Validation locale Python/SQLite et worker séparé. Pas de recette Docker/Windows/PostgreSQL/RQ. Aucune nouvelle capacité de décodage ni fidélité graphique native supplémentaire revendiquée.
