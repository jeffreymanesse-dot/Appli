# Écarts et acceptation

État : 26 septembre 2026, moteur 0.1.2. Les termes « conforme » ci-dessous portent uniquement sur le contrôle indiqué. Aucun oracle documentaire complet n'est disponible.

| Élément attendu | Référence / preuve | Sortie moteur | Catégorie | Correction / prochaine action | Statut |
|---|---|---|---|---|---|
| Header admissible | 4 fichiers, offsets 0/4/24/49 | Reconnaissance des deux profils | Erreur initiale | Retirer la fausse équivalence champ 24 = longueur exacte ; borner le pointeur candidat | Corrigé 0.1.1 |
| ID/type/cardinalité de 3 variables | 18 contrôles par fichier ; offsets figés | Identiques | Aucune | Maintenir ces fixtures de calibration privées hors Git | 72 conformes |
| Catalogue IDs compilés | 1 comparaison exhaustive de liste par fichier | Identique | Aucune | Maintenir les quatre listes indépendantes | 4 conformes |
| Expressions sources | Versement rule790284 : header 5139588, source 5139839, compilé 5140081 | 0 liaison en 0.1.1 ; 100 règles liées sur Versement en 0.1.2 | Omission | Lecteur uint32 et header de règle avec même ID | Corrigé pour ce profil ; autres cas ouverts |
| Faux d'une règle simple | Source + valeur initiale numIncludes dans code | Inféré seulement si schéma simple strict | Incertitude | Garder inconnu pour les branches complexes | Partiel |
| Ordre APP/DOC/PAG/CMP/PAR | Références de conception absentes ; graphe non décodé | Identifiants/offsets sans ordre métier | Mauvais ordre évité, omission restante | Décoder listes de références parent/enfants | Ouvert, bloquant métier |
| Visuel complet et Pxx | Exigence cahier des charges | Rubriques signalées non disponibles | Présentation / omission | Reconstruire après validation des relations et frontières | Ouvert, bloquant métier |
| Cibles et portées exactes Rn | IDs recherchés sous forme uint32 | Occurrences candidates ; aucun ciblage certain | Portée imprécise | Décoder le champ et son record propriétaire | Ouvert, bloquant métier |
| Tables/lignes/colonnes/cellules | Deux signatures anneeRac Adhésion ; quatre candidates ligne Versement | Candidats avec driver, sans parent prouvé | Mauvaise association évitée / omission | Décoder parentages, fusions, toutes colonnes et propriétés | Ouvert, bloquant métier |
| Échantillons, formats, lookup, paramètres | Pas de preuve de liaison suffisante | Non déterminé / code brut | Omission | Décoder les records et sites de valorisation | Ouvert |
| Annuaire des seuls champs utilisés | Mappings source décodés ; usages incomplets | Tous mappings flow en JSON ; sélection de 3 dans PDF | Couverture / présentation | Relier le graphe d'usages puis étendre le rapport exhaustif | Ouvert, bloquant métier |
| XSD fiable | Ordre/namespaces/occurrences non établis | Non produit, raison explicite | Limite de preuve | Décoder les contraintes XML, sans assimiler Array à maxOccurs | Bloqué par preuve |
| Application exécutable | TestClient + build Next + worker local | API/UI/modules fournis | Aucune sur parcours testés | Recette navigateur et intranet | Local fonctionnel ; production non validée |
| RQ/PostgreSQL/SSO | Pas de Docker ni infrastructure client | Configuration et adaptateur signés fournis | Intégration non testée | Recette réelle sur environnement privé | Bloqué par environnement |

## Conclusion d'acceptation

Les critères 1 à 7 sont implémentés pour le parcours local, sous réserve des limites documentées et de la recette d'infrastructure. Les critères 8 et 9 (rapports métier complets et validation globale du moteur) ne sont **pas satisfaits**. Les références sont des constats ciblés partiels ; leur existence ne suffit pas à lever ce blocage.
