# Validation du flux documentaire — 0.14.2

La correction porte sur la distinction entre définition d'un composant et occurrence de sa référence dans le flux. Les définitions et les propriétés extraites sont conservées. Les sauts de page aux frontières DOCUMENT suivent la consigne utilisateur ; aucune nouvelle propriété native `breakpage` n'est supposée.

## Corpus vérifié

15 chemins disponibles, 14 contenus distincts par SHA-256 ; le PUB Adhésion de référence dans `PUB.zip` est identique au fichier attaché. Les 13 fichiers acceptés ont été réanalysés, comparés au modèle complet 0.14.1, puis leurs visuels ont été régénérés avec le code final. FDC reste refusé sans exception d'en-tête.

| PUB | Effet sur le flux | Occurrences visuelles avant → après | Faits extraits |
| --- | --- | --- | --- |
| `03-AFR_EPI_NOE_BULLETIN_ADHESION.pub` | Séquence inchangée | 24 → 24 | Identiques |
| `04-AFR_EPI_NOE_BULLETIN_VERSEMENT.pub` | Séquence inchangée | 8 → 8 | Identiques |
| `05-AFR_GENERIC_FIP_DEVIS_ESSENCIEL.pub` | Séquence inchangée | 27 → 27 | Identiques |
| `06-AFR_GENERIC_PROJET_OBSEQUES_ESSENCIEL.pub` | Séquence inchangée | 20 → 20 | Identiques |
| `07-AFR_IARD_DEVIS_AUTO.pub` | Séquence inchangée | 13 → 13 | Identiques |
| `AFR_GENERIC_IARD_VEHIC_NOA_DEVIS.pub` | Séquence inchangée | 22 → 22 | Identiques |
| `AFR_GENERIC_IARD_VEHIC_PLAISANCE_CP_DEVIS.pub` | Séquence inchangée | 20 → 20 | Identiques |
| `AFR_GENERIC_IARD_VEHIC_PLAISANCE_FDC.pub` | Non analysable : même refus d'en-tête | — | — |
| `AFR_EPI_NOE_BULLETIN_ADHESION_Color.pub` | Séquence inchangée | 24 → 24 | Identiques |
| `AFR_EPI_NOE_BULLETIN_ADHESION_Round.pub` | Séquence inchangée | 24 → 24 | Identiques |
| `AFR_EPI_NOE_BULLETIN_ADHESION_Width.pub` | Séquence inchangée | 24 → 24 | Identiques |
| `AFR_EPI_NOE_BULLETIN_ADHESION_Black.pub` | Séquence inchangée | 24 → 24 | Identiques |
| `AFR_EPI_NOE_BULLETIN_ADHESION_BorderPink.pub` | Séquence inchangée | 24 → 24 | Identiques |
| `AFR_EPI_WEBLURE_COURRIER_SIMUL.txt` | Seconde occurrence du tableau rétablie | 50 → 51 | Identiques |

La comparaison retire seulement le numéro de version et les nouveaux arbres `document_flow` du modèle et de la projection visuelle. Tous les autres champs et toutes les listes sont identiques, y compris leurs ordres. Aucune neutralisation des textes, algorithmes, styles ou numéros de règles n'est utilisée. Les preuves compactes et les empreintes des fichiers d'entrée sont incluses dans `validation/flow_0.14.2`.

## Vérifications de sortie

289 tests réussis, zéro échec/saut, un avertissement. Treize nouveaux cas couvrent les séquences A/B/A et A/B/C équivalents, les variantes consécutives, les sections réutilisées avec ou sans séparateur, les références inconnues, les cycles, les frontières DOCUMENT, les variantes vides et la détection d'un flux altéré. Le test WEBLURE génère les deux PDF, vérifie les deux tableaux et mesure les pages de début/fin des occurrences dans le visuel.

Rapport WEBLURE : 306 pages. Visuel : 16 pages. Les 54 occurrences connues sont retrouvées dans l'ordre dans le corps du rapport. Les deux titres du tableau sont présents. Les débuts de document relevés dans le PDF de rapport sont :

- `DOC_AFR_EPI_WEBLURE_COURRIER` : page PDF 7.
- `DOC_AFR_EPI_WEBLURE_SIMULATION` : page PDF 16.
- `DOC_AFR_EPI_WEBLURE_MIEUX_COMPRENDRE` : page PDF 34.
- `DOC_AFR_EPI_WEBLURE_DEM_MISE_EN_SERVICE` : page PDF 40.

Les 237 unités visuelles distinctes correspondent à 347 placements attendus ; chaque occurrence est contrôlée séparément pour ne pas masquer une perte par un doublon ailleurs. Aucun manque/doublon accidentel ni fractionnement de ligne signalé. Contrôle automatique de toutes les pages livrées ; rendu et parcours de toutes les pages en planches, avec agrandissements ciblés. Le tableau de 19 colonnes garde sa densité existante. Cette revue ne certifie pas la pagination native Exstream.

## Périmètre et limites

L'inventaire dédoublonné reste utilisé pour les faits, la couverture et la numérotation éditoriale. L'arbre d'occurrences sert uniquement au parcours des contenus et aux frontières DOCUMENT. Les paragraphes équivalents consécutifs sont regroupés dans le visuel ; les sections consécutives ne sont regroupées que pour une même référence de section décodée. Les références inconnues et cycles interrompent ce regroupement. Le corps du rapport conserve les occurrences et leurs règles.

La référence WEBLURE `21:38941`, l'annexe FIP, le flux documentaire Auto incomplet, l'en-tête FDC, les data sections de lignes, Header/Footer, les propriétés `breakpage` natives et les images non reliées restent des limites. Décodeurs, données sources, interface et scripts de démarrage inchangés. Pas de recette Windows/Docker/navigateur ni déploiement utilisateur.
