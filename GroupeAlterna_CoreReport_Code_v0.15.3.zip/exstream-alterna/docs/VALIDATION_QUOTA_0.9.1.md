# Validation du correctif de stockage 0.9.1

28 septembre 2026 — itération 35 terminée.

## Écarts et résultats

| Écart | Preuve 0.9.0 | Correction | Statut |
|---|---|---|---|
| Toutes les tâches réservent deux entrées | `api.submit`, réserve `2*max_file_bytes+max_output_bytes` | Nombre réel de fichiers attendu, puis taille réellement reçue + budget de sortie | Corrigé |
| Réserve maximale conservée après un succès | Aucun recalcul dans `run_job` | Comptage de tous les fichiers privés à la fin de l’écriture | Corrigé |
| Anciens succès continuent de bloquer | Six réservations de 320 Mio : admission suivante HTTP 507 | Réconciliation des succès avant admission et pendant maintenance | Corrigé |
| Échecs/annulations contrôlés conservent leur budget inutilisé | Absence de réajustement après nettoyage | Réajustement après la fin des écritures et du nettoyage | Corrigé |
| Anciens échecs/annulations d’arrêt incertain | Un état terminal n’établit pas toujours l’arrêt du processus | Commande explicite de reprise après arrêt des services producteurs | Corrigé par procédure ; réserve prudente en exploitation |
| Quota du `.env` ignoré par les conteneurs | Clés absentes de `environment` | Variables de quota transmises aux trois services | Corrigé, contrôle statique |
| Message IHM conseille seulement d’attendre la purge | Texte HTTP 507 antérieur | Message mentionnant expiration ou quota configuré | Corrigé sans changement d’apparence |

## Tests

Le test de reproduction a échoué sur 0.9.0 (HTTP 507 attendu pour constater le défaut), puis réussi après correction. Suite complète : **132 réussites, aucun échec, aucun saut**, en 71,30 secondes. Un avertissement de dépréciation Starlette/httpx subsiste dans l’environnement de test.

Les 13 cas supplémentaires portent sur les anciennes réservations, les modes analyse/comparaison, les tâches actives ou d’arrêt incertain, le quota réellement plein, les échecs de génération, les annulations, les dossiers illisibles, la reprise arrêtée, les admissions concurrentes et les fichiers internes/liens symboliques. Les transactions d’admission restent sérialisées par le mécanisme préexistant.

La commande `python -m retro.storage --reconcile-stopped` a été exécutée dans un sous-processus contre une base SQLite et des fichiers isolés : trois tâches terminales sont passées de 1 006 632 960 octets réservés à 12 288 octets réellement conservés ; la quatrième tâche active est restée à 320 Mio. Empreintes des quatre fichiers inchangées. Les ancres Compose transmettent les trois paramètres de stockage à api/worker/purge.

Les tests préexistants sur Adhésion, Versement, FIP, Auto, Obsèques et NOA passent. Les fichiers de présentation, d’analyse binaire et de génération des PDF sont inchangés. Il n’y a pas eu de nouvelle comparaison visuelle page par page : le correctif ne modifie pas ces composants.

## Fichiers applicatifs modifiés

- `backend/retro/__init__.py` : version 0.9.1.
- `backend/retro/api.py` : réservation à l’admission/réception et message de quota.
- `backend/retro/jobs.py` : libération du budget inutilisé après traitement, réconciliation des succès.
- `backend/retro/storage.py` : nouveau compteur et commande de reprise.
- `docker-compose.yml` : passage de la configuration de quota aux services.
- `backend/tests/test_storage_quotas.py` : nouvelles régressions.

L’archive est un patch pour 0.9.0. Elle ne contient aucun `.env`, fichier client, base, volume ou PDF métier. Le journal et le guide de mise à jour sont inclus.

## Limites

Pas de runtime Docker ici : reconstruction d’image, PostgreSQL réel, Redis/RQ et Windows restent à vérifier sur l’installation de l’utilisateur. La commande de reprise exige l’arrêt préalable d’api/worker/purge. Les tâches actives ne sont pas libérées arbitrairement. Un dossier illisible conserve sa réserve ; un quota réellement rempli reste bloquant. La purge normale conserve ses délais et son comportement antérieurs.

Les journaux techniques conservés dans `validation/quota_0.9.1` contiennent la reproduction, l’extrait final de la suite complète, la reprise CLI et les comparaisons d’empreintes.
