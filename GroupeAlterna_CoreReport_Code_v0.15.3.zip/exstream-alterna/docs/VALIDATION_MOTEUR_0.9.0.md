# Validation moteur 0.9.0 — 28 septembre 2026

La version 0.9.0 produit automatiquement la rétro-documentation et un second PDF de conception du courrier. Les trois options de chapitres restent indépendantes et s’appliquent à la rétro-documentation. La comparaison produit cinq PDF : deux analyses, deux visuels et le différentiel.

## Itérations réalisées

31 : port du prototype graphique NOA dans des modules réutilisables, données propres à chaque analyse, ressources typographiques distribuées. Les premiers essais ont révélé un masquage de méthode dans le portage et la spécificité des régions de page Auto.

32 : correction du masquage ; génération réussie des cinq premiers packages. Modèle de rétro-documentation conservé, travail graphique dans une copie isolée.

33 : reconstruction des grilles et contenus de page Auto, sans rattachement erroné aux décorations ; intégration de l’export, des liens et des libellés. Six visuels produisibles. Le premier rendu Versement a révélé des polices absentes et du texte sombre sur fond sombre.

34 : reconnaissance de l’enveloppe de police 134, en complément de 133 ; les références de police du flux riche résolvent maintenant les styles Versement/FIP. Régénération complète des six paires, inspections et recette navigateur.

## Résultats du corpus final

Toutes les options de rétro-documentation sont activées dans ces six exemples. La recette navigateur teste aussi l’annuaire seul.

| Package | Pages rétro | Pages visuel | Unités affichées / rattachées | Styles décodés | Styles non interprétés |
|---|---:|---:|---:|---:|---:|
| AFR_EPI_NOE_BULLETIN_ADHESION | 168 | 9 | 73 / 87 | 86 | 1 |
| AFR_EPI_NOE_BULLETIN_VERSEMENT | 125 | 5 | 71 / 73 | 72 | 1 |
| AFR_GENERIC_FIP_DEVIS_ESSENCIEL | 172 | 9 | 73 / 82 | 78 | 4 |
| AFR_GENERIC_IARD_VEHIC_NOA_DEVIS | 235 | 11 | 355 / 372 | 364 | 8 |
| AFR_GENERIC_PROJET_OBSEQUES_ESSENCIEL | 118 | 7 | 118 / 129 | 96 | 33 |
| AFR_IARD_DEVIS_AUTO | 109 | 10 | 144 / 144 | 143 | 1 |

Les 53 unités regroupées correspondent à des blocs équivalents ou à des éléments de page identiques : contenu, noms de variables, styles, fonds et topologie sont comparés. Le regroupement concerne uniquement la vue graphique. Les différences de variables métier empêchent le regroupement. Les preuves du modèle normal sont conservées. Couverture contrôlée : 834 unités affichées sur 887, 53 retraits intentionnels tracés, aucune unité rattachée perdue sans justification ni double placement. Ce décompte ne prouve pas que tout le format PUB est décodé.

104 fonds activés et 126 bordures basses du profil reconnu sont exploités sur le corpus. 839 styles d’objet sont décodés, 48 restent non interprétés. Les polices/couleurs sont relues depuis chaque source ; aucune table de contenu NOA figée n’est injectée dans un autre fichier.

## Vérifications

- 119 tests réussis, aucun sauté ; un avertissement de dépréciation Starlette/httpx dans l’environnement de test.
- 76/76 contrôles de calibration historique réussis.
- Modèles de rétro-documentation sémantiquement identiques à 0.8.0 pour les six PUB, hors version et ajout du modèle visuel.
- 51 pages des six PDF visuels rendues par Poppler et inspectées. Aucun débordement, superposition majeure, ligne de table scindée ou paragraphe trop haut signalé sur ce corpus. Les noms de variables longs se replient dans les colonnes étroites.
- Les douze PDF finaux ont été ouverts et leur texte extrait : aucun mot hors page. Les 927 pages de rétro-documentation ont des contrôles techniques ; elles n’ont pas toutes fait l’objet d’une nouvelle revue visuelle, car leur modèle et leurs gabarits sont inchangés.
- Compilation Next.js et vérification TypeScript réussies.
- Parcours réel avec Next compilé, FastAPI, SQLite et worker séparé : dépôt Versement, actualisation de la tâche, annuaire seul conservé, téléchargement des deux PDF, clavier, bureau 1440×1100 et mobile 390×844, aucun débordement horizontal ni erreur JavaScript. Les huit combinaisons de chapitres, les cinq PDF de comparaison et les liens protégés sont également testés côté API.
- Échec du second rendu : les livrables précédents restent intacts ; le traitement n’est pas présenté comme réussi. Deux rendus parallèles gardent leurs données séparées.
- CSS, logo, API, orchestration, gabarits de rétro-documentation et options de chapitres inchangés. L’interface ne reçoit que les nouveaux libellés et explications de téléchargement.

Docker Desktop, Windows, PostgreSQL et RQ/Redis n’ont pas été exécutés dans cet environnement. Aucune migration ni modification de leurs contrats n’est introduite.

## Écarts restants

| Écart | Statut et preuve disponible |
|---|---|
| Pagination et positions absolues Exstream | Partiel. Les grilles reconnues donnent lignes, colonnes et proportions ; les sections sont ordonnées par les relations déjà décodées. Les positions natives et certains rattachements de page restent inconnus. Les éléments de page non positionnés sont regroupés à la fin. |
| Arrondis | Calibration réservée à l’empreinte exacte du PUB NOA étudié et au fond bleu corroboré. Le contour polygonal provient de l’exemple natif antérieur. Rayon/masque/héritage dans le PUB non décodés ; aucun arrondi appliqué par analogie aux cinq autres fichiers. |
| Bordures et fonds | Fonds explicites et profil de bordure basse reconnus. Autres côtés, héritages, contours composites et fusions non reconnues conservés comme limites. |
| Ressources et symboles | Emplacements d’images par cadres croisés sans le mot « image ». Ressources externes absentes. Certaines polices sont substituées ; les glyphes Wingdings non corroborés restent des symboles de remplacement. |
| Typographie | Deux enveloppes de ressources validées sur le corpus. 48 styles sans grammaire riche exploitable restent non interprétés. Pas de police/couleur prétendue source lorsqu’elle est inconnue. |
| Variantes, répétitions et données | Aucune règle exécutée et aucun flux client fourni : les variantes distinctes restent visibles, les répétitions ne sont pas développées sur des données inventées. Les noms de variables remplacent toujours leurs exemples de conception. |
| Exhaustivité | Seuls les contenus reliés par les profils reconnus sont couverts par le compteur. Les références de message, des liens et des propriétés encore non résolus peuvent contenir d’autres éléments. |

Le PDF visuel est une reconstruction de conception, pas une édition Exstream certifiée ni une reproduction pixel par pixel. Le PDF v6 historique n’a pas été utilisé dans cette évolution. Sources : les six PUB fournis, les modules 0.8.0, le journal et le profil graphique NOA V9 déjà établi depuis les trois pages de l’exemple natif. Aucun Tools Report.

## Livrables et reprise

`GroupeAlterna_Exstream_Code_v0.9.0.zip` contient le code complet, les polices sous licence fournie, `.env` initial, `.env.example`, les tests, le guide et le journal. `GroupeAlterna_Validation_v0.9.0.zip` conserve les douze PDF finaux, leurs rendus visuels, les résultats et preuves de recette. Les PUB originaux et le PDF client ne sont pas redistribués dans ces archives.

Prochaine investigation graphique : fournir deux PUB minimaux ne différant que par le rayon ou un coin activé, puis relier le changement aux enveloppes de style. Pour un autre fichier défaillant, conserver son empreinte, son diagnostic de propriété et le visuel avant de compléter un profil. Ne jamais généraliser la calibration NOA par nom de fichier.
