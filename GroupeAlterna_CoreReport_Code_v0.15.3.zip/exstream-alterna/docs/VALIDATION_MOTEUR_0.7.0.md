# Validation du moteur 0.7.0 — NOA et corpus de régression

28 septembre 2026. Livraison après les itérations 24 à 27. L'interface, le contrat API et les services restent inchangés. Le moteur a été corrigé de manière réutilisable ; les noms métier et les offsets ci-dessous servent de preuves et de fixtures de tests, pas de conditions spéciales du décodeur.

## Sources et méthode

Base : code 0.6.0 livré, vérifié contre son archive avant copie dans `work_noa/exstream-alterna`. Les travaux précédents sont conservés. Le journal persistant a été lu avant intervention. Les spécifications 01 et le cahier consolidé 02 ont été consultés ; les demandes de présentation du 28 septembre remplacent l'ancien chapitre séquentiel.

Sources métier effectivement analysées : les six PUB indiqués dans le tableau ci-dessous, dont `upload/AFR_GENERIC_IARD_VEHIC_NOA_DEVIS.pub`. Comparaison du texte extrait de `upload/rapport-2.pdf` (233 pages) et des rendus ciblés des pages 2, 3, 9, 13, 17, 18, 19, 63 et 69. Il ne s'agit pas d'une inspection visuelle des 233 pages de l'ancien rapport. Les six nouveaux rapports, eux, sont intégralement rendus et inspectés selon le protocole décrit plus bas.

Empreinte SHA-256 du PUB NOA : `331bd9af95813d30daad1b9a0da4209bbaa127b4bb19195ec31d2bc6bc197f52`. Celle du rapport d'entrée : `af5a842f018f719a62cda068070f00dd08cd87efa63cbec9dd350523e9668a52`. Vérifications finales : sources intactes. Les autres empreintes figurent dans `analysis/metrics_final.json` de l'archive de validation.

Aucun Tools Report, flux client ni moteur Exstream externe n'a été utilisé. Le PDF v6 historique n'était pas accessible lors de cette reprise : aucune nouvelle comparaison avec lui n'est revendiquée. Le moteur ne reçoit que le PUB ; les PDF d'entrée servent à observer les écarts de restitution.

## Retours NOA et corrections

| Écart signalé | Correction et preuve | État |
|---|---|---|
| Titres génériques « P00 / 29 blocs » | La vue utilise les noms de composants PAR issus des définitions. Les 29 paragraphes principaux NOA sont conservés. | Corrigé |
| Algorithmes difficiles à retrouver | Un récapitulatif `Rn / Nom de la règle / Algorithme` suit chaque bloc. L'ID compilé déduplique les occurrences d'une même règle dans ce bloc. Le catalogue renvoie au premier récapitulatif au lieu de recopier son algorithme. | Corrigé |
| Règle globale du premier titre non reconnue | PAR `21:25233` : ouverture classe 21 à 4543942, définition appariée à 4556768, record 136 à 4556866, référence à 4556914 = règle 524781, `DF_RUL_pdf`. Les signatures voisines et l'identité PAR contrôlent l'association. Page 2 du nouveau rapport. | Corrigé pour le profil corroboré |
| Global confondu avec portée interne | La condition du composant entier est indiquée uniquement lorsqu'elle est décodée. `[Rn]` et `[/Rn]` encadrent le bloc entier ; les cibles internes gardent leurs propres repères. 24 des 29 PAR principaux NOA ont une condition globale ainsi reconnue. | Corrigé ; profils inconnus restent inconnus |
| Design samples dans Conducteurs_Assures | Enregistrement `text:4743194`, PAR `21:40201` : variante de propriétés de puce reconnue, 16 paragraphes internes, 25 cibles. Le répertoire indépendant démontre 4 variables distinctes, 8 occurrences. Les noms remplacent les valeurs de conception. Pages 39–40. | Corrigé |
| Retours internes perdus | Les frontières des paragraphes de glyphes sont conservées, y compris lorsqu'une frontière traverse un token littéral. Test dédié. Les fins de ligne liées à une largeur de composition ne sont pas assimilées à des retours métier. | Corrigé pour les structures reconnues |
| Paragraphes de tableaux aplatis | Les compteurs d'ouverture, groupes d'axes, fermeture et coordonnées de cellule démontrent les grilles imbriquées. Exemple Garanties : PAR `21:40824`, racine à 4920109, 7 colonnes × 19 lignes ; enfant à 5012737, 3 × 23, dans la cellule ligne 9/colonne 0 (indices binaires). | Corrigé pour le profil corroboré |
| En-têtes fusionnés mal restitués | Étendue horizontale sérialisée et bornée ; exemple `text:4920707` (« Vos garanties »), portée de 5 colonnes. Aucun span inféré à partir d'une cellule voisine vide. 16 tables imbriquées reconnues dans NOA. | Partiel : autres profils de fusion inconnus |
| Commentaires « R1 : paragraphe interne 2 » et chapitre séquentiel redondants | Commentaires supprimés ; chapitre « Analyse séquentielle et preuves » supprimé. Les preuves restent dans le JSON et les sections conservées. | Corrigé |
| Propriétés de lignes/colonnes inutiles | Le PDF détaille uniquement les axes ayant une règle ou une répétition reconnue. Toutes les colonnes restent inspectées dans le modèle : 113 pour le package NOA. Absence de détail PDF ne signifie pas preuve d'absence d'une propriété inconnue. | Corrigé |
| Colonne Ligne sans contenu métier | Les propriétés affichent le contenu complet de la ligne, variables comprises. Les cas strictement identiques sont regroupés en conservant tous les indices et offsets. Exemple « Votre tarif », page 46. | Corrigé |
| Coupures et surcharge | Rn élargi, repères insécables, lignes de tableaux insécables, algorithmes de référence mutualisés. Certains grands tableaux laissent du blanc pour préserver leurs cellules. | Corrigé pour les coupures observées |

L'ancienne **R57** est désormais **R1**, mais reste la même règle compilée **524781 / DF_RUL_pdf**. Les Rn sont des repères documentaires attribués dans l'ordre de rencontre ; ils ne sont pas des identifiants stables entre versions. Le nom et l'ID compilé permettent le suivi. Le rouge dépend uniquement d'une cible démontrée, y compris d'une condition sur le composant entier ; une variable dynamique seule reste noire.

Les noms de fonctions/règles/pages, les origines et affectations statiques, l'annuaire INPUT démontré et les drivers de répétition introduits auparavant sont conservés. Cette reprise ne prétend pas résoudre toutes les origines externes ou l'ordre global d'exécution.

## Boucle effectuée

| Itération | Production | Résultat de revue |
|---|---|---|
| 24 | NOA, 236 pages | Rendu complet ; pages 1–48 inspectées. Profils globaux, variables et tables ajoutés. Rn trop étroit et coupures de lignes identifiés. |
| 25 | NOA, 235 pages | Rendu complet et contrôle de marges. Largeurs, repères, lignes et regroupements corrigés. Nouvelles variantes de propriétés sondées. Pas de revendication d'inspection intégrale de cette version intermédiaire. |
| 26 | Six PDF, 924 pages | Profils de préfixes bornés améliorés ; 84 tests, 76 contrôles de calibration. Inspection visuelle des 924 pages par planches complètes, avec zooms des passages sensibles. |
| 27 | Six PDF, 924 pages | Clarification de la limite sur les fusions ; seuls les textes de limites du modèle changent. Tous les PDF sont régénérés et rendus. Les 918 images inchangées réutilisent leur revue de l'itération 26 après vérification ; les six pages modifiées sont inspectées séparément. |

Les échecs intermédiaires de tests concernaient trois attentes utilisant des Rn figés et une forme de coordonnées devenue hiérarchique. Les tests retrouvent maintenant les mêmes règles par leur ID compilé et conservent les assertions sur les cibles et coordonnées. Aucun contrôle de plage n'a été retiré pour obtenir un passage artificiel.

## Rapports finaux et couverture

Chaque rapport se trouve sous `validation/corpus6/iteration_27/<nom du PUB sans extension>/rapport.pdf`, avec `rapport.json`. Les PDF renommés sont fournis séparément. « Portées » compte les contenus principaux avec structure riche complètement décodée, pas les seules règles ; ce ratio ne constitue pas une mesure de conformité métier.

| Courrier | Pages | Règles rattachées | Contenus principaux / portées décodées | PAR avec condition globale | Colonnes inspectées dans le package |
|---|---:|---:|---:|---:|---:|
| AFR_GENERIC_IARD_VEHIC_NOA_DEVIS | 234 | 154 | 265 / 264 | 24 | 113 |
| AFR_EPI_NOE_BULLETIN_ADHESION | 167 | 65 | 74 / 73 | 19 | 38 |
| AFR_EPI_NOE_BULLETIN_VERSEMENT | 125 | 28 | 62 / 61 | 0 | 30 |
| AFR_GENERIC_FIP_DEVIS_ESSENCIEL | 170 | 35 | 61 / 57 | 0 | 24 |
| AFR_IARD_DEVIS_AUTO | 110 | 143 | 142 / 141 | 0 | 21 |
| AFR_GENERIC_PROJET_OBSEQUES_ESSENCIEL | 118 | 9 | 82 / 81 | 12 | 35 |

Versement contient une unité principale sans structure de texte riche, mais aucun échec de portée signalé. Le nombre de colonnes et certains inventaires concernent le package entier, plus large que le seul courrier principal. Zéro condition globale reconnue ne certifie pas l'absence de toute condition dans un profil inconnu.

La suppression des redondances n'impose pas un objectif de pages : NOA passe de 233 pages dans `rapport-2.pdf` à 234, avec une restitution plus complète. Les rapports historiques issus de 0.6.0 passent respectivement de 196 à 167 pages (Adhésion), 146 à 125 (Versement), 198 à 170 (FIP), 159 à 110 (Auto) et 130 à 118 (Obsèques), sans perte sur les 48 invariants comparés.

## Contrôles réalisés

- **84 tests pytest réussis, aucun sauté**, après les corrections finales. Six tests NOA supplémentaires vérifient les profils et leurs corruptions : garde global, répertoire variable, échec de portée sans fausse coloration, compteurs de tables, étendue invalide, déduplication/filtrage, retour dans un token.
- **76/76 contrôles de calibration historique** sur Adhésion, Versement, FIP et Obsèques. Ce sont des contrôles ciblés, pas un oracle métier complet ; Auto et NOA sont couverts par les tests et comparaisons de corpus supplémentaires.
- **48 invariants de non-régression**, huit par fichier : identité/type/cardinalité des variables, mappings, ordre structurel des PAR, contenu brut/parent, anciennes portées, règles compilées, calculs et drivers. Les modèles 26 et 27 ne diffèrent que dans le texte des limites.
- **27 fichiers protégés identiques par empreinte**, dont frontend, API, worker, configuration et orchestration. Aucun nouveau contrôle navigateur n'est revendiqué ; l'interface n'a pas été éditée.
- **924 pages rendues** dans la version finale, texte extractible sur chacune, pagination séquentielle, polices utilisées DejaVu incorporées, aucune page vide ni dépassement de marge détecté. Revue visuelle sans coupure ou superposition majeure observée, complétée par des zooms. Les longs algorithmes restent denses et certains tableaux occupent plusieurs pages par lignes entières.
- Sources PUB et rapport d'entrée non modifiés. Aucun rapprochement par octets ou métadonnées entre les deux PDF n'a servi de comparaison métier. Les empreintes d'images servent seulement à réutiliser une inspection entre deux rendus identiques de nos itérations.

Preuves : `analysis/tests_iteration27.txt`, `calibration27.txt`, `non_regression_060.json`, `interface_non_regression.json`, `metrics_final.json`, `visual_reuse27.json`, `REVUE_VISUELLE.md` et rendus 26/27 dans l'archive de validation. Docker Desktop, Windows et PostgreSQL n'ont pas été exécutés ici.

## Limites précises conservées

| Source | Portée encore non interprétée | Conséquence |
|---|---|---|
| NOA | P17.03, `text:6611819`, propriétés 6611979–6614481 : table de ciblage non encadrée | Le payload et ses variables sont indépendamment décodés. Pas de coloration interne inventée ; contrôle apparié opaque conservé. |
| Adhésion | P22.01, `text:5023442`, propriétés 5023508–5026703 | Chaîne propriétaire/index non résolu ; texte conservé. |
| FIP | P13.01 `4702030`, P25.01 `4920764`, P27.01 `4943885`, P28.01 `4958948` | Quatre chaînes de propriétés non résolues ; payloads disponibles indépendamment. |
| Obsèques | P17.02, `text:4704658`, propriétés 4705890–4717749 | Portée non démontrée, contenu conservé. Les trois ciblages de colonnes Financement Simulation restent décodés, pages 7 et 16. |
| Auto | P00.07, `text:1252466`, opcode -240 à 1254569 | Arity du contrôle non établie ; pas de plage déduite. Ordre entre régions et objets libres également non démontré. |

Origine encore non résolue parmi les variables directement rencontrées dans les contenus principaux : NOA 4, Adhésion 4, FIP 1, Auto 15 ; Versement et Obsèques 0 sur ce seul périmètre. Le package entier comprend d'autres variables non résolues, inventoriées dans les JSON. NOA et Adhésion : `DF_PAR_SIGN2_label1`, `DF_PAR_SIGN2_label2`, `DF_PAR_SIGN3_label1`, `DF_PAR_SIGN_label0`. FIP : `DF_FIC_CD_AGRT_effStartDate`. La liste complète Auto est dans `metrics_final.json`. Un nom FIC ou SYS ne suffit pas à prouver une source ou une valorisation.

Restent également non établis : fusions autres que le profil horizontal contrôlé, paramètres graphiques fins, ressources externes, pagination Exstream évaluée, développement exhaustif des instances répétées de PAR, valeurs client, ordre global des événements et effets runtime des fonctions externes. Les contenus sans parent démontré restent dans les preuves. Les branches absentes/null ne sont pas fabriquées.

**La conformité exhaustive n'est pas déclarée.** La fiabilité est améliorée et contrôlée sur ces six fichiers, sans garantie pour tout PUB possible. La prochaine action de décodage précise est d'isoler et corroborer la chaîne de propriétés de lien de NOA `text:6611819`, puis les quatre chaînes FIP ; une preuve indépendante est nécessaire avant d'ajouter leurs associations. Pour la recette locale, installer 0.7.0 et relancer les analyses, en conservant le `.env` et les volumes existants.
