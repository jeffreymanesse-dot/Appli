# Validation du correctif FIP — Core Report 0.12.1

Date : 30 septembre 2026. Base de comparaison : moteur 0.12.0 conservé. Sources client inchangées.

## Défaut et preuves

Paragraphe : `PAR_AFR_EPI_NSE_FDC_DEVOIR_DE_CONSEIL_ESSENCIEL_BR_notreEntretien`, identifiant `21:42706`, table `grid:21:42706`. SHA-256 du PUB : `efb587a1afbb8f61b07c667a62df50c166389e5b3e20cbf831de5d4c0a355a05`.

Le tableau comporte trois lignes principales et une note fusionnée. Le conteneur binaire déclare quatre colonnes et quatre axes de lignes : le quatrième porte cette note. Il ne faut ni supprimer la note ni forcer artificiellement le compteur binaire à trois.

| Ligne affichée | Index source | Offset de l'axe | Hauteur brute |
|---|---:|---:|---:|
| En-tête : Simple, Standard, Supérieure | 0 | 4 760 128 | 82 |
| Inhumation | 1 | 4 761 011 | 186 |
| Crémation | 2 | 4 761 894 | 186 |
| Note fusionnée sur quatre colonnes | 3 | 4 762 777 | 82 |

La version 0.12.0 exigeait au moins une valeur `0xffffffff` aux positions relatives +12/+16 de chaque axe. Les lignes Inhumation et Crémation contiennent zéro dans les deux champs et un flux de propriétés explicites valide. Le lecteur ne conservait donc que deux axes ; les cellules d'index 2 et 3 sortaient de cette grille réduite. Le conteneur complet utilisait aussi une valeur opaque 30 à l'emplacement où l'ancien profil n'admettait que 29, provoquant le recours à une détection moins précise à l'échelle du paragraphe.

Le début du conteneur est à l'offset 4 733 628 ; sa fin à 4 763 828. Les quatre axes de colonnes portent la largeur brute 543. Le texte d'introduction à l'offset 4 722 313 précède le conteneur et reste hors du tableau. La note présente un span source de quatre colonnes. Les dimensions brutes ne sont pas des centimètres ; ce correctif ne change pas les conversions d'unités validées en 0.12.0.

## Correction générique

- `layout.py` reconnaît le profil de ligne complet : enveloppes, préfixe, huit champs TLV de tailles attendues, limites et marqueur de fin. La preuve `OBS-styled-row-axis-v2` couvre 883 octets. Les zéros seuls ne suffisent pas ; la grammaire des colonnes n'est pas élargie.
- Le conteneur à valeur opaque 30 est accepté uniquement en présence du profil de lignes reconnu et des autres garde-fous, notamment les compteurs. La signification de cette valeur reste inconnue.
- Une ligne de ce profil corrompue ne doit pas compacter les indices : si les axes reconnus contredisent le compteur indépendant, la grille est rejetée avec diagnostic. Une dernière ligne vide reste conservée si axes et compteur concordent.
- Les styles sont enrichis après la finalisation de couverture : leur audit correspond à la liste finale des cellules validées.
- Un petit tableau terminé par une note fusionnée sur toute sa largeur reste sur une même page dans le rapport. Le contrôle utilise la structure de fusion, sans libellé ou identifiant FIP codé en dur.

Les identifiants et offsets ci-dessus sont des preuves de test, pas des critères de sélection du code de production. L'API et le parcours utilisateur restent inchangés ; les métadonnées de version passent à 0.12.1.

## Tests

La suite finale fournit **184 réussites, zéro échec, zéro erreur et zéro saut en 161,83 secondes**. Le bilan est corroboré par le XML JUnit et `test_summary.json`. Un avertissement de dépréciation Starlette/httpx préexistant est conservé. Les lancements intermédiaires sans bilan complet ne sont pas comptabilisés.

Les 13 nouveaux cas couvrent le profil synthétique, cinq corruptions ou troncatures, les trois lignes principales et leurs six variables, deux corruptions de lignes du vrai PUB, le placement dans le PDF visuel, la dernière ligne vide d'un composant partagé et les rapports FR/EN avec note conservée sur la même page. Le test historique qui attendait un rejet de rattachement FIP a été remplacé par l'invariant réel : l'introduction reste hors du tableau.

## Corpus complet

Les 12 chemins sources représentent 11 contenus distincts. Le second exemplaire de la référence Adhésion est enregistré comme alias. Chaque contenu a été analysé dans un processus distinct avec 0.12.0 puis 0.12.1.

| PUB | Tables corrigées | Rapport, pages | Visuel, pages |
|---|---:|---:|---:|
| NOA Devis | 6 | 250 | 12 |
| Bulletin Adhésion, référence | 10 | 172 | 9 |
| Bulletin Versement | 10 | 129 | 5 |
| FIP Devis Essentiel | 12 | 174 | 9 |
| Projet Obsèques Essentiel | 0 | 124 | 7 |
| IARD Devis Auto | 0 | 112 | 11 |
| Adhésion Color | 10 | 166 | 9 |
| Adhésion Round | 10 | 166 | 9 |
| Adhésion Width | 10 | 166 | 9 |
| Adhésion Black | 10 | 166 | 9 |
| Adhésion BorderPink | 10 | 166 | 9 |

Les 88 corrections de tables comprennent les répétitions de composants partagés entre fichiers. Il ne s'agit pas de 88 modèles indépendants. Dans FIP, une seconde table et des composants `DF_MSG_*` contenaient également des axes du même profil.

Le script `validate_styled_rows.py` vérifie : mêmes tables, mêmes colonnes, conservation de tous les axes et cellules précédents, profil reconnu pour chaque axe ajouté et coordonnées de chaque cellule conformes aux octets source. Les métadonnées sources, textes, déclarations de variables, algorithmes de règles, cibles internes de règles, mappings, calculs, dictionnaire d'entrée et XSD gardent leurs empreintes. Les rattachements de cellules et les informations d'usage dérivées changent volontairement ; aucune égalité globale du modèle n'est revendiquée.

Les 22 PDF, soit 1 889 pages, passent les contrôles d'ouverture, de pages vides et de texte hors page. Tous les visuels ont zéro élément manquant, placement dupliqué, ligne fractionnée ou paragraphe trop long dans les contrôles du moteur. Les déduplications intentionnelles préexistantes restent explicites dans les audits.

Revue visuelle : neuf pages du visuel FIP, plus la page PDF 13 du rapport complet. Le tableau corrigé figure à la page 3 du visuel ; la note est conservée dessous. Les autres pages du corpus ont fait l'objet des contrôles automatiques ci-dessus, sans relecture humaine exhaustive.

## Reproduction

Installer les dépendances de développement. Placer les six PUB historiques dans le dossier `project_sources` voisin du projet, dont FIP. Définir `PUB_TABLE_CORPUS` vers la racine contenant `pub_variants` et `pub_variants2`. Les fixtures absentes provoquent des sauts, qui ne constituent pas une validation complète.

Depuis le dossier `exstream-alterna` :

```bash
PUB_TABLE_CORPUS=/chemin/du/corpus PYTHONPATH=backend python -m pytest backend/tests -q --junitxml=../tests_0121.xml
PYTHONPATH=backend python scripts/validate_styled_rows.py --source-dir ../project_sources --source-dir ../pub_variants --source-dir ../pub_variants2 --source-dir '/chemin/vers/Conception Appli' --output-dir ../validation_0121 --baseline-backend /chemin/vers/0.12.0/exstream-alterna/backend
```

Le dossier de sortie du corpus doit être vide. Les sources ne sont ni modifiées ni copiées dans les archives livrées. Le script de comparaison exacte `validate_table_corpus.py` reste disponible pour les évolutions qui ne corrigent pas les associations du modèle ; il n'est pas l'oracle adapté à la comparaison 0.12.0/0.12.1.

## Limites et livraison

Les profils sont établis sur le corpus disponible, sans prétention de conformité universelle Exstream. Les limites de 0.12.0 concernant le rayon exact des arrondis, les bordures non calibrées et leur héritage, les ressources externes et la pagination native demeurent. Le visuel affiche les variables et conditions statiques, sans exécuter les données d'un destinataire.

Livraison : code complet 0.12.1, archive de validation, visuel FIP corrigé et journal de validation conservant tout son historique. Les preuves de validation sont les sorties finales ; les essais intermédiaires restent exclus du paquet. Aucun déploiement, nouvelle recette navigateur, Docker, Windows ou PostgreSQL/RQ n'est revendiqué.
