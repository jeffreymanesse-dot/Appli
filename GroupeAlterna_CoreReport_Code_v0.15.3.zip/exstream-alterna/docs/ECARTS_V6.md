# Révision V6 — moteur 0.5.0, itérations 13 à 19

État actuel : `validation/corpus4/iteration_19/AFR_EPI_NOE_BULLETIN_VERSEMENT/rapport.pdf`, **141 pages**. Les 28 IDs de règles de V6 et les 73 noms de variables identifiés dans son annuaire sont présents dans le périmètre documentaire et le nouvel annuaire INPUT. Les quatre drivers de répétition sont conservés. Cela ne démontre pas une conformité exhaustive des effets, de la géométrie ou de l’ordre d’exécution.

Le bilan détaillé est `VALIDATION_CORPUS_0.5.0.md`. La concordance des **46 pages** de référence est dans `validation/corpus4/CONCORDANCE_PAGES_V6.md` ; la comparaison de contenu, dans `comparison_v6_0.5.0.json`. V6 est utilisé pour comparer les résultats, jamais comme source du moteur.

| Écart | État actuel |
|---|---|
| Unités internes non décodées dans Versement | 61 unités rich-text décodées sur 62 unités du courrier ; la dernière est un titre littéral distinct. Aucune erreur de décodage rich-text dans ce périmètre. Les contenus non rattachés restent en annexe. |
| Sélection des algorithmes incomplète | Affectations explicites et appels suivis, notamment formula107407 ; ordre global des événements toujours inconnu. |
| Hypothèse de double index de ciblage | Corrigée après le contrôle croisé Adhésion/FIP : +56 est l’index local, +4 reste brut. Les affirmations anciennes ci-dessous de « redondance d’index » sont obsolètes. |
| Cible TIN/SSN opposée au commentaire V6 p.15 | Divergence justifiée maintenue : propriété à 4419547, champ +56 à 4419603, table locale 4426352 et frontières 4423574–4424050. Le PUB démontre la cible rule781268. |
| Portée R28 | Seul « tte » est ciblé (instructions 4620097–4620117), pas toute la variable dynamique. |
| Présentation | Vue d’ensemble puis analyse Pxx, règles, répétitions, algorithmes et annuaire ; pagination, densité, ordre de rubriques et découpage Pxx différents de V6. 141 pages contre 46, en partie à cause des sources d’algorithmes et dépendances intégrales. |
| Qualité PDF | 141 pages rendues ; rendu identique à l’itération 18 entièrement inspectée. Aucun dépassement automatique ni défaut majeur observé ; texte sélectionnable et polices utilisées intégrées. |
| Tables et graphique | Colonnes inspectées systématiquement ; fusions, certaines propriétés conditionnelles et géométrie fine non interprétées. Reproduction pixel à pixel non acquise. |

Validation globale : **73 tests réussis**, **76/76 contrôles historiques**, **656 pages finales rendues et revues** sur les quatre courriers. Les 22 fichiers interface/API/worker/configuration contrôlés sont inchangés. Les originaux restent intacts.

## Historique conservé — moteur 0.4.0, itérations 10 à 12

Les résultats ci-dessous décrivent la livraison précédente. Ils ne remplacent pas l’état 0.5.0 ci-dessus et contiennent l’ancienne hypothèse de double index, depuis corrigée.

## Résultat actuel

Rapport final : `validation/revision_v6/iteration_12/rapport.pdf`, **41 pages** toutes rendues et inspectées. Le moteur dispose maintenant des portées des dix règles internes du Bulletin de Versement, en complément des dix-huit règles de ligne. La conformité exhaustive au PDF v6 reste non acquise.

Les rapports précédents, le PDF v6 de 46 pages et la nouvelle méthode jointe sont conservés. L'interface et le contrat API n'ont pas changé. Les corrections concernent le moteur, le modèle JSON, la comparaison et le rendu PDF.

## Contenu métier et preuves de correction

| Écart depuis 0.3.0 | Indice vérifié dans les sources | Correction / statut |
|---|---|---|
| R28 reliée au texte sans portée | Méthode jointe §§6–7 ; PUB token à 0x466EE5, instructions à 4620097 et 4620117, index 1 vers rule781266 à 4624664 | Corrigé : seul « tte » est ciblé et rouge ; typeCourrier reste dynamique et non rouge |
| Oui/Non associés sans frontières | Flux -254/-110 : 4422874–4422902, 4422902–4422930, 4423518–4423546, 4423546–4423574 | Corrigé : quatre plages de trois caractères, reliées aux bons index locaux de règles |
| R1 : ambiguïté paragraphe/variable | Propriétés du paragraphe 0 à 4377318, index 0 redondant, règle à 4378107, glyphes et répertoire de variable concordants | Corrigé : le paragraphe « N° Orias : » et la variable sont ciblés ensemble |
| R2 : ambiguïté cellule/nom de naissance | Propriétés de paragraphe à 4406087, frontières à 4410762 et 4410978 | Corrigé : seulement libellé + variable du nom de naissance, autres champs conservés en couleur normale |
| Frais : « nuls » / « de … % » sans plage | Instructions 4500124–4500156 et 4500156–4500392 ; table des règles à 4500947 | Corrigé : deux runs, dont le second inclut une variable complète ; la règle de ligne englobante reste distincte |
| R27 non résolue | Propriétés de paragraphes 2 et 3 à 4613337 et 4613683 ; index 0 de rule789194 | Corrigé : paragraphe d'avenant ciblé, ainsi qu'un paragraphe de deux espaces conservé dans les preuves |
| Assemblage « ce tte » | Fragmentation exacte + comptage du flux de composition | Corrigé : concaténation « ce » + « tte » sans espace inventé. Sauts de paragraphe issus de -244 quand le profil est reconnu |
| Propriétaires et preuves insuffisants dans le modèle | Méthode jointe §§12–14 | Corrigé : propriétaires, chaîne de parentage, fragments, offsets, profil, confiance motivée et preuves ; aucune position absolue de texte final inventée |
| Occurrences d'ID non classées | Record 108/classe 30 ; listes de targeting ; occurrences tardives non résolues | Corrigé partiellement : définition/ciblage distingués ; métadonnées non reconnues laissées opaques, jamais supprimées |
| Noms de règles corrompus | Header paramétré : variable et littéral Pascal avant le nom (ex. rule781268 à 5141256) | Corrigé : variante décodée sans offset de nom fixe ; noms non valides non inventés |
| Conditions de chaînes encore compilées | Comparaison exacte à « true » / « false » avec deux branches explicites | Corrigé : lecture lisible, guillemets conservés ; absence/null non assimilés arbitrairement à une branche |
| Comparaison ignorait les nouvelles portées | Nouveau tableau `targets` | Corrigé : comparaison sémantique des propriétaires et tokens, indépendante de leurs offsets binaires |

**Différence volontaire avec la référence :** le commentaire de la page 15 du PDF v6 dit que le champ TIN/SSN est inconditionnel. Le PUB contient un index de règle 0 aux offsets 4419551 et 4419603 du paragraphe 11, référençant rule781268 à 4426352. Le flux en donne les frontières de contenu, depuis 4423574 jusqu'à 4424050. Le rapport conserve donc cette cible supplémentaire et ne recopie pas l'affirmation contraire. La même règle cible aussi le mot « Oui » à l'index 3 de la table locale.

## Présentation et qualité PDF

| Itération | Pages | Revue et correction suivante |
|---|---:|---|
| 10 | 42 | Toutes inspectées. Portées et rouge corrigés ; alternatives accolées, assemblage de repli et fin d'annuaire à améliorer |
| 11 | 42 | Toutes inspectées. Exposants documentaires Rn, cellules compactes et annuaire corrigés ; explications répétées isolant R28 sur une page |
| 12 | 41 | Toutes inspectées. Explication du niveau de preuve mutualisée, offsets de propriétaire/ciblage explicites, R28 regroupée avec le catalogue |

Contrôles : 41 pages à texte sélectionnable, polices DejaVu Sans/Sans Bold intégrées, aucun texte hors page. La couleur PDF de « tte » a été vérifiée, avec contexte et variable non colorés par cette règle. Aucune coupure d'extrait, de ligne de tableau ou superposition majeure observée. Les données techniques longues restent denses dans certaines cellules. L'annuaire demeure en portrait ; la pagination et les styles Exstream ne sont pas reproduits.

## Tests, non-régression et limites de calibration

- Itération 10 : 44 tests ; itérations 11 et 12 : 49 tests réussis, sans tests sautés. Un avertissement httpx/Starlette existant subsiste.
- 76/76 contrôles de calibration existants sur quatre packages ; inventaires de variables, mappings, règles, calculs et contenus du Versement conservés.
- Nouveau profil : 52/62 unités du courrier, sept runs inline et cinq paragraphes ciblés, dix identifiants distincts. Les dix-huit règles de ligne et quatre répétitions sont conservées.
- Les trois autres packages ne passent pas les contrôles stricts de ce nouveau profil : aucune nouvelle portée exacte n'y est affirmée. Les 76 contrôles historiques ne constituent pas une calibration métier des nouveaux spans.
- Les corruptions d'index, de frontière, d'opcode, de variable, de compteur et de parentage sont rejetées ; les données non interprétées restent dans le modèle.
- Les 17 fichiers frontend/API/worker/configuration/orchestration de la livraison antérieure contrôlés sont identiques. Aucun changement visuel de l'interface ni des routes de téléchargement. Docker/Windows non exécutés ici.

## Sources et blocages restants

Sources réellement consultées : nouvelle méthode de détermination de portée (entière), PUB Versement exact, extraits ciblage des spécifications 01/02, journal du dépôt et placeholder 18, PDF v6/son texte et rendus antérieurs validés (revue renouvelée pages 15/28), modèles et rapports itération 9, code et tests ; quatre PUB pour la calibration. Aucun Tools Report, aucune consultation de la documentation OpenText originale citée par la méthode, aucun code embarqué exécuté. Le générateur consomme uniquement le modèle issu du PUB.

Restent : variantes de rich-text hors profil (neuf unités de grille du courrier, plus titre littéral séparé), généralisation aux trois autres packages, découpage Pxx, exemples, ordre global des événements, fusions/styles/pagination Exstream et politiques de longueur/null des répétitions. Ce sont des limites actuelles ; aucune impossibilité intrinsèque du format n'est démontrée.

Prochaine action exacte : partir des `scope_decode_issue` dans le JSON final ; examiner d'abord le suffixe du record 4437952 (table vide avec variante de propriétés) et les deux champs divergents du paragraphe 4574019 ; décoder séparément les variantes de glyphes des autres packages avec fixtures indépendantes. Ne pas relâcher un contrôle pour obtenir une portée. Ensuite reprendre les frontières éditoriales Pxx et les exemples.

La table des correspondances R20–R23 de la version précédente reste valable : le numéro documentaire n'est pas une clé métier, utiliser l'ID compilé pour le rapprochement.

---

# Historique conservé

# Révision V6 — moteur 0.3.0, itérations 7 à 9

## Résultat actuel
Rapport final : `validation/revision_v6/iteration_9/rapport.pdf`, **41 pages**, toutes rendues et inspectées. La conformité exhaustive à la référence v6 n'est pas acquise.

Le PDF d'itération 6 fourni en pièce jointe a 76 pages ; son texte extrait correspond à la version de reprise. Référence inchangée : `GroupeAlterna_RetroDocumentation_AFR_EPI_NOE_BULLETIN_VERSEMENT_2026-09-26_v6.pdf` (46 pages, revue intégrale conservée ; rapprochement renouvelé avec les pages 5 et 29 pour l'ordre et le tableau). Aucun original n'a été remplacé.

## Contenu métier et reconnaissance

| Écart depuis 0.2.0 | Preuve dans le PUB | Correction / statut |
|---|---|---|
| Contenus sans parent fiable | Ouverture tag 111, classe 21 et ID ; fermeture tag 104, même classe et ID | Corrigé sur le profil : 27 paragraphes rattachés, dont huit référencés par la section du bulletin |
| Ordre des paragraphes inconnu | Liste comptée de huit références 101/205, offsets 342549–342677 | Corrigé : ordre explicite des huit paragraphes, sans tri par nom |
| Mauvais ordre des objectifs et de l'origine des fonds | Cellules à coordonnées -105 : origine à ligne 15 ; transmission à ligne 2 | Corrigé : lecture selon ligne puis colonne ; numéro de contrat également replacé avant les dispositions |
| Table des supports absente | Grille du paragraphe 21:43718 : 12 lignes, 6 colonnes techniques, cellules métier colonnes 1–4 | Corrigé partiellement : quatre colonnes métier et ordre Euro, Croissance, UC, spécifiques, total. Colonnes vides conservées. Fusions et unités graphiques non interprétées |
| REP1–REP4 non rattachés | Records de lignes à 4599779, 4600686, 4601593, 4602500 ; drivers aux offsets 4599875, 4600782, 4601689, 4602596 | Corrigé sur le profil : quatre REP-L, IDs 107948, 107953, 108184, 107600. Ce sont désormais des propriétés de lignes reliées à la grille, pas de simples occurrences de variables Array |
| Règles mélangées aux composants partagés | 18 règles dans les propriétés de lignes (identifiant dupliqué), 10 dans les listes internes des textes (compteur redondant) | Corrigé : 28 identifiants de la référence rattachés au bulletin ; 118 autres règles conservées dans le JSON |
| Rouge sans cible prouvée | Propriétés de ligne : ex. rule781329 à 4508597/4508601 | Rouge limité aux lignes liées à une règle. Les règles internes sont annotées sans coloration arbitraire ; leur plage exacte reste bloquée |
| Sources de fonctions non extraites | Définition classe 159, identifiant functionNN, texte à longueur bornée avant code compilé | Sources lisibles : 20 → 42 sur 57 calculs ; celles non décodées restent brutes |
| Variables de référence sans chaîne d'origine | TRIGGER DF_REF_TITLE dans function882 ; TRIGGER DF_REF_DIST dans function918 ; mappings de sources de référence | Deux chaînes lookup reliées avec appelants et algorithmes ; contenu réel des référentiels et résultat à l'exécution non établis |
| Conditions compilées simples peu lisibles | Forme exacte IF/comparaison/setInclude/ELSE/setInclude | Cinq variantes du périmètre traduites avec les deux effets explicites. Toute expression hors grammaire reste compilée, notamment les comparaisons de chaînes non prises en charge |
| Dictionnaire différent des 73 champs de la référence | 74 mappings issus des contenus, règles rattachées et formules sélectionnées | Partiel : périmètre plus pertinent, mais sélection exacte, chaînes d'usages indirectes et exemples non établis |

## Présentation et qualité PDF

| Itération | Pages | Revue et corrections |
|---|---:|---|
| 7 | 47 | Toutes inspectées. Vue structurée ajoutée ; variante de style du code UC perdait la cellule ; colonnes ISIN vides décalées ; pages de vue trop aérées |
| 8 | 42 | Toutes inspectées. Header de style lu comme champ 16 bits avec sentinelle ; code UC ligne 6/colonne 2 récupéré ; largeur de colonnes maintenue ; fonctions et appels ajoutés |
| 9 | 41 | Toutes inspectées. Fiches règles regroupées ; titres et extraits regroupés ; place réservée aux grandes cellules ; conditions simples rendues lisiblement |

Aucun texte hors des limites de page détecté ; 41 pages contiennent du texte sélectionnable. Le texte utilise DejaVu Sans et DejaVu Sans Bold intégrées ; logo authentique conservé. Aucune superposition ni coupure de ligne/tableau majeure observée. Des espaces résiduels et des listes de variables réparties sur plusieurs pages restent visibles. L'annuaire est en portrait alors que la référence emploie un format large.

La vue est une transcription documentaire de toutes les variantes reconnues, avec variables apparentes. Elle n'est pas un exemplaire client évalué, ni une restitution pixel par pixel des trois pages Exstream. Le découpage B01–B62 suit les cellules ; P00–P25 n'est pas encore reconstruit. Les frontières typographiques des fragments internes demeurent non interprétées.

## Vérifications et préservation
- 33 tests passent, dont trois contrôles du PUB exact, sans test sauté ; un avertissement httpx de dépréciation.
- Calibration relancée après les corrections : 76/76 sur quatre packages, portée ciblée.
- Les 28 identifiants de référence sont présents et associés. Le ciblage de 10 règles internes au caractère n'est pas validé.
- 12 fichiers source frontend inchangés. API, worker, jobs, sécurité, configuration et Compose inchangés par empreintes.
- Docker/Windows/PostgreSQL non exécutés ici.
- Générateur indépendant du PDF v6 : il ne consomme que le modèle issu du PUB ; aucun remplacement statique et aucun Tools Reports.

## Numérotation des règles
Les numéros R du rapport suivent l'ordre de première rencontre. Ils ne sont pas tous identiques à ceux du PDF v6. L'identifiant compilé est la clé stable de rapprochement.

| Identifiant | Rapport 0.3.0 | Référence v6 |
|---|---|---|
| rule790284 | R1 | R1 |
| rule777343 | R2 | R2 |
| rule781268 | R3 | R3 |
| rule781270 | R4 | R4 |
| rule787027 | R5 | R5 |
| rule781269 | R6 | R6 |
| rule781274 | R7 | R7 |
| rule781277 | R8 | R8 |
| rule781276 | R9 | R9 |
| rule781278 | R10 | R10 |
| rule781279 | R11 | R11 |
| rule781280 | R12 | R12 |
| rule781281 | R13 | R13 |
| rule781282 | R14 | R14 |
| rule781283 | R15 | R15 |
| rule781284 | R16 | R16 |
| rule781285 | R17 | R17 |
| rule781286 | R18 | R18 |
| rule781287 | R19 | R19 |
| rule781329 | R20 | R22 |
| rule781330 | R21 | R23 |
| rule781331 | R22 | R20 |
| rule781332 | R23 | R21 |
| rule789439 | R24 | R24 |
| rule790440 | R25 | R25 |
| rule790441 | R26 | R26 |
| rule789194 | R27 | R27 |
| rule781266 | R28 | R28 |

## Blocages et prochaine action
Les listes de règles internes sont décodées et reliées aux textes, mais pas leur correspondance avec les plages de caractères. Exemple : 4426336 contient la liste du texte d'adresse ; les mêmes IDs peuvent apparaître plusieurs fois. Ne pas assimiler son ordre à l'ordre des fragments ni colorer toute la cellule.

Prochaine action exacte : décoder les attributs de segments entre 4425526 et 4426608 et les tokens de mise en forme du texte commençant à 4420501 ; valider une plage Oui/Non sur plusieurs règles, avec test rejetant une association ambiguë. Ensuite seulement appliquer le rouge et affiner les unités Pxx. Décoder en parallèle les valeurs d'exemple dans les records variables et les frontières d'événements. Les limites sont celles du lecteur actuel ; aucune impossibilité intrinsèque du format n'est démontrée.

---

# État antérieur conservé : 0.2.0

# Comparaison V6 — moteur 0.2.0, itération 6

## Conclusion
Amélioration partielle, **non conforme à la cible V6**. Le rapport de 76 pages est un dossier de preuves enrichi, pas encore la reconstruction du courrier. Les 46 pages de référence et les 6 pages du rapport initial ont été inspectées avant modification. Les PDF d'origine sont conservés.

Source analysée : `04-AFR_EPI_NOE_BULLETIN_VERSEMENT.pub`, SHA-256 `f23ca63a540159156cc72f63277b238bf656751f1035791fae294b65b21f0877` (identique à la référence). Les spécifications 01/02, charte 14, tokens et logo ont aussi été consultés. Aucun Tools Reports utilisé. Le générateur ne lit pas le PDF v6.

## Écarts et preuves

| Écart | Preuve / cause | Résultat |
|---|---|---|
| Rapport limité aux premières règles et mappings | Ancien render.py : troncatures ; référence p.33–38 et 41–46 | Corrigé pour le catalogue : 146 règles du package, 77 mappings sélectionnés ; périmètre du courrier encore incertain |
| Calculs manquants | PUB : signatures `_formula[` et `_formulas[` ; regex initiale ne lit que la seconde | Corrigé : 57 calculs contre 37 ; 20 sources lisibles rattachées |
| Texte métier absent | Enregistrements à longueur redondante ; titre à 4368307, identité à 4409463, adresse à 4420501 | Partiel : 162 unités de contenu avec offsets ; certaines appartiennent aux composants partagés |
| Sources des algorithmes peu lisibles | Initialisation : source 5265677, compilé 5277199 ; patrimoine : source 5394391, compilé 5397377 | Corrigé sur les sources décodées ; originaux complets conservés dans le modèle |
| Dépendances à noms ignorées | Appels getValue avec nom entre guillemets dans le code compilé | Corrigé : résolution via dictionnaire de variables, sans exécuter le code |
| Référentiels confondus avec entrées | Racine flow également dans les références ; INPUT à 349723, références après 3604004 | Partiel : classification empirique avec preuve ; pas de namespace ou chemin inventé |
| Courrier complet, P00–P25 et ordre réel absents | Référence p.4–28 ; les offsets placent origine des fonds 4443394 avant objectifs 4446952, contrairement au courrier | Bloqué par relations parent/enfant et ordre documentaire non décodés ; Txxx n'est pas Pxx |
| Cibles rouges non établies | Règle 790284 référencée à 4378107 ; source à 5139839 ; champs de portée encore non interprétés | Les 28 identifiants de référence sont présents, mais leurs cibles exactes ne sont pas validées. Aucun rouge arbitraire |
| REP1–REP4 non reconstruits | Référence tableaux p.29–30 ; candidats à 4535240, 4540852, 4555120, 4560688 | Bloqué : quatre signatures ne démontrent pas quatre répétitions métier ; UC et supports spécifiques non reconstruits |
| Valorisation et composition | Formule 107407 récupérée ; instructions internes visibles mais ordre global de déclenchement inconnu | Partiel : code et dépendances exposés ; ordre d'exécution global non affirmé |
| Valeurs nulles / défauts | Patrimoine : initialisation vide, cas explicites chaîne vide/null → Aucun ; pas de CaseElse | Source conservée ; aucune branche opposée ni valeur client fabriquée |
| Dictionnaire attendu de 73 champs | Référence p.41–46 ; sélection actuelle 77 mappings liés aux contenus/règles | Partiel : sélection exacte des 73 champs, exemples et usages exhaustifs non établis |
| Présentation | Charte, référence : bleu marine, cyan, logo, tables et annotations | Partiel : styles rapprochés ; reconstruction graphique et pagination du v6 non reproduites |
| Coupures et espace excessif | Itérations 3/4 : KeepTogether imbriqués → 202 pages | Corrigé : groupe unique par fiche ; itération 6 : 76 pages sans coupure ou superposition majeure observée. Quelques espaces résiduels et code dense |
| Exclusions du cahier | Sections de redéveloppement et jeu minimal de tests présentes dans la référence mais exclues du cahier consolidé | Exclusions respectées dans le rapport |

## Vérifications
- 24 tests réussis ; un avertissement de dépréciation httpx, aucun échec.
- Calibration : 76 contrôles ciblés sur quatre packages. Ce périmètre ne valide pas la reconstruction métier.
- Les 28 identifiants de règles de référence sont retrouvés parmi les 146 règles du package ; présence n'est pas validation de portée.
- 12 fichiers source de l'interface inchangés par comparaison d'empreintes. API et worker inchangés.
- Rapports 1 (94 pages), 2 (65), 5 (73) et 6 (76) intégralement rendus et inspectés. Rapports 3/4 (202 pages chacun) rendus mais rejetés après constat du défaut répétitif, sans revue intégrale prétendue.
- Texte sélectionnable, polices DejaVu intégrées, logo authentique. Aucun remplacement statique par le PDF de référence.
- Docker/Windows/PostgreSQL non exécutés dans cet environnement.

## Reprise exacte
Décoder les relations parent/enfant et champs de ciblage autour de 4377580–4378107, puis vérifier indépendamment une relation texte/règle et une relation table/colonne/répétition avant généralisation. Établir un test de non-régression à partir de ces preuves. Reprendre ensuite l'ordre Pxx, les répétitions UC/spécifiques et la vue composée. Ne pas supposer ces limites irréductibles : elles sont celles du décodeur actuel, pas la preuve que le PUB ne contient pas l'information.
