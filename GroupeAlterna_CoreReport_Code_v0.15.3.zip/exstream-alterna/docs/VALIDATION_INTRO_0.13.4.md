# Core Report 0.13.4 — Puces, interligne et dimensions

30 septembre 2026 — itération 44. Base 0.13.3 conservée.

## Constat et correction

Dans PAR_AFR_IAR_IARD_VEHIC_PLAISANCE_CP_DEVIS_IntroCP, le contenu utilise Source Sans Pro Regular 10 pt, y compris les noms de variables. Cette police est vérifiée et conservée ; aucune uniformisation arbitraire des titres ou passages gras. Les cinq paragraphes du contenu central sont conservés, avec deux véritables propriétés de puce dans les deuxième et troisième paragraphes.

Ces puces utilisent un symbole Wingdings 0xA7. Le préfixe compté identifie son caractère et son emplacement dans la table de polices ; son équivalent Unicode est le petit carré noir U+25AA. Référence : Unicode WG2 N4115, ligne w-1167, page 27 : https://www.unicode.org/L2/L2011/11344-wingdings.pdf. Le dessin est rendu avec DejaVu Sans embarquée comme substitution du symbole, sans appliquer Wingdings au texte ni aux variables. Les modes et glyphes non reconnus restent non interprétés.

Retrait des deux puces : 42/300 pouce, soit 10,08 pt. Taille : 10 pt. Interligne retrouvé : 52/300 pouce, soit 12,48 pt. Les espaces avant/après et les frontières des paragraphes sont conservés. Les retours automatiques sont recalculés dans la largeur source ; les positions de lignes composées ne sont pas transformées aveuglément en sauts forcés, car les noms longs des variables et l'affichage de toutes les conditions changent la composition.

Le tableau IntroCP possède une colonne de 1500/300 pouce = **12,70 cm**. Ses hauteurs de lignes sources 191, 411 et 284 unités sont désormais utilisées comme minima (45,84, 98,64 et 68,16 pt). Les largeurs reconnues des autres tableaux restent converties depuis 1/300 pouce, sans étirement des tableaux étroits à toute la page.

Les zones de texte conservent leurs dimensions et leur hauteur minimale bornées. Une zone parente contenant des objets ancrés ne réserve pas une seconde fois la hauteur de ses enfants. Le texte libre à largeur source conserve la possibilité de se répartir sur plusieurs pages. La hauteur augmente si nécessaire pour ne pas tronquer les variables ou les branches documentées ; ce n'est pas une reproduction de la pagination d'un courrier valorisé.

## Fichiers

- `backend/retro/scopes.py` : conserve l'adresse de la table des lignes atteinte par la grammaire existante.
- `backend/retro/text_styles.py` : lecture bornée des puces personnalisées et de leur police ; interligne dérivé des géométries de lignes corroborées. Contrôle des bornes, ordre, dimensions et terminaison avant emploi.
- `backend/retro/visual_graphics.py` : transmet les polices au lecteur de paragraphes et exige un propriétaire identique pour les dimensions de fond.
- `backend/retro/visual_render.py` : puces et retraits, interligne source reconnu, hauteurs minimales des lignes et zones, largeur source des textes libres. `SourceWidthFlowable` permet leur coupure entre pages ; pas de double comptage des objets ancrés. Empreintes de présentation enrichies pour ne pas dédupliquer des contenus dont les puces ou l'interligne diffèrent.
- `backend/tests/test_intro_layout.py` : sept cas, dont vérification des deux puces, des variables Regular 10 pt, du retrait, de l'interligne et des dimensions ; mutations de caractère/police/mode de puce et de bornes ; contrôle du non-double-comptage des enfants.

Aucune sélection par nom de fichier, paragraphe, identifiant métier, empreinte ou offset absolu dans les nouveaux profils du moteur. Les offsets et valeurs métier sont limités aux tests sur fixtures client.

## Validation

**246 tests finaux réussis, zéro échec et zéro saut.** La première campagne a révélé des conteneurs ancrés réservés deux fois et des textes longs devenus insécables : corrigés avant la suite finale. Les journaux intermédiaires sont conservés. Avertissement Starlette/httpx préexistant.

14 chemins / 13 PUB distincts ; 26 PDF / 2434 pages. Comparaison des 11 PUB historiques avec 0.13.3 : faits sources, textes/variables, règles, topologies et contenus visuels préexistants conservés. Aucun vide/débordement de page physique, manque/doublon de contenu reconnu, ligne fractionnée ou paragraphe excessif signalé par les contrôles finaux.

Plaisance CP : rapport 205 pages, visuel 14 pages. Revue des 14 pages du visuel et des pages 1/2/3/5/7/35/205 du rapport ; zoom du visuel 1 et du rapport 5. Les autres pages sont contrôlées automatiquement, sans prétendre à une revue visuelle exhaustive des 26 PDF.

| Source | Rapport | Visuel |
|---|---:|---:|
| AFR_GENERIC_IARD_VEHIC_NOA_DEVIS.pub | 283 | 15 |
| 03-AFR_EPI_NOE_BULLETIN_ADHESION.pub | 177 | 10 |
| 04-AFR_EPI_NOE_BULLETIN_VERSEMENT.pub | 133 | 5 |
| 05-AFR_GENERIC_FIP_DEVIS_ESSENCIEL.pub | 173 | 10 |
| 06-AFR_GENERIC_PROJET_OBSEQUES_ESSENCIEL.pub | 131 | 9 |
| 07-AFR_IARD_DEVIS_AUTO.pub | 128 | 14 |
| AFR_EPI_NOE_BULLETIN_ADHESION_Color.pub | 171 | 10 |
| AFR_EPI_NOE_BULLETIN_ADHESION_Round.pub | 171 | 10 |
| AFR_EPI_NOE_BULLETIN_ADHESION_Width.pub | 171 | 10 |
| AFR_EPI_NOE_BULLETIN_ADHESION_Black.pub | 171 | 10 |
| AFR_EPI_NOE_BULLETIN_ADHESION_BorderPink.pub | 171 | 10 |
| upload/AFR_GENERIC_IARD_VEHIC_PLAISANCE_CP_DEVIS.pub | 205 | 14 |
| /workspace/scratch/ae30fa916b72/upload/AFR_GENERIC_IARD_VEHIC_PLAISANCE_FDC.pub | 211 | 11 |

## Reproduction et limites

`PYTHONPATH=backend PUB_TABLE_CORPUS=/chemin/corpus PUB_PLAISANCE_CP=/chemin/AFR_GENERIC_IARD_VEHIC_PLAISANCE_CP_DEVIS.pub python -m pytest backend/tests -q`

Les fixtures historiques vont dans `../project_sources`, les variantes dans PUB_TABLE_CORPUS/pub_variants et pub_variants2. Les PUB client ne sont pas redistribués. Tests dépendants explicitement sautés lorsque les sources manquent.

Le FDC Plaisance à en-tête nul reste refusé par le moteur normal : il est testé avec le contournement local autorisé auparavant, isolé dans le banc. Les profils de puces, retraits et géométrie inconnus restent des limites explicites ; toutes les puces Exstream ne sont pas déclarées couvertes. Les images non reliées, le soulignement non calibré, la pagination native et l'évaluation des conditions restent hors de cette correction. Aucun déploiement ni recette Windows/Docker/navigateur/PostgreSQL dans cette itération.
