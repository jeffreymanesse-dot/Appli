# Charte graphique Groupe Alterna

Version 1.0 • 25 septembre 2026

Référentiel opérationnel pour documents, tableaux, images, présentations, web et IHM.

## 01. Fondements et références

### Intention

Une identité sobre et structurée : fond blanc, typographie sans empattement, marine pour la hiérarchie, cyan pour les accents. Le motif ramifié à cercles évoque visuellement les connexions et le développement. Cette lecture graphique ne constitue pas une affirmation sur les activités ou les valeurs officielles du Groupe.

### Ce que contiennent les sources

Logo_GroupeAlterna.png : image RGBA transparente de 467 × 236 pixels. fond.docx : document A4 portrait, marges de 25 mm, sans contenu rédactionnel ; logo centré dans l’en-tête courant et grand motif pâle en arrière-plan. Il contient un second logo transparent de 825 × 416 pixels et un fond JPEG CMJN de 2481 × 3508 pixels avec profil ICC.

### Typographies constatées

Le thème Word indique Aptos pour le corps et Aptos Display pour les titres ; le corps par défaut est de 12 pt. Ces paramètres sont ceux du thème Office et ne prouvent pas un choix typographique de marque. La police exacte du lettrage du logo n’est pas identifiée : conserver le dessin du logo.

### Statut de la version 1.0

Cette charte opérationnelle, datée du 25 septembre 2026, préserve les éléments fournis et fixe des règles complémentaires pour les nouveaux supports. Les dimensions d’usage, palettes fonctionnelles, grilles et composants sont des propositions de normalisation applicables par défaut, révisables par le propriétaire de la marque.

### Priorité des règles

Une demande explicite de l’utilisateur prime sur les règles de cette charte. Pour les autres choix, appliquer cette version ; le fichier du logo fait autorité sur son dessin. Ne pas reprendre automatiquement toutes les couleurs du thème Office comme couleurs de marque. Ne jamais inventer de slogan, coordonnées, mentions légales, certifications ou filiales.

## 02. Logo et motif de fond

### Version de référence

Employer le logo complet en couleur sur fond blanc. Préférer assets/Logo_GroupeAlterna_825px.png, extrait sans modification du document Word, pour les documents. Le PNG joint reste disponible sous son nom original. Respecter le rapport propre à chaque fichier : 1,979 pour le 467 px et 1,983 pour le 825 px ; ne jamais forcer les deux dimensions.

### Tailles et protection

Règle proposée : largeur minimale 35 mm en impression et 160 px CSS à l’écran. Taille courante A4 : 40 à 50 mm ; en-tête web : 180 à 220 px CSS. Réserver autour du logo une zone libre égale à 15 % de sa hauteur totale, hors du rectangle de l’image. Ne placer ni texte, ni bordure, ni autre logo dans cette zone.

### Qualité disponible

À 300 pixels/pouce, les largeurs maximales natives sont de 39,5 mm pour le PNG 467 px et 69,9 mm pour le PNG 825 px. Un agrandissement logiciel n’ajoute pas de détail. Pour de grandes affiches, demander un original vectoriel SVG, EPS ou PDF ; ne pas prétendre qu’un PNG placé dans un SVG devient vectoriel.

### Surfaces et interdits

Sur une photo ou un fond foncé, placer le logo sur un cartouche blanc avec sa zone de protection. Aucune version blanche ou monochrome officielle n’est fournie. Ne pas recolorer, étirer, pivoter, recadrer, redessiner, ajouter d’ombre ou recomposer le mot ALTERNA avec une police. Ne pas détacher le symbole pour un favicon sans variante validée.

### Motif de fond

Utiliser le JPEG extrait pour une couverture, un séparateur ou une page aérée. Il comporte déjà un fond blanc et un motif très pâle : ne pas lui appliquer une transparence supplémentaire par défaut. Le conserver proportionnel, orienté comme dans le document source. Sur pages denses, tableaux et formulaires, préférer un fond blanc sans motif ; aucune donnée ne doit être masquée.

### Reproduction du modèle

fond.docx reste le modèle visuel de départ, pas un gabarit universel pour tous les formats. Ses en-têtes première page, paire et courante ne sont pas identiques. Contrôler les pages après export, notamment les documents multipages. Conserver le JPEG CMJN et son profil pour l’impression ; effectuer une conversion colorimétrique gérée pour le web.

## 03. Palette et contrastes

### Référence des couleurs

Les HEX sont des références numériques de travail, relevées ou proposées dans la référence Markdown. Marine, cyan et noir sont relevés ; bleu fonctionnel et neutres sont proposés. Le logo contient un dégradé et de nombreux pixels intermédiaires : la palette ne remplace jamais son image. Le marine est un ton sombre représentatif relevé, pas une preuve de spécification historique.

### Répartition

Viser environ 75 % de blanc et de surfaces claires, 20 % de marine/bleu et 5 % de cyan dans les éléments graphiques hors photographies. Cette proportion est un guide, pas une contrainte de surface à mesurer. Le cyan attire l’attention ; éviter les grands aplats saturés sur les pages de lecture.

### Dégradé et impression

Pour un élément décoratif neuf seulement : dégradé horizontal #212F44 vers #176B9A puis #35BAEC. C’est une interprétation, pas une reconstruction exacte du logo. Aucune référence Pantone ou recette CMJN officielle ne peut être déduite des fichiers. Convertir selon le profil de sortie de l’imprimeur et contrôler une épreuve.

### Lisibilité

Cible interne : contraste de 4,5:1 au minimum pour tout texte courant et 3:1 pour les contours fonctionnels. Le blanc sur cyan et le cyan sur blanc sont insuffisants pour le texte. Utiliser le marine sur cyan. Un état, une série ou une erreur doit aussi avoir un libellé, une forme ou une icône ; jamais uniquement une couleur.

### Couleurs de travail

| Nom | HEX | RVB | Usage | Provenance |
|---|---|---|---|---|
| Marine Alterna | #212F44 | 33, 47, 68 | Titres, texte principal, en-têtes | Pixel opaque relevé dans les logos |
| Cyan Alterna | #35BAEC | 53, 186, 236 | Accent, repères, décoration | Aplat dominant relevé dans les logos |
| Noir du logo | #070708 | 7, 7, 8 | Lettrage GROUPE ; usage limité | Aplat relevé dans les logos |
| Bleu fonctionnel | #176B9A | 23, 107, 154 | Boutons, liens, données principales | Extension proposée |
| Blanc | #FFFFFF | 255, 255, 255 | Fond principal | Présent dans le document |
| Fond doux | #F3F8FC | 243, 248, 252 | Cartes et lignes alternées | Extension proposée |
| Gris secondaire | #536476 | 83, 100, 118 | Légendes et métadonnées | Extension proposée |
| Bordure douce | #D8E4ED | 216, 228, 237 | Séparateurs décoratifs | Extension proposée |
| Bordure active | #70849A | 112, 132, 154 | Contours de champs et contrôles | Extension proposée |

## 04. Typographie et composition

### Familles

Bureautique : Aptos pour le corps, Aptos Display pour les titres lorsque disponibles. Replis : Arial, puis DejaVu Sans. Web et IHM : Arial, Helvetica, sans-serif, pour une base stable sans téléchargement externe. Pour ce PDF, DejaVu Sans est incorporée. Ne pas mélanger plus de deux familles dans un support ; garder une seule famille de repli dans tout le document.

### Échelle bureautique

Titre de couverture 28 à 32 pt, titre principal 20 pt, sous-titre 16 pt, intertitre 13 pt gras, corps 12 pt, légende 10 pt, note/pagination 9 pt minimum. Profil guide technique compact : corps 10 à 11 pt, notes 8 pt, titres 23 pt ; c’est le profil de ce guide. Marine pour les titres et le corps ; gris secondaire pour les légendes. Éviter les titres tout en capitales, sauf libellés très courts. Le dessin capitalisé du logo reste inchangé.

### Rythme de lecture

Alignement à gauche, interligne 1,15 à 1,25 en bureautique ; 1,5 sur le web. Espacement après paragraphe 6 à 8 pt. Avant titre : 12 à 18 pt ; après : 6 à 8 pt. Conserver les titres avec le paragraphe suivant et éviter les lignes isolées. Limiter la largeur des paragraphes web à environ 65 caractères.

### Grille

A4 portrait 210 × 297 mm, marges 25 mm (18 mm pour un guide technique compact) ; passer en paysage pour un tableau large plutôt que réduire excessivement la police. Grille numérique fondée sur 4 px : 4, 8, 12, 16, 24, 32, 48, 64. Cartes web : espacement interne 24 px, arrondi 8 px. Ne pas imposer ces pixels aux mesures de document imprimé.

### Ton et rédaction

Français par défaut ; dénomination éditoriale : Groupe Alterna. Ton professionnel, direct, clair et concret. Titres informatifs, acronymes explicités à leur première apparition, unités et dates cohérentes. Conserver le contenu métier et les chiffres ; la mise en forme ne doit jamais les modifier.

## 05. Word et PDF

### Structure par défaut

En-tête : logo centré de 42 mm de large (aligné à droite pour le profil guide compact), cohérent avec le document fourni. Corps de page : titre, contexte ou synthèse, sections, tableaux éventuels. Pied : titre court, version ou date si utile, numéro de page. Réserver au moins 8 mm entre l’en-tête et le contenu ; une marge supérieure de 40 mm convient à un logo haut d’environ 21 mm.

### Deux usages du fond

Mode institutionnel : motif original sur couverture ou page courte et aérée. Mode lecture : pages intérieures blanches, identité portée par le logo, les titres et les couleurs de tableau. Ne pas étendre systématiquement le filigrane à un rapport dense. Le présent guide illustre le mode lecture.

### Styles éditables

Utiliser les vrais styles Titre, Titre 1, Titre 2, Titre 3, Normal, Légende et les listes natives. Prévoir un sommaire pour les rapports longs. Ajouter un texte alternatif au logo porteur d’identité ; marquer le fond comme décoratif lorsque le format le permet. Les titres doivent structurer la navigation, pas seulement avoir une taille différente.

### Tableaux

En-tête marine, texte blanc, corps sur blanc et alternance #F3F8FC. Texte à gauche, chiffres à droite, unités dans l’en-tête. Bordures légères #D8E4ED ; pas de grille noire épaisse. Répéter la ligne d’en-tête sur les pages suivantes. Ne pas fusionner des cellules qui compliquent inutilement la lecture.

### Export PDF

Exporter du texte sélectionnable, avec polices incorporées et liens fonctionnels lorsque possibles. Conserver les signets et balises d’accessibilité si l’outil le permet ; ne pas déclarer une conformité sans audit. Contrôler chaque page rendue : accents, images, sauts de page, titres orphelins, contrastes et pagination.

### Livraison

Un document Word doit rester modifiable. Un PDF doit s’ouvrir sans police manquante ni contenu rogné. Ne pas transformer un document entier en image pour préserver sa mise en page. Fournir les deux formats seulement si demandés ou utiles au besoin ; nommer clairement la version et la date.

## 06. Excel et graphiques

### Organisation du classeur

Police Aptos 11 pt, repli Arial ou DejaVu Sans. Première feuille « Synthèse » si plusieurs feuilles. Ajouter le logo une fois sur la synthèse, ancré et sans masquer de cellule. Réserver les premières lignes pour le titre et la période. Figer la ligne d’en-tête, activer les filtres et ajuster les colonnes ; éviter les cellules fusionnées dans les données.

### Styles de données

En-têtes marine avec texte blanc gras, lignes alternées blanches et fond doux. Entrées utilisateur : fond #E7F6FC, texte marine et légende « À renseigner ». Résultats calculés : fond blanc ; totaux gras sur fond doux. Les couleurs de saisie ne remplacent ni la validation des données ni la protection éventuelle des formules.

### Nombres

Conserver les nombres comme valeurs numériques. Format français : 1 234,56 ; montant 1 234,56 € ; pourcentage 12,3 % ; date jj/mm/aaaa. Adapter le nombre de décimales à l’information. Distinguer zéro, donnée manquante et non applicable. Ne pas convertir une formule en texte pour la styliser.

### Graphiques

Fond blanc, sans 3D, grille horizontale discrète, unités explicites et titre informatif. Série principale #176B9A ; comparaison #212F44 ; troisième série #35BAEC avec étiquettes foncées. Ajouter marqueurs, styles de trait ou étiquettes directes. Le cyan ne doit pas porter seul une courbe fine indispensable sur fond blanc.

### Comparaisons et alertes

Au-delà de trois séries, préférer des petits graphiques séparés ; si nécessaire, étendre avec #7656A5, #A85D00 et #18734A et des formes distinctes. Ces couleurs sont fonctionnelles, pas des couleurs du logo. Succès #18734A, avertissement #8A5800, erreur #B3261E ; toujours accompagner d’un texte.

### Impression et contrôle

Zone d’impression définie, une page en largeur mais hauteur libre, titres répétés, paysage au besoin. Vérifier la lisibilité à taille réelle et le recalcul des formules. Contrôler valeurs, filtres, références, unités et absence d’erreurs ; une charte cohérente ne suffit pas à valider le calcul.

## 07. Présentations et images

### Diaporamas

Format 16:9 par défaut. Logo complet sur cartouche blanc si nécessaire, dans un emplacement stable ; éviter qu’il domine chaque diapositive. Titres 30 à 36 pt, texte 20 à 24 pt, légendes 14 pt minimum. Une idée forte par diapositive ; fond blanc, texte marine, un accent bleu ou cyan.

### Visuels et illustrations

Privilégier des compositions aérées, une géométrie simple, des lignes arrondies et des points de connexion inspirés du motif fourni. Photos naturelles, nettes, cadrées sur le sujet, sans dominante de couleur forcée. Ne pas présenter des personnes, locaux ou réalisations fictifs comme appartenant au Groupe.

### Production d’images

Définir d’abord l’usage et le format final : carré 1080 × 1080, portrait 1080 × 1350, paysage 1920 × 1080 ou dimensions demandées. Ces formats sont des canevas de travail proposés. Garder environ 5 % de marge de sécurité pour textes et logo. Prévoir PNG pour transparence et diagrammes ; JPEG pour photos ; SVG pour dessins réellement vectoriels.

### Génération assistée

Décrire la composition, la palette, le style, le sujet et une zone libre pour la marque. Ajouter ensuite le véritable logo comme élément graphique, sans le demander redessiné au générateur. Les titres, chiffres et mentions doivent être composés et relus séparément lorsque leur exactitude compte.

### Prompt de base

Créer un visuel professionnel pour Groupe Alterna, fond blanc ou très clair, palette marine #212F44, bleu #176B9A et touches cyan #35BAEC, composition aérée, géométrie simple et évocation discrète des connexions. Réserver une zone blanche au logo fourni. Sujet : [sujet demandé]. Format : [dimensions]. Ne pas inventer de slogan ni de texte institutionnel.

### Résolution

Pour l’impression, viser 300 pixels/pouce à la taille finale des images matricielles. Ne pas confondre dimensions en pixels et résolution d’impression. Le fond JPEG fourni a des dimensions proches d’un A4 à 300 pixels/pouce ; le logo reste limité par ses propres dimensions.

## 08. Web et interfaces métier

### Structure responsive

Fond #F3F8FC ou blanc, contenu centré de 1200 px maximum, marges latérales 24 px sur bureau et 16 px sur mobile. Grille 12 colonnes sur bureau et une colonne sur petit écran ; seuil de travail 768 px, à adapter au contenu. Aucun défilement horizontal global ; permettre un défilement local pour les grands tableaux.

### Typographie et cartes

Corps 16 px, petits textes 14 px minimum, h1 40 px sur bureau / 32 px sur mobile, h2 28 px, h3 20 px. Cartes blanches, arrondis 8 px, bordure douce 1 px, ombre légère facultative. Espacements issus de la grille de 4 px. Éviter le motif derrière un formulaire, une grille métier ou une zone de lecture.

### Boutons et liens

Action principale : fond #176B9A, texte blanc ; survol #12567C. Action secondaire : fond blanc, texte et bordure #176B9A. Cyan réservé aux accents, ou fond cyan avec texte marine. Liens bleus soulignés dans le texte. Libellés verbaux précis : « Télécharger », « Enregistrer », « Annuler ».

### Interaction

Contrôles d’au moins 44 px de haut comme objectif interne de confort. Focus clavier visible : contour #176B9A de 3 px, décalage blanc de 3 px. Champs avec label permanent et bordure #70849A ; placeholder facultatif, jamais seul libellé. Navigation clavier, ordre de tabulation logique, erreurs reliées au champ et annoncées aux technologies d’assistance.

### États

Prévoir normal, survol, focus, actif, désactivé, chargement, vide, succès et erreur. Désactivé : fond #E7EDF2, texte #536476 et comportement réellement désactivé. Chargement avec message ; erreur en #B3261E avec explication et solution. Respecter la réduction des animations demandée par l’appareil.

### Mode sombre

Non défini par les fichiers sources. Par défaut, livrer un mode clair cohérent. Si un mode sombre est demandé, créer une palette dédiée, conserver le logo sur cartouche blanc et vérifier tous les couples texte/fond et les états. Ne pas obtenir le mode sombre par simple inversion des couleurs.

## 09. Application dans un Projet

### Sources à joindre

Ajouter Charte_Graphique_Groupe_Alterna.md comme référence textuelle, le PDF pour la lecture visuelle, puis le logo 825 px et fond.docx. Le kit ZIP regroupe les sources, les règles et les fichiers techniques ; extraire ses fichiers avant de les ajouter comme sources. Le JSON et le CSS servent aux productions automatisées et aux interfaces.

### Instructions du Projet

Copier le contenu de Instructions_Projet_Groupe_Alterna.txt dans les instructions du Projet. La présence d’un fichier de charte seule ne garantit pas son application dans chaque outil : les instructions doivent demander sa consultation et une vérification avant livraison. Aucune configuration du Projet n’est effectuée par ce kit.

### Routine de production

Avant création : lire la charte, choisir les règles du format, vérifier la disponibilité du logo. Pendant : utiliser les codes exacts et les styles nommés ; préserver le contenu métier. Après : rendre et inspecter le résultat, vérifier les données ou interactions selon le format, puis livrer le fichier final.

### Cas dégradés

Si le logo est absent, ne pas le recréer : appliquer les couleurs et la typographie, indiquer la limite et demander le fichier si sa présence est indispensable. Si une police manque, appliquer un repli cohérent et contrôler les retours à la ligne. Si le format ne permet pas le branding, le signaler : un CSV ou un TXT ne porte pas de styles visuels.

### Contrôle avant livraison

Logo intact et lisible ; marges et zone de protection ; palette et hiérarchie ; contraste ; absence de chevauchement ; lisibilité des tableaux ; exactitude des données ; texte alternatif lorsque pertinent ; liens et navigation ; format et nom corrects. Pour un fichier multipage, inspecter toutes les pages. Pour une interface, tester au moins petit et grand écran ainsi que le clavier.

### Évolution

Nommer les fichiers GroupeAlterna_TypeDocument_Objet_AAAA-MM-JJ_v1.ext. Incrémenter la version lorsque les règles changent et mettre à jour ensemble MD, PDF, JSON et CSS. Une charte ultérieure explicitement validée remplace cette version ; conserver la provenance des actifs et les exceptions demandées.

## Annexe : contrastes calculés

Calcul sur les valeurs sRGB des aplats, sans transparence. Vérifier de nouveau après toute modification de couleur, opacité ou arrière-plan.

| Premier plan | Fond | Rapport | Usage |
|---|---|---|---|
| #212F44 | #FFFFFF | 13.51:1 | Texte courant possible |
| #176B9A | #FFFFFF | 5.82:1 | Texte courant possible |
| #536476 | #FFFFFF | 6.08:1 | Texte courant possible |
| #35BAEC | #FFFFFF | 2.24:1 | Décoration seulement |
| #212F44 | #35BAEC | 6.04:1 | Texte courant possible |
| #70849A | #FFFFFF | 3.85:1 | Contours seulement |

## Fichiers du kit

- Charte_Graphique_Groupe_Alterna.pdf : guide visuel.
- Charte_Graphique_Groupe_Alterna.md : référence textuelle complète.
- Instructions_Projet_Groupe_Alterna.txt : bloc à copier dans les instructions.
- alterna.tokens.json : valeurs partagées et provenance.
- alterna.css : base de styles web.
- assets/ : copies inchangées du logo joint, du logo extrait, du fond JPEG et de fond.docx.
- manifest.json : dimensions et empreintes SHA-256 des actifs pour contrôler leur intégrité.
