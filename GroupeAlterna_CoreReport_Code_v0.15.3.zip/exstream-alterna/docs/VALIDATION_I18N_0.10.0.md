# Validation 0.10.0 — interface et rapports bilingues

Date : 29 septembre 2026. Base préservée : 0.9.1, dans une copie isolée. Itération 36.

## Réalisation

Catalogue explicite FR/EN pour les textes de présentation. La langue est isolée par contexte de rendu, stockée avec les options de la tâche et passée de l'interface à l'API, au worker et aux exporteurs. Les sorties historiques restent dans leur langue d'origine. Défaut français pour les anciens appels et les anciennes tâches ; une langue invalide est refusée.

Les textes source ne passent pas dans le catalogue : littéraux du courrier, noms, algorithmes, conditions, preuves brutes et chemins XML restent intacts. Les diagnostics appartenant au moteur sont traduits selon un catalogue ou des gabarits numériques bornés. Les associations métier et les données du modèle ne sont pas modifiées.

L'interface garde sa charte et ses interactions. Deux boutons avec drapeaux vectoriels sont ajoutés dans l'en-tête, avec nom accessible, état sélectionné et navigation au clavier. Les erreurs, aides, dates, unités et liens sont présentés dans la langue choisie. Aucun nouveau format de téléchargement n'est exposé.

## Tests

| Contrôle | Résultat |
|---|---|
| Suite backend complète | 146 réussites, 0 échec, 0 saut ; 71,106 s |
| Nouveaux cas de traduction | 14 cas couvrant API, worker, sorties, langue historique, invalidité, concurrence et préservation des sources |
| Compatibilité | Tests quota 0.9.1, sécurité, options, export et corpus de six PUB réussis |
| Frontend | Compilation de production Next.js et contrôle TypeScript réussis |
| Navigateur réel | FR/EN, clavier, persistance, analyse/comparaison, sélection et options conservées, états et erreurs traduits |
| Analyse via interface | Versement, annuaire seul, langue anglaise conservée malgré bascule FR pendant le traitement et actualisation ; deux PDF téléchargés en anglais |
| Formats d'écran | 1 440 × 1 100 et 390 × 844 ; aucun débordement horizontal détecté |
| Données PUB | Modèles identiques avant/après exports FR/EN ; test de collision entre littéraux source et mots du catalogue |
| Isolation | Langues concurrentes et remise à zéro du contexte après erreur testées |

Un avertissement de dépréciation Starlette/httpx demeure. Aucun changement de dépendance n'a été introduit.

## Corpus PDF

Toutes les options de chapitres sont activées pour les générations ci-dessous.

| PUB | Rapport FR | Rapport EN | Visuel FR | Visuel EN |
|---|---:|---:|---:|---:|
| AFR_EPI_NOE_BULLETIN_VERSEMENT | 125 | 126 | 5 | 5 |
| AFR_GENERIC_FIP_DEVIS_ESSENCIEL | 172 | 173 | 9 | 9 |
| AFR_GENERIC_IARD_VEHIC_NOA_DEVIS | 235 | 235 | 11 | 11 |

La comparaison Versement/FIP ajoute 6 pages FR et 6 pages EN : total 14 PDF, 1 128 pages. Les deux rapports de comparaison vérifient le rendu bilingue ; ils ne représentent pas une évolution réelle du même courrier.

Les 1 128 pages ont été rendues en images. Revue de toutes les pages sur 40 planches, puis inspection détaillée de pages représentatives : introduction et hiérarchie Versement, blocs/règles NOA, propriétés de tableaux NOA, inventaire FIP, limites du visuel NOA et comparaison. Il ne s'agit pas d'une relecture ligne par ligne de tous les algorithmes bruts. Aucun défaut important nouveau de superposition ou de coupure n'a été observé ; aucun mot extrait ne sort des limites de page. Texte sélectionnable conservé.

Les traductions font varier la pagination de deux rapports d'une page. Les noms de variables longs et les longs algorithmes conservent la densité préexistante ; ils ne sont pas abrégés ni traduits.

## Sources et limites

Consultés : journal canonique, charte et instructions consolidées, application 0.9.1, interface, API/jobs/export, gabarits, hiérarchie, rendu visuel, tests, scripts navigateur et les trois PUB ci-dessus. La suite de régression utilise également Adhésion, Auto et Obsèques. Aucun Tools Report, aucune nouvelle donnée client, aucun remplacement des références PDF.

Les modules de décodage, de provenance, de portée, de calcul, de comparaison et de stockage sont identiques à 0.9.1. Les logos et ressources graphiques sont identiques. Seule la présentation de la hiérarchie est traduite ; la construction du graphe demeure inchangée.

Docker est indisponible dans cet environnement : recette Python/SQLite avec worker séparé et serveur Next de production. Pas de recette Docker/Windows/PostgreSQL/RQ revendiquée. Les limites binaires et graphiques antérieures restent celles du journal ; aucune amélioration du décodage ou conformité exhaustive Exstream n'est revendiquée par cette évolution linguistique.

## Preuves et reprise

L'archive séparée `GroupeAlterna_Validation_v0.10.0.zip` conserve les 14 PDF, planches, pages représentatives, captures d'interface, résultats de tests et contrôles. Le code complet et l'archive de mise à jour comprennent ce bilan et le journal. Les fichiers PUB d'entrée et les données privées de test ne sont pas redistribués.

Prochaine action : installer 0.10.0 selon `MISE_A_JOUR_0.10.0.md`, conserver `.env` et les volumes, puis réaliser une analyse FR et une analyse EN sur l'installation Docker de l'utilisateur.
