# Core Report 0.13.3 — Zones de texte et variables structurées

30 septembre 2026 — itération 43.

## Résultat

Les objets de DuréeContratCP et DuréeContratAV sont des **zones de texte (text boxes)**, conformément à la précision de l'utilisateur. Ils ne sont pas ajoutés à la collection des tableaux ou des grilles. Le cadre visuel n'est pas une preuve de tableau ; l'enveloppe commune d'objet fournit le contour, tandis que le contenu rich-text borné détermine ce profil de zone de texte.

Le décodage retrouve quatre occurrences de variables par bloc : début/prochaine échéance, puis début/fin du contrat. Les valeurs de conception `______` ne remplacent plus les noms dans le rapport ou le visuel. Le `d` parasite est un octet de l'en-tête variable, isolé par le répertoire des variables et corroboré par le flux de glyphes. Aucun nettoyage global des lettres d ou des tirets bas.

Trois paragraphes internes sont conservés. Les deux premiers portent la règle 700080 (PNTEMPO) et le troisième 700081 (PTEMPO). La condition est Contains(DF_FIC_BD_misc_docClauses_clauseId, code) > 0 : inclusion si vraie, exclusion sinon. Les règles sont référencées dans les propriétés de chaque paragraphe et dans la table locale comptée, sans association par proximité. Les branches ne sont pas évaluées : elles sont toutes documentées avec leurs repères dans le rapport et leurs crochets dans le visuel.

Présentation retrouvée : fond #b2b2dd, contour #00008f de 0,24 pt, corps Source Sans Pro Bold 10 pt bleu, titre gras 14 pt bleu. Largeurs des objets sources : CP 1535/300 pouce = 12,9967 cm ; AV 2173/300 pouce = 18,3981 cm. Marges uniformes : 24/300 pouce = 5,76 pt. La largeur est plafonnée à l'espace disponible ; la hauteur s'adapte au texte documentaire (noms longs des variables et toutes les branches), sans revendication de pagination native.

## Implémentation générique

- `backend/retro/scopes.py` : segmentation des tokens aux bornes d'en-tête prouvées indépendamment ; conservation de la prose ; contrôle des IDs, glyphes, formats et bornes. La chaîne propriétaire accepte les discriminants de couleur RGB et palette au lieu de supposer un champ noir nul.
- `backend/retro/text_boxes.py` : profil borné des zones de texte, lien au propriétaire rich-text, nom source, rectangle, dimensions, marges uniformes et contour ; classification explicite `kind=text_box`.
- `backend/retro/table_frames.py` : primitives de géométrie et de contour partagées ; la reconnaissance des grilles comptées reste distincte et inchangée.
- `backend/retro/visual_graphics.py` : `graphics.text_boxes` séparé de `tables`, styles et couleurs issus des ressources PUB.
- `backend/retro/visual_render.py` : cadre, fond, largeur et marges de la text box ; paragraphes conditionnels marqués, variables nommées. Le conteneur ReportLab Table est un mécanisme de dessin, pas une classification du contenu source.
- `backend/retro/report_structure.py` : utilise la même restitution décorée que le visuel et conserve les repères Rn et les algorithmes associés.
- `backend/tests/test_plaisance_blocks.py` : huit tests de régression, dont mutations du répertoire des variables, discriminant de couleur, index de règle, enveloppe et rectangle. Renommage des variables sans changer leur ID ; conservation du vrai texte « date d’échéance ».

Aucun nom de fichier, nom métier, offset absolu, identifiant client ou empreinte ne sélectionne ces nouveaux profils dans le moteur. Les valeurs spécifiques sont utilisées uniquement dans les fixtures de test. Les deux familles de sérialisation ne sont pas confondues.

## Validation

239 tests réussis dans la suite finale, zéro échec, zéro saut. Une première suite avait également passé avant la clarification de classification ; seule la suite finale est la référence de livraison. Avertissement Starlette/httpx préexistant.

14 chemins / 13 PUB distincts examinés : 12 traités normalement et Plaisance FDC testé uniquement avec l'exception locale d'en-tête déjà autorisée. Le contrôle d'en-tête du moteur livré est inchangé ; le FDC à en-tête nul reste refusé par l'application. Le test expérimental est isolé dans le banc, sans modification du fichier.

26 PDF / 2415 pages, sans page vide ni texte hors page détecté, sans contenu visuel décodé manquant ou dupliqué, ligne fractionnée ni paragraphe excessif signalé. Sur les 11 PUB historiques : faits sources, textes/variables, règles, topologies et anciens contenus visuels préservés par comparaison des audits 0.13.2/0.13.3.

Revue visuelle : les 12 pages du visuel Plaisance CP sur planches, zoom de la page 2 ; rapport pages 1, 2, 3, 7, 8 et 201, zoom page 7. Les autres pages ont été contrôlées automatiquement. La génération ne prouve pas la fidélité exhaustive à Exstream.

| Source | Rapport | Visuel |
|---|---:|---:|
| AFR_GENERIC_IARD_VEHIC_NOA_DEVIS.pub | 280 | 11 |
| 03-AFR_EPI_NOE_BULLETIN_ADHESION.pub | 176 | 10 |
| 04-AFR_EPI_NOE_BULLETIN_VERSEMENT.pub | 133 | 5 |
| 05-AFR_GENERIC_FIP_DEVIS_ESSENCIEL.pub | 174 | 10 |
| 06-AFR_GENERIC_PROJET_OBSEQUES_ESSENCIEL.pub | 131 | 8 |
| 07-AFR_IARD_DEVIS_AUTO.pub | 126 | 13 |
| AFR_EPI_NOE_BULLETIN_ADHESION_Color.pub | 171 | 10 |
| AFR_EPI_NOE_BULLETIN_ADHESION_Round.pub | 171 | 10 |
| AFR_EPI_NOE_BULLETIN_ADHESION_Width.pub | 171 | 10 |
| AFR_EPI_NOE_BULLETIN_ADHESION_Black.pub | 171 | 10 |
| AFR_EPI_NOE_BULLETIN_ADHESION_BorderPink.pub | 171 | 10 |
| upload/AFR_GENERIC_IARD_VEHIC_PLAISANCE_CP_DEVIS.pub | 201 | 12 |
| /workspace/scratch/ae30fa916b72/upload/AFR_GENERIC_IARD_VEHIC_PLAISANCE_FDC.pub | 210 | 10 |

## Reproduction et limites

`PYTHONPATH=backend PUB_TABLE_CORPUS=/chemin/corpus PUB_PLAISANCE_CP=/chemin/AFR_GENERIC_IARD_VEHIC_PLAISANCE_CP_DEVIS.pub python -m pytest backend/tests -q`

Les fixtures historiques doivent être dans `../project_sources`, les variantes dans PUB_TABLE_CORPUS/pub_variants et pub_variants2. Les sources client ne sont pas redistribuées. Sans ces fichiers, les tests dépendants sont explicitement sautés.

Les profils restent bornés : styles non reconnus et objets/images non reliés restent explicites, soulignement non calibré, pagination native et évaluation des conditions non reproduites. La reconnaissance de text box n'invente ni cellules ni propriétés de ligne/colonne. Aucune recette Windows/Docker/navigateur/PostgreSQL ni déploiement dans cette itération. Aucune interface métier modifiée.
