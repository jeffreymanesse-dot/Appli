# Groupe Alterna — validation Core Report 0.14.5

## Base consolidée

Deux archives différentes avaient été diffusées sous le numéro 0.14.4. Cette version prend pour base l’archive complète contenant les Data Files, les règles PAGE/Page Flow et les profils de lignes : SHA-256 `2847df407f4c39ec15f8e59fbbf04b26805a4d904e9317f31965c180de70e7b9`. Elle y ajoute le référentiel système, sans repartir de la branche limitée à 0.14.3. Les archives antérieures sont conservées.

## Correction du référentiel

Source fournie : `VariableSystem.pdf`, chapitre 3, pages imprimées 3-20 à 3-24. SHA-256 `7ec138d7ce81b5157aa48f7a05bacbba636aed0c89fcac64e22a12fc33190d18`.

Le contrôle porte sur la colonne « Variable name », pas sur toutes les chaînes SYS_ du texte : **34 entrées distinctes, 64 lignes de classement dans 7 familles**. Chaque nom et numéro de page du catalogue concorde avec les lignes extraites du PDF.

Le résultat précédent « 35 variables / 62 appartenances » était incorrect. `SYS_PageTotalPrintedInDocument` apparaît uniquement dans la description de `SYS_PageTotalPrinted`, page 3-20. Il est conservé comme mention non confirmée, sans fusion ni création d’alias. Les appartenances « Comptage » de `SYS_PageInQueue` et `SYS_SheetInQueue` sont bien conservées.

Le guide présente des divergences pour `SYS_LanguageCustomer`, `SYS_LanguageDefault` et `SYS_SheetInQueue` selon les rubriques. Le rapport les signale. Les notices françaises et anglaises sont des synthèses, pas de nouvelles preuves d’exécution.

## Effet sur le moteur

- Catalogue exact avec familles multiples, description, pages source, empreinte du PDF et notes d’incertitude.
- Annotations uniquement pour les variables réellement décodées ; aucune nouvelle variable ajoutée au package.
- Conservation de la convention SYS_ de la base. Un nom système absent de ce guide reste « non listé », pas « invalide » et pas « documenté ».
- Origine, mappings, types, cardinalités, valeurs de conception et affectations préexistants inchangés.
- Aucune évaluation de SYS_TableRow, des dates, de la pagination ou des compteurs. Les lignes non composées peuvent entrer dans SYS_TableRow selon le guide ; aucun compteur visuel n’est utilisé comme substitut.
- Rapport : notices dans les fiches utilisées et catalogue des noms présents dans le package. Les noms, descriptions et références sont regroupés pour éviter un titre isolé en bas de page. Français et anglais pris en charge.

## Corpus vérifié

Les 15 packages de référence 0.14.4 ont été repris et acceptés, y compris Plaisance FDC dont le support existait déjà dans cette base.

| Package ou groupe | Packages | Noms du catalogue présents par package | Noms du catalogue dans le périmètre documentaire |
|---|---:|---:|---:|
| Adhésion et cinq variantes de tableaux | 6 | 11 | 5 |
| Versement, ancien et nouveau package | 2 | 11 | 5 |
| FIP | 1 | 11 | 5 |
| Obsèques | 1 | 10 | 4 |
| Auto | 1 | 6 | 3 |
| NOA | 1 | 11 | 5 |
| Plaisance CP | 1 | 11 | 6 |
| Plaisance FDC | 1 | 7 | 4 |
| WEBLURE | 1 | 10 | 6 |

Exemples de noms observés mais non listés dans ce guide : `SYS_CurrentProfile`, `SYS_CustInvalidDataLevel`, `SYS_CustomerEffectiveDate`, `SYS_CustomerQueues`, `SYS_PageFlows`, `SYS_TableRowPage`. Leur présence est conservée ; leur description n’est pas inventée.

La comparaison profonde des modèles complets est identique après retrait des seules annotations ajoutées et du numéro de version. Les clés numériques sont normalisées comme dans les caches JSON. Cela couvre les textes, noms/algorithmes/IDs de règles, variables, mappings, data sections, Data Files, PAGE/Page Flow, occurrences, tableaux, styles et modèle visuel. Les empreintes avant/après et noms par package sont dans `validation/systemvars_0.14.5/corpus_comparison.json`.

## Tests et sorties

Suite complète : **362 tests réussis, zéro échec, zéro test sauté**, dont 44 nouveaux tests système. Les fixtures disponibles ont été raccordées explicitement à leurs emplacements de test. Un avertissement de dépréciation Starlette/httpx subsiste ; aucune dépendance n’a été modifiée pour ce travail.

Les rapports et visuels Versement historique et WEBLURE ont été générés pour le contrôle : respectivement 152/8 et 354/22 pages. Aucun dépassement physique ni page entièrement vide détecté, aucun contenu reconnu manquant ni erreur d’occurrence. Les nouvelles fiches et pages de référentiel ont fait l’objet d’une inspection visuelle ciblée ; les centaines de pages antérieures n’ont pas toutes été revues manuellement dans cette itération. La page de titre de section aérée du visuel Versement existait déjà et n’a pas été modifiée.

Le PDF source, les PUB client et les PDF de recette ne sont pas inclus dans l’archive du code. Le logo authentique et les actifs Alterna de la base sont inchangés. Les journaux Markdown techniques n’embarquent pas de mise en forme bureautique.

## Limites et prochaine action

Il s’agit de documentation statique, pas d’une exécution native Exstream. L’extrait fourni ne prouve pas l’exhaustivité de toutes les versions du produit. Les valeurs d’exécution, la pagination native, les ressources externes et le Page template restent soumis aux limites déjà signalées. Aucune installation sur le poste utilisateur ni recette Windows/Docker/PostgreSQL réelle n’est revendiquée.

Installer l’archive en conservant `.env` et les volumes, reconstruire puis lancer une nouvelle analyse. Les anciens rapports ne sont pas recalculés automatiquement.
