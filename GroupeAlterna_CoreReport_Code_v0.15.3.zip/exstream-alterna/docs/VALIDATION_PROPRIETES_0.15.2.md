# Validation CoreReport 0.15.2 — contenus, objets et propriétés de lignes

Date : 9 octobre 2026. Base : archive complète 0.15.1. Source de recette principale : AFR_EPI_WEBLURE_COURRIER_SIMUL.txt, analysée comme package Exstream. Les octets client ne sont pas inclus dans l'archive du programme.

## Réponse aux retours

| Demande | Correction et contrôle |
| --- | --- |
| Retirer les statuts des deux tableaux Data Section | La deuxième colonne contient le nom de la Data Section sans suffixe de statut. |
| Positionner R18 et R20 sur les images | Décodage du répertoire d'objet inclus, recoupé avec son ancrage et son cadre. Les repères ouvrants et fermants encadrent la cible. Les six objets image du courrier portant une règle propre ou d'ancrage ont été contrôlés. |
| Compléter DF_PAR_SIGN2_Lg_seg_BR et DF_PAR_SIGN2_Lg_jpg_BR | Six cellules par composant, sur trois lignes et deux colonnes ; toutes décodées avec leur texte enrichi et leurs propriétés graphiques reconnues. Deux unités supplémentaires récupérées par composant. |
| Signaler DOCUMENT, PAGE, SECTION et leurs règles | Entrées explicites dans la vue détaillée, avec ligne de règles uniquement si présente. Les règles globales des PAGE reconnues sont ajoutées au catalogue. Les règles des objets d'une PAGE conservent leur cible distincte. |
| Fusionner les deux tableaux de lignes | Une seule table Organisation et répétition des lignes présente type, propriétés, répétition et règle. Les propriétés des colonnes restent dans leur propre tableau. |
| Retirer les mentions d'ordre local et d'absence de driver | Absence vérifiée dans le PDF. Une propriété absente reste vide ; aucun driver n'est inventé. |
| Repositionner le tableau Liste-data | L'ancrage enregistré est rétabli entre la date de naissance et le taux technique. La première ligne est Header (H). |
| Restituer les dix lignes du tableau principal | Voir le relevé ci-dessous. |

### Tableau PAR_AFR_EPI_WEBLURE_TABLE

| Ligne | Type reconnu | Propriété complémentaire |
| --- | --- | --- |
| 1 | Repeating footer — Except last Page (F-) | Propriétés et règle source conservées. |
| 2 | Footer | Analyse précédente conservée. |
| 3 | Header (H) | First row of table section ; Break method When variable value change sur WRK_AFR_EPI_WEBLURE_RENTE_LineTitle ; règle conservée. |
| 4 à 7 | Header (H) | Règles conservées. |
| 8 | Automated row — repeating on defined criteria (R) | Répétition précédemment reconnue conservée. |
| 9 et 10 | Automated row — repeating on defined criteria (R) | Group with previous row. Aucun driver explicite n'est ajouté. |

### Contenu des signatures

Chaque bloc restitue les variables DF_PAR_SIGN2_label1, DF_PAR_SIGN_label1, DF_PAR_SIGN_label2 et son image DF_PAR_SIGN_jpgPh ou DF_PAR_SIGN_segPh. Les deux cellules vides sont conservées. Les unités DF_PAR_SIGN_label1 et DF_PAR_SIGN_label2 étaient omises par un filtre exigeant à tort une première couleur noire directe. Le filtre valide maintenant un préambule de couleurs complet, direct ou de palette, puis la chaîne de texte, le répertoire de variables et le propriétaire.

Le nombre total d'unités du package passe de 362 à 366. Les six cellules de chacune des deux signatures sont couvertes ; cette vérification n'est pas une certification de propriétés encore inconnues du format. Une image alimentée à l'exécution est représentée par son emplacement et sa variable lorsque sa ressource n'est pas embarquée.

## Principe des corrections génériques

- `scopes.py` et `content_recovery.py` : validation du préambule de couleurs compté, sans dépendance à une valeur noire initiale. Les longueurs, les types de couleur, le texte et le répertoire de variables restent contrôlés.
- `inline_objects.py` : nouveau lecteur borné du profil de répertoire à un objet reconnu. Il exige l'ancrage vide, le compteur, le descripteur, les dimensions répétées, un cadre enfant complet de même propriétaire et une cible unique. Un profil multiple, incohérent ou inconnu n'est pas extrapolé.
- `table_frames.py`, `table_anchors.py`, `visual_render.py` : résolution du cadre image ou tableau, insertion à l'ancrage et affichage des règles autour de l'objet ; exclusion de la seconde restitution autonome du même enfant.
- `layout.py` : types de lignes 2 et 7 ; variante de référence nulle du profil étendu ; propriété de groupement lue dans son propre champ ; extension First row of table section ; rupture sur changement de variable reconnue indépendamment. Le nouveau marqueur de conteneur n'est accepté que si le profil étendu complet le confirme.
- `page_analysis.py`, `coverage.py`, `document_flow.py` : règles globales PAGE et événements de rapport préservant les occurrences de paragraphes. Les PAGE initiales et de débordement sont présentées à l'entrée du DOCUMENT. Aucune transition calculée ni association SECTION/PAGE absente du package n'est inventée.
- `report_structure.py`, `report_data_sections.py` : présentation des conteneurs et des cibles de règles, fusion des propriétés de lignes et allègement des libellés. Traductions anglaises correspondantes ajoutées.

Les noms et identifiants client servent uniquement aux assertions de recette, pas aux branches du décodeur. Des cas renommés, déplacés et volontairement corrompus vérifient les conditions d'acceptation et de rejet.

## Résultats et périmètre

- Premier lot : **98 tests réussis, 2 tests liés à l'API désélectionnés**. Deux échecs initiaux du lecteur de flowables utilisé par les tests ont été corrigés avant ce résultat.
- Second lot : **3 tests supplémentaires réussis**, sur les valeurs 0, 1 et inconnue du champ de groupement ; les 14 autres tests de ce fichier avaient déjà été exécutés dans le premier lot.
- Total : **101 tests ciblés distincts réussis**. La suite complète historique n'a pas été relancée. Aucune nouvelle validation API, navigateur, Docker ou Windows n'est revendiquée.
- Six autres packages réanalysés : Adhésion, Bulletin historique, FIP, Obsèques, Auto et dernier Bulletin de versement. Schéma et couverture du Visuel valides, sans contenu attendu manquant, doublon ni erreur d'occurrence. Ces contrôles ne sont pas une comparaison visuelle native Exstream.
- Toutes les variantes de règles et les calculs restent identiques au modèle 0.15.1. L'export ne modifie pas le modèle. Aucun algorithme métier, commentaire ou source native n'est réécrit.
- Rapport final : **223 pages** avec annexe Template et Page ; Visuel : **15 pages**, sans section Pages, composants et débordements. Rasterisation et inspection de toutes les pages, agrandissements des zones concernées, contrôle des repères de règles et de l'absence de texte hors page.

Preuves compactes : `validation/properties_0.15.2/tests.log`, `tests-grouping.log`, `checks.json`, `pdf-checks.json`, `validation.log` et `pdf-qa.log`. Les tests client se relancent en définissant `PUB_WEBLURE` vers le package de recette, avec les dépendances de développement installées ; aucune donnée client n'est livrée avec les tests.

La reconnaissance reste bornée aux structures validées. Les ressources dynamiques, la pagination native, l'exécution des conditions et les variantes non reconnues restent hors du périmètre certifié.
