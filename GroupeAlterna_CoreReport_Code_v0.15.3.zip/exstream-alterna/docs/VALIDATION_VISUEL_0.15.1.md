# Validation — Visuel 0.15.1

Date : 9 octobre 2026. Base : livraison complète CoreReport 0.15.0.

## Modification

Le rendu du PDF Visuel omet entièrement la section « Pages, composants et débordements ». Les unités appartenant exclusivement à ces pages sont comptabilisées comme exclusions intentionnelles dans le contrôle de couverture. Un contenu du courrier manquant continue à provoquer une erreur. Les observations Page restent disponibles dans le modèle et pour l’annexe du rapport principal.

Le changement concerne `visual_render.py`, un commentaire de `visual_model.py`, les numéros de version et la documentation. Le décodeur et le rendu de l’annexe ne sont pas modifiés.

## Tests ciblés

Depuis le dossier du projet, avec les dépendances de développement installées :

```bash
PYTHONPATH=backend python -m pytest backend/tests/test_visual_letter_only.py backend/tests/test_visual_export.py -k 'not real_graphical' -q
```

Résultat : **10 passed, 6 deselected**. Les six tests de profils graphiques du corpus exclus par ce filtre n’ont pas été rejoués. La suite complète historique n’a pas été relancée pour cette livraison.

Les nouveaux tests couvrent les sorties française et anglaise, la conservation du courrier, l’absence de la section Page, les exclusions de couverture, la non-mutation du modèle, le refus d’une perte de contenu du courrier et un package ne contenant que des unités Page.

## Dernier Bulletin de versement

Source contrôlée : `AFR_EPI_NOE_BULLETIN_VERSEMENT.pub`, 12 082 019 octets.

| Contrôle | Résultat |
| --- | --- |
| Nombre de pages du Visuel | 8 avant, 4 après |
| Pages conservées | Anciennes pages 1, 2, 3 et 8 |
| Comparaison des corps de page | Pixels identiques, hors pied de page, rasterisation à 1,5 fois la taille PDF |
| Contenus | 101 unités analysées ; 77 rendues ; 24 unités Page exclues intentionnellement |
| Couverture | Aucun contenu attendu manquant, aucune occurrence en erreur, aucun doublon de placement |
| Texte hors page | Aucun détecté |
| Inspection visuelle | Quatre pages rendues en images et vérifiées |
| Rapport principal | 100 pages ; annexe Template et Page présente |
| Modèle après export | Identique au modèle avant export |

Les traces sont conservées dans `validation/visual_0.15.1/tests.log` et `checks.json`. Le PDF principal régénéré sert au contrôle ; la sortie livrée à nouveau est le Visuel.

## Limites

Aucun déploiement sur l’installation utilisateur, essai interactif de l’interface, validation native Exstream ni nouvelle validation de l’ensemble du corpus n’est revendiqué. Les comportements non concernés conservent leurs limites documentées dans les versions précédentes.
