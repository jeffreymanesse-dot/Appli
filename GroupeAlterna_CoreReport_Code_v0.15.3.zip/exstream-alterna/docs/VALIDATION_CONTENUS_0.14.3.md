# Validation des contenus — Core Report 0.14.3 — 7 octobre 2026

## Corrections génériques

- Les textes littéraux A0 et les objets rich-text bornés (y compris cellules vides, valeurs numériques et éléments de page) sont extraits dans le modèle commun avant tableaux, portées, provenance et couverture. Le visuel projette ces faits ; il n'ajoute plus de texte de paragraphe absent du rapport.
- Les références sont dédoublonnées par leurs bornes binaires, pas par égalité de texte. Deux enregistrements distincts contenant le même texte restent distincts.
- Un run conditionnel explicitement fermé et de longueur zéro est conservé dans la structure sans lui inventer une cible textuelle. Il n'interrompt plus la lecture des variables qui suivent. Les paragraphes internes vides conservent leur condition d'objet.
- Une variable n'est substituée à son exemple que lorsque l'instruction de composition, l'identifiant défini et le répertoire indépendant concordent sur l'identité, le format et les bornes. Les données de conception restent conservées dans le modèle, séparées du nom affiché.
- Le contenu et son répertoire peuvent être décodés indépendamment du rattachement à une page ou à un paragraphe : un propriétaire inconnu reste inconnu. Cela corrige notamment des exemples de coordonnées et d'ORIAS dans Auto.
- L'inventaire et le rapport de repli affichent aussi les noms de variables établis. Aucun nom de variable n'est déduit de la forme d'une date ou d'un montant.
- Les noms source des règles sont préservés. Quand plusieurs identifiants compilés partagent un nom, le libellé documentaire ajoute l'ID compilé ; le catalogue expose la condition décodée et les cibles. Aucun nom RUL n'est fabriqué et les règles ne sont pas fusionnées par leur libellé.
- Le visuel retire les seuls espacements de fin avant un saut de page explicite. Cela supprime une page vide observée sur Versement, sans supprimer de contenu ni de cellule et en conservant les sauts entre DOCUMENT.
- Contrôles bloquants : concordance des tokens entre modèle et visuel, cohérence des événements variables, présence de tous les contenus attendus dans chaque occurrence du corps du rapport et dans le visuel. Ces contrôles portent sur les structures décodées, pas sur une promesse de décodage exhaustif de tout PUB.

## Mesures avant/après

15 chemins sources recensés, 14 contenus distincts par SHA-256 ; 13 analysables et Plaisance FDC refusé avec le même en-tête non pris en charge. Les deux sorties PDF ont été produites pour chacun des 13 PUB analysables.

La colonne « omissions rapport corrigées » est mesurée en instrumentant le constructeur du rapport 0.14.2 intact et en comparant ses placements aux unités non vides déjà connues de son visuel. Elle ne compte ni les cellules vides ni les textes déjà rendus par une composition graphique. Les « unités ajoutées au modèle » incluent aussi des cellules vides, des ressources partagées et des éléments hors flux ; ce nombre n'est pas un nombre de paragraphes manquants. Les variables sont comptées en occurrences de tokens nouvellement identifiés, sans dédoublonnage entre PUB et variantes.

| PUB | Omissions rapport corrigées | Unités ajoutées au modèle | Occurrences variables nouvellement identifiées | Unités rich-text encore non vérifiées |
| --- | ---: | ---: | ---: | ---: |
| 03-AFR_EPI_NOE_BULLETIN_ADHESION.pub | 0 | 33 | 25 | 0 |
| 04-AFR_EPI_NOE_BULLETIN_VERSEMENT.pub | 0 | 35 | 18 | 0 |
| 05-AFR_GENERIC_FIP_DEVIS_ESSENCIEL.pub | 0 | 29 | 26 | 0 |
| 06-AFR_GENERIC_PROJET_OBSEQUES_ESSENCIEL.pub | 32 | 66 | 12 | 0 |
| 07-AFR_IARD_DEVIS_AUTO.pub | 2 | 43 | 33 | 1 |
| AFR_GENERIC_IARD_VEHIC_NOA_DEVIS.pub | 6 | 793 | 35 | 0 |
| AFR_GENERIC_IARD_VEHIC_PLAISANCE_CP_DEVIS.pub | 0 | 106 | 29 | 0 |
| AFR_GENERIC_IARD_VEHIC_PLAISANCE_FDC.pub | Refus d'en-tête inchangé | — | — | — |
| AFR_EPI_NOE_BULLETIN_ADHESION_Color.pub | 0 | 33 | 25 | 0 |
| AFR_EPI_NOE_BULLETIN_ADHESION_Round.pub | 0 | 33 | 25 | 0 |
| AFR_EPI_NOE_BULLETIN_ADHESION_Width.pub | 0 | 33 | 25 | 0 |
| AFR_EPI_NOE_BULLETIN_ADHESION_Black.pub | 0 | 33 | 25 | 0 |
| AFR_EPI_NOE_BULLETIN_ADHESION_BorderPink.pub | 0 | 33 | 25 | 0 |
| AFR_EPI_WEBLURE_COURRIER_SIMUL.txt | 13 | 154 | 136 | 0 |

Les 53 omissions non vides mesurées concernent WEBLURE (13 titres), Obsèques (32 fragments dans plusieurs paragraphes), NOA (6 fragments, dont titres et clauses de sinistre) et Auto (2 fragments de soulignement, sans texte métier ajouté). Les autres PUB ne présentent pas d'omission non vide de ce type dans le constructeur 0.14.2 ; ils bénéficient de la mise en commun des objets et des variables de page.

## Cas WEBLURE

Les 13 titres A0 sont réintégrés, y compris `PAR_WEBLURE_Demande_Titre_pieces-justif`. `PAR_WEBLURE_Simul_Titre` affiche `DF_FIC_SD_SIMURENTE_SIMBYPRODUCT_annuityEffectiveDate` (ID 92874) au lieu du sample `03/08/2008`. Le contrôle PDF vérifie cette substitution dans le passage du titre, pas seulement la présence du nom quelque part dans le rapport.

Les anciens R66–R91 sont les 26 IDs compilés de 574465 à 577090 concernés par `Message Component PAR_WEBLURE_VosContacts` (la plage numérique contient des trous). Tous leurs noms et algorithmes restent inchangés. Les repères Rn peuvent se décaler avec les nouveaux objets/règles rattachés ; `correspondance_regles_WEBLURE.csv` donne les anciens et nouveaux repères par identifiant stable.

Rapport : 326 pages. Visuel : 17 pages. Les 54 occurrences de paragraphes du corps sont vérifiées dans l'ordre ; le tableau est conservé deux fois. Les débuts DOCUMENT sont contrôlés sur des pages distinctes :

- DOC_AFR_EPI_WEBLURE_COURRIER : page PDF 7.
- DOC_AFR_EPI_WEBLURE_SIMULATION : page PDF 16.
- DOC_AFR_EPI_WEBLURE_MIEUX_COMPRENDRE : page PDF 33.
- DOC_AFR_EPI_WEBLURE_DEM_MISE_EN_SERVICE : page PDF 39.

## Tests et conservation

307 tests réussis, aucun échec ni saut. Les nouveaux tests couvrent les runs vides, les IDs/borne/slot/opcode corrompus, le renommage et changement d'ID d'une variable de test, les littéraux identiques dans des records distincts, le partage rapport/visuel, la non-fusion des règles, les variables de contenu sans propriétaire établi et les espacements précédant un saut de page. Les compteurs historiques ont été ajustés uniquement pour les objets supplémentaires démontrés ; les anciennes cibles de paragraphes vides restent vérifiées.

Les comparaisons profondes gardent identiques les définitions, mappings, noms/algorithmes de règles, applications, ordre documentaire, data sections/rattachements, catalogue compilé et compositions graphiques. Le flux documentaire et toutes les anciennes unités sont conservés. Les objets/cellules et associations supplémentaires proviennent des profils bornés. Les axes préexistants de tableaux gardent leurs propriétés ; aucun effet universel sur des PUB absents du corpus n'est revendiqué.

Contrôles automatiques des 26 PDF : pas de page de corps vide ni de texte hors des limites physiques. Revue visuelle des deux PDF WEBLURE livrés, avec agrandissements des titres et transitions. Les autres PDF servent à la vérification du corpus ; ils ne font pas l'objet d'une certification visuelle exhaustive.

## Limites conservées

- Plaisance FDC : en-tête non pris en charge, aucun contournement.
- Auto `text:1252466` : opcode -240 à l'offset 1254569 non interprété ; contenu brut conservé avec avertissement, pas de variable ou de portée devinée. Les 25 autres unités auparavant privées de propriétaire sont décodées pour leur contenu sans fabriquer de rattachement.
- Référence WEBLURE `21:38941`, annexe FIP, ordre documentaire Auto incomplet : inchangés.
- Data sections de lignes, Header/Footer, propriétés natives `breakpage`, ressources externes et pagination native : limites antérieures maintenues. Les sauts entre DOCUMENT et les réapparitions de composants séparés restent actifs.
- Certaines propriétés de portée restent non interprétées, même lorsque le texte et les variables sont décodés séparément. Un paragraphe sans texte reconnu n'est pas déclaré réellement vide.
- Pas de recette Windows/Docker/PostgreSQL/RQ/navigateur ni de déploiement sur le poste utilisateur.
