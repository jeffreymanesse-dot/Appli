# Core Report — mise à jour 0.11.0

## Ce qui change

L'interface porte désormais le nom **Core Report**, en marine et bleu Groupe Alterna, avec l'accroche **« Vos applications documentaires, en toute clarté. »**. En anglais : **“Clarity for your document applications.”** Le choix FR/EN et les fonctions existantes sont conservés.

Chaque nouvelle rétro-documentation commence par une couverture : motif original Groupe Alterna, logo complet en haut, **Core Report** centré et, juste dessous, **le nom d'application réellement décodé dans le `.pub`**. Aucun slogan, numéro, date ou commentaire supplémentaire n'y est ajouté lorsque le nom est disponible.

Le nom du fichier n'est pas substitué au nom de l'application. Par exemple, le package `AFR_GENERIC_FIP_DEVIS_ESSENCIEL.pub` contient l'application `APP_AFR_EPI_NSE_FDC_DEVOIR_DE_CONSEIL_ESSENCIEL_BR`. Les noms ne sont jamais traduits. Si aucun nom n'est décodé, la couverture le signale explicitement ; s'il y en a plusieurs, ils sont tous conservés.

La couverture n'est pas numérotée. L'introduction qui suit reste la page 1 du contenu. Les pages intérieures conservent leur fond blanc et leur mise en page. Les analyses A/B et le rapport de comparaison reçoivent aussi une couverture ; la comparaison présente les noms distincts des applications comparées. Le PDF de visualisation du courrier reste sans couverture documentaire.

Les PDF déjà générés restent inchangés. Relancez une analyse pour obtenir la nouvelle présentation.

## Mise à jour d'une installation 0.10.0

Téléchargez `GroupeAlterna_CoreReport_MiseAJour_v0.11.0.zip`. C'est une mise à jour à fusionner dans votre application existante, pas une application autonome.

1. Attendez la fin des traitements en cours et sauvegardez votre dossier de l'application.
2. Depuis votre dossier habituel `exstream-alterna`, exécutez :

   ```powershell
   docker compose stop api worker purge web
   ```

3. Décompressez le ZIP, puis copiez le **contenu** de son dossier `exstream-alterna` dans votre dossier existant du même nom. Fusionnez les dossiers et remplacez les fichiers fournis, y compris le nouveau fond sous `assets`. Ne créez pas un second dossier imbriqué.
4. **Gardez votre `.env`, le même dossier Compose et les volumes existants.** Le ZIP de mise à jour ne contient aucun `.env` et ne change aucun mot de passe.
5. Exécutez, une commande à la fois :

   ```powershell
   docker compose build api worker purge web
   docker compose up -d
   docker compose ps
   ```

6. Ouvrez `http://localhost:3000`, actualisez la page et lancez une analyse. Vérifiez le nom Core Report, les drapeaux FR/EN et la première page de la rétro-documentation téléchargée.

Si une commande échoue, conservez le message pour diagnostic. Aucun effacement de volume, changement de quota ou migration de base n'est requis.

## Installation neuve

Utilisez `GroupeAlterna_CoreReport_Code_v0.11.0.zip`, puis `DEMARRER_WINDOWS.cmd` avec Docker Desktop démarré. Le `.env` initial contient seulement des marqueurs ; le lanceur génère les secrets locaux. Pour une installation existante, conservez toujours votre propre `.env`.

## Validation et limites

Les couvertures et l'interface sont vérifiées en FR/EN. Les rapports Versement et FIP ont été régénérés ; le contrôle du texte et du rendu des pages intérieures vérifie leur conservation. Le bilan détaillé se trouve dans `docs/VALIDATION_CORE_REPORT_0.11.0.md`, et le journal dans `ETAT_VALIDATION_MOTEUR.md`.

Le fond original ajoute environ 1,2 Mio par PDF couvert, selon l'encodage. Les limites normales de stockage ne changent pas. Une limite de sortie personnalisée très faible devra tenir compte du poids des couvertures, notamment des trois rapports d'une comparaison.

Cette évolution concerne l'identité et la présentation, sans modification du décodage métier. Les limites Exstream antérieures restent applicables. La recette locale utilise SQLite et un worker séparé ; Docker Desktop, Windows et PostgreSQL/RQ ne sont pas exécutés dans l'environnement de livraison.
