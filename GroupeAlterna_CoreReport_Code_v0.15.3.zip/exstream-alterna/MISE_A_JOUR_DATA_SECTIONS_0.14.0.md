# Core Report 0.14.0 — mise à jour des data sections

Cette version intègre les observations vérifiées sur le PUB WEBLURE : déclarations XML et sélecteurs document/section, documents à plusieurs pages référencées, règles des conteneurs, lignes étendues et colonnes conditionnelles. Les points encore non décodés apparaissent explicitement dans le rapport.

## Installation

1. Arrêter l'application avec `ARRETER_WINDOWS.cmd` ou `docker compose stop`.
2. Sauvegarder l'installation actuelle et conserver son `.env` ainsi que les volumes Docker.
3. Décompresser cette archive et remplacer les fichiers du programme par ceux du dossier `exstream-alterna`. L'archive ne contient pas de `.env` réel.
4. Relancer `DEMARRER_WINDOWS.cmd`, ou `docker compose up --build --detach` dans le dossier du programme. Ne pas supprimer les volumes.
5. Créer une nouvelle analyse : les rapports déjà générés ne sont pas recalculés automatiquement.

Le formulaire accepte maintenant `.pub` et `.txt` pour un PUB renommé. Le contenu doit rester un package Exstream binaire reconnu ; il n'est pas converti depuis du texte.

## Points à vérifier dans la recette WEBLURE

| Observation | Résultat attendu |
| --- | --- |
| Data sections du sous-arbre WEBLURE | 8 déclarations présentées, dont 3 sans rattachement explicite décodé |
| Rattachements explicites | 10 sections + 1 document |
| Tableau principal | 10 lignes et 19 colonnes |
| Règles de colonnes | 16 cibles, colonnes physiques 3 à 18 |
| Règles de lignes | 8 cibles, lignes 3 à 10 |
| Repeat explicite du grand tableau | Ligne 8, driver `WRK_AFR_EPI_WEBLURE_RENTE_LineValue1` |
| Catalogue du package | 274 IDs distincts, 327 occurrences compilées |

Les codes de types de lignes sont conservés bruts. Le moteur ne certifie pas encore les rattachements de data sections aux lignes, Header/Footer, les héritages ni la pagination native. Pour signaler un écart, fournir le nom du composant, la ligne/colonne, le résultat attendu et idéalement la propriété visible dans Exstream.

## Validation réalisée

210 cas distincts réussis (suite générale puis reprise ciblée), 50 cas de corpus sautés faute des autres fichiers client. Compilation frontend réussie et comparaison sur cinq PUB historiques. Voir `docs/VALIDATION_DATA_SECTIONS_0.14.0.md` et `ETAT_VALIDATION_MOTEUR.md` pour le détail et les limites. La recette de l'installation Windows/Docker reste à effectuer chez l'utilisateur.
