# Mise à jour Core Report 0.13.4

Remplacer les fichiers du programme par le ZIP en conservant le `.env` et les volumes existants. Reconstruire les services selon le README puis relancer les analyses. Les PDF existants ne sont pas régénérés automatiquement.

Corrections : puces bornées Wingdings, retrait et interligne, dimensions minimales des tableaux/zones de texte, texte long à largeur source et objets ancrés. Voir `docs/VALIDATION_INTRO_0.13.4.md`. Aucune migration de données. Le problème distinct d'en-tête FDC n'est pas modifié.
