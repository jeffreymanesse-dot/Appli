# Mise à jour de l’application 0.8.0

Cette version ajoute la structure de l’application en introduction de chaque rapport. En analyse, trois cases permettent de choisir indépendamment les chapitres Valorisation et origine des variables, Annuaire des données du flux et Inventaire et limites de reconstruction. Elles sont toutes cochées par défaut ; on peut aussi toutes les décocher. Le plan et les numéros de chapitres s’adaptent. L’interface propose uniquement les PDF.

## Installation existante avec Docker Desktop

1. Attendre la fin des analyses et conserver une copie de votre installation.
2. Décompresser le ZIP 0.8.0 dans un dossier temporaire. Copier le contenu du dossier `exstream-alterna` fourni dans votre dossier d’installation existant, en remplaçant les fichiers du programme. Cette mise à jour concerne **le backend et le frontend** : remplacer uniquement `backend/retro` ne suffit pas.
3. Conserver votre `.env` actuel, le nom du dossier d’installation et les volumes Docker. L’archive contient `.env.example` ; elle ne remplace pas vos secrets ni le mot de passe de votre base existante. Aucune migration de base n’est nécessaire.
4. Depuis votre dossier d’installation existant, exécuter :

```powershell
docker compose up -d --build api worker purge web
```

5. Ouvrir `http://localhost:3000` et actualiser la page. En mode « Analyser un fichier », les trois cases apparaissent sous la zone de dépôt. Lancer une nouvelle analyse ; son PDF indique le moteur `0.8.0` en pied de page.

Les PDF déjà produits ne sont pas réécrits. Relancer les anciennes analyses pour bénéficier de la structure et des choix de chapitres. Le mode comparaison conserve les deux analyses complètes et le PDF de comparaison.

Ne pas supprimer les volumes pour cette mise à jour. Si PostgreSQL utilise un volume déjà initialisé, conserver les identifiants qui correspondent à ce volume.

## Installation neuve

Décompresser le ZIP puis lancer `DEMARRER_WINDOWS.cmd`. Le lanceur crée automatiquement le fichier `.env` à partir de `.env.example` avec des secrets locaux. Il n’utilise pas de script PowerShell. Voir `LIRE_EN_PREMIER.md` pour les prérequis et le lancement Linux/WSL.

## Vérifications réalisées

107 tests passent, sans saut, ainsi que les 76 contrôles de calibration historique. La compilation Next/TypeScript et le parcours navigateur bureau/mobile ont été exécutés. Trois rapports finaux sont contrôlés : NOA avec tous les chapitres, Versement sans chapitre complémentaire, Obsèques avec valorisation et annuaire. Une analyse Versement avec annuaire seul est également téléchargée depuis le navigateur.

Docker Desktop, Windows, PostgreSQL et RQ/Redis ne sont pas exécutés dans cet environnement de validation. Le parcours réel est testé avec le frontend compilé, FastAPI, SQLite et un worker local séparé.

Le moteur conserve ses limites de décodage : notamment l’affectation de certaines sections aux pages, des propriétés non interprétées et l’ordre global des événements. La nouvelle structure n’invente pas ces liens. Détails : `docs/VALIDATION_MOTEUR_0.8.0.md` et `ETAT_VALIDATION_MOTEUR.md`.
