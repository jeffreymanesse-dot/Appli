# Core Report — tableaux et typographie 0.13.0

Le tableau FIP « formulesContratEtChoix » est inséré après le texte qui se termine par « charges et revenus déclarés », avant « Vous avez choisi… ». L'introduction et le petit tableau restent ensemble sur une page. Le même décodage replace le tableau « notreEntretien » dans son texte propriétaire, en conservant l'en-tête, Inhumation, Crémation et la note fusionnée.

Les deux PDF utilisent désormais les mêmes styles sources : fonds, bordures reconnues des quatre côtés, traits de lignes et de colonnes, tailles et couleurs de police, gras, italique, alignements gauche/droite/centré/justifié et retours à la ligne reconnus. Les cellules vides sont conservées pour restituer leurs bordures, notamment celles de « Code ISIN » dans le Bulletin de Versement. Dans le rapport, les repères de règles restent visibles sans remplacer la couleur du texte par du rouge.

## Installation

1. Arrêter les services et sauvegarder l'installation.
2. Décompresser `GroupeAlterna_CoreReport_Code_v0.13.0.zip` dans un dossier distinct.
3. Remplacer le programme par le dossier `exstream-alterna`, en conservant votre `.env` configuré et les volumes de données.
4. Reconstruire puis relancer :

```bash
docker compose up -d --build
```

5. Relancer l'analyse des PUB concernés. Les PDF d'anciennes tâches ne sont pas modifiés automatiquement.

Pour une nouvelle installation, suivre `LIRE_EN_PREMIER.md`. Le `.env` livré est le modèle initial identique à `.env.example`. Aucune migration de base ni dépendance Python supplémentaire n'est nécessaire. Des polices DejaVu Sans de substitution sont incluses avec leur licence ; elles préservent les variantes gras/italique lorsque la police source n'est pas disponible.

## Validation et limites

**203 tests réussis**, zéro échec, erreur ou saut. Les 12 chemins PUB disponibles représentent 11 contenus distincts. Les 22 PDF générés totalisent 1914 pages, sans page vide ni texte hors page détecté. Les faits sources et chaque contenu visuel antérieur sont comparés à 0.12.1. Le détail, les empreintes et les contrôles sont dans l'archive de validation et `docs/VALIDATION_PRESENTATION_0.13.0.md`.

Le soulignement n'est pas encore calibré. Le rayon exact des arrondis, les conflits entre bordures partagées, un éventuel contour global indépendant du tableau, les traits non continus, les retraits, les puces, les tabulations et la pagination native restent partiels. La hauteur des appels en exposant est indicative. Les variables restent affichées par leur nom et les conditions ne sont pas exécutées.

Pour calibrer le soulignement : fournir deux PUB identiques, avec un seul mot souligné dans le second, en indiquant le paragraphe et le mot, idéalement accompagnés d'une capture de ses propriétés. Les familles de police absentes peuvent être fournies sous forme TTF/OTF si leur licence en permet l'usage.

Cette livraison n'est pas déployée. Aucune nouvelle recette navigateur, Docker, Windows ou PostgreSQL/RQ n'est revendiquée.
