# Correctif 0.9.1 — « Espace réservé insuffisant ; attendez la purge »

Ce correctif s’applique à l’application 0.9.0 déjà installée. Il corrige le calcul du quota sans modifier l’apparence de l’interface ni le contenu des deux PDF produits.

## Pourquoi le blocage apparaît

La version 0.9.0 réserve 320 Mio pour chaque tâche et conserve cette réservation jusqu’à expiration, même si les fichiers réellement conservés sont petits. Avec le quota par défaut de 2 Gio, six réservations de ce type suffisent à bloquer la suivante. Ce message ne démontre donc pas que le disque Windows est plein.

En 0.9.1, une tâche en cours conserve un budget pour ses sorties. Une fois terminée, seuls les octets effectivement conservés sont comptés, y compris les fichiers internes. Les réservations des anciens succès sont recalculées automatiquement. La commande de reprise ci-dessous recalcule aussi celles des anciens échecs et annulations, avec les services producteurs arrêtés. Elle ne supprime aucun fichier.

## Installation dans PowerShell

1. Attends la fin des analyses en cours. Télécharge et décompresse `GroupeAlterna_Correctif_Quota_v0.9.1.zip` dans un dossier temporaire.
2. Copie le **contenu** du dossier `exstream-alterna` de l’archive dans ton dossier `exstream-alterna` existant, en fusionnant les dossiers et en remplaçant les fichiers correspondants. Ne déplace pas ton installation et ne crée pas un deuxième dossier `exstream-alterna` à l’intérieur du premier. L’archive contient uniquement le correctif, pas une application autonome.
3. Garde ton `.env` actuel : aucun `.env` n’est fourni ni remplacé par ce correctif. Tes mots de passe PostgreSQL et tes volumes restent les mêmes.
4. Dans PowerShell, depuis le dossier existant contenant `docker-compose.yml` et `.env`, exécute les commandes suivantes **une par une**. Si une commande échoue, arrête-toi et transmets son erreur avant de poursuivre.

```powershell
docker compose stop api worker purge
docker compose build api worker purge
docker compose run --rm --no-deps api python -m retro.storage --reconcile-stopped
docker compose up -d api worker purge web
docker compose ps
```

PostgreSQL et Redis doivent rester démarrés pendant ces opérations. La commande de recalcul doit terminer sans erreur ; elle affiche le nombre de tâches examinées et les octets comptés avant/après. Si elle signale des fichiers illisibles, leurs anciennes réservations sont conservées.

Actualise l’interface puis lance une nouvelle analyse. Pour contrôler la version du backend :

```powershell
docker compose exec api python -c "from retro import __version__; print(__version__)"
```

Résultat attendu : `0.9.1`. Ne lance pas `docker compose down -v` : cette commande supprimerait les volumes de l’installation. La politique habituelle d’expiration des résultats reste active après le redémarrage.

## Si le quota est réellement atteint

La limite reste à 2 Gio par défaut. Elle comprend les fichiers conservés et les budgets nécessaires aux tâches en attente ou en cours. Les réservations des tâches encore actives ne sont pas diminuées par la commande de reprise.

Le paramètre `DISK_QUOTA_BYTES` de `.env` est désormais transmis à l’API, au worker et au service de purge. Si les résultats occupent réellement le quota, attends leur expiration ou augmente cette valeur selon l’espace effectivement disponible dans Docker Desktop, puis relance `docker compose up -d api worker purge`. Il n’est pas nécessaire d’augmenter le quota pour corriger les anciennes réservations excessives.

Les échecs provoqués par un arrêt externe brutal peuvent conserver une réserve prudente jusqu’à expiration ou jusqu’à une nouvelle reprise avec les producteurs arrêtés. Cela évite de réallouer de l’espace alors qu’un processus pourrait encore écrire.

## Validation effectuée

- Erreur reproduite avant correction : la septième analyse était refusée avec six anciennes réservations de 320 Mio.
- Après correction : admission acceptée, fichiers précédents inchangés, quota réel toujours respecté.
- 132 tests réussis, aucun sauté, dont 13 cas de quota et les régressions sur les six PUB disponibles.
- Commande de reprise testée sur une base isolée : succès, échecs et annulations recalculés ; réservations actives et fichiers préservés.
- Transmission des paramètres aux trois services vérifiée dans la configuration Compose.
- Interface, analyseur, générateurs PDF et schéma de base inchangés par comparaison des fichiers.

Docker/Windows/PostgreSQL/RQ n’ont pas été exécutés dans l’environnement de validation disponible. Les transactions et la reprise ont été testées avec SQLite ; la configuration Docker a été contrôlée statiquement. Aucun nouveau niveau de fidélité du rendu Exstream n’est revendiqué par ce correctif de stockage.

Références Docker pour l’exploitation : [conteneur ponctuel Compose](https://docs.docker.com/reference/cli/docker/compose/run/) et [transmission des variables d’environnement](https://docs.docker.com/compose/how-tos/environment-variables/set-environment-variables/).
