# Core Report 0.13.1 — portées des bordures

Les bordures du tableau, des lignes, des colonnes et des cellules sont désormais conservées et dessinées séparément dans le rapport et le visuel.

| Propriété | Étendue |
|---|---|
| Table Properties | Cadre extérieur du tableau complet |
| Row Properties | Trait supérieur ou inférieur sur toute la largeur du tableau |
| Column Properties | Trait gauche ou droit sur toute la hauteur du tableau |
| Cell Properties | Uniquement les côtés activés de la cellule concernée |

Le cadre du tableau ne crée pas une grille interne. Un trait de colonne traverse aussi une cellule fusionnée ; une cellule sans bordure propre n'efface pas un trait de ligne ou de colonne. Les cellules vides restent prises en compte. Le rapport distingue les propriétés des quatre portées ; la couleur enregistrée ne signifie pas qu'un trait est activé.

Les captures fournies correspondent aux cadres de CONSEILLER, CONTRAT et VOTRE_SITUATION : bleu RGB(0,0,143), trait continu, épaisseur affichée 0,02 cm. La valeur binaire vaut 2/300 de pouce, soit 0,016933 cm ou 0,48 pt. Le même profil est présent dans les sept tableaux du courrier Versement. VOTRE_SITUATION : colonnes de 9,4827 cm et 8,9154 cm (affichage 9,48 et 8,92), trait droit de la première colonne, aucun trait propre sur la seconde.

**Point à confirmer : TITRE.** Le PUB disponible (SHA-256 `f23ca63a540159156cc72f63277b238bf656751f1035791fae294b65b21f0877`) ne contient aucun axe de ligne, de colonne ni conteneur de tableau dans `PAR_AFR_EPI_NOE_BULLETIN_VERSEMENT_TITRE` (21:43432). Il contient un objet texte. La capture Row Properties (hauteur 1,10 cm, trait inférieur 0,02 cm) ne peut donc pas être rattachée à ce paragraphe dans cette version. Fournir le PUB compilé correspondant à cette capture pour valider ce cas ; aucun trait n'a été ajouté par libellé ou codé en dur.

## Installation

Décompresser `GroupeAlterna_CoreReport_Code_v0.13.1.zip`. Remplacer le programme en conservant votre `.env` configuré et les volumes de données, puis reconstruire les services et lancer une nouvelle analyse :

```bash
docker compose up -d --build
```

Les anciennes sorties ne sont pas modifiées automatiquement. Le `.env` livré est le modèle initial, identique à `.env.example`. Aucune nouvelle dépendance applicative ni migration de base. Aucun déploiement ou test Docker/Windows/navigateur n'est revendiqué pour cette livraison.

## Validation

219 tests réussis, zéro échec, erreur ou saut, en 143.30 secondes. Les 12 chemins PUB (11 contenus SHA-256 distincts) sont comparés à 0.13.0. Textes, variables, règles, faits sources, topologie principale et contenus visuels antérieurs conservés. Les 22 PDF totalisent 1982 pages, sans page vide ni texte hors page détecté. Les cinq pages du visuel Versement et les pages PDF 5, 11 et 12 de son rapport ont été inspectées ; les autres pages ont subi les contrôles automatiques.

La restitution est bornée aux profils reconnus. Les types de traits non continus et la priorité native entre traits superposés restent à calibrer : le PDF dessine les propriétés globales puis les propriétés locales, sans présenter cet ordre comme une règle d'héritage Exstream. En cas de passage sur plusieurs pages, aucun cadre horizontal supplémentaire n'est inventé à la coupure. Le soulignement, le rayon exact des arrondis, la pagination native et les ressources externes restent partiels.
