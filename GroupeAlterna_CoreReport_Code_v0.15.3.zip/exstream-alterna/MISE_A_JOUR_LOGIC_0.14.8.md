# Groupe Alterna — Core Report 0.14.8

Cette version reprend intégralement la base 0.14.7 et simplifie le chapitre « Variables et fonctions ».

## Présentation

- Les listes générées « Lectures » et « Écritures » sont supprimées.
- Une fonction ou sous-routine avec arguments affiche leurs noms et types dans l’ordre déclaré. Les arguments facultatifs sont identifiés ; un argument tableau est noté `Type[]`.
- Une `Function` affiche son type de retour. Une `Subroutine` n’en affiche pas.
- Sans argument, aucune ligne « Arguments en entrée » n’est ajoutée.
- Le script apparaît sous **Logic** pour les fonctions et sous-routines, sous **Formula** pour les variables calculées.
- Le chapitre est limité à ces informations et aux scripts. Les longues fiches de dépendances et de provenance sont retirées de cette vue ; les données d’analyse restent disponibles dans le moteur.

Les signatures proviennent des propriétés de conception enregistrées dans le PUB. Elles ne sont pas déduites des variables lues, des affectations ou des commentaires. Aucun type n’est inventé lorsque la déclaration ne correspond pas au profil reconnu.

Les commentaires, l’indentation et les lignes vides du code sont conservés. Le code compilé reste absent du rapport. La pièce jointe contenant les sources originales est inchangée.

## Installation

1. Conserver `.env` et les volumes Docker de l’installation.
2. Remplacer les fichiers du programme par le dossier `exstream-alterna` de cette archive.
3. Reconstruire avec `docker compose up -d --build`, ou utiliser le lanceur Windows habituel.
4. Lancer une nouvelle analyse du PUB ; les anciens rapports ne sont pas recalculés automatiquement.

Aucune nouvelle dépendance ni migration n’est requise par rapport à 0.14.7. Cette livraison ne constitue pas un déploiement sur votre poste.

Les résultats et limites sont détaillés dans `docs/VALIDATION_LOGIC_0.14.8.md`.
