# Mise à jour Core Report 0.14.4

Le moteur passe en 0.14.4. Décompresser l’archive du code en conservant le `.env` et les volumes existants, puis reconstruire les services avec `docker compose up -d --build`. Ne pas supprimer les volumes pour cette mise à jour.

Les anciens rapports enregistrés ne sont pas recalculés automatiquement. Relancer les analyses des packages pour produire les résultats avec la nouvelle extraction des Data Files, des types de lignes, des règles PAGE et des pages de débordement.

Le lot des 15 analyses régénérées accompagne cette archive. Les rapports détaillent l’ordre, les contenus, les tables, les règles, les fichiers de données et les limites reconnues. La validation du corpus et les limites restantes figurent dans `docs/VALIDATION_CONTENUS_0.14.4.md`.
