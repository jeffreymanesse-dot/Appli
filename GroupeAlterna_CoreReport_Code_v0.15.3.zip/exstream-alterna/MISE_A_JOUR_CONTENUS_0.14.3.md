# Mise à jour Core Report 0.14.3

Conserver le fichier `.env` existant et les volumes. Remplacer les fichiers du programme par le contenu de l'archive, puis reconstruire les services avec `docker compose up -d --build`. Ne pas supprimer les volumes pour cette mise à jour.

Relancer une nouvelle analyse des PUB : les anciens rapports enregistrés ne sont pas recalculés automatiquement. L'interface et les scripts Windows restent inchangés. La nouvelle version réunit les extractions du rapport et du visuel, identifie les variables au lieu de leurs samples lorsque les preuves concordent et distingue les règles homonymes par leur ID compilé.

Vérifier le titre de simulation, les titres d'annexes et de demande, les deux occurrences du tableau et l'ordre des DOCUMENT. Les numéros Rn sont éditoriaux ; utiliser l'identifiant compilé pour rapprocher deux versions. Le bilan `docs/VALIDATION_CONTENUS_0.14.3.md` détaille le corpus et les limites restantes.
